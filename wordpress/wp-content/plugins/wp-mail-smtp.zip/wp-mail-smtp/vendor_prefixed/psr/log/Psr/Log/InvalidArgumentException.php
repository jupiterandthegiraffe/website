<?php

namespace WPMailSMTP\Vendor\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
