<?php

namespace WPForms\Vendor\CoreInterfaces\Core\Authentication;

interface AuthGroup
{
    public const AND = "And";
    public const OR = "Or";
}
