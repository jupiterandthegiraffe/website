<?php

namespace WPForms\Vendor\CoreInterfaces\Sdk;

interface ExceptionInterface extends \Throwable
{
}
