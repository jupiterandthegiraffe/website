<?php

namespace WPForms\Vendor;

class Contact
{
    public $name;
    /**
     * @var Address
     */
    public $address;
}
