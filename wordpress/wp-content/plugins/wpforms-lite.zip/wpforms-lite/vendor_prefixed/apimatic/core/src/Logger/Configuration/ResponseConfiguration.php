<?php

declare (strict_types=1);
namespace WPForms\Vendor\Core\Logger\Configuration;

class ResponseConfiguration extends BaseHttpLoggingConfiguration
{
}
