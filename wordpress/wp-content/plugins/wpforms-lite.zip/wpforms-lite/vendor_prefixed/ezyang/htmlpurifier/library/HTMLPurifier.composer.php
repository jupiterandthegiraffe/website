<?php

namespace WPForms\Vendor;

if (!\defined('WPForms\\Vendor\\HTMLPURIFIER_PREFIX')) {
    \define('WPForms\\Vendor\\HTMLPURIFIER_PREFIX', \dirname(__FILE__));
}
