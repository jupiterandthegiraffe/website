$(function(){$("body").one("pinegrow-ready",function(t,r){class o extends PgTutorial{constructor(){super(),this.name="Start Projects",this.description=``,this.prefix="new_",this.registerThisTutorial=!0,this.showOnStartScreen=!1,this.startProjects=!0,this.allowRandomAccess=!0}}var e,a,i,n,s=`<p style="font-size: 24px; margin: 10px 40px 20px; max-width: 640px;">Below is a sample block. Delete it and create your own, or use it as the starting point for your block.</p>
`,d=new o;(i=new PgTutorialLesson("new_html",null)).name="Blank HTML Project",a=`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>New page</title>
    <link href="css/normalize.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>

<body></body>
</html>`,i.addPage("index.html",`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>New page</title>
    <link href="css/normalize.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>

<body></body>
</html>`),i.addHiddenFile("_new.html",a),i.addStylesheet("css/normalize.css",pgSVGIcons.css_normalize),i.addStylesheet("css/style.css",""),d.addLesson(i),(a=new PgTutorialLesson("new_html_blocks",null)).name="HTML Blocks",i=`<!DOCTYPE html>
<html lang="en" wp-template>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>New page</title>
    <link href="css/normalize.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>

<body></body>
</html>`,a.addPage("index.html",`<!DOCTYPE html>
<html lang="en" wp-template>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>New page</title>
    <link href="css/normalize.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="about-me.css" rel="stylesheet">
</head>
<body>
${s}
<section cms-block="about-me" cms-block-title="About me" class="cool-blocks-about-me" cms-block-style="about-me.css" cms-block-icon="<svg xmlns=&quot;http://www.w3.org/2000/svg&quot; width=&quot;16&quot; height=&quot;16&quot; fill=&quot;currentColor&quot; class=&quot;bi bi-person-lines-fill&quot; viewBox=&quot;0 0 16 16&quot;>   <path d=&quot;M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm-5 6s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zM11 3.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5zm.5 2.5a.5.5 0 0 0 0 1h4a.5.5 0 0 0 0-1h-4zm2 3a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1h-2zm0 3a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1h-2z&quot;/> </svg>" cms-block-category="custom" cms-block-category-custom="cool_blocks" cms-block-category-custom-register="true" cms-block-category-custom-register-name="Cool Blocks">
            <div>
                <img src="https://pinegrow.com/placeholders/img16.jpg" cms-block-field="image" cms-block-field-type="image" cms-block-field-title="image"/>
            </div>
            <div>
                <h3 cms-block-field="name" cms-block-field-type="content" cms-block-field-title="Name">Mr. Pine Cone</h3>
                <p cms-block-field="bio" cms-block-field-type="content" cms-block-field-title="Bio">Something about me...</p><a href="" cms-block-field="more_link" cms-block-field-type="link" cms-block-field-title="Learn more link">Learn more about me</a>
            </div>
        </section>
</body>
</html>`),a.addHiddenFile("_new.html",i),a.addStylesheet("css/normalize.css",pgSVGIcons.css_normalize),a.addStylesheet("css/style.css",""),a.addStylesheet("about-me.css",`.cool-blocks-about-me {
    display: grid;
    grid-template-columns: 2fr;
    grid-template-rows: auto;
    gap: 20px;
    padding-top: 20px;
    padding-bottom: 20px;
}

@media (min-width: 769px) {
    .cool-blocks-about-me {
        display: grid;
        grid-template-columns: 1fr 1fr;
        grid-template-rows: auto;
    }
}

.cool-blocks-about-me img {
    max-width: 100%;
    min-height: 340px;
    object-fit: cover;
}
`),d.addLesson(a),(i=new PgTutorialLesson("new_bs")).name="Blank Bootstrap Project",a=`<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Blank Template for Bootstrap</title>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
  </head>

  <body>
    <script src="assets/js/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>
`,i.addPage("index.html",a),i.addHiddenFile("_new.html",a),i.addStylesheet("css/style.css",""),i.addResource("assets/js/popper.min.js","frameworks/bootstrap5/template/assets/js/popper.min.js"),i.addResource("bootstrap/js/bootstrap.min.js","frameworks/bootstrap5/template/bootstrap/js/bootstrap.min.js"),i.addResource("bootstrap/css/bootstrap.min.css","frameworks/bootstrap5/template/bootstrap/css/bootstrap.min.css"),d.addLesson(i),(a=new PgTutorialLesson("new_bs_blocks")).name="Bootstrap Blocks Project",i=`<!DOCTYPE html>
<html lang="en" wp-template>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Blank Template for Bootstrap</title>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
  </head>

  <body>
    <script src="assets/js/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>
`,a.addPage("index.html",`<!DOCTYPE html>
<html lang="en" wp-template>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Blank Template for Bootstrap</title>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
  </head>

  <body class="pt-5">
  ${s}
<section cms-block="about-me" cms-block-title="About me" class="cool-blocks-about-me" cms-block-icon="<svg xmlns=&quot;http://www.w3.org/2000/svg&quot; width=&quot;16&quot; height=&quot;16&quot; fill=&quot;currentColor&quot; class=&quot;bi bi-person-lines-fill&quot; viewBox=&quot;0 0 16 16&quot;>   <path d=&quot;M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm-5 6s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zM11 3.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5zm.5 2.5a.5.5 0 0 0 0 1h4a.5.5 0 0 0 0-1h-4zm2 3a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1h-2zm0 3a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1h-2z&quot;/> </svg>" cms-block-category="custom" cms-block-category-custom="cool_blocks" cms-block-category-custom-register="true" cms-block-category-custom-register-name="Cool Blocks">
    <div>
        <div class="row">
            <div class="col-md-6">
                <img src="https://pinegrow.com/placeholders/img16.jpg" cms-block-field="image" cms-block-field-type="image" cms-block-field-title="image" class="img-fluid"/>                  
            </div>
            <div class="col-md-6">
                <h3 cms-block-field="name" cms-block-field-type="content" cms-block-field-title="Name">Mr. Pine Cone</h3>
                <p cms-block-field="bio" cms-block-field-type="content" cms-block-field-title="Bio">Something about me...</p>
                <a href="" cms-block-field="more_link" cms-block-field-type="link" cms-block-field-title="Learn more link" class="btn btn-primary">Learn more about me</a>                  
            </div>
        </div>
    </div>
</section>
        
    <script src="assets/js/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>
`),a.addHiddenFile("_new.html",i),a.addStylesheet("css/style.css",""),a.addResource("assets/js/popper.min.js","frameworks/bootstrap5/template/assets/js/popper.min.js"),a.addResource("bootstrap/js/bootstrap.min.js","frameworks/bootstrap5/template/bootstrap/js/bootstrap.min.js"),a.addResource("bootstrap/css/bootstrap.min.css","frameworks/bootstrap5/template/bootstrap/css/bootstrap.min.css"),d.addLesson(a),(i=new PgTutorialLesson("new_tw")).name="Blank Tailwind Project",a=`<!DOCTYPE html> 
<html lang="en"> 
    <head> 
        <meta charset="utf-8"/> 
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/> 
        <title>New page</title>                  
        <link href="tailwind_theme/tailwind.css" rel="stylesheet" type="text/css"/>
    </head>     
    <body> 
</body>     
</html>`,i.addPage("index.html",a),i.addHiddenFile("_new.html",a),i.addStylesheet("tailwind_theme/tailwind.css",`/*
        ! tailwindcss v3.0.12 | MIT License | https://tailwindcss.com
        *//*
        1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)
        2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)
        */

        *,
        ::before,
        ::after {
          box-sizing: border-box; /* 1 */
          border-width: 0; /* 2 */
          border-style: solid; /* 2 */
          border-color: #e5e7eb; /* 2 */
        }

        ::before,
        ::after {
          --tw-content: '';
        }

        /*
        1. Use a consistent sensible line-height in all browsers.
        2. Prevent adjustments of font size after orientation changes in iOS.
        3. Use a more readable tab size.
        4. Use the user's configured sans font-family by default.
        */

        html {
          line-height: 1.5; /* 1 */
          -webkit-text-size-adjust: 100%; /* 2 */
          -moz-tab-size: 4; /* 3 */
          -o-tab-size: 4;
             tab-size: 4; /* 3 */
          font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; /* 4 */
        }

        /*
        1. Remove the margin in all browsers.
        2. Inherit line-height from html so users can set them as a class directly on the html element.
        */

        body {
          margin: 0; /* 1 */
          line-height: inherit; /* 2 */
        }

        /*
        1. Add the correct height in Firefox.
        2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
        3. Ensure horizontal rules are visible by default.
        */

        hr {
          height: 0; /* 1 */
          color: inherit; /* 2 */
          border-top-width: 1px; /* 3 */
        }

        /*
        Add the correct text decoration in Chrome, Edge, and Safari.
        */

        abbr:where([title]) {
          -webkit-text-decoration: underline dotted;
                  text-decoration: underline dotted;
        }

        /*
        Remove the default font size and weight for headings.
        */

        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
          font-size: inherit;
          font-weight: inherit;
        }

        /*
        Reset links to optimize for opt-in styling instead of opt-out.
        */

        a {
          color: inherit;
          text-decoration: inherit;
        }

        /*
        Add the correct font weight in Edge and Safari.
        */

        b,
        strong {
          font-weight: bolder;
        }

        /*
        1. Use the user's configured mono font family by default.
        2. Correct the odd em font sizing in all browsers.
        */

        code,
        kbd,
        samp,
        pre {
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; /* 1 */
          font-size: 1em; /* 2 */
        }

        /*
        Add the correct font size in all browsers.
        */

        small {
          font-size: 80%;
        }

        /*
        Prevent sub and sup elements from affecting the line height in all browsers.
        */

        sub,
        sup {
          font-size: 75%;
          line-height: 0;
          position: relative;
          vertical-align: baseline;
        }

        sub {
          bottom: -0.25em;
        }

        sup {
          top: -0.5em;
        }

        /*
        1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
        2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
        3. Remove gaps between table borders by default.
        */

        table {
          text-indent: 0; /* 1 */
          border-color: inherit; /* 2 */
          border-collapse: collapse; /* 3 */
        }

        /*
        1. Change the font styles in all browsers.
        2. Remove the margin in Firefox and Safari.
        3. Remove default padding in all browsers.
        */

        button,
        input,
        optgroup,
        select,
        textarea {
          font-family: inherit; /* 1 */
          font-size: 100%; /* 1 */
          line-height: inherit; /* 1 */
          color: inherit; /* 1 */
          margin: 0; /* 2 */
          padding: 0; /* 3 */
        }

        /*
        Remove the inheritance of text transform in Edge and Firefox.
        */

        button,
        select {
          text-transform: none;
        }

        /*
        1. Correct the inability to style clickable types in iOS and Safari.
        2. Remove default button styles.
        */

        button,
        [type='button'],
        [type='reset'],
        [type='submit'] {
          -webkit-appearance: button; /* 1 */
          background-color: transparent; /* 2 */
          background-image: none; /* 2 */
        }

        /*
        Use the modern Firefox focus style for all focusable elements.
        */

        :-moz-focusring {
          outline: auto;
        }

        /*
        Remove the additional :invalid styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)
        */

        :-moz-ui-invalid {
          box-shadow: none;
        }

        /*
        Add the correct vertical alignment in Chrome and Firefox.
        */

        progress {
          vertical-align: baseline;
        }

        /*
        Correct the cursor style of increment and decrement buttons in Safari.
        */

        ::-webkit-inner-spin-button,
        ::-webkit-outer-spin-button {
          height: auto;
        }

        /*
        1. Correct the odd appearance in Chrome and Safari.
        2. Correct the outline style in Safari.
        */

        [type='search'] {
          -webkit-appearance: textfield; /* 1 */
          outline-offset: -2px; /* 2 */
        }

        /*
        Remove the inner padding in Chrome and Safari on macOS.
        */

        ::-webkit-search-decoration {
          -webkit-appearance: none;
        }

        /*
        1. Correct the inability to style clickable types in iOS and Safari.
        2. Change font properties to inherit in Safari.
        */

        ::-webkit-file-upload-button {
          -webkit-appearance: button; /* 1 */
          font: inherit; /* 2 */
        }

        /*
        Add the correct display in Chrome and Safari.
        */

        summary {
          display: list-item;
        }

        /*
        Removes the default spacing and border for appropriate elements.
        */

        blockquote,
        dl,
        dd,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        hr,
        figure,
        p,
        pre {
          margin: 0;
        }

        fieldset {
          margin: 0;
          padding: 0;
        }

        legend {
          padding: 0;
        }

        ol,
        ul,
        menu {
          list-style: none;
          margin: 0;
          padding: 0;
        }

        /*
        Prevent resizing textareas horizontally by default.
        */

        textarea {
          resize: vertical;
        }

        /*
        1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)
        2. Set the default placeholder color to the user's configured gray 400 color.
        */

        input::-moz-placeholder, textarea::-moz-placeholder {
          opacity: 1; /* 1 */
          color: #9ca3af; /* 2 */
        }

        input:-ms-input-placeholder, textarea:-ms-input-placeholder {
          opacity: 1; /* 1 */
          color: #9ca3af; /* 2 */
        }

        input::placeholder,
        textarea::placeholder {
          opacity: 1; /* 1 */
          color: #9ca3af; /* 2 */
        }

        /*
        Set the default cursor for buttons.
        */

        button,
        [role="button"] {
          cursor: pointer;
        }

        /*
        Make sure disabled buttons don't get the pointer cursor.
        */
        :disabled {
          cursor: default;
        }

        /*
        1. Make replaced elements display: block by default. (https://github.com/mozdevs/cssremedy/issues/14)
        2. Add vertical-align: middle to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)
           This can trigger a poorly considered lint error in some tools but is included by design.
        */

        img,
        svg,
        video,
        canvas,
        audio,
        iframe,
        embed,
        object {
          display: block; /* 1 */
          vertical-align: middle; /* 2 */
        }

        /*
        Constrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)
        */

        img,
        video {
          max-width: 100%;
          height: auto;
        }

        /*
        Ensure the default browser behavior of the hidden attribute.
        */

        [hidden] {
          display: none;
        }

[type='text'],[type='email'],[type='url'],[type='password'],[type='number'],[type='date'],[type='datetime-local'],[type='month'],[type='search'],[type='tel'],[type='time'],[type='week'],[multiple],textarea,select {
          -webkit-appearance: none;
             -moz-appearance: none;
                  appearance: none;
          background-color: #fff;
          border-color: #6b7280;
          border-width: 1px;
          border-radius: 0px;
          padding-top: 0.5rem;
          padding-right: 0.75rem;
          padding-bottom: 0.5rem;
          padding-left: 0.75rem;
          font-size: 1rem;
          line-height: 1.5rem;
          --tw-shadow: 0 0 #0000;
}

[type='text']:focus, [type='email']:focus, [type='url']:focus, [type='password']:focus, [type='number']:focus, [type='date']:focus, [type='datetime-local']:focus, [type='month']:focus, [type='search']:focus, [type='tel']:focus, [type='time']:focus, [type='week']:focus, [multiple]:focus, textarea:focus, select:focus {
          outline: 2px solid transparent;
          outline-offset: 2px;
          --tw-ring-inset: var(--tw-empty,/*!*/ /*!*/);
          --tw-ring-offset-width: 0px;
          --tw-ring-offset-color: #fff;
          --tw-ring-color: #2563eb;
          --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
          --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
          box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
          border-color: #2563eb;
}

input::-moz-placeholder, textarea::-moz-placeholder {
          color: #6b7280;
          opacity: 1;
}

input:-ms-input-placeholder, textarea:-ms-input-placeholder {
          color: #6b7280;
          opacity: 1;
}

input::placeholder,textarea::placeholder {
          color: #6b7280;
          opacity: 1;
}

::-webkit-datetime-edit-fields-wrapper {
          padding: 0;
}

::-webkit-date-and-time-value {
          min-height: 1.5em;
}

select {
          background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e");
          background-position: right 0.5rem center;
          background-repeat: no-repeat;
          background-size: 1.5em 1.5em;
          padding-right: 2.5rem;
          -webkit-print-color-adjust: exact;
                  color-adjust: exact;
}

[multiple] {
          background-image: initial;
          background-position: initial;
          background-repeat: unset;
          background-size: initial;
          padding-right: 0.75rem;
          -webkit-print-color-adjust: unset;
                  color-adjust: unset;
}

[type='checkbox'],[type='radio'] {
          -webkit-appearance: none;
             -moz-appearance: none;
                  appearance: none;
          padding: 0;
          -webkit-print-color-adjust: exact;
                  color-adjust: exact;
          display: inline-block;
          vertical-align: middle;
          background-origin: border-box;
          -webkit-user-select: none;
             -moz-user-select: none;
              -ms-user-select: none;
                  user-select: none;
          flex-shrink: 0;
          height: 1rem;
          width: 1rem;
          color: #2563eb;
          background-color: #fff;
          border-color: #6b7280;
          border-width: 1px;
          --tw-shadow: 0 0 #0000;
}

[type='checkbox'] {
          border-radius: 0px;
}

[type='radio'] {
          border-radius: 100%;
}

[type='checkbox']:focus,[type='radio']:focus {
          outline: 2px solid transparent;
          outline-offset: 2px;
          --tw-ring-inset: var(--tw-empty,/*!*/ /*!*/);
          --tw-ring-offset-width: 2px;
          --tw-ring-offset-color: #fff;
          --tw-ring-color: #2563eb;
          --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
          --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
          box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
}

[type='checkbox']:checked,[type='radio']:checked {
          border-color: transparent;
          background-color: currentColor;
          background-size: 100% 100%;
          background-position: center;
          background-repeat: no-repeat;
}

[type='checkbox']:checked {
          background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.207 4.793a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-2-2a1 1 0 011.414-1.414L6.5 9.086l4.293-4.293a1 1 0 011.414 0z'/%3e%3c/svg%3e");
}

[type='radio']:checked {
          background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3ccircle cx='8' cy='8' r='3'/%3e%3c/svg%3e");
}

[type='checkbox']:checked:hover,[type='checkbox']:checked:focus,[type='radio']:checked:hover,[type='radio']:checked:focus {
          border-color: transparent;
          background-color: currentColor;
}

[type='checkbox']:indeterminate {
          background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 16 16'%3e%3cpath stroke='white' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M4 8h8'/%3e%3c/svg%3e");
          border-color: transparent;
          background-color: currentColor;
          background-size: 100% 100%;
          background-position: center;
          background-repeat: no-repeat;
}

[type='checkbox']:indeterminate:hover,[type='checkbox']:indeterminate:focus {
          border-color: transparent;
          background-color: currentColor;
}

[type='file'] {
          background: unset;
          border-color: inherit;
          border-width: 0;
          border-radius: 0;
          padding: 0;
          font-size: unset;
          line-height: inherit;
}

[type='file']:focus {
          outline: 1px auto -webkit-focus-ring-color;
}

*, ::before, ::after {
          --tw-translate-x: 0;
          --tw-translate-y: 0;
          --tw-rotate: 0;
          --tw-skew-x: 0;
          --tw-skew-y: 0;
          --tw-scale-x: 1;
          --tw-scale-y: 1;
          --tw-pan-x:  ;
          --tw-pan-y:  ;
          --tw-pinch-zoom:  ;
          --tw-scroll-snap-strictness: proximity;
          --tw-ordinal:  ;
          --tw-slashed-zero:  ;
          --tw-numeric-figure:  ;
          --tw-numeric-spacing:  ;
          --tw-numeric-fraction:  ;
          --tw-ring-inset:  ;
          --tw-ring-offset-width: 0px;
          --tw-ring-offset-color: #fff;
          --tw-ring-color: rgb(59 130 246 / 0.5);
          --tw-ring-offset-shadow: 0 0 #0000;
          --tw-ring-shadow: 0 0 #0000;
          --tw-shadow: 0 0 #0000;
          --tw-shadow-colored: 0 0 #0000;
          --tw-blur:  ;
          --tw-brightness:  ;
          --tw-contrast:  ;
          --tw-grayscale:  ;
          --tw-hue-rotate:  ;
          --tw-invert:  ;
          --tw-saturate:  ;
          --tw-sepia:  ;
          --tw-drop-shadow:  ;
          --tw-backdrop-blur:  ;
          --tw-backdrop-brightness:  ;
          --tw-backdrop-contrast:  ;
          --tw-backdrop-grayscale:  ;
          --tw-backdrop-hue-rotate:  ;
          --tw-backdrop-invert:  ;
          --tw-backdrop-opacity:  ;
          --tw-backdrop-saturate:  ;
          --tw-backdrop-sepia:  ;
}

body, html {
    min-height: 100vh;
}
`),i.addPage("pinegrow.json",`{"files":{"index.html":{"frameworks":["newtw2","pg.insight.events","pg.svg.lib","pg.css.grid","pg.image.overlay","pg.code-validator","pg.project.items","pg.asset.manager","pg.tw.lib","tw","pg.html","pg.components"],"last_page_width":1024}},"breakpoints":[],"frameworks":["newtw2","pg.insight.events","pg.svg.lib","pg.css.grid","pg.image.overlay","pg.code-validator","pg.project.items","pg.asset.manager","pg.tw.lib","tw","pg.html","pg.components"],"template_framework_id":"tailwind","urls":{"index.html":{"open-page-views":[{"w":1024,"h":0}]}},"active-design-provider":"tw"}`),i.addPage("projectdb.pgml",`<project>
    <documents></documents>
    <dmdesigns>
        <dmdesign active>
            <dmdesignskill skill="tw.colors">
                <dmcolor key="gray" color="rgba(107,114,128,1)" shade-50="rgba(249,250,251,1)" shade-100="rgba(243,244,246,1)" shade-200="rgba(229,231,235,1)" shade-300="rgba(209,213,219,1)" shade-400="rgba(156,163,175,1)" shade-500="rgba(107,114,128,1)" shade-600="rgba(75,85,99,1)" shade-700="rgba(55,65,81,1)" shade-800="rgba(31,41,55,1)" shade-900="rgba(17,24,39,1)"/>
                <dmcolor key="red" color="rgba(239,68,68,1)" shade-50="rgba(254,242,242,1)" shade-100="rgba(254,226,226,1)" shade-200="rgba(254,202,202,1)" shade-300="rgba(252,165,165,1)" shade-400="rgba(248,113,113,1)" shade-500="rgba(239,68,68,1)" shade-600="rgba(220,38,38,1)" shade-700="rgba(185,28,28,1)" shade-800="rgba(153,27,27,1)" shade-900="rgba(127,29,29,1)"/>
                <dmcolor key="yellow" color="rgba(245,158,11,1)" shade-50="rgba(255,251,235,1)" shade-100="rgba(254,243,199,1)" shade-200="rgba(253,230,138,1)" shade-300="rgba(252,211,77,1)" shade-400="rgba(251,191,36,1)" shade-500="rgba(245,158,11,1)" shade-600="rgba(217,119,6,1)" shade-700="rgba(180,83,9,1)" shade-800="rgba(146,64,14,1)" shade-900="rgba(120,53,15,1)"/>
                <dmcolor key="green" color="rgba(16,185,129,1)" shade-50="rgba(236,253,245,1)" shade-100="rgba(209,250,229,1)" shade-200="rgba(167,243,208,1)" shade-300="rgba(110,231,183,1)" shade-400="rgba(52,211,153,1)" shade-500="rgba(16,185,129,1)" shade-600="rgba(5,150,105,1)" shade-700="rgba(4,120,87,1)" shade-800="rgba(6,95,70,1)" shade-900="rgba(6,78,59,1)"/>
                <dmcolor key="blue" color="rgba(59,130,246,1)" shade-50="rgba(239,246,255,1)" shade-100="rgba(219,234,254,1)" shade-200="rgba(191,219,254,1)" shade-300="rgba(147,197,253,1)" shade-400="rgba(96,165,250,1)" shade-500="rgba(59,130,246,1)" shade-600="rgba(37,99,235,1)" shade-700="rgba(29,78,216,1)" shade-800="rgba(30,64,175,1)" shade-900="rgba(30,58,138,1)"/>
                <dmcolor key="indigo" color="rgba(99,102,241,1)" shade-50="rgba(238,242,255,1)" shade-100="rgba(224,231,255,1)" shade-200="rgba(199,210,254,1)" shade-300="rgba(165,180,252,1)" shade-400="rgba(129,140,248,1)" shade-500="rgba(99,102,241,1)" shade-600="rgba(79,70,229,1)" shade-700="rgba(67,56,202,1)" shade-800="rgba(55,48,163,1)" shade-900="rgba(49,46,129,1)"/>
                <dmcolor key="purple" color="rgba(139,92,246,1)" shade-50="rgba(245,243,255,1)" shade-100="rgba(237,233,254,1)" shade-200="rgba(221,214,254,1)" shade-300="rgba(196,181,253,1)" shade-400="rgba(167,139,250,1)" shade-500="rgba(139,92,246,1)" shade-600="rgba(124,58,237,1)" shade-700="rgba(109,40,217,1)" shade-800="rgba(91,33,182,1)" shade-900="rgba(76,29,149,1)"/>
                <dmcolor key="pink" color="rgba(236,72,153,1)" shade-50="rgba(253,242,248,1)" shade-100="rgba(252,231,243,1)" shade-200="rgba(251,207,232,1)" shade-300="rgba(249,168,212,1)" shade-400="rgba(244,114,182,1)" shade-500="rgba(236,72,153,1)" shade-600="rgba(219,39,119,1)" shade-700="rgba(190,24,93,1)" shade-800="rgba(157,23,77,1)" shade-900="rgba(131,24,67,1)"/>
            </dmdesignskill>
            <dmdesignskill skill="fonts"></dmdesignskill>
            <dmdesignskill skill="background" image_for_colors="true" advanced="true" filter_blur="0" filter_brightness="100" filter_contrast="100" filter_grayscale="0" filter_hue-rotate="0" filter_invert="0" filter_opacity="100" filter_saturate="100" filter_sepia="0"></dmdesignskill>
            <dmdesignskill skill="tailwind"></dmdesignskill>
        </dmdesign>
    </dmdesigns>
    <dmlocked tw-colors-gray="true" tw-colors-red="true" tw-colors-yellow="true" tw-colors-green="true" tw-colors-blue="true" tw-colors-indigo="true" tw-colors-purple="true" tw-colors-pink="true"></dmlocked>
</project>`),d.addLesson(i),(a=new PgTutorialLesson("new_tw_blocks")).name="Tailwind Blocks Project",i=`<!DOCTYPE html> 
<html lang="en" wp-template> 
    <head> 
        <meta charset="utf-8"/> 
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/> 
        <title>New page</title>                  
        <link href="tailwind_theme/tailwind.css" rel="stylesheet" type="text/css"/>
    </head>     
    <body> 
</body>     
</html>`,a.addPage("index.html",`<!DOCTYPE html> 
<html lang="en" wp-template> 
    <head> 
        <meta charset="utf-8"/> 
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/> 
        <title>New page</title>                  
        <link href="tailwind_theme/tailwind.css" rel="stylesheet" type="text/css"/>
    </head>     
    <body> 
    ${s}
    <section cms-block="about-me" cms-block-title="About me" class="cool-blocks-about-me grid grid-cols-2 grid-rows-1" cms-block-icon="<svg xmlns=&quot;http://www.w3.org/2000/svg&quot; width=&quot;16&quot; height=&quot;16&quot; fill=&quot;currentColor&quot; class=&quot;bi bi-person-lines-fill&quot; viewBox=&quot;0 0 16 16&quot;>   <path d=&quot;M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm-5 6s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zM11 3.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5zm.5 2.5a.5.5 0 0 0 0 1h4a.5.5 0 0 0 0-1h-4zm2 3a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1h-2zm0 3a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1h-2z&quot;/> </svg>" cms-block-category="custom" cms-block-category-custom="cool_blocks" cms-block-category-custom-register="true" cms-block-category-custom-register-name="Cool Blocks">
    <div>
        <img src="https://pinegrow.com/placeholders/img16.jpg" cms-block-field="image" cms-block-field-type="image" cms-block-field-title="image" /> 
    </div>
    <div class="p-4 prose">
        <h3 cms-block-field="name" cms-block-field-type="content" cms-block-field-title="Name">Mr. Pine Cone</h3>
        <p cms-block-field="bio" cms-block-field-type="content" cms-block-field-title="Bio">Something about me...</p>
        <a href="" cms-block-field="more_link" cms-block-field-type="link" cms-block-field-title="Learn more link">Learn more about me</a> 
    </div>
</section>
</body>     
</html>`),a.addHiddenFile("_new.html",i),a.addStylesheet("tailwind_theme/tailwind.css",`/*
        ! tailwindcss v3.0.12 | MIT License | https://tailwindcss.com
        *//*
        1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)
        2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)
        */

        *,
        ::before,
        ::after {
          box-sizing: border-box; /* 1 */
          border-width: 0; /* 2 */
          border-style: solid; /* 2 */
          border-color: #e5e7eb; /* 2 */
        }

        ::before,
        ::after {
          --tw-content: '';
        }

        /*
        1. Use a consistent sensible line-height in all browsers.
        2. Prevent adjustments of font size after orientation changes in iOS.
        3. Use a more readable tab size.
        4. Use the user's configured sans font-family by default.
        */

        html {
          line-height: 1.5; /* 1 */
          -webkit-text-size-adjust: 100%; /* 2 */
          -moz-tab-size: 4; /* 3 */
          -o-tab-size: 4;
             tab-size: 4; /* 3 */
          font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; /* 4 */
        }

        /*
        1. Remove the margin in all browsers.
        2. Inherit line-height from html so users can set them as a class directly on the html element.
        */

        body {
          margin: 0; /* 1 */
          line-height: inherit; /* 2 */
        }

        /*
        1. Add the correct height in Firefox.
        2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
        3. Ensure horizontal rules are visible by default.
        */

        hr {
          height: 0; /* 1 */
          color: inherit; /* 2 */
          border-top-width: 1px; /* 3 */
        }

        /*
        Add the correct text decoration in Chrome, Edge, and Safari.
        */

        abbr:where([title]) {
          -webkit-text-decoration: underline dotted;
                  text-decoration: underline dotted;
        }

        /*
        Remove the default font size and weight for headings.
        */

        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
          font-size: inherit;
          font-weight: inherit;
        }

        /*
        Reset links to optimize for opt-in styling instead of opt-out.
        */

        a {
          color: inherit;
          text-decoration: inherit;
        }

        /*
        Add the correct font weight in Edge and Safari.
        */

        b,
        strong {
          font-weight: bolder;
        }

        /*
        1. Use the user's configured mono font family by default.
        2. Correct the odd em font sizing in all browsers.
        */

        code,
        kbd,
        samp,
        pre {
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; /* 1 */
          font-size: 1em; /* 2 */
        }

        /*
        Add the correct font size in all browsers.
        */

        small {
          font-size: 80%;
        }

        /*
        Prevent sub and sup elements from affecting the line height in all browsers.
        */

        sub,
        sup {
          font-size: 75%;
          line-height: 0;
          position: relative;
          vertical-align: baseline;
        }

        sub {
          bottom: -0.25em;
        }

        sup {
          top: -0.5em;
        }

        /*
        1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
        2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
        3. Remove gaps between table borders by default.
        */

        table {
          text-indent: 0; /* 1 */
          border-color: inherit; /* 2 */
          border-collapse: collapse; /* 3 */
        }

        /*
        1. Change the font styles in all browsers.
        2. Remove the margin in Firefox and Safari.
        3. Remove default padding in all browsers.
        */

        button,
        input,
        optgroup,
        select,
        textarea {
          font-family: inherit; /* 1 */
          font-size: 100%; /* 1 */
          line-height: inherit; /* 1 */
          color: inherit; /* 1 */
          margin: 0; /* 2 */
          padding: 0; /* 3 */
        }

        /*
        Remove the inheritance of text transform in Edge and Firefox.
        */

        button,
        select {
          text-transform: none;
        }

        /*
        1. Correct the inability to style clickable types in iOS and Safari.
        2. Remove default button styles.
        */

        button,
        [type='button'],
        [type='reset'],
        [type='submit'] {
          -webkit-appearance: button; /* 1 */
          background-color: transparent; /* 2 */
          background-image: none; /* 2 */
        }

        /*
        Use the modern Firefox focus style for all focusable elements.
        */

        :-moz-focusring {
          outline: auto;
        }

        /*
        Remove the additional :invalid styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)
        */

        :-moz-ui-invalid {
          box-shadow: none;
        }

        /*
        Add the correct vertical alignment in Chrome and Firefox.
        */

        progress {
          vertical-align: baseline;
        }

        /*
        Correct the cursor style of increment and decrement buttons in Safari.
        */

        ::-webkit-inner-spin-button,
        ::-webkit-outer-spin-button {
          height: auto;
        }

        /*
        1. Correct the odd appearance in Chrome and Safari.
        2. Correct the outline style in Safari.
        */

        [type='search'] {
          -webkit-appearance: textfield; /* 1 */
          outline-offset: -2px; /* 2 */
        }

        /*
        Remove the inner padding in Chrome and Safari on macOS.
        */

        ::-webkit-search-decoration {
          -webkit-appearance: none;
        }

        /*
        1. Correct the inability to style clickable types in iOS and Safari.
        2. Change font properties to inherit in Safari.
        */

        ::-webkit-file-upload-button {
          -webkit-appearance: button; /* 1 */
          font: inherit; /* 2 */
        }

        /*
        Add the correct display in Chrome and Safari.
        */

        summary {
          display: list-item;
        }

        /*
        Removes the default spacing and border for appropriate elements.
        */

        blockquote,
        dl,
        dd,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        hr,
        figure,
        p,
        pre {
          margin: 0;
        }

        fieldset {
          margin: 0;
          padding: 0;
        }

        legend {
          padding: 0;
        }

        ol,
        ul,
        menu {
          list-style: none;
          margin: 0;
          padding: 0;
        }

        /*
        Prevent resizing textareas horizontally by default.
        */

        textarea {
          resize: vertical;
        }

        /*
        1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)
        2. Set the default placeholder color to the user's configured gray 400 color.
        */

        input::-moz-placeholder, textarea::-moz-placeholder {
          opacity: 1; /* 1 */
          color: #9ca3af; /* 2 */
        }

        input:-ms-input-placeholder, textarea:-ms-input-placeholder {
          opacity: 1; /* 1 */
          color: #9ca3af; /* 2 */
        }

        input::placeholder,
        textarea::placeholder {
          opacity: 1; /* 1 */
          color: #9ca3af; /* 2 */
        }

        /*
        Set the default cursor for buttons.
        */

        button,
        [role="button"] {
          cursor: pointer;
        }

        /*
        Make sure disabled buttons don't get the pointer cursor.
        */
        :disabled {
          cursor: default;
        }

        /*
        1. Make replaced elements display: block by default. (https://github.com/mozdevs/cssremedy/issues/14)
        2. Add vertical-align: middle to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)
           This can trigger a poorly considered lint error in some tools but is included by design.
        */

        img,
        svg,
        video,
        canvas,
        audio,
        iframe,
        embed,
        object {
          display: block; /* 1 */
          vertical-align: middle; /* 2 */
        }

        /*
        Constrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)
        */

        img,
        video {
          max-width: 100%;
          height: auto;
        }

        /*
        Ensure the default browser behavior of the hidden attribute.
        */

        [hidden] {
          display: none;
        }

[type='text'],[type='email'],[type='url'],[type='password'],[type='number'],[type='date'],[type='datetime-local'],[type='month'],[type='search'],[type='tel'],[type='time'],[type='week'],[multiple],textarea,select {
          -webkit-appearance: none;
             -moz-appearance: none;
                  appearance: none;
          background-color: #fff;
          border-color: #6b7280;
          border-width: 1px;
          border-radius: 0px;
          padding-top: 0.5rem;
          padding-right: 0.75rem;
          padding-bottom: 0.5rem;
          padding-left: 0.75rem;
          font-size: 1rem;
          line-height: 1.5rem;
          --tw-shadow: 0 0 #0000;
}

[type='text']:focus, [type='email']:focus, [type='url']:focus, [type='password']:focus, [type='number']:focus, [type='date']:focus, [type='datetime-local']:focus, [type='month']:focus, [type='search']:focus, [type='tel']:focus, [type='time']:focus, [type='week']:focus, [multiple]:focus, textarea:focus, select:focus {
          outline: 2px solid transparent;
          outline-offset: 2px;
          --tw-ring-inset: var(--tw-empty,/*!*/ /*!*/);
          --tw-ring-offset-width: 0px;
          --tw-ring-offset-color: #fff;
          --tw-ring-color: #2563eb;
          --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
          --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
          box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
          border-color: #2563eb;
}

input::-moz-placeholder, textarea::-moz-placeholder {
          color: #6b7280;
          opacity: 1;
}

input:-ms-input-placeholder, textarea:-ms-input-placeholder {
          color: #6b7280;
          opacity: 1;
}

input::placeholder,textarea::placeholder {
          color: #6b7280;
          opacity: 1;
}

::-webkit-datetime-edit-fields-wrapper {
          padding: 0;
}

::-webkit-date-and-time-value {
          min-height: 1.5em;
}

select {
          background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e");
          background-position: right 0.5rem center;
          background-repeat: no-repeat;
          background-size: 1.5em 1.5em;
          padding-right: 2.5rem;
          -webkit-print-color-adjust: exact;
                  color-adjust: exact;
}

[multiple] {
          background-image: initial;
          background-position: initial;
          background-repeat: unset;
          background-size: initial;
          padding-right: 0.75rem;
          -webkit-print-color-adjust: unset;
                  color-adjust: unset;
}

[type='checkbox'],[type='radio'] {
          -webkit-appearance: none;
             -moz-appearance: none;
                  appearance: none;
          padding: 0;
          -webkit-print-color-adjust: exact;
                  color-adjust: exact;
          display: inline-block;
          vertical-align: middle;
          background-origin: border-box;
          -webkit-user-select: none;
             -moz-user-select: none;
              -ms-user-select: none;
                  user-select: none;
          flex-shrink: 0;
          height: 1rem;
          width: 1rem;
          color: #2563eb;
          background-color: #fff;
          border-color: #6b7280;
          border-width: 1px;
          --tw-shadow: 0 0 #0000;
}

[type='checkbox'] {
          border-radius: 0px;
}

[type='radio'] {
          border-radius: 100%;
}

[type='checkbox']:focus,[type='radio']:focus {
          outline: 2px solid transparent;
          outline-offset: 2px;
          --tw-ring-inset: var(--tw-empty,/*!*/ /*!*/);
          --tw-ring-offset-width: 2px;
          --tw-ring-offset-color: #fff;
          --tw-ring-color: #2563eb;
          --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
          --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
          box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
}

[type='checkbox']:checked,[type='radio']:checked {
          border-color: transparent;
          background-color: currentColor;
          background-size: 100% 100%;
          background-position: center;
          background-repeat: no-repeat;
}

[type='checkbox']:checked {
          background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.207 4.793a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-2-2a1 1 0 011.414-1.414L6.5 9.086l4.293-4.293a1 1 0 011.414 0z'/%3e%3c/svg%3e");
}

[type='radio']:checked {
          background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3ccircle cx='8' cy='8' r='3'/%3e%3c/svg%3e");
}

[type='checkbox']:checked:hover,[type='checkbox']:checked:focus,[type='radio']:checked:hover,[type='radio']:checked:focus {
          border-color: transparent;
          background-color: currentColor;
}

[type='checkbox']:indeterminate {
          background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 16 16'%3e%3cpath stroke='white' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M4 8h8'/%3e%3c/svg%3e");
          border-color: transparent;
          background-color: currentColor;
          background-size: 100% 100%;
          background-position: center;
          background-repeat: no-repeat;
}

[type='checkbox']:indeterminate:hover,[type='checkbox']:indeterminate:focus {
          border-color: transparent;
          background-color: currentColor;
}

[type='file'] {
          background: unset;
          border-color: inherit;
          border-width: 0;
          border-radius: 0;
          padding: 0;
          font-size: unset;
          line-height: inherit;
}

[type='file']:focus {
          outline: 1px auto -webkit-focus-ring-color;
}

*, ::before, ::after {
          --tw-translate-x: 0;
          --tw-translate-y: 0;
          --tw-rotate: 0;
          --tw-skew-x: 0;
          --tw-skew-y: 0;
          --tw-scale-x: 1;
          --tw-scale-y: 1;
          --tw-pan-x:  ;
          --tw-pan-y:  ;
          --tw-pinch-zoom:  ;
          --tw-scroll-snap-strictness: proximity;
          --tw-ordinal:  ;
          --tw-slashed-zero:  ;
          --tw-numeric-figure:  ;
          --tw-numeric-spacing:  ;
          --tw-numeric-fraction:  ;
          --tw-ring-inset:  ;
          --tw-ring-offset-width: 0px;
          --tw-ring-offset-color: #fff;
          --tw-ring-color: rgb(59 130 246 / 0.5);
          --tw-ring-offset-shadow: 0 0 #0000;
          --tw-ring-shadow: 0 0 #0000;
          --tw-shadow: 0 0 #0000;
          --tw-shadow-colored: 0 0 #0000;
          --tw-blur:  ;
          --tw-brightness:  ;
          --tw-contrast:  ;
          --tw-grayscale:  ;
          --tw-hue-rotate:  ;
          --tw-invert:  ;
          --tw-saturate:  ;
          --tw-sepia:  ;
          --tw-drop-shadow:  ;
          --tw-backdrop-blur:  ;
          --tw-backdrop-brightness:  ;
          --tw-backdrop-contrast:  ;
          --tw-backdrop-grayscale:  ;
          --tw-backdrop-hue-rotate:  ;
          --tw-backdrop-invert:  ;
          --tw-backdrop-opacity:  ;
          --tw-backdrop-saturate:  ;
          --tw-backdrop-sepia:  ;
}

body, html {
    min-height: 100vh;
}
`),a.addPage("pinegrow.json",`{"files":{"index.html":{"frameworks":["newtw2","pg.insight.events","pg.svg.lib","pg.css.grid","pg.image.overlay","pg.code-validator","pg.project.items","pg.asset.manager","pg.tw.lib","tw","pg.html","pg.components"],"last_page_width":1024}},"breakpoints":[],"frameworks":["newtw2","pg.insight.events","pg.svg.lib","pg.css.grid","pg.image.overlay","pg.code-validator","pg.project.items","pg.asset.manager","pg.tw.lib","tw","pg.html","pg.components"],"template_framework_id":"tailwind","urls":{"index.html":{"open-page-views":[{"w":1024,"h":0}]}},"active-design-provider":"tw"}`),a.addPage("projectdb.pgml",`<project>
    <documents></documents>
    <dmdesigns>
        <dmdesign active>
            <dmdesignskill skill="tw.colors">
                <dmcolor key="gray" color="rgba(107,114,128,1)" shade-50="rgba(249,250,251,1)" shade-100="rgba(243,244,246,1)" shade-200="rgba(229,231,235,1)" shade-300="rgba(209,213,219,1)" shade-400="rgba(156,163,175,1)" shade-500="rgba(107,114,128,1)" shade-600="rgba(75,85,99,1)" shade-700="rgba(55,65,81,1)" shade-800="rgba(31,41,55,1)" shade-900="rgba(17,24,39,1)"/>
                <dmcolor key="red" color="rgba(239,68,68,1)" shade-50="rgba(254,242,242,1)" shade-100="rgba(254,226,226,1)" shade-200="rgba(254,202,202,1)" shade-300="rgba(252,165,165,1)" shade-400="rgba(248,113,113,1)" shade-500="rgba(239,68,68,1)" shade-600="rgba(220,38,38,1)" shade-700="rgba(185,28,28,1)" shade-800="rgba(153,27,27,1)" shade-900="rgba(127,29,29,1)"/>
                <dmcolor key="yellow" color="rgba(245,158,11,1)" shade-50="rgba(255,251,235,1)" shade-100="rgba(254,243,199,1)" shade-200="rgba(253,230,138,1)" shade-300="rgba(252,211,77,1)" shade-400="rgba(251,191,36,1)" shade-500="rgba(245,158,11,1)" shade-600="rgba(217,119,6,1)" shade-700="rgba(180,83,9,1)" shade-800="rgba(146,64,14,1)" shade-900="rgba(120,53,15,1)"/>
                <dmcolor key="green" color="rgba(16,185,129,1)" shade-50="rgba(236,253,245,1)" shade-100="rgba(209,250,229,1)" shade-200="rgba(167,243,208,1)" shade-300="rgba(110,231,183,1)" shade-400="rgba(52,211,153,1)" shade-500="rgba(16,185,129,1)" shade-600="rgba(5,150,105,1)" shade-700="rgba(4,120,87,1)" shade-800="rgba(6,95,70,1)" shade-900="rgba(6,78,59,1)"/>
                <dmcolor key="blue" color="rgba(59,130,246,1)" shade-50="rgba(239,246,255,1)" shade-100="rgba(219,234,254,1)" shade-200="rgba(191,219,254,1)" shade-300="rgba(147,197,253,1)" shade-400="rgba(96,165,250,1)" shade-500="rgba(59,130,246,1)" shade-600="rgba(37,99,235,1)" shade-700="rgba(29,78,216,1)" shade-800="rgba(30,64,175,1)" shade-900="rgba(30,58,138,1)"/>
                <dmcolor key="indigo" color="rgba(99,102,241,1)" shade-50="rgba(238,242,255,1)" shade-100="rgba(224,231,255,1)" shade-200="rgba(199,210,254,1)" shade-300="rgba(165,180,252,1)" shade-400="rgba(129,140,248,1)" shade-500="rgba(99,102,241,1)" shade-600="rgba(79,70,229,1)" shade-700="rgba(67,56,202,1)" shade-800="rgba(55,48,163,1)" shade-900="rgba(49,46,129,1)"/>
                <dmcolor key="purple" color="rgba(139,92,246,1)" shade-50="rgba(245,243,255,1)" shade-100="rgba(237,233,254,1)" shade-200="rgba(221,214,254,1)" shade-300="rgba(196,181,253,1)" shade-400="rgba(167,139,250,1)" shade-500="rgba(139,92,246,1)" shade-600="rgba(124,58,237,1)" shade-700="rgba(109,40,217,1)" shade-800="rgba(91,33,182,1)" shade-900="rgba(76,29,149,1)"/>
                <dmcolor key="pink" color="rgba(236,72,153,1)" shade-50="rgba(253,242,248,1)" shade-100="rgba(252,231,243,1)" shade-200="rgba(251,207,232,1)" shade-300="rgba(249,168,212,1)" shade-400="rgba(244,114,182,1)" shade-500="rgba(236,72,153,1)" shade-600="rgba(219,39,119,1)" shade-700="rgba(190,24,93,1)" shade-800="rgba(157,23,77,1)" shade-900="rgba(131,24,67,1)"/>
            </dmdesignskill>
            <dmdesignskill skill="fonts"></dmdesignskill>
            <dmdesignskill skill="background" image_for_colors="true" advanced="true" filter_blur="0" filter_brightness="100" filter_contrast="100" filter_grayscale="0" filter_hue-rotate="0" filter_invert="0" filter_opacity="100" filter_saturate="100" filter_sepia="0"></dmdesignskill>
            <dmdesignskill skill="tailwind"></dmdesignskill>
        </dmdesign>
    </dmdesigns>
    <dmlocked tw-colors-gray="true" tw-colors-red="true" tw-colors-yellow="true" tw-colors-green="true" tw-colors-blue="true" tw-colors-indigo="true" tw-colors-purple="true" tw-colors-pink="true"></dmlocked>
</project>`),d.addLesson(a),(s=new PgTutorialLesson("new_tw_block_theme")).name="Block Theme Tailwind Project",i=`<!DOCTYPE html> 
<html lang="en" wp-template wp-template-export-as="index.php" wp-template-define-master-page="true"> 
    <head> 
        <meta charset="utf-8"> 
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> 
        <title>New block theme</title>
        <link href="tailwind_theme/tailwind.css" rel="stylesheet" type="text/css">
    </head>     
    <body>
    <section class="bg-yellow-50 px-4 py-4 md:px-8 lg:px-16" data-pg-name="Instructions" data-pg-collapsed cms-no-export>
        <div>
            <h2>Quick Start Guide</h2>
            <div class="bg-blue-100 border-blue-500 border-l-4 flex items-center mb-6 not-prose p-4 rounded-r space-x-3" role="alert">
                <div>
                    <p class="font-sans text-base text-blue-700">Memorize the instructions, then destroy this section&nbsp;&#128522;</p>
                </div>
            </div>
            <div>
                <p>This is a quick start template for a WordPress block theme with Tailwind CSS.</p>
                <a data-pg-external-link target="_blank" href="https://youtu.be/L2Eo3kt5fBo" class="inline-block px-8 py-4 text-lg font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition duration-300 shadow-lg">Watch the video guide</a>
                <p>Steps you need to do:</p>
                <ul>
                    <li>
                        <b>Save this page</b> and open it as <b>project</b>.
                    </li>
                    <li>Change the theme info in <b>Theme settings</b>
                        <span>, including Block category for custom blocks.</span>
                    </li>
                    <li>If you are going to use the AI Assistant, create the <b>project brief</b> in the AI panel.
                    </li>
                    <li>Create a <code>section</code> (or <code>nav</code>, <code>header</code>, <code>footer</code>) for every template section and content block. Use <b>Block</b> action to turn the section into a block.
                    </li>
                </ul>
                <p>About the styling:</p>
                <ul>
                    <li><b>Body</b>&nbsp;style adds class <code>prose</code> so that prose is added both to the front-end and to the WP Block editor.
                    </li>
                    <li>Most sections should have <code>not-prose</code> class so that prose styling is disabled within that section.
                    </li>
                    <li>Sections that display post content should not have the <code>non-prose</code> class. Instead <code>non-prose</code> can be added on their sub-elements that do not display post content.
                    </li>
                    <li>Add class <code>active</code> to the first item of the nav menu. Customize the style in Style manager.
                    </li>
                    <li><b>nav</b> style with <code>wp-has-admin-bar</code> variant moves the top nav bar below the WordPress admin bar, if it is shown.
                    </li>
                    <li><b>pre</b> style is an example of how to style elements in the WP Block editor.
                    </li>
                    <li><code>additional-editor-styles.css</code> contains CSS styling for the <code>body</code> that is applied only in the WP block editor.
                    </li>
                </ul>
            </div>
        </div>
    </section>
        <nav class="not-prose" data-empty-placeholder></nav>
        <header class="not-prose" data-empty-placeholder></header>
        <section class="not-prose" data-empty-placeholder></section>
        <section class="not-prose" data-pg-name="Section with post content">
            <div class="not-prose">Post header without prose</div>
            <div>Post content with prose</div>
        </section>
        <footer class="not-prose" data-empty-placeholder></footer>
    </body>     
</html>`,s.addPage("index.html",i),s.addHiddenFile("_new.html",i),s.addStylesheet("tailwind_theme/tailwind.css",`@import url('https://fonts.googleapis.com/css?family=Sora:100,200,300,400,500,600,700,800&display=swap');


/* ! tailwindcss v3.4.3 | MIT License | https://tailwindcss.com *//*
1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)
2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)
*/
*,
::before,
::after {
    box-sizing: border-box; /* 1 */
    border-width: 0; /* 2 */
    border-style: solid; /* 2 */
    border-color: #e5e7eb; /* 2 */
}

::before,
::after {
    --tw-content: '';
}

/*
1. Use a consistent sensible line-height in all browsers.
2. Prevent adjustments of font size after orientation changes in iOS.
3. Use a more readable tab size.
4. Use the user's configured \`sans\` font-family by default.
5. Use the user's configured \`sans\` font-feature-settings by default.
6. Use the user's configured \`sans\` font-variation-settings by default.
7. Disable tap highlights on iOS
*/
html,
:host {
    line-height: 1.5; /* 1 */
    -webkit-text-size-adjust: 100%; /* 2 */
    -moz-tab-size: 4; /* 3 */
    -o-tab-size: 4;
    tab-size: 4; /* 3 */
    font-family: 'Sora', sans-serif; /* 4 */
    font-feature-settings: normal; /* 5 */
    font-variation-settings: normal; /* 6 */
    -webkit-tap-highlight-color: transparent; /* 7 */
}

/*
1. Remove the margin in all browsers.
2. Inherit line-height from \`html\` so users can set them as a class directly on the \`html\` element.
*/
body {
    margin: 0; /* 1 */
    line-height: inherit; /* 2 */
}

/*
1. Add the correct height in Firefox.
2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
3. Ensure horizontal rules are visible by default.
*/
hr {
    height: 0; /* 1 */
    color: inherit; /* 2 */
    border-top-width: 1px; /* 3 */
}

/*
Add the correct text decoration in Chrome, Edge, and Safari.
*/
abbr:where([title]) {
    -webkit-text-decoration: underline dotted;
    text-decoration: underline dotted;
}

/*
Remove the default font size and weight for headings.
*/
h1,
h2,
h3,
h4,
h5,
h6 {
    font-size: inherit;
    font-weight: inherit;
}

/*
Reset links to optimize for opt-in styling instead of opt-out.
*/
a {
    color: inherit;
    text-decoration: inherit;
}

/*
Add the correct font weight in Edge and Safari.
*/
b,
strong {
    font-weight: bolder;
}

/*
1. Use the user's configured \`mono\` font-family by default.
2. Use the user's configured \`mono\` font-feature-settings by default.
3. Use the user's configured \`mono\` font-variation-settings by default.
4. Correct the odd \`em\` font sizing in all browsers.
*/
code,
kbd,
samp,
pre {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; /* 1 */
    font-feature-settings: normal; /* 2 */
    font-variation-settings: normal; /* 3 */
    font-size: 1em; /* 4 */
}

/*
Add the correct font size in all browsers.
*/
small {
    font-size: 80%;
}

/*
Prevent \`sub\` and \`sup\` elements from affecting the line height in all browsers.
*/
sub,
sup {
    font-size: 75%;
    line-height: 0;
    position: relative;
    vertical-align: baseline;
}

sub {
    bottom: -0.25em;
}

sup {
    top: -0.5em;
}

/*
1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
3. Remove gaps between table borders by default.
*/
table {
    text-indent: 0; /* 1 */
    border-color: inherit; /* 2 */
    border-collapse: collapse; /* 3 */
}

/*
1. Change the font styles in all browsers.
2. Remove the margin in Firefox and Safari.
3. Remove default padding in all browsers.
*/
button,
input,
optgroup,
select,
textarea {
    font-family: inherit; /* 1 */
    font-feature-settings: inherit; /* 1 */
    font-variation-settings: inherit; /* 1 */
    font-size: 100%; /* 1 */
    font-weight: inherit; /* 1 */
    line-height: inherit; /* 1 */
    letter-spacing: inherit; /* 1 */
    color: inherit; /* 1 */
    margin: 0; /* 2 */
    padding: 0; /* 3 */
}

/*
Remove the inheritance of text transform in Edge and Firefox.
*/
button,
select {
    text-transform: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Remove default button styles.
*/
button,
input:where([type='button']),
input:where([type='reset']),
input:where([type='submit']) {
    -webkit-appearance: button; /* 1 */
    background-color: transparent; /* 2 */
    background-image: none; /* 2 */
}

/*
Use the modern Firefox focus style for all focusable elements.
*/
:-moz-focusring {
    outline: auto;
}

/*
Remove the additional \`:invalid\` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)
*/
:-moz-ui-invalid {
    box-shadow: none;
}

/*
Add the correct vertical alignment in Chrome and Firefox.
*/
progress {
    vertical-align: baseline;
}

/*
Correct the cursor style of increment and decrement buttons in Safari.
*/
::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
    height: auto;
}

/*
1. Correct the odd appearance in Chrome and Safari.
2. Correct the outline style in Safari.
*/
[type='search'] {
    -webkit-appearance: textfield; /* 1 */
    outline-offset: -2px; /* 2 */
}

/*
Remove the inner padding in Chrome and Safari on macOS.
*/
::-webkit-search-decoration {
    -webkit-appearance: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Change font properties to \`inherit\` in Safari.
*/
::-webkit-file-upload-button {
    -webkit-appearance: button; /* 1 */
    font: inherit; /* 2 */
}

/*
Add the correct display in Chrome and Safari.
*/
summary {
    display: list-item;
}

/*
Removes the default spacing and border for appropriate elements.
*/
blockquote,
dl,
dd,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
figure,
p,
pre {
    margin: 0;
}

fieldset {
    margin: 0;
    padding: 0;
}

legend {
    padding: 0;
}

ol,
ul,
menu {
    list-style: none;
    margin: 0;
    padding: 0;
}

/*
Reset default styling for dialogs.
*/
dialog {
    padding: 0;
}

/*
Prevent resizing textareas horizontally by default.
*/
textarea {
    resize: vertical;
}

/*
1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)
2. Set the default placeholder color to the user's configured gray 400 color.
*/
input::-moz-placeholder, textarea::-moz-placeholder {
    opacity: 1; /* 1 */
    color: #9ca3af; /* 2 */
}

input::placeholder,
textarea::placeholder {
    opacity: 1; /* 1 */
    color: #9ca3af; /* 2 */
}

/*
Set the default cursor for buttons.
*/
button,
[role="button"] {
    cursor: pointer;
}

/*
Make sure disabled buttons don't get the pointer cursor.
*/
:disabled {
    cursor: default;
}

/*
1. Make replaced elements \`display: block\` by default. (https://github.com/mozdevs/cssremedy/issues/14)
2. Add \`vertical-align: middle\` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)
   This can trigger a poorly considered lint error in some tools but is included by design.
*/
img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
    display: block; /* 1 */
    vertical-align: middle; /* 2 */
}

/*
Constrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)
*/
img,
video {
    max-width: 100%;
    height: auto;
}

/* Make elements with the HTML hidden attribute stay hidden by default */
[hidden] {
    display: none;
}

[type='text'], input:where(:not([type])), [type='email'], [type='url'], [type='password'], [type='number'], [type='date'], [type='datetime-local'], [type='month'], [type='search'], [type='tel'], [type='time'], [type='week'], [multiple], textarea, select {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    background-color: #fff;
    border-color: #6b7280;
    border-width: 1px;
    border-radius: 0px;
    padding-top: 0.5rem;
    padding-right: 0.75rem;
    padding-bottom: 0.5rem;
    padding-left: 0.75rem;
    font-size: 1rem;
    line-height: 1.5rem;
    --tw-shadow: 0 0 #0000;
}

[type='text']:focus, input:where(:not([type])):focus, [type='email']:focus, [type='url']:focus, [type='password']:focus, [type='number']:focus, [type='date']:focus, [type='datetime-local']:focus, [type='month']:focus, [type='search']:focus, [type='tel']:focus, [type='time']:focus, [type='week']:focus, [multiple]:focus, textarea:focus, select:focus {
    outline: 2px solid transparent;
    outline-offset: 2px;
    --tw-ring-inset: var(--tw-empty, /*!*/ /*!*/);
    --tw-ring-offset-width: 0px;
    --tw-ring-offset-color: #fff;
    --tw-ring-color: #2563eb;
    --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
    --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
    box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
    border-color: #2563eb;
}

input::-moz-placeholder, textarea::-moz-placeholder {
    color: #6b7280;
    opacity: 1;
}

input::placeholder, textarea::placeholder {
    color: #6b7280;
    opacity: 1;
}

::-webkit-datetime-edit-fields-wrapper {
    padding: 0;
}

::-webkit-date-and-time-value {
    min-height: 1.5em;
    text-align: inherit;
}

::-webkit-datetime-edit {
    display: inline-flex;
}

::-webkit-datetime-edit, ::-webkit-datetime-edit-year-field, ::-webkit-datetime-edit-month-field, ::-webkit-datetime-edit-day-field, ::-webkit-datetime-edit-hour-field, ::-webkit-datetime-edit-minute-field, ::-webkit-datetime-edit-second-field, ::-webkit-datetime-edit-millisecond-field, ::-webkit-datetime-edit-meridiem-field {
    padding-top: 0;
    padding-bottom: 0;
}

select {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e");
    background-position: right 0.5rem center;
    background-repeat: no-repeat;
    background-size: 1.5em 1.5em;
    padding-right: 2.5rem;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
}

[multiple], [size]:where(select:not([size="1"])) {
    background-image: initial;
    background-position: initial;
    background-repeat: unset;
    background-size: initial;
    padding-right: 0.75rem;
    -webkit-print-color-adjust: unset;
    print-color-adjust: unset;
}

[type='checkbox'], [type='radio'] {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    padding: 0;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
    display: inline-block;
    vertical-align: middle;
    background-origin: border-box;
    -webkit-user-select: none;
    -moz-user-select: none;
    user-select: none;
    flex-shrink: 0;
    height: 1rem;
    width: 1rem;
    color: #2563eb;
    background-color: #fff;
    border-color: #6b7280;
    border-width: 1px;
    --tw-shadow: 0 0 #0000;
}

[type='checkbox'] {
    border-radius: 0px;
}

[type='radio'] {
    border-radius: 100%;
}

[type='checkbox']:focus, [type='radio']:focus {
    outline: 2px solid transparent;
    outline-offset: 2px;
    --tw-ring-inset: var(--tw-empty, /*!*/ /*!*/);
    --tw-ring-offset-width: 2px;
    --tw-ring-offset-color: #fff;
    --tw-ring-color: #2563eb;
    --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
    --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
    box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
}

[type='checkbox']:checked, [type='radio']:checked {
    border-color: transparent;
    background-color: currentColor;
    background-size: 100% 100%;
    background-position: center;
    background-repeat: no-repeat;
}

[type='checkbox']:checked {
    background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.207 4.793a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-2-2a1 1 0 011.414-1.414L6.5 9.086l4.293-4.293a1 1 0 011.414 0z'/%3e%3c/svg%3e");
}

@media (forced-colors: active) {
    [type='checkbox']:checked {
        -webkit-appearance: auto;
        -moz-appearance: auto;
        appearance: auto;
    }
}

[type='radio']:checked {
    background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3ccircle cx='8' cy='8' r='3'/%3e%3c/svg%3e");
}

@media (forced-colors: active) {
    [type='radio']:checked {
        -webkit-appearance: auto;
        -moz-appearance: auto;
        appearance: auto;
    }
}

[type='checkbox']:checked:hover, [type='checkbox']:checked:focus, [type='radio']:checked:hover, [type='radio']:checked:focus {
    border-color: transparent;
    background-color: currentColor;
}

[type='checkbox']:indeterminate {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 16 16'%3e%3cpath stroke='white' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M4 8h8'/%3e%3c/svg%3e");
    border-color: transparent;
    background-color: currentColor;
    background-size: 100% 100%;
    background-position: center;
    background-repeat: no-repeat;
}

@media (forced-colors: active) {
    [type='checkbox']:indeterminate {
        -webkit-appearance: auto;
        -moz-appearance: auto;
        appearance: auto;
    }
}

[type='checkbox']:indeterminate:hover, [type='checkbox']:indeterminate:focus {
    border-color: transparent;
    background-color: currentColor;
}

[type='file'] {
    background: unset;
    border-color: inherit;
    border-width: 0;
    border-radius: 0;
    padding: 0;
    font-size: unset;
    line-height: inherit;
}

[type='file']:focus {
    outline: 1px solid ButtonText;
    outline: 1px auto -webkit-focus-ring-color;
}

*, ::before, ::after {
    --tw-border-spacing-x: 0;
    --tw-border-spacing-y: 0;
    --tw-translate-x: 0;
    --tw-translate-y: 0;
    --tw-rotate: 0;
    --tw-skew-x: 0;
    --tw-skew-y: 0;
    --tw-scale-x: 1;
    --tw-scale-y: 1;
    --tw-pan-x: ;
    --tw-pan-y: ;
    --tw-pinch-zoom: ;
    --tw-scroll-snap-strictness: proximity;
    --tw-gradient-from-position: ;
    --tw-gradient-via-position: ;
    --tw-gradient-to-position: ;
    --tw-ordinal: ;
    --tw-slashed-zero: ;
    --tw-numeric-figure: ;
    --tw-numeric-spacing: ;
    --tw-numeric-fraction: ;
    --tw-ring-inset: ;
    --tw-ring-offset-width: 0px;
    --tw-ring-offset-color: #fff;
    --tw-ring-color: rgb(59 130 246 / 0.5);
    --tw-ring-offset-shadow: 0 0 #0000;
    --tw-ring-shadow: 0 0 #0000;
    --tw-shadow: 0 0 #0000;
    --tw-shadow-colored: 0 0 #0000;
    --tw-blur: ;
    --tw-brightness: ;
    --tw-contrast: ;
    --tw-grayscale: ;
    --tw-hue-rotate: ;
    --tw-invert: ;
    --tw-saturate: ;
    --tw-sepia: ;
    --tw-drop-shadow: ;
    --tw-backdrop-blur: ;
    --tw-backdrop-brightness: ;
    --tw-backdrop-contrast: ;
    --tw-backdrop-grayscale: ;
    --tw-backdrop-hue-rotate: ;
    --tw-backdrop-invert: ;
    --tw-backdrop-opacity: ;
    --tw-backdrop-saturate: ;
    --tw-backdrop-sepia: ;
    --tw-contain-size: ;
    --tw-contain-layout: ;
    --tw-contain-paint: ;
    --tw-contain-style: ;
}

::backdrop {
    --tw-border-spacing-x: 0;
    --tw-border-spacing-y: 0;
    --tw-translate-x: 0;
    --tw-translate-y: 0;
    --tw-rotate: 0;
    --tw-skew-x: 0;
    --tw-skew-y: 0;
    --tw-scale-x: 1;
    --tw-scale-y: 1;
    --tw-pan-x: ;
    --tw-pan-y: ;
    --tw-pinch-zoom: ;
    --tw-scroll-snap-strictness: proximity;
    --tw-gradient-from-position: ;
    --tw-gradient-via-position: ;
    --tw-gradient-to-position: ;
    --tw-ordinal: ;
    --tw-slashed-zero: ;
    --tw-numeric-figure: ;
    --tw-numeric-spacing: ;
    --tw-numeric-fraction: ;
    --tw-ring-inset: ;
    --tw-ring-offset-width: 0px;
    --tw-ring-offset-color: #fff;
    --tw-ring-color: rgb(59 130 246 / 0.5);
    --tw-ring-offset-shadow: 0 0 #0000;
    --tw-ring-shadow: 0 0 #0000;
    --tw-shadow: 0 0 #0000;
    --tw-shadow-colored: 0 0 #0000;
    --tw-blur: ;
    --tw-brightness: ;
    --tw-contrast: ;
    --tw-grayscale: ;
    --tw-hue-rotate: ;
    --tw-invert: ;
    --tw-saturate: ;
    --tw-sepia: ;
    --tw-drop-shadow: ;
    --tw-backdrop-blur: ;
    --tw-backdrop-brightness: ;
    --tw-backdrop-contrast: ;
    --tw-backdrop-grayscale: ;
    --tw-backdrop-hue-rotate: ;
    --tw-backdrop-invert: ;
    --tw-backdrop-opacity: ;
    --tw-backdrop-saturate: ;
    --tw-backdrop-sepia: ;
    --tw-contain-size: ;
    --tw-contain-layout: ;
    --tw-contain-paint: ;
    --tw-contain-style: ;
}

body {
    color: var(--tw-prose-body);
    max-width: 65ch;
}

body :where(p):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-top: 1.25em;
    margin-bottom: 1.25em;
}

body :where([class~="lead"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: var(--tw-prose-lead);
    font-size: 1.25em;
    line-height: 1.6;
    margin-top: 1.2em;
    margin-bottom: 1.2em;
}

body :where(a):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: var(--tw-prose-links);
    text-decoration: underline;
    font-weight: 500;
}

body :where(strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: var(--tw-prose-bold);
    font-weight: 600;
}

body :where(a strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: inherit;
}

body :where(blockquote strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: inherit;
}

body :where(thead th strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: inherit;
}

body :where(ol):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    list-style-type: decimal;
    margin-top: 1.25em;
    margin-bottom: 1.25em;
    padding-inline-start: 1.625em;
}

body :where(ol[type="A"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    list-style-type: upper-alpha;
}

body :where(ol[type="a"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    list-style-type: lower-alpha;
}

body :where(ol[type="A" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    list-style-type: upper-alpha;
}

body :where(ol[type="a" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    list-style-type: lower-alpha;
}

body :where(ol[type="I"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    list-style-type: upper-roman;
}

body :where(ol[type="i"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    list-style-type: lower-roman;
}

body :where(ol[type="I" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    list-style-type: upper-roman;
}

body :where(ol[type="i" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    list-style-type: lower-roman;
}

body :where(ol[type="1"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    list-style-type: decimal;
}

body :where(ul):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    list-style-type: disc;
    margin-top: 1.25em;
    margin-bottom: 1.25em;
    padding-inline-start: 1.625em;
}

body :where(ol > li):not(:where([class~="not-prose"],[class~="not-prose"] *))::marker {
    font-weight: 400;
    color: var(--tw-prose-counters);
}

body :where(ul > li):not(:where([class~="not-prose"],[class~="not-prose"] *))::marker {
    color: var(--tw-prose-bullets);
}

body :where(dt):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: var(--tw-prose-headings);
    font-weight: 600;
    margin-top: 1.25em;
}

body :where(hr):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    border-color: var(--tw-prose-hr);
    border-top-width: 1px;
    margin-top: 3em;
    margin-bottom: 3em;
}

body :where(blockquote):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    font-weight: 500;
    font-style: italic;
    color: var(--tw-prose-quotes);
    border-inline-start-width: 0.25rem;
    border-inline-start-color: var(--tw-prose-quote-borders);
    quotes: "\\201C" "\\201D" "\\2018" "\\2019";
    margin-top: 1.6em;
    margin-bottom: 1.6em;
    padding-inline-start: 1em;
}

body :where(blockquote p:first-of-type):not(:where([class~="not-prose"],[class~="not-prose"] *))::before {
    content: open-quote;
}

body :where(blockquote p:last-of-type):not(:where([class~="not-prose"],[class~="not-prose"] *))::after {
    content: close-quote;
}

body :where(h1):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: var(--tw-prose-headings);
    font-weight: 800;
    font-size: 2.25em;
    margin-top: 0;
    margin-bottom: 0.8888889em;
    line-height: 1.1111111;
}

body :where(h1 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    font-weight: 900;
    color: inherit;
}

body :where(h2):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: var(--tw-prose-headings);
    font-weight: 700;
    font-size: 1.5em;
    margin-top: 2em;
    margin-bottom: 1em;
    line-height: 1.3333333;
}

body :where(h2 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    font-weight: 800;
    color: inherit;
}

body :where(h3):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: var(--tw-prose-headings);
    font-weight: 600;
    font-size: 1.25em;
    margin-top: 1.6em;
    margin-bottom: 0.6em;
    line-height: 1.6;
}

body :where(h3 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    font-weight: 700;
    color: inherit;
}

body :where(h4):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: var(--tw-prose-headings);
    font-weight: 600;
    margin-top: 1.5em;
    margin-bottom: 0.5em;
    line-height: 1.5;
}

body :where(h4 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    font-weight: 700;
    color: inherit;
}

body :where(img):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-top: 2em;
    margin-bottom: 2em;
}

body :where(picture):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    display: block;
    margin-top: 2em;
    margin-bottom: 2em;
}

body :where(video):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-top: 2em;
    margin-bottom: 2em;
}

body :where(kbd):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    font-weight: 500;
    font-family: inherit;
    color: var(--tw-prose-kbd);
    box-shadow: 0 0 0 1px rgb(var(--tw-prose-kbd-shadows) / 10%), 0 3px 0 rgb(var(--tw-prose-kbd-shadows) / 10%);
    font-size: 0.875em;
    border-radius: 0.3125rem;
    padding-top: 0.1875em;
    padding-inline-end: 0.375em;
    padding-bottom: 0.1875em;
    padding-inline-start: 0.375em;
}

body :where(code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: var(--tw-prose-code);
    font-weight: 600;
    font-size: 0.875em;
}

body :where(code):not(:where([class~="not-prose"],[class~="not-prose"] *))::before {
    content: "\`";
}

body :where(code):not(:where([class~="not-prose"],[class~="not-prose"] *))::after {
    content: "\`";
}

body :where(a code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: inherit;
}

body :where(h1 code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: inherit;
}

body :where(h2 code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: inherit;
    font-size: 0.875em;
}

body :where(h3 code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: inherit;
    font-size: 0.9em;
}

body :where(h4 code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: inherit;
}

body :where(blockquote code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: inherit;
}

body :where(thead th code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: inherit;
}

body :where(pre):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: var(--tw-prose-pre-code);
    background-color: var(--tw-prose-pre-bg);
    overflow-x: auto;
    font-weight: 400;
    font-size: 0.875em;
    line-height: 1.7142857;
    margin-top: 1.7142857em;
    margin-bottom: 1.7142857em;
    border-radius: 0.375rem;
    padding-top: 0.8571429em;
    padding-inline-end: 1.1428571em;
    padding-bottom: 0.8571429em;
    padding-inline-start: 1.1428571em;
}

body :where(pre code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    background-color: transparent;
    border-width: 0;
    border-radius: 0;
    padding: 0;
    font-weight: inherit;
    color: inherit;
    font-size: inherit;
    font-family: inherit;
    line-height: inherit;
}

body :where(pre code):not(:where([class~="not-prose"],[class~="not-prose"] *))::before {
    content: none;
}

body :where(pre code):not(:where([class~="not-prose"],[class~="not-prose"] *))::after {
    content: none;
}

body :where(table):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    width: 100%;
    table-layout: auto;
    text-align: start;
    margin-top: 2em;
    margin-bottom: 2em;
    font-size: 0.875em;
    line-height: 1.7142857;
}

body :where(thead):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    border-bottom-width: 1px;
    border-bottom-color: var(--tw-prose-th-borders);
}

body :where(thead th):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: var(--tw-prose-headings);
    font-weight: 600;
    vertical-align: bottom;
    padding-inline-end: 0.5714286em;
    padding-bottom: 0.5714286em;
    padding-inline-start: 0.5714286em;
}

body :where(tbody tr):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    border-bottom-width: 1px;
    border-bottom-color: var(--tw-prose-td-borders);
}

body :where(tbody tr:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    border-bottom-width: 0;
}

body :where(tbody td):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    vertical-align: baseline;
}

body :where(tfoot):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    border-top-width: 1px;
    border-top-color: var(--tw-prose-th-borders);
}

body :where(tfoot td):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    vertical-align: top;
}

body :where(figure > *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-top: 0;
    margin-bottom: 0;
}

body :where(figcaption):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    color: var(--tw-prose-captions);
    font-size: 0.875em;
    line-height: 1.4285714;
    margin-top: 0.8571429em;
}

body {
    --tw-prose-body: #374151;
    --tw-prose-headings: #111827;
    --tw-prose-lead: #4b5563;
    --tw-prose-links: #111827;
    --tw-prose-bold: #111827;
    --tw-prose-counters: #6b7280;
    --tw-prose-bullets: #d1d5db;
    --tw-prose-hr: #e5e7eb;
    --tw-prose-quotes: #111827;
    --tw-prose-quote-borders: #e5e7eb;
    --tw-prose-captions: #6b7280;
    --tw-prose-kbd: #111827;
    --tw-prose-kbd-shadows: 17 24 39;
    --tw-prose-code: #111827;
    --tw-prose-pre-code: #e5e7eb;
    --tw-prose-pre-bg: #1f2937;
    --tw-prose-th-borders: #d1d5db;
    --tw-prose-td-borders: #e5e7eb;
    --tw-prose-invert-body: #d1d5db;
    --tw-prose-invert-headings: #fff;
    --tw-prose-invert-lead: #9ca3af;
    --tw-prose-invert-links: #fff;
    --tw-prose-invert-bold: #fff;
    --tw-prose-invert-counters: #9ca3af;
    --tw-prose-invert-bullets: #4b5563;
    --tw-prose-invert-hr: #374151;
    --tw-prose-invert-quotes: #f3f4f6;
    --tw-prose-invert-quote-borders: #374151;
    --tw-prose-invert-captions: #9ca3af;
    --tw-prose-invert-kbd: #fff;
    --tw-prose-invert-kbd-shadows: 255 255 255;
    --tw-prose-invert-code: #fff;
    --tw-prose-invert-pre-code: #d1d5db;
    --tw-prose-invert-pre-bg: rgb(0 0 0 / 50%);
    --tw-prose-invert-th-borders: #4b5563;
    --tw-prose-invert-td-borders: #374151;
    font-size: 1rem;
    line-height: 1.75;
}

body :where(picture > img):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-top: 0;
    margin-bottom: 0;
}

body :where(li):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-top: 0.5em;
    margin-bottom: 0.5em;
}

body :where(ol > li):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    padding-inline-start: 0.375em;
}

body :where(ul > li):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    padding-inline-start: 0.375em;
}

body :where(.prose > ul > li p):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-top: 0.75em;
    margin-bottom: 0.75em;
}

body :where(.prose > ul > li > *:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-top: 1.25em;
}

body :where(.prose > ul > li > *:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-bottom: 1.25em;
}

body :where(.prose > ol > li > *:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-top: 1.25em;
}

body :where(.prose > ol > li > *:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-bottom: 1.25em;
}

body :where(ul ul, ul ol, ol ul, ol ol):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-top: 0.75em;
    margin-bottom: 0.75em;
}

body :where(dl):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-top: 1.25em;
    margin-bottom: 1.25em;
}

body :where(dd):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-top: 0.5em;
    padding-inline-start: 1.625em;
}

body :where(hr + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-top: 0;
}

body :where(h2 + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-top: 0;
}

body :where(h3 + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-top: 0;
}

body :where(h4 + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-top: 0;
}

body :where(thead th:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    padding-inline-start: 0;
}

body :where(thead th:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    padding-inline-end: 0;
}

body :where(tbody td, tfoot td):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    padding-top: 0.5714286em;
    padding-inline-end: 0.5714286em;
    padding-bottom: 0.5714286em;
    padding-inline-start: 0.5714286em;
}

body :where(tbody td:first-child, tfoot td:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    padding-inline-start: 0;
}

body :where(tbody td:last-child, tfoot td:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    padding-inline-end: 0;
}

body :where(figure):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-top: 2em;
    margin-bottom: 2em;
}

body :where(.prose > :first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-top: 0;
}

body :where(.prose > :last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
    margin-bottom: 0;
}

body {
    max-width: none;
}

pre:where(.editor-styles-wrapper *) {
    --tw-text-opacity: 1 !important;
    color: rgb(249 250 251 / var(--tw-text-opacity)) !important;
}

nav:where(.admin-bar *) {
    top: var(--wp-admin--admin-bar--height);
}

.mb-6 {
    margin-bottom: 1.5rem;
}

.inline-block {
    display: inline-block;
}

.flex {
    display: flex;
}

.items-center {
    align-items: center;
}

.space-x-3 > :not([hidden]) ~ :not([hidden]) {
    --tw-space-x-reverse: 0;
    margin-right: calc(0.75rem * var(--tw-space-x-reverse));
    margin-left: calc(0.75rem * calc(1 - var(--tw-space-x-reverse)));
}

.rounded-lg {
    border-radius: 0.5rem;
}

.rounded-r {
    border-top-right-radius: 0.25rem;
    border-bottom-right-radius: 0.25rem;
}

.border-l-4 {
    border-left-width: 4px;
}

.border-blue-500 {
    --tw-border-opacity: 1;
    border-color: rgb(59 130 246 / var(--tw-border-opacity));
}

.bg-blue-100 {
    --tw-bg-opacity: 1;
    background-color: rgb(219 234 254 / var(--tw-bg-opacity));
}

.bg-blue-600 {
    --tw-bg-opacity: 1;
    background-color: rgb(37 99 235 / var(--tw-bg-opacity));
}

.bg-yellow-50 {
    --tw-bg-opacity: 1;
    background-color: rgb(255 251 235 / var(--tw-bg-opacity));
}

.p-4 {
    padding: 1rem;
}

.px-4 {
    padding-left: 1rem;
    padding-right: 1rem;
}

.px-8 {
    padding-left: 2rem;
    padding-right: 2rem;
}

.py-4 {
    padding-top: 1rem;
    padding-bottom: 1rem;
}

.font-sans {
    font-family: 'Sora', sans-serif;
}

.text-base {
    font-size: 1rem;
    line-height: 1.5rem;
}

.text-lg {
    font-size: 1.125rem;
    line-height: 1.75rem;
}

.font-semibold {
    font-weight: 600;
}

.text-blue-700 {
    --tw-text-opacity: 1;
    color: rgb(29 78 216 / var(--tw-text-opacity));
}

.text-white {
    --tw-text-opacity: 1;
    color: rgb(255 255 255 / var(--tw-text-opacity));
}

.shadow-lg {
    --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
    --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
    box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.transition {
    transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, -webkit-backdrop-filter;
    transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
    transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter, -webkit-backdrop-filter;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-duration: 150ms;
}

.duration-300 {
    transition-duration: 300ms;
}


/* Class styles components */
body, html {
    min-height: 100vh;
}

.hover\\:bg-blue-700:hover {
    --tw-bg-opacity: 1;
    background-color: rgb(29 78 216 / var(--tw-bg-opacity));
}

@media (min-width: 768px) {
    .md\\:px-8 {
        padding-left: 2rem;
        padding-right: 2rem;
    }
}

@media (min-width: 1024px) {
    .lg\\:px-16 {
        padding-left: 4rem;
        padding-right: 4rem;
    }
}
`),s.addStylesheet("tailwind_theme/tailwind_for_wp_editor.css",`@import url('https://fonts.googleapis.com/css?family=Sora:100,200,300,400,500,600,700,800&display=swap');



*,::before,::after {
  box-sizing: border-box;
}

a {
          color: inherit;
          text-decoration: inherit;
        }
        ol,
        ul,
        menu {
          list-style: none;
          margin: 0;
          padding: 0;
        }
        
        blockquote,
        dl,
        dd,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        hr,
        figure,
        p,
        pre {
          margin: 0;
        }                        

html {
  font-family: 'Sora', sans-serif;
}                      

body{
  color: var(--tw-prose-body);
  max-width: 65ch;
}
body :where(p):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-top: 1.25em;
  margin-bottom: 1.25em;
}
body :where([class~="lead"]):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: var(--tw-prose-lead);
  font-size: 1.25em;
  line-height: 1.6;
  margin-top: 1.2em;
  margin-bottom: 1.2em;
}
body :where(a):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: var(--tw-prose-links);
  text-decoration: underline;
  font-weight: 500;
}
body :where(strong):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: var(--tw-prose-bold);
  font-weight: 600;
}
body :where(a strong):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: inherit;
}
body :where(blockquote strong):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: inherit;
}
body :where(thead th strong):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: inherit;
}
body :where(ol):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  list-style-type: decimal;
  margin-top: 1.25em;
  margin-bottom: 1.25em;
  padding-inline-start: 1.625em;
}
body :where(ol[type="A"]):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  list-style-type: upper-alpha;
}
body :where(ol[type="a"]):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  list-style-type: lower-alpha;
}
body :where(ol[type="A" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  list-style-type: upper-alpha;
}
body :where(ol[type="a" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  list-style-type: lower-alpha;
}
body :where(ol[type="I"]):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  list-style-type: upper-roman;
}
body :where(ol[type="i"]):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  list-style-type: lower-roman;
}
body :where(ol[type="I" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  list-style-type: upper-roman;
}
body :where(ol[type="i" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  list-style-type: lower-roman;
}
body :where(ol[type="1"]):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  list-style-type: decimal;
}
body :where(ul):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  list-style-type: disc;
  margin-top: 1.25em;
  margin-bottom: 1.25em;
  padding-inline-start: 1.625em;
}
body :where(ol > li):not(:where([class~="not-prose"],[class~="not-prose"] *))::marker{
  font-weight: 400;
  color: var(--tw-prose-counters);
}
body :where(ul > li):not(:where([class~="not-prose"],[class~="not-prose"] *))::marker{
  color: var(--tw-prose-bullets);
}
body :where(dt):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: var(--tw-prose-headings);
  font-weight: 600;
  margin-top: 1.25em;
}
body :where(hr):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  border-color: var(--tw-prose-hr);
  border-top-width: 1px;
  margin-top: 3em;
  margin-bottom: 3em;
}
body :where(blockquote):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  font-weight: 500;
  font-style: italic;
  color: var(--tw-prose-quotes);
  border-inline-start-width: 0.25rem;
  border-inline-start-color: var(--tw-prose-quote-borders);
  quotes: "\\201C""\\201D""\\2018""\\2019";
  margin-top: 1.6em;
  margin-bottom: 1.6em;
  padding-inline-start: 1em;
}
body :where(blockquote p:first-of-type):not(:where([class~="not-prose"],[class~="not-prose"] *))::before{
  content: open-quote;
}
body :where(blockquote p:last-of-type):not(:where([class~="not-prose"],[class~="not-prose"] *))::after{
  content: close-quote;
}
body :where(h1):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: var(--tw-prose-headings);
  font-weight: 800;
  font-size: 2.25em;
  margin-top: 0;
  margin-bottom: 0.8888889em;
  line-height: 1.1111111;
}
body :where(h1 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  font-weight: 900;
  color: inherit;
}
body :where(h2):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: var(--tw-prose-headings);
  font-weight: 700;
  font-size: 1.5em;
  margin-top: 2em;
  margin-bottom: 1em;
  line-height: 1.3333333;
}
body :where(h2 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  font-weight: 800;
  color: inherit;
}
body :where(h3):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: var(--tw-prose-headings);
  font-weight: 600;
  font-size: 1.25em;
  margin-top: 1.6em;
  margin-bottom: 0.6em;
  line-height: 1.6;
}
body :where(h3 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  font-weight: 700;
  color: inherit;
}
body :where(h4):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: var(--tw-prose-headings);
  font-weight: 600;
  margin-top: 1.5em;
  margin-bottom: 0.5em;
  line-height: 1.5;
}
body :where(h4 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  font-weight: 700;
  color: inherit;
}
body :where(img):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-top: 2em;
  margin-bottom: 2em;
}
body :where(picture):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  display: block;
  margin-top: 2em;
  margin-bottom: 2em;
}
body :where(video):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-top: 2em;
  margin-bottom: 2em;
}
body :where(kbd):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  font-weight: 500;
  font-family: inherit;
  color: var(--tw-prose-kbd);
  box-shadow: 0 0 0 1px rgb(var(--tw-prose-kbd-shadows) / 10%), 0 3px 0 rgb(var(--tw-prose-kbd-shadows) / 10%);
  font-size: 0.875em;
  border-radius: 0.3125rem;
  padding-top: 0.1875em;
  padding-inline-end: 0.375em;
  padding-bottom: 0.1875em;
  padding-inline-start: 0.375em;
}
body :where(code):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: var(--tw-prose-code);
  font-weight: 600;
  font-size: 0.875em;
}
body :where(code):not(:where([class~="not-prose"],[class~="not-prose"] *))::before{
  content: "\`";
}
body :where(code):not(:where([class~="not-prose"],[class~="not-prose"] *))::after{
  content: "\`";
}
body :where(a code):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: inherit;
}
body :where(h1 code):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: inherit;
}
body :where(h2 code):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: inherit;
  font-size: 0.875em;
}
body :where(h3 code):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: inherit;
  font-size: 0.9em;
}
body :where(h4 code):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: inherit;
}
body :where(blockquote code):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: inherit;
}
body :where(thead th code):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: inherit;
}
body :where(pre):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: var(--tw-prose-pre-code);
  background-color: var(--tw-prose-pre-bg);
  overflow-x: auto;
  font-weight: 400;
  font-size: 0.875em;
  line-height: 1.7142857;
  margin-top: 1.7142857em;
  margin-bottom: 1.7142857em;
  border-radius: 0.375rem;
  padding-top: 0.8571429em;
  padding-inline-end: 1.1428571em;
  padding-bottom: 0.8571429em;
  padding-inline-start: 1.1428571em;
}
body :where(pre code):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  background-color: transparent;
  border-width: 0;
  border-radius: 0;
  padding: 0;
  font-weight: inherit;
  color: inherit;
  font-size: inherit;
  font-family: inherit;
  line-height: inherit;
}
body :where(pre code):not(:where([class~="not-prose"],[class~="not-prose"] *))::before{
  content: none;
}
body :where(pre code):not(:where([class~="not-prose"],[class~="not-prose"] *))::after{
  content: none;
}
body :where(table):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  width: 100%;
  table-layout: auto;
  text-align: start;
  margin-top: 2em;
  margin-bottom: 2em;
  font-size: 0.875em;
  line-height: 1.7142857;
}
body :where(thead):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  border-bottom-width: 1px;
  border-bottom-color: var(--tw-prose-th-borders);
}
body :where(thead th):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: var(--tw-prose-headings);
  font-weight: 600;
  vertical-align: bottom;
  padding-inline-end: 0.5714286em;
  padding-bottom: 0.5714286em;
  padding-inline-start: 0.5714286em;
}
body :where(tbody tr):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  border-bottom-width: 1px;
  border-bottom-color: var(--tw-prose-td-borders);
}
body :where(tbody tr:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  border-bottom-width: 0;
}
body :where(tbody td):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  vertical-align: baseline;
}
body :where(tfoot):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  border-top-width: 1px;
  border-top-color: var(--tw-prose-th-borders);
}
body :where(tfoot td):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  vertical-align: top;
}
body :where(figure > *):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-top: 0;
  margin-bottom: 0;
}
body :where(figcaption):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  color: var(--tw-prose-captions);
  font-size: 0.875em;
  line-height: 1.4285714;
  margin-top: 0.8571429em;
}
body{
  --tw-prose-body: #374151;
  --tw-prose-headings: #111827;
  --tw-prose-lead: #4b5563;
  --tw-prose-links: #111827;
  --tw-prose-bold: #111827;
  --tw-prose-counters: #6b7280;
  --tw-prose-bullets: #d1d5db;
  --tw-prose-hr: #e5e7eb;
  --tw-prose-quotes: #111827;
  --tw-prose-quote-borders: #e5e7eb;
  --tw-prose-captions: #6b7280;
  --tw-prose-kbd: #111827;
  --tw-prose-kbd-shadows: 17 24 39;
  --tw-prose-code: #111827;
  --tw-prose-pre-code: #e5e7eb;
  --tw-prose-pre-bg: #1f2937;
  --tw-prose-th-borders: #d1d5db;
  --tw-prose-td-borders: #e5e7eb;
  --tw-prose-invert-body: #d1d5db;
  --tw-prose-invert-headings: #fff;
  --tw-prose-invert-lead: #9ca3af;
  --tw-prose-invert-links: #fff;
  --tw-prose-invert-bold: #fff;
  --tw-prose-invert-counters: #9ca3af;
  --tw-prose-invert-bullets: #4b5563;
  --tw-prose-invert-hr: #374151;
  --tw-prose-invert-quotes: #f3f4f6;
  --tw-prose-invert-quote-borders: #374151;
  --tw-prose-invert-captions: #9ca3af;
  --tw-prose-invert-kbd: #fff;
  --tw-prose-invert-kbd-shadows: 255 255 255;
  --tw-prose-invert-code: #fff;
  --tw-prose-invert-pre-code: #d1d5db;
  --tw-prose-invert-pre-bg: rgb(0 0 0 / 50%);
  --tw-prose-invert-th-borders: #4b5563;
  --tw-prose-invert-td-borders: #374151;
  font-size: 1rem;
  line-height: 1.75;
}
body :where(picture > img):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-top: 0;
  margin-bottom: 0;
}
body :where(li):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-top: 0.5em;
  margin-bottom: 0.5em;
}
body :where(ol > li):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  padding-inline-start: 0.375em;
}
body :where(ul > li):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  padding-inline-start: 0.375em;
}
body :where(.prose > ul > li p):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-top: 0.75em;
  margin-bottom: 0.75em;
}
body :where(.prose > ul > li > *:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-top: 1.25em;
}
body :where(.prose > ul > li > *:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-bottom: 1.25em;
}
body :where(.prose > ol > li > *:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-top: 1.25em;
}
body :where(.prose > ol > li > *:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-bottom: 1.25em;
}
body :where(ul ul, ul ol, ol ul, ol ol):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-top: 0.75em;
  margin-bottom: 0.75em;
}
body :where(dl):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-top: 1.25em;
  margin-bottom: 1.25em;
}
body :where(dd):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-top: 0.5em;
  padding-inline-start: 1.625em;
}
body :where(hr + *):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-top: 0;
}
body :where(h2 + *):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-top: 0;
}
body :where(h3 + *):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-top: 0;
}
body :where(h4 + *):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-top: 0;
}
body :where(thead th:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  padding-inline-start: 0;
}
body :where(thead th:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  padding-inline-end: 0;
}
body :where(tbody td, tfoot td):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  padding-top: 0.5714286em;
  padding-inline-end: 0.5714286em;
  padding-bottom: 0.5714286em;
  padding-inline-start: 0.5714286em;
}
body :where(tbody td:first-child, tfoot td:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  padding-inline-start: 0;
}
body :where(tbody td:last-child, tfoot td:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  padding-inline-end: 0;
}
body :where(figure):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-top: 2em;
  margin-bottom: 2em;
}
body :where(.prose > :first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-top: 0;
}
body :where(.prose > :last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)){
  margin-bottom: 0;
}
body{
  max-width: none;
}
pre:where(.editor-styles-wrapper *){
  --tw-text-opacity: 1 !important;
  color: rgb(249 250 251 / var(--tw-text-opacity)) !important;
}
nav:where(.admin-bar *){
  top: var(--wp-admin--admin-bar--height);
}
.mb-6{
  margin-bottom: 1.5rem;
}
.flex{
  display: flex;
}
.items-center{
  align-items: center;
}
.space-x-3 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse: 0;
  margin-right: calc(0.75rem * var(--tw-space-x-reverse));
  margin-left: calc(0.75rem * calc(1 - var(--tw-space-x-reverse)));
}
.rounded-r{
  border-top-right-radius: 0.25rem;
  border-bottom-right-radius: 0.25rem;
}
.border-l-4{
  border-left-width: 4px;
}
.border-blue-500{
  --tw-border-opacity: 1;
  border-color: rgb(59 130 246 / var(--tw-border-opacity));
}
.bg-blue-100{
  --tw-bg-opacity: 1;
  background-color: rgb(219 234 254 / var(--tw-bg-opacity));
}
.bg-yellow-50{
  --tw-bg-opacity: 1;
  background-color: rgb(255 251 235 / var(--tw-bg-opacity));
}
.p-4{
  padding: 1rem;
}
.px-4{
  padding-left: 1rem;
  padding-right: 1rem;
}
.py-4{
  padding-top: 1rem;
  padding-bottom: 1rem;
}
.font-sans{
  font-family: 'Sora', sans-serif;
}
.text-base{
  font-size: 1rem;
  line-height: 1.5rem;
}
.text-blue-700{
  --tw-text-opacity: 1;
  color: rgb(29 78 216 / var(--tw-text-opacity));
}


                    
/* Class styles components */                    
body, html {
    min-height: 100vh;
}                    
@media (min-width: 768px){.md\\:px-8{
    padding-left: 2rem;
    padding-right: 2rem;
  }
}                    
@media (min-width: 1024px){.lg\\:px-16{
    padding-left: 4rem;
    padding-right: 4rem;
  }
}
`),s.addPage("pinegrow.json",`{"files":{"index.html":{"frameworks":["BlockThemeTailwindTemplate","wordpress.pinegrow","pg.insight.events","pg.tw.lib","pg.asset.manager","pg.project.items","pg.code-validator","pg.image.overlay","pg.css.grid","pg.svg.lib","tw.flowbite","tw","pg.html","pine.cone.lib","pg.components"]},"style.html":{"frameworks":["StyledGarden","pg.insight.events","pg.svg.lib","pg.tw.lib","pg.css.grid","pg.image.overlay","pg.code-validator","pg.project.items","pg.asset.manager","tw.flowbite","tw","pg.html","pine.cone.lib","pg.components"]},"style-guide.html":{"frameworks":["StyledGarden","pg.insight.events","pg.svg.lib","pg.tw.lib","pg.css.grid","pg.image.overlay","pg.code-validator","pg.project.items","pg.asset.manager","tw.flowbite","tw","pg.html","pine.cone.lib","pg.components"]}},"breakpoints":["640px","768px","1024px"],"frameworks":["BlockThemeTailwindTemplate","wordpress.pinegrow","pg.insight.events","pg.tw.lib","pg.asset.manager","pg.project.items","pg.code-validator","pg.image.overlay","pg.css.grid","pg.svg.lib","tw.flowbite","tw","pg.html","pine.cone.lib","pg.components"],"template_framework_id":"tailwind","urls":{"index.html":{"open-page-views":[{"w":640,"h":0,"wrapper_url":null,"wrapper_selector":"auto_detect","wrapper_data":{"selector":"auto_detect","url":"_none_","name":"None - no preview","post_id":null}}],"open-with-wrapper":false},"style.html":{"open-with-wrapper":false,"open-page-views":[{"w":1024,"h":0}]},"style-guide.html":{"open-with-wrapper":false,"open-page-views":[{"w":1024,"h":0}]}},"open-pages":["index.html","style-guide.html"],"active-design-provider":"tw","ai-project-brief":null,"netlify-site-domain":"gardenhose.netlify.app","recent-classes":["text-base","py-4","bg-yellow-50","py-24","sm:pt-40","md:pt-56","pt-32","bg-primary-50","faq-item","faq-answer","hover:text-white","text-gray-300","active","hover:text-primary-300","text-primary-400","z-10","w-full","fixed","lg:hidden","lg:flex","[&:where(.editor-styles-wrapper_*)]:text-gray-50","not-prose","max-w-none","prose","w-10","h-10","w-8","text-white","text-primary-500"],"wp-theme-info":{"dir":"/Users/Matjaz/Dropbox/Development/DVWeb/DV/Pinegrow/lab/PinegrowAcademy/WPBlockMaker/BlockThemeTailwindTemplate","name":"Block Theme with Tailwind","slug":"block_theme","url":null,"project_version":"1.0.0","auto_increment_version":"1","page":"index.html","themejson":"true","wpseo":"true","wpjquery":"false","generator":"true","images":{},"block_theme":"true","blocks_type":"native-hybrid","pg_version":"8.2","blocks_editor_styles":["tailwind_theme/tailwind_for_wp_editor.css","additional-editor-styles.css"],"project_type":"theme","blocks_inline_svg":"true","blocks_load_if_rendered":"false","block_category":"my_blocks","block_category_register":"true","block_category_name":"My blocks","wc_enabled":"false"},"wp-insight":{"menus":["footer_bottom","footer_resources","primary","social"],"taxonomies":["category","post_tag"],"customizer_sections":[],"customizer_controls":[],"post_types":["attachment","page","post"],"template_parts":[],"sidebars":[],"master_pages":[],"image_sizes":["full","large","medium","medium_large","post-thumbnail","thumbnail"],"custom_funcs":["echo 'https://barcode.orcascan.com/?type=qr&data=' . urlencode(get_permalink());","echo 'https://barcode.orcascan.com/?type=qr&data=' . urlencode(site_url());","echo 'https://twitter.com/intent/tweet?url=' . urlencode(get_permalink());","echo 'https://twitter.com/intent/tweet?url=' . urlencode(site_url());","echo 'https://www.facebook.com/sharer/sharer.php?u=' . urlencode(get_permalink());","echo 'https://www.facebook.com/sharer/sharer.php?u=' . urlencode(site_url());"],"block_categories":["styled_garden"]},"class-styles-components":"1","wp-recent-urls":[{"selector":"auto_detect","url":"http://styled-garden.local","name":"Home","post_id":null}]}`),s.addPage("projectdb.pgml",`<project>
    <documents></documents>
    <dmdesigns>
        <dmdesign active>
            <dmdesignskill skill="tw.colors">
                <dmcolor key="gray" color="rgba(107,114,128,1)" shade-50="rgba(249,250,251,1)" shade-100="rgba(243,244,246,1)" shade-200="rgba(229,231,235,1)" shade-300="rgba(209,213,219,1)" shade-400="rgba(156,163,175,1)" shade-500="rgba(107,114,128,1)" shade-600="rgba(75,85,99,1)" shade-700="rgba(55,65,81,1)" shade-800="rgba(31,41,55,1)" shade-900="rgba(17,24,39,1)"/>
                <dmcolor key="red" color="rgba(239,68,68,1)" shade-50="rgba(254,242,242,1)" shade-100="rgba(254,226,226,1)" shade-200="rgba(254,202,202,1)" shade-300="rgba(252,165,165,1)" shade-400="rgba(248,113,113,1)" shade-500="rgba(239,68,68,1)" shade-600="rgba(220,38,38,1)" shade-700="rgba(185,28,28,1)" shade-800="rgba(153,27,27,1)" shade-900="rgba(127,29,29,1)"/>
                <dmcolor key="yellow" color="rgba(245,158,11,1)" shade-50="rgba(255,251,235,1)" shade-100="rgba(254,243,199,1)" shade-200="rgba(253,230,138,1)" shade-300="rgba(252,211,77,1)" shade-400="rgba(251,191,36,1)" shade-500="rgba(245,158,11,1)" shade-600="rgba(217,119,6,1)" shade-700="rgba(180,83,9,1)" shade-800="rgba(146,64,14,1)" shade-900="rgba(120,53,15,1)"/>
                <dmcolor key="green" color="rgba(16,185,129,1)" shade-50="rgba(236,253,245,1)" shade-100="rgba(209,250,229,1)" shade-200="rgba(167,243,208,1)" shade-300="rgba(110,231,183,1)" shade-400="rgba(52,211,153,1)" shade-500="rgba(16,185,129,1)" shade-600="rgba(5,150,105,1)" shade-700="rgba(4,120,87,1)" shade-800="rgba(6,95,70,1)" shade-900="rgba(6,78,59,1)"/>
                <dmcolor key="blue" color="rgba(59,130,246,1)" shade-50="rgba(239,246,255,1)" shade-100="rgba(219,234,254,1)" shade-200="rgba(191,219,254,1)" shade-300="rgba(147,197,253,1)" shade-400="rgba(96,165,250,1)" shade-500="rgba(59,130,246,1)" shade-600="rgba(37,99,235,1)" shade-700="rgba(29,78,216,1)" shade-800="rgba(30,64,175,1)" shade-900="rgba(30,58,138,1)"/>
                <dmcolor key="indigo" color="rgba(99,102,241,1)" shade-50="rgba(238,242,255,1)" shade-100="rgba(224,231,255,1)" shade-200="rgba(199,210,254,1)" shade-300="rgba(165,180,252,1)" shade-400="rgba(129,140,248,1)" shade-500="rgba(99,102,241,1)" shade-600="rgba(79,70,229,1)" shade-700="rgba(67,56,202,1)" shade-800="rgba(55,48,163,1)" shade-900="rgba(49,46,129,1)"/>
                <dmcolor key="purple" color="rgba(139,92,246,1)" shade-50="rgba(245,243,255,1)" shade-100="rgba(237,233,254,1)" shade-200="rgba(221,214,254,1)" shade-300="rgba(196,181,253,1)" shade-400="rgba(167,139,250,1)" shade-500="rgba(139,92,246,1)" shade-600="rgba(124,58,237,1)" shade-700="rgba(109,40,217,1)" shade-800="rgba(91,33,182,1)" shade-900="rgba(76,29,149,1)"/>
                <dmcolor key="pink" color="rgba(236,72,153,1)" shade-50="rgba(253,242,248,1)" shade-100="rgba(252,231,243,1)" shade-200="rgba(251,207,232,1)" shade-300="rgba(249,168,212,1)" shade-400="rgba(244,114,182,1)" shade-500="rgba(236,72,153,1)" shade-600="rgba(219,39,119,1)" shade-700="rgba(190,24,93,1)" shade-800="rgba(157,23,77,1)" shade-900="rgba(131,24,67,1)"/>
                <dmcolor key="primary" color="rgb(252 73 110)" shade-50="#ffedef" shade-100="#ffd1d5" shade-200="#ffb4bb" shade-300="#ff95a2" shade-400="#ff7387" shade-500="rgb(252 73 110)" shade-600="#e14162" shade-700="#c73a57" shade-800="#ae324c" shade-900="#952b41"/>
                <dmcolor key="secondary" color="rgb(130 2 28)" shade-50="#f0ebeb" shade-100="#e0bfbd" shade-200="#cc9491" shade-300="#b66a67" shade-400="#9d3f40" shade-500="rgb(130 2 28)" shade-600="#740219" shade-700="#670217" shade-800="#5a0114" shade-900="#4d0111"/>
                <dmcolor key="color3" color="rgb(252 125 148)" shade-50="#fff0f2" shade-100="#ffdadf" shade-200="#ffc4cc" shade-300="#ffaeb9" shade-400="#ff95a6" shade-500="rgb(252 125 148)" shade-600="#e17084" shade-700="#c76375" shade-800="#ae5666" shade-900="#954a58"/>
                <dmcolor key="color4" color="rgb(150 2 33)" shade-50="#f2ebeb" shade-100="#e6c1bf" shade-200="#d79793" shade-300="#c46e6b" shade-400="#ae4344" shade-500="rgb(150 2 33)" shade-600="#86021e" shade-700="#77021a" shade-800="#680117" shade-900="#590114"/>
            </dmdesignskill>
            <dmdesignskill skill="fonts" family_1="Sora" family_2="&quot;Palatino Linotype&quot;, &quot;Book Antiqua&quot;, Palatino, serif"></dmdesignskill>
            <dmdesignskill skill="background" image_for_colors="true" advanced="true" filter_blur="0" filter_brightness="100" filter_contrast="100" filter_grayscale="0" filter_hue-rotate="0" filter_invert="0" filter_opacity="100" filter_saturate="100" filter_sepia="0" image></dmdesignskill>
            <dmdesignskill skill="tailwind"></dmdesignskill>
        </dmdesign>
    </dmdesigns>
    <dmlocked tw-colors-gray="true" tw-colors-red="true" tw-colors-yellow="true" tw-colors-green="true" tw-colors-blue="true" tw-colors-indigo="true" tw-colors-purple="true" tw-colors-pink="true"></dmlocked>
    <classstyles>
        <classstyle name="body" key="body" class="max-w-none prose" component expanded></classstyle>
        <classstyle name="nav .active" key="nav .active" class="text-primary-400 hover:text-primary-300" component></classstyle>
        <classstyle name="pre" key="pre" class="[&:where(.editor-styles-wrapper_*)]:!text-gray-50" component states=""></classstyle>
        <deleted key=".wp-block-button.aligncenter" component class="text-center mx-auto mb-4"></deleted>
        <deleted key=".wp-block-button.alignleft" component class="float-left mr-4 mb-4"></deleted>
        <deleted key=".wp-block-button.alignright" component class="float-right ml-4 mb-4"></deleted>
        <deleted key="table" component class="w-full border-collapse bg-white shadow-lg rounded-lg overflow-hidden mb-8 [&_thead_th]:text-white [&_thead_th]:px-6 [&_thead_th]:py-4 [&_th]:text-left [&_td]:px-6 [&_td]:py-4 [&_tbody_tr:nth-child(even)]:bg-gray-100 [&_tbody_th]:font-semibold [&_tbody_td]:text-gray-600 border-gray-200 [&_tbody_tr:hover]:!bg-primary-50 [&_tr_th:first-child]:pl-8 [&_tr_td:first-child]:pl-8 [&_thead]:bg-secondary-400"></deleted>
        <deleted key=".wp-block-button__link" component class="inline-block px-6 py-3 text-white bg-primary-600 rounded-full font-semibold transition-all duration-300 hover:bg-primary-700 hover:shadow-lg focus:ring-4 focus:ring-primary-200 active:bg-primary-800"></deleted>
        <deleted key=".is-style-outline .wp-block-button__link" component class="inline-block px-6 py-3 text-primary-600 bg-transparent border-2 border-primary-600 rounded-full font-semibold transition-all duration-300 hover:bg-primary-50 hover:shadow-lg focus:ring-4 focus:ring-primary-200 active:border-primary-800 active:text-primary-800"></deleted>
        <deleted key=".wp-block-button" component class="mb-4 [&.aligncenter]:text-center [&.aligncenter]:mx-auto [&.alignleft]:float-left [&.alignleft]:mr-4 [&.alignright]:float-right [&.alignright]:ml-4"></deleted>
        <classstyle name="nav" key="nav" class="[&:where(.admin-bar_*)]:top-[var(--wp-admin--admin-bar--height)]" expanded component states=""></classstyle>
    </classstyles>
</project>`),s.addPage("style.css",`/*
Theme Name: Styled Garden
Theme URI: http://example.com
Author: Your name
Author URI: http://pinegrow.com/
Description: This theme was created with Pinegrow Web Editor
Version: 1.0.54
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: styled_garden
*/`),s.addPage("additional-editor-styles.css",`body {
    padding-left: 2rem;
    padding-right: 2rem;
}`),d.addLesson(s);(e=new PgTutorialLesson("new_pinekit")).name="Blank Pinekit Project",a=`<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Pinekit template</title>
        <link rel="stylesheet" href="assets/vendor/bootstrap-icons/font/bootstrap-icons.css">
        <link href="pinekit_theme/pinekit.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        <header>
            <nav class="bg-white navbar navbar-expand-lg navbar-light">
                <div class="container"><a class="navbar-brand" href="#"><img class="navbar-brand-logo" src="assets/svg/logos/logo.svg" alt="Image Description"></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown-1" aria-controls="navbarNavDropdown-1" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> 
                    </button>
                    <div class="collapse navbar-collapse " id="navbarNavDropdown-1"> 
                        <ul class="ms-auto navbar-nav"> 
                            <li class="nav-item"> <a class="active nav-link" aria-current="page" href="#">Home</a> 
                            </li>                             
                            <li class="nav-item"> <a class="nav-link" href="#">About</a> 
                            </li>                             
                            <li class="nav-item"> <a class="nav-link" href="#">Features</a> 
                            </li>                             
                            <li class="nav-item"> <a class="nav-link" href="#">Services</a> 
                            </li>                             
                            <li class="nav-item"> <a class="nav-link" href="#">Contact</a> 
                            </li>                             
                            <li class="nav-item dropdown"> <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">                                     Dropdown link </a> 
                                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink"> <a class="dropdown-item" href="#">Action</a> <a class="dropdown-item" href="#">Another action</a> <a class="dropdown-item" href="#">Something else here</a> 
                                </div>                                 
                            </li>                             
                        </ul>                         
                    </div>
                </div>                 
            </nav>
        </header>
        <main role="main" data-pgc-field="main">
            <section style="min-height: 50vh; display: flex; align-items: center; justify-content: center; background-color: #f1f1f1;">The content goes into&nbsp;<code>&lt;main&gt;</code>. Delete this section.
            </section>
        </main>
        <footer class="bg-dark">
            <div class="container">
                <div class="row align-items-center pt-8 pb-4">
                    <div class="col-md mb-5 mb-md-0">
                        <h2 class="fw-medium text-white-70 mb-0">Join the thriving<br><span class="fw-bold text-white">Pinekit</span> business agency</h2>
                    </div>
                    <!-- End Col -->
                    <div class="col-md-auto">
                        <div class="d-grid d-sm-flex gap-3">
                            <a class="btn btn-primary" href="#">Request demo</a>
                            <a class="btn btn-ghost-light btn-pointer" href="#">Sign up free</a>
                        </div>
                    </div>
                    <!-- End Col -->
                </div>
                <!-- End Row -->
                <div class="border-bottom border-white-10">
                    <div class="row py-6">
                        <div class="col-6 col-sm-4 col-lg mb-7 mb-lg-0">
                            <span class="text-cap text-white">Resources</span>
                            <!-- List -->
                            <ul class="list-unstyled list-py-1 mb-0">
                                <li><a class="link link-light link-light-75" href="#">Blog</a>
                                </li>
                                <li><a class="link link-light link-light-75" href="#">Guidance</a>
                                </li>
                                <li><a class="link link-light link-light-75" href="#">Customer Stories</a>
                                </li>
                                <li><a class="link link-light link-light-75" href="#">Support <i class="bi-box-arrow-up-right ms-1"></i></a>
                                </li>
                                <li><a class="link link-light link-light-75" href="#">API</a>
                                </li>
                                <li><a class="link link-light link-light-75" href="#">Packages</a>
                                </li>
                            </ul>
                            <!-- End List -->
                        </div>
                        <!-- End Col -->
                        <div class="col-6 col-sm-4 col-lg mb-7 mb-lg-0">
                            <span class="text-cap text-white">Company</span>
                            <!-- List -->
                            <ul class="list-unstyled list-py-1 mb-0">
                                <li><a class="link link-light link-light-75" href="#">Belonging <i class="bi-box-arrow-up-right ms-1"></i></a>
                                </li>
                                <li><a class="link link-light link-light-75" href="#">Company</a>
                                </li>
                                <li><a class="link link-light link-light-75" href="#">Careers</a> <span class="fs-6 fw-bold text-primary">&mdash; We're hiring</span>
                                </li>
                                <li><a class="link link-light link-light-75" href="#">Contacts</a>
                                </li>
                                <li><a class="link link-light link-light-75" href="#">Security</a>
                                </li>
                            </ul>
                            <!-- End List -->
                        </div>
                        <!-- End Col -->
                        <div class="col-6 col-sm-4 col-lg mb-7 mb-sm-0">
                            <span class="text-cap text-white">Platform</span>
                            <!-- List -->
                            <ul class="list-unstyled list-py-1 mb-0">
                                <li><a class="link link-light link-light-75" href="#">Web</a>
                                </li>
                                <li><a class="link link-light link-light-75" href="#">Mobile</a>
                                </li>
                                <li><a class="link link-light link-light-75" href="#">iOS</a>
                                </li>
                                <li><a class="link link-light link-light-75" href="#">Android</a>
                                </li>
                                <li><a class="link link-light link-light-75" href="#">Figma Importing</a>
                                </li>
                            </ul>
                            <!-- End List -->
                        </div>
                        <!-- End Col -->
                        <div class="col-6 col-sm-4 col-lg mb-7 mb-sm-0">
                            <span class="text-cap text-white">Legal</span>
                            <!-- List -->
                            <ul class="list-unstyled list-py-1 mb-5">
                                <li><a class="link link-light link-light-75" href="#">Terms of use</a>
                                </li>
                                <li><a class="link link-light link-light-75" href="#">Privacy policy <i class="bi-box-arrow-up-right ms-1"></i></a>
                                </li>
                            </ul>
                            <!-- End List -->
                            <span class="text-cap text-white">Docs</span>
                            <!-- List -->
                            <ul class="list-unstyled list-py-1 mb-0">
                                <li><a class="link link-light link-light-75" href="#">Documentation</a>
                                </li>
                                <li><a class="link link-light link-light-75" href="#">Snippets</a>
                                </li>
                            </ul>
                            <!-- End List -->
                        </div>
                        <!-- End Col -->
                        <div class="col-6 col-sm-4 col-lg">
                            <span class="text-cap text-white">Follow us</span>
                            <!-- List -->
                            <ul class="list-unstyled list-py-2 mb-0">
                                <li><a class="link link-light link-light-75" href="#"> <div class="d-flex">
                                            <div class="flex-shrink-0">
                                                <i class="bi-envelope-open-fill"></i>
                                            </div>
                                            <div class="flex-grow-1 ms-2">
                                                <span>Subscribe by email</span>
                                            </div>
                                        </div> </a>
                                </li>
                                <li><a class="link link-light link-light-75" href="#"> <div class="d-flex">
                                            <div class="flex-shrink-0">
                                                <i class="bi-facebook"></i>
                                            </div>
                                            <div class="flex-grow-1 ms-2">
                                                <span>Facebook</span>
                                            </div>
                                        </div> </a>
                                </li>
                                <li><a class="link link-light link-light-75" href="#"> <div class="d-flex">
                                            <div class="flex-shrink-0">
                                                <i class="bi-linkedin"></i>
                                            </div>
                                            <div class="flex-grow-1 ms-2">
                                                <span>Linkedin</span>
                                            </div>
                                        </div> </a>
                                </li>
                                <li><a class="link link-light link-light-75" href="#"> <div class="d-flex">
                                            <div class="flex-shrink-0">
                                                <i class="bi-twitter"></i>
                                            </div>
                                            <div class="flex-grow-1 ms-2">
                                                <span>Twitter</span>
                                            </div>
                                        </div> </a>
                                </li>
                                <li><a class="link link-light link-light-75" href="#"> <div class="d-flex">
                                            <div class="flex-shrink-0">
                                                <i class="bi-slack"></i>
                                            </div>
                                            <div class="flex-grow-1 ms-2">
                                                <span>Slack</span>
                                            </div>
                                        </div> </a>
                                </li>
                            </ul>
                            <!-- End List -->
                        </div>
                        <!-- End Col -->
                    </div>
                    <!-- End Row -->
                </div>
                <div class="row align-items-md-center py-6">
                    <div class="col-md mb-3 mb-md-0">
                        <!-- List -->
                        <ul class="list-inline list-px-2 mb-0">
                            <li class="list-inline-item"><a class="link link-light link-light-75" href="#">Privacy and Policy</a>
                            </li>
                            <li class="list-inline-item"><a class="link link-light link-light-75" href="#">Terms</a>
                            </li>
                            <li class="list-inline-item"><a class="link link-light link-light-75" href="#">Status</a>
                            </li>
                            <li class="list-inline-item">
                                <!-- Button Group -->
                                <div class="btn-group">
                                    <a class="link link-light link-light-75" href="javascript:;" id="selectLanguage" data-bs-toggle="dropdown" aria-expanded="false"> <span class="d-flex align-items-center"> <img class="avatar avatar-xss avatar-circle me-2" src="assets/vendor/flag-icon-css/flags/1x1/us.svg" alt="Image description" width="16"/> <span>English</span> </span> </a>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item d-flex align-items-center active" href="#"> <img class="avatar avatar-xss avatar-circle me-2" src="assets/vendor/flag-icon-css/flags/1x1/us.svg" alt="Image description" width="16"/> <span>English</span> </a>
                                        <a class="dropdown-item d-flex align-items-center" href="#"> <img class="avatar avatar-xss avatar-circle me-2" src="assets/vendor/flag-icon-css/flags/1x1/de.svg" alt="Image description" width="16"/> <span>Deutsch</span> </a>
                                        <a class="dropdown-item d-flex align-items-center" href="#"> <img class="avatar avatar-xss avatar-circle me-2" src="assets/vendor/flag-icon-css/flags/1x1/es.svg" alt="Image description" width="16"/> <span>Español</span> </a>
                                    </div>
                                </div>
                                <!-- End Button Group -->
                            </li>
                        </ul>
                        <!-- End List -->
                    </div>
                    <!-- End Col -->
                    <div class="col-md-auto">
                        <p class="fs-5 text-white-70 mb-0">© Pinekit, 2024</p>
                    </div>
                    <!-- End Col -->
                </div>
                <!-- End Row -->
            </div>
        </footer>
        <script src="assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>`,e.addStylesheet("css/style.css",""),e.addPage("pinegrow.json",`{
  "files": {
    "index.html": {
      "frameworks": [
        "PinekitBlocks",
        "pg.bs5.lib",
        "pg.asset.manager",
        "pg.insight.events",
        "pg.project.items",
        "pg.code-validator",
        "pg.pinekit.blocks",
        "pg.image.overlay",
        "pg.css.grid",
        "bs5",
        "pg.ai.lib",
        "pg.html",
        "pg.components"
      ]
    }
  },
  "open-pages": [
    "index.html"
  ],
  "urls": {
    "index.html": {
      "open-with-wrapper": false,
      "open-page-views": [
        {
          "w": 1024,
          "h": 0
        }
      ]
    }
  },
  "active-design-provider": "bs5",
  "frameworks": [
    "PinekitBlocks",
    "pg.bs5.lib",
    "pg.asset.manager",
    "pg.insight.events",
    "pg.project.items",
    "pg.code-validator",
    "pg.pinekit.blocks",
    "pg.image.overlay",
    "pg.css.grid",
    "bs5",
    "pg.ai.lib",
    "pg.html",
    "pg.components"
  ],
  "template_framework_id": "PinekitBlocks"
}`),e.addStylesheet("pinekit_theme/pinekit.css",`@charset "UTF-8";
@import url("https://fonts.googleapis.com/css?family=Inter:100,200,300,400,500,600,700,800,900&display=swap");
.card.card-ghost {
  box-shadow: none;
}

.card.card-ghost {
  box-shadow: none;
}

/*!
 * Bootstrap  v5.3.2 (https://getbootstrap.com/)
 * Copyright 2011-2023 The Bootstrap Authors
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
:root,
[data-bs-theme=light] {
  --bs-blue: #334AC0;
  --bs-indigo: #6610f2;
  --bs-purple: #6f42c1;
  --bs-pink: #d63384;
  --bs-red: #692340;
  --bs-orange: #fd7e14;
  --bs-yellow: #f39568;
  --bs-green: #0ABF53;
  --bs-teal: #077C76;
  --bs-cyan: #0dcaf0;
  --bs-black: #000;
  --bs-white: white;
  --bs-gray: #8C98A4;
  --bs-gray-dark: #51596C;
  --bs-gray-100: #F5F7FA;
  --bs-gray-200: #f3f6f9;
  --bs-gray-300: #dce0e5;
  --bs-gray-400: #BDC5D1;
  --bs-gray-500: #97A4AF;
  --bs-gray-600: #8C98A4;
  --bs-gray-700: #677788;
  --bs-gray-800: #51596C;
  --bs-gray-900: #2d374b;
  --bs-primary: #0abf53;
  --bs-secondary: #51596c;
  --bs-success: #077c76;
  --bs-info: #334ac0;
  --bs-warning: #f39568;
  --bs-danger: #692340;
  --bs-light: #f8f9fa;
  --bs-dark: #2d374b;
  --bs-primary-rgb: 10, 191, 83;
  --bs-secondary-rgb: 81, 89, 108;
  --bs-success-rgb: 7, 124, 118;
  --bs-info-rgb: 51, 74, 192;
  --bs-warning-rgb: 243, 149, 104;
  --bs-danger-rgb: 105, 35, 64;
  --bs-light-rgb: 248, 249, 250;
  --bs-dark-rgb: 45, 55, 75;
  --bs-primary-text-emphasis: #044c21;
  --bs-secondary-text-emphasis: #20242b;
  --bs-success-text-emphasis: #03322f;
  --bs-info-text-emphasis: #141e4d;
  --bs-warning-text-emphasis: #613c2a;
  --bs-danger-text-emphasis: #2a0e1a;
  --bs-light-text-emphasis: #677788;
  --bs-dark-text-emphasis: #677788;
  --bs-primary-bg-subtle: #cef2dd;
  --bs-secondary-bg-subtle: #dcdee2;
  --bs-success-bg-subtle: #cde5e4;
  --bs-info-bg-subtle: #d6dbf2;
  --bs-warning-bg-subtle: #fdeae1;
  --bs-danger-bg-subtle: #e1d3d9;
  --bs-light-bg-subtle: #fafbfd;
  --bs-dark-bg-subtle: #BDC5D1;
  --bs-primary-border-subtle: #9de5ba;
  --bs-secondary-border-subtle: #b9bdc4;
  --bs-success-border-subtle: #9ccbc8;
  --bs-info-border-subtle: #adb7e6;
  --bs-warning-border-subtle: #fad5c3;
  --bs-danger-border-subtle: #c3a7b3;
  --bs-light-border-subtle: #f3f6f9;
  --bs-dark-border-subtle: #97A4AF;
  --bs-white-rgb: 255, 255, 255;
  --bs-black-rgb: 0, 0, 0;
  --bs-font-sans-serif: "Inter", sans-serif;
  --bs-font-monospace: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
  --bs-gradient: linear-gradient(180deg, rgba(255, 255, 255, 0.15), rgba(255, 255, 255, 0));
  --bs-body-font-family: "Inter", sans-serif;
  --bs-body-font-size: 1rem;
  --bs-body-font-weight: 400;
  --bs-body-line-height: 1.5;
  --bs-body-color: #51596C;
  --bs-body-color-rgb: 81, 89, 108;
  --bs-body-bg: white;
  --bs-body-bg-rgb: 255, 255, 255;
  --bs-emphasis-color: #000;
  --bs-emphasis-color-rgb: 0, 0, 0;
  --bs-secondary-color: rgba(81, 89, 108, 0.75);
  --bs-secondary-color-rgb: 81, 89, 108;
  --bs-secondary-bg: #f3f6f9;
  --bs-secondary-bg-rgb: 243, 246, 249;
  --bs-tertiary-color: rgba(81, 89, 108, 0.5);
  --bs-tertiary-color-rgb: 81, 89, 108;
  --bs-tertiary-bg: #F5F7FA;
  --bs-tertiary-bg-rgb: 245, 247, 250;
  --bs-heading-color: #2d374b;
  --bs-link-color: #0abf53;
  --bs-link-color-rgb: 10, 191, 83;
  --bs-link-decoration: none;
  --bs-link-hover-color: #07853a;
  --bs-link-hover-color-rgb: 7, 133, 58;
  --bs-code-color: #d63384;
  --bs-highlight-color: #51596C;
  --bs-highlight-bg: #fdeae1;
  --bs-border-width: 0.0625rem;
  --bs-border-style: solid;
  --bs-border-color: rgba(220, 224, 229, 0.6);
  --bs-border-color-translucent: rgba(0, 0, 0, 0.175);
  --bs-border-radius: 0.6rem;
  --bs-border-radius-sm: 0.4rem;
  --bs-border-radius-lg: 0.8rem;
  --bs-border-radius-xl: 1rem;
  --bs-border-radius-xxl: 2rem;
  --bs-border-radius-2xl: var(--bs-border-radius-xxl);
  --bs-border-radius-pill: 6.1875rem;
  --bs-box-shadow: 0rem 0.375rem 1.5rem 0rem rgba(140, 152, 164, 0.125);
  --bs-box-shadow-sm: 0rem 0.1875rem 0.375rem rgba(140, 152, 164, 0.25);
  --bs-box-shadow-lg: 0rem 1rem 1.75rem 0rem rgba(45, 55, 75, 0.1);
  --bs-box-shadow-inset: inset 0 1px 2px rgba(0, 0, 0, 0.075);
  --bs-focus-ring-width: 0.25rem;
  --bs-focus-ring-opacity: 0.25;
  --bs-focus-ring-color: rgba(10, 191, 83, 0.25);
  --bs-form-valid-color: #077c76;
  --bs-form-valid-border-color: #077c76;
  --bs-form-invalid-color: #692340;
  --bs-form-invalid-border-color: #692340;
}

[data-bs-theme=dark] {
  color-scheme: dark;
  --bs-body-color: #dce0e5;
  --bs-body-color-rgb: 220, 224, 229;
  --bs-body-bg: #2d374b;
  --bs-body-bg-rgb: 45, 55, 75;
  --bs-emphasis-color: white;
  --bs-emphasis-color-rgb: 255, 255, 255;
  --bs-secondary-color: rgba(220, 224, 229, 0.75);
  --bs-secondary-color-rgb: 220, 224, 229;
  --bs-secondary-bg: #51596C;
  --bs-secondary-bg-rgb: 81, 89, 108;
  --bs-tertiary-color: rgba(220, 224, 229, 0.5);
  --bs-tertiary-color-rgb: 220, 224, 229;
  --bs-tertiary-bg: #3f485c;
  --bs-tertiary-bg-rgb: 63, 72, 92;
  --bs-primary-text-emphasis: #6cd998;
  --bs-secondary-text-emphasis: #979ba7;
  --bs-success-text-emphasis: #6ab0ad;
  --bs-info-text-emphasis: #8592d9;
  --bs-warning-text-emphasis: #f8bfa4;
  --bs-danger-text-emphasis: #a57b8c;
  --bs-light-text-emphasis: #F5F7FA;
  --bs-dark-text-emphasis: #dce0e5;
  --bs-primary-bg-subtle: #022611;
  --bs-secondary-bg-subtle: #101216;
  --bs-success-bg-subtle: #011918;
  --bs-info-bg-subtle: #0a0f26;
  --bs-warning-bg-subtle: #311e15;
  --bs-danger-bg-subtle: #15070d;
  --bs-light-bg-subtle: #51596C;
  --bs-dark-bg-subtle: #292d36;
  --bs-primary-border-subtle: #067332;
  --bs-secondary-border-subtle: #313541;
  --bs-success-border-subtle: #044a47;
  --bs-info-border-subtle: #1f2c73;
  --bs-warning-border-subtle: #92593e;
  --bs-danger-border-subtle: #3f1526;
  --bs-light-border-subtle: #677788;
  --bs-dark-border-subtle: #51596C;
  --bs-heading-color: inherit;
  --bs-link-color: #6cd998;
  --bs-link-hover-color: #89e1ad;
  --bs-link-color-rgb: 108, 217, 152;
  --bs-link-hover-color-rgb: 137, 225, 173;
  --bs-code-color: #e685b5;
  --bs-highlight-color: #dce0e5;
  --bs-highlight-bg: #613c2a;
  --bs-border-color: #677788;
  --bs-border-color-translucent: rgba(255, 255, 255, 0.15);
  --bs-form-valid-color: #6cd998;
  --bs-form-valid-border-color: #6cd998;
  --bs-form-invalid-color: #a57b8c;
  --bs-form-invalid-border-color: #a57b8c;
}

*,
*::before,
*::after {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: var(--bs-body-font-family);
  font-size: var(--bs-body-font-size);
  font-weight: var(--bs-body-font-weight);
  line-height: var(--bs-body-line-height);
  color: var(--bs-body-color);
  text-align: var(--bs-body-text-align);
  background-color: var(--bs-body-bg);
  -webkit-text-size-adjust: 100%;
  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
}

hr {
  margin: 2rem 0;
  color: rgba(220, 224, 229, 0.6);
  border: 0;
  border-top: var(--bs-border-width) solid;
  opacity: 1;
}

h6, .h6, h5, .h5, h4, .h4, h3, .h3, h2, .h2, h1, .h1 {
  margin-top: 0;
  margin-bottom: 0.8125rem;
  font-weight: 700;
  line-height: 1.3;
  color: var(--bs-heading-color);
}

h1, .h1 {
  font-size: calc(1.4rem + 1.8vw);
}
@media (min-width: 1200px) {
  h1, .h1 {
    font-size: 2.75rem;
  }
}

h2, .h2 {
  font-size: calc(1.35rem + 1.2vw);
}
@media (min-width: 1200px) {
  h2, .h2 {
    font-size: 2.25rem;
  }
}

h3, .h3 {
  font-size: calc(1.3rem + 0.6vw);
}
@media (min-width: 1200px) {
  h3, .h3 {
    font-size: 1.75rem;
  }
}

h4, .h4 {
  font-size: calc(1.25625rem + 0.075vw);
}
@media (min-width: 1200px) {
  h4, .h4 {
    font-size: 1.3125rem;
  }
}

h5, .h5 {
  font-size: 1.125rem;
}

h6, .h6 {
  font-size: 1rem;
}

p {
  margin-top: 0;
  margin-bottom: 1rem;
}

abbr[title] {
  text-decoration: underline dotted;
  cursor: help;
  text-decoration-skip-ink: none;
}

address {
  margin-bottom: 1rem;
  font-style: normal;
  line-height: inherit;
}

ol,
ul {
  padding-left: 2rem;
}

ol,
ul,
dl {
  margin-top: 0;
  margin-bottom: 1rem;
}

ol ol,
ul ul,
ol ul,
ul ol {
  margin-bottom: 0;
}

dt {
  font-weight: 700;
}

dd {
  margin-bottom: 0.5rem;
  margin-left: 0;
}

blockquote {
  margin: 0 0 1rem;
}

b,
strong {
  font-weight: bolder;
}

small, .small {
  font-size: 0.875em;
}

mark, .mark {
  padding: 0.1875em;
  color: var(--bs-highlight-color);
  background-color: var(--bs-highlight-bg);
}

sub,
sup {
  position: relative;
  font-size: 0.75em;
  line-height: 0;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

a {
  color: rgba(var(--bs-link-color-rgb), var(--bs-link-opacity, 1));
  text-decoration: none;
}
a:hover {
  --bs-link-color-rgb: var(--bs-link-hover-color-rgb);
}

a:not([href]):not([class]), a:not([href]):not([class]):hover {
  color: inherit;
  text-decoration: none;
}

pre,
code,
kbd,
samp {
  font-family: var(--bs-font-monospace);
  font-size: 1em;
}

pre {
  display: block;
  margin-top: 0;
  margin-bottom: 1rem;
  overflow: auto;
  font-size: 1em;
}
pre code {
  font-size: inherit;
  color: inherit;
  word-break: normal;
}

code {
  font-size: 1em;
  color: var(--bs-code-color);
  word-wrap: break-word;
}
a > code {
  color: inherit;
}

kbd {
  padding: 0.1875rem 0.375rem;
  font-size: 1em;
  color: #2d374b;
  background-color: #dce0e5;
  border-radius: 0.4rem;
}
kbd kbd {
  padding: 0;
  font-size: 1em;
}

figure {
  margin: 0 0 1rem;
}

img,
svg {
  vertical-align: middle;
}

table {
  caption-side: bottom;
  border-collapse: collapse;
}

caption {
  padding-top: 0.75rem;
  padding-bottom: 0.75rem;
  color: var(--bs-secondary-color);
  text-align: left;
}

th {
  font-weight: 400;
  text-align: inherit;
  text-align: -webkit-match-parent;
}

thead,
tbody,
tfoot,
tr,
td,
th {
  border-color: inherit;
  border-style: solid;
  border-width: 0;
}

label {
  display: inline-block;
}

button {
  border-radius: 0;
}

button:focus:not(:focus-visible) {
  outline: 0;
}

input,
button,
select,
optgroup,
textarea {
  margin: 0;
  font-family: inherit;
  font-size: inherit;
  line-height: inherit;
}

button,
select {
  text-transform: none;
}

[role=button] {
  cursor: pointer;
}

select {
  word-wrap: normal;
}
select:disabled {
  opacity: 1;
}

[list]:not([type=date]):not([type=datetime-local]):not([type=month]):not([type=week]):not([type=time])::-webkit-calendar-picker-indicator {
  display: none !important;
}

button,
[type=button],
[type=reset],
[type=submit] {
  -webkit-appearance: button;
}
button:not(:disabled),
[type=button]:not(:disabled),
[type=reset]:not(:disabled),
[type=submit]:not(:disabled) {
  cursor: pointer;
}

::-moz-focus-inner {
  padding: 0;
  border-style: none;
}

textarea {
  resize: vertical;
}

fieldset {
  min-width: 0;
  padding: 0;
  margin: 0;
  border: 0;
}

legend {
  float: left;
  width: 100%;
  padding: 0;
  margin-bottom: 0.5rem;
  font-size: calc(1.275rem + 0.3vw);
  line-height: inherit;
}
@media (min-width: 1200px) {
  legend {
    font-size: 1.5rem;
  }
}
legend + * {
  clear: left;
}

::-webkit-datetime-edit-fields-wrapper,
::-webkit-datetime-edit-text,
::-webkit-datetime-edit-minute,
::-webkit-datetime-edit-hour-field,
::-webkit-datetime-edit-day-field,
::-webkit-datetime-edit-month-field,
::-webkit-datetime-edit-year-field {
  padding: 0;
}

::-webkit-inner-spin-button {
  height: auto;
}

[type=search] {
  -webkit-appearance: textfield;
  outline-offset: -2px;
}

/* rtl:raw:
[type="tel"],
[type="url"],
[type="email"],
[type="number"] {
  direction: ltr;
}
*/
::-webkit-search-decoration {
  -webkit-appearance: none;
}

::-webkit-color-swatch-wrapper {
  padding: 0;
}

::file-selector-button {
  font: inherit;
  -webkit-appearance: button;
}

output {
  display: inline-block;
}

iframe {
  border: 0;
}

summary {
  display: list-item;
  cursor: pointer;
}

progress {
  vertical-align: baseline;
}

[hidden] {
  display: none !important;
}

.lead {
  font-size: calc(1.25625rem + 0.075vw);
  font-weight: 400;
}
@media (min-width: 1200px) {
  .lead {
    font-size: 1.3125rem;
  }
}

.display-1 {
  font-size: calc(1.925rem + 8.1vw);
  font-weight: 700;
  line-height: 1.2;
}
@media (min-width: 1200px) {
  .display-1 {
    font-size: 8rem;
  }
}

.display-2 {
  font-size: calc(1.575rem + 3.9vw);
  font-weight: 700;
  line-height: 1.2;
}
@media (min-width: 1200px) {
  .display-2 {
    font-size: 4.5rem;
  }
}

.display-3 {
  font-size: calc(1.525rem + 3.3vw);
  font-weight: 700;
  line-height: 1.2;
}
@media (min-width: 1200px) {
  .display-3 {
    font-size: 4rem;
  }
}

.display-4 {
  font-size: calc(1.5rem + 3vw);
  font-weight: 700;
  line-height: 1.2;
}
@media (min-width: 1200px) {
  .display-4 {
    font-size: 3.75rem;
  }
}

.display-5 {
  font-size: calc(1.425rem + 2.1vw);
  font-weight: 700;
  line-height: 1.2;
}
@media (min-width: 1200px) {
  .display-5 {
    font-size: 3rem;
  }
}

.display-6 {
  font-size: calc(1.375rem + 1.5vw);
  font-weight: 700;
  line-height: 1.2;
}
@media (min-width: 1200px) {
  .display-6 {
    font-size: 2.5rem;
  }
}

.list-unstyled {
  padding-left: 0;
  list-style: none;
}

.list-inline {
  padding-left: 0;
  list-style: none;
}

.list-inline-item {
  display: inline-block;
}
.list-inline-item:not(:last-child) {
  margin-right: 0.5rem;
}

.initialism {
  font-size: 0.875em;
  text-transform: uppercase;
}

.blockquote {
  margin-bottom: 0;
  font-size: 1.25rem;
}
.blockquote > :last-child {
  margin-bottom: 0;
}

.blockquote-footer {
  margin-top: 0;
  margin-bottom: 0;
  font-size: 1rem;
  color: #2d374b;
}
.blockquote-footer::before {
  content: "— ";
}

.img-fluid {
  max-width: 100%;
  height: auto;
}

.img-thumbnail {
  padding: 0.25rem;
  background-color: var(--bs-body-bg);
  border: var(--bs-border-width) solid var(--bs-border-color);
  border-radius: var(--bs-border-radius);
  box-shadow: var(--bs-box-shadow-sm);
  max-width: 100%;
  height: auto;
}

.figure {
  display: inline-block;
}

.figure-img {
  margin-bottom: 0.5rem;
  line-height: 1;
}

.figure-caption {
  font-size: 0.875em;
  color: var(--bs-secondary-color);
}

.container,
.container-fluid,
.container-xl,
.container-lg,
.container-md,
.container-sm {
  --bs-gutter-x: 30px;
  --bs-gutter-y: 0;
  width: 100%;
  padding-right: calc(var(--bs-gutter-x) * 0.5);
  padding-left: calc(var(--bs-gutter-x) * 0.5);
  margin-right: auto;
  margin-left: auto;
}

@media (min-width: 576px) {
  .container-sm, .container {
    max-width: 540px;
  }
}
@media (min-width: 768px) {
  .container-md, .container-sm, .container {
    max-width: 720px;
  }
}
@media (min-width: 992px) {
  .container-lg, .container-md, .container-sm, .container {
    max-width: 960px;
  }
}
@media (min-width: 1200px) {
  .container-xl, .container-lg, .container-md, .container-sm, .container {
    max-width: 1140px;
  }
}
:root {
  --bs-breakpoint-xs: 0;
  --bs-breakpoint-sm: 576px;
  --bs-breakpoint-md: 768px;
  --bs-breakpoint-lg: 992px;
  --bs-breakpoint-xl: 1200px;
  --bs-breakpoint-xxl: 1400px;
}

.row {
  --bs-gutter-x: 30px;
  --bs-gutter-y: 0;
  display: flex;
  flex-wrap: wrap;
  margin-top: calc(-1 * var(--bs-gutter-y));
  margin-right: calc(-0.5 * var(--bs-gutter-x));
  margin-left: calc(-0.5 * var(--bs-gutter-x));
}
.row > * {
  flex-shrink: 0;
  width: 100%;
  max-width: 100%;
  padding-right: calc(var(--bs-gutter-x) * 0.5);
  padding-left: calc(var(--bs-gutter-x) * 0.5);
  margin-top: var(--bs-gutter-y);
}

.col {
  flex: 1 0 0%;
}

.row-cols-auto > * {
  flex: 0 0 auto;
  width: auto;
}

.row-cols-1 > * {
  flex: 0 0 auto;
  width: 100%;
}

.row-cols-2 > * {
  flex: 0 0 auto;
  width: 50%;
}

.row-cols-3 > * {
  flex: 0 0 auto;
  width: 33.33333333%;
}

.row-cols-4 > * {
  flex: 0 0 auto;
  width: 25%;
}

.row-cols-5 > * {
  flex: 0 0 auto;
  width: 20%;
}

.row-cols-6 > * {
  flex: 0 0 auto;
  width: 16.66666667%;
}

.col-auto {
  flex: 0 0 auto;
  width: auto;
}

.col-1 {
  flex: 0 0 auto;
  width: 8.33333333%;
}

.col-2 {
  flex: 0 0 auto;
  width: 16.66666667%;
}

.col-3 {
  flex: 0 0 auto;
  width: 25%;
}

.col-4 {
  flex: 0 0 auto;
  width: 33.33333333%;
}

.col-5 {
  flex: 0 0 auto;
  width: 41.66666667%;
}

.col-6 {
  flex: 0 0 auto;
  width: 50%;
}

.col-7 {
  flex: 0 0 auto;
  width: 58.33333333%;
}

.col-8 {
  flex: 0 0 auto;
  width: 66.66666667%;
}

.col-9 {
  flex: 0 0 auto;
  width: 75%;
}

.col-10 {
  flex: 0 0 auto;
  width: 83.33333333%;
}

.col-11 {
  flex: 0 0 auto;
  width: 91.66666667%;
}

.col-12 {
  flex: 0 0 auto;
  width: 100%;
}

.offset-1 {
  margin-left: 8.33333333%;
}

.offset-2 {
  margin-left: 16.66666667%;
}

.offset-3 {
  margin-left: 25%;
}

.offset-4 {
  margin-left: 33.33333333%;
}

.offset-5 {
  margin-left: 41.66666667%;
}

.offset-6 {
  margin-left: 50%;
}

.offset-7 {
  margin-left: 58.33333333%;
}

.offset-8 {
  margin-left: 66.66666667%;
}

.offset-9 {
  margin-left: 75%;
}

.offset-10 {
  margin-left: 83.33333333%;
}

.offset-11 {
  margin-left: 91.66666667%;
}

.g-0,
.gx-0 {
  --bs-gutter-x: 0;
}

.g-0,
.gy-0 {
  --bs-gutter-y: 0;
}

.g-1,
.gx-1 {
  --bs-gutter-x: 0.25rem;
}

.g-1,
.gy-1 {
  --bs-gutter-y: 0.25rem;
}

.g-2,
.gx-2 {
  --bs-gutter-x: 0.5rem;
}

.g-2,
.gy-2 {
  --bs-gutter-y: 0.5rem;
}

.g-3,
.gx-3 {
  --bs-gutter-x: 1rem;
}

.g-3,
.gy-3 {
  --bs-gutter-y: 1rem;
}

.g-4,
.gx-4 {
  --bs-gutter-x: 1.5rem;
}

.g-4,
.gy-4 {
  --bs-gutter-y: 1.5rem;
}

.g-5,
.gx-5 {
  --bs-gutter-x: 2rem;
}

.g-5,
.gy-5 {
  --bs-gutter-y: 2rem;
}

.g-6,
.gx-6 {
  --bs-gutter-x: 2.5rem;
}

.g-6,
.gy-6 {
  --bs-gutter-y: 2.5rem;
}

.g-7,
.gx-7 {
  --bs-gutter-x: 3rem;
}

.g-7,
.gy-7 {
  --bs-gutter-y: 3rem;
}

.g-8,
.gx-8 {
  --bs-gutter-x: 3.5rem;
}

.g-8,
.gy-8 {
  --bs-gutter-y: 3.5rem;
}

.g-9,
.gx-9 {
  --bs-gutter-x: 4rem;
}

.g-9,
.gy-9 {
  --bs-gutter-y: 4rem;
}

.g-10,
.gx-10 {
  --bs-gutter-x: 4.5rem;
}

.g-10,
.gy-10 {
  --bs-gutter-y: 4.5rem;
}

@media (min-width: 576px) {
  .col-sm {
    flex: 1 0 0%;
  }
  .row-cols-sm-auto > * {
    flex: 0 0 auto;
    width: auto;
  }
  .row-cols-sm-1 > * {
    flex: 0 0 auto;
    width: 100%;
  }
  .row-cols-sm-2 > * {
    flex: 0 0 auto;
    width: 50%;
  }
  .row-cols-sm-3 > * {
    flex: 0 0 auto;
    width: 33.33333333%;
  }
  .row-cols-sm-4 > * {
    flex: 0 0 auto;
    width: 25%;
  }
  .row-cols-sm-5 > * {
    flex: 0 0 auto;
    width: 20%;
  }
  .row-cols-sm-6 > * {
    flex: 0 0 auto;
    width: 16.66666667%;
  }
  .col-sm-auto {
    flex: 0 0 auto;
    width: auto;
  }
  .col-sm-1 {
    flex: 0 0 auto;
    width: 8.33333333%;
  }
  .col-sm-2 {
    flex: 0 0 auto;
    width: 16.66666667%;
  }
  .col-sm-3 {
    flex: 0 0 auto;
    width: 25%;
  }
  .col-sm-4 {
    flex: 0 0 auto;
    width: 33.33333333%;
  }
  .col-sm-5 {
    flex: 0 0 auto;
    width: 41.66666667%;
  }
  .col-sm-6 {
    flex: 0 0 auto;
    width: 50%;
  }
  .col-sm-7 {
    flex: 0 0 auto;
    width: 58.33333333%;
  }
  .col-sm-8 {
    flex: 0 0 auto;
    width: 66.66666667%;
  }
  .col-sm-9 {
    flex: 0 0 auto;
    width: 75%;
  }
  .col-sm-10 {
    flex: 0 0 auto;
    width: 83.33333333%;
  }
  .col-sm-11 {
    flex: 0 0 auto;
    width: 91.66666667%;
  }
  .col-sm-12 {
    flex: 0 0 auto;
    width: 100%;
  }
  .offset-sm-0 {
    margin-left: 0;
  }
  .offset-sm-1 {
    margin-left: 8.33333333%;
  }
  .offset-sm-2 {
    margin-left: 16.66666667%;
  }
  .offset-sm-3 {
    margin-left: 25%;
  }
  .offset-sm-4 {
    margin-left: 33.33333333%;
  }
  .offset-sm-5 {
    margin-left: 41.66666667%;
  }
  .offset-sm-6 {
    margin-left: 50%;
  }
  .offset-sm-7 {
    margin-left: 58.33333333%;
  }
  .offset-sm-8 {
    margin-left: 66.66666667%;
  }
  .offset-sm-9 {
    margin-left: 75%;
  }
  .offset-sm-10 {
    margin-left: 83.33333333%;
  }
  .offset-sm-11 {
    margin-left: 91.66666667%;
  }
  .g-sm-0,
.gx-sm-0 {
    --bs-gutter-x: 0;
  }
  .g-sm-0,
.gy-sm-0 {
    --bs-gutter-y: 0;
  }
  .g-sm-1,
.gx-sm-1 {
    --bs-gutter-x: 0.25rem;
  }
  .g-sm-1,
.gy-sm-1 {
    --bs-gutter-y: 0.25rem;
  }
  .g-sm-2,
.gx-sm-2 {
    --bs-gutter-x: 0.5rem;
  }
  .g-sm-2,
.gy-sm-2 {
    --bs-gutter-y: 0.5rem;
  }
  .g-sm-3,
.gx-sm-3 {
    --bs-gutter-x: 1rem;
  }
  .g-sm-3,
.gy-sm-3 {
    --bs-gutter-y: 1rem;
  }
  .g-sm-4,
.gx-sm-4 {
    --bs-gutter-x: 1.5rem;
  }
  .g-sm-4,
.gy-sm-4 {
    --bs-gutter-y: 1.5rem;
  }
  .g-sm-5,
.gx-sm-5 {
    --bs-gutter-x: 2rem;
  }
  .g-sm-5,
.gy-sm-5 {
    --bs-gutter-y: 2rem;
  }
  .g-sm-6,
.gx-sm-6 {
    --bs-gutter-x: 2.5rem;
  }
  .g-sm-6,
.gy-sm-6 {
    --bs-gutter-y: 2.5rem;
  }
  .g-sm-7,
.gx-sm-7 {
    --bs-gutter-x: 3rem;
  }
  .g-sm-7,
.gy-sm-7 {
    --bs-gutter-y: 3rem;
  }
  .g-sm-8,
.gx-sm-8 {
    --bs-gutter-x: 3.5rem;
  }
  .g-sm-8,
.gy-sm-8 {
    --bs-gutter-y: 3.5rem;
  }
  .g-sm-9,
.gx-sm-9 {
    --bs-gutter-x: 4rem;
  }
  .g-sm-9,
.gy-sm-9 {
    --bs-gutter-y: 4rem;
  }
  .g-sm-10,
.gx-sm-10 {
    --bs-gutter-x: 4.5rem;
  }
  .g-sm-10,
.gy-sm-10 {
    --bs-gutter-y: 4.5rem;
  }
}
@media (min-width: 768px) {
  .col-md {
    flex: 1 0 0%;
  }
  .row-cols-md-auto > * {
    flex: 0 0 auto;
    width: auto;
  }
  .row-cols-md-1 > * {
    flex: 0 0 auto;
    width: 100%;
  }
  .row-cols-md-2 > * {
    flex: 0 0 auto;
    width: 50%;
  }
  .row-cols-md-3 > * {
    flex: 0 0 auto;
    width: 33.33333333%;
  }
  .row-cols-md-4 > * {
    flex: 0 0 auto;
    width: 25%;
  }
  .row-cols-md-5 > * {
    flex: 0 0 auto;
    width: 20%;
  }
  .row-cols-md-6 > * {
    flex: 0 0 auto;
    width: 16.66666667%;
  }
  .col-md-auto {
    flex: 0 0 auto;
    width: auto;
  }
  .col-md-1 {
    flex: 0 0 auto;
    width: 8.33333333%;
  }
  .col-md-2 {
    flex: 0 0 auto;
    width: 16.66666667%;
  }
  .col-md-3 {
    flex: 0 0 auto;
    width: 25%;
  }
  .col-md-4 {
    flex: 0 0 auto;
    width: 33.33333333%;
  }
  .col-md-5 {
    flex: 0 0 auto;
    width: 41.66666667%;
  }
  .col-md-6 {
    flex: 0 0 auto;
    width: 50%;
  }
  .col-md-7 {
    flex: 0 0 auto;
    width: 58.33333333%;
  }
  .col-md-8 {
    flex: 0 0 auto;
    width: 66.66666667%;
  }
  .col-md-9 {
    flex: 0 0 auto;
    width: 75%;
  }
  .col-md-10 {
    flex: 0 0 auto;
    width: 83.33333333%;
  }
  .col-md-11 {
    flex: 0 0 auto;
    width: 91.66666667%;
  }
  .col-md-12 {
    flex: 0 0 auto;
    width: 100%;
  }
  .offset-md-0 {
    margin-left: 0;
  }
  .offset-md-1 {
    margin-left: 8.33333333%;
  }
  .offset-md-2 {
    margin-left: 16.66666667%;
  }
  .offset-md-3 {
    margin-left: 25%;
  }
  .offset-md-4 {
    margin-left: 33.33333333%;
  }
  .offset-md-5 {
    margin-left: 41.66666667%;
  }
  .offset-md-6 {
    margin-left: 50%;
  }
  .offset-md-7 {
    margin-left: 58.33333333%;
  }
  .offset-md-8 {
    margin-left: 66.66666667%;
  }
  .offset-md-9 {
    margin-left: 75%;
  }
  .offset-md-10 {
    margin-left: 83.33333333%;
  }
  .offset-md-11 {
    margin-left: 91.66666667%;
  }
  .g-md-0,
.gx-md-0 {
    --bs-gutter-x: 0;
  }
  .g-md-0,
.gy-md-0 {
    --bs-gutter-y: 0;
  }
  .g-md-1,
.gx-md-1 {
    --bs-gutter-x: 0.25rem;
  }
  .g-md-1,
.gy-md-1 {
    --bs-gutter-y: 0.25rem;
  }
  .g-md-2,
.gx-md-2 {
    --bs-gutter-x: 0.5rem;
  }
  .g-md-2,
.gy-md-2 {
    --bs-gutter-y: 0.5rem;
  }
  .g-md-3,
.gx-md-3 {
    --bs-gutter-x: 1rem;
  }
  .g-md-3,
.gy-md-3 {
    --bs-gutter-y: 1rem;
  }
  .g-md-4,
.gx-md-4 {
    --bs-gutter-x: 1.5rem;
  }
  .g-md-4,
.gy-md-4 {
    --bs-gutter-y: 1.5rem;
  }
  .g-md-5,
.gx-md-5 {
    --bs-gutter-x: 2rem;
  }
  .g-md-5,
.gy-md-5 {
    --bs-gutter-y: 2rem;
  }
  .g-md-6,
.gx-md-6 {
    --bs-gutter-x: 2.5rem;
  }
  .g-md-6,
.gy-md-6 {
    --bs-gutter-y: 2.5rem;
  }
  .g-md-7,
.gx-md-7 {
    --bs-gutter-x: 3rem;
  }
  .g-md-7,
.gy-md-7 {
    --bs-gutter-y: 3rem;
  }
  .g-md-8,
.gx-md-8 {
    --bs-gutter-x: 3.5rem;
  }
  .g-md-8,
.gy-md-8 {
    --bs-gutter-y: 3.5rem;
  }
  .g-md-9,
.gx-md-9 {
    --bs-gutter-x: 4rem;
  }
  .g-md-9,
.gy-md-9 {
    --bs-gutter-y: 4rem;
  }
  .g-md-10,
.gx-md-10 {
    --bs-gutter-x: 4.5rem;
  }
  .g-md-10,
.gy-md-10 {
    --bs-gutter-y: 4.5rem;
  }
}
@media (min-width: 992px) {
  .col-lg {
    flex: 1 0 0%;
  }
  .row-cols-lg-auto > * {
    flex: 0 0 auto;
    width: auto;
  }
  .row-cols-lg-1 > * {
    flex: 0 0 auto;
    width: 100%;
  }
  .row-cols-lg-2 > * {
    flex: 0 0 auto;
    width: 50%;
  }
  .row-cols-lg-3 > * {
    flex: 0 0 auto;
    width: 33.33333333%;
  }
  .row-cols-lg-4 > * {
    flex: 0 0 auto;
    width: 25%;
  }
  .row-cols-lg-5 > * {
    flex: 0 0 auto;
    width: 20%;
  }
  .row-cols-lg-6 > * {
    flex: 0 0 auto;
    width: 16.66666667%;
  }
  .col-lg-auto {
    flex: 0 0 auto;
    width: auto;
  }
  .col-lg-1 {
    flex: 0 0 auto;
    width: 8.33333333%;
  }
  .col-lg-2 {
    flex: 0 0 auto;
    width: 16.66666667%;
  }
  .col-lg-3 {
    flex: 0 0 auto;
    width: 25%;
  }
  .col-lg-4 {
    flex: 0 0 auto;
    width: 33.33333333%;
  }
  .col-lg-5 {
    flex: 0 0 auto;
    width: 41.66666667%;
  }
  .col-lg-6 {
    flex: 0 0 auto;
    width: 50%;
  }
  .col-lg-7 {
    flex: 0 0 auto;
    width: 58.33333333%;
  }
  .col-lg-8 {
    flex: 0 0 auto;
    width: 66.66666667%;
  }
  .col-lg-9 {
    flex: 0 0 auto;
    width: 75%;
  }
  .col-lg-10 {
    flex: 0 0 auto;
    width: 83.33333333%;
  }
  .col-lg-11 {
    flex: 0 0 auto;
    width: 91.66666667%;
  }
  .col-lg-12 {
    flex: 0 0 auto;
    width: 100%;
  }
  .offset-lg-0 {
    margin-left: 0;
  }
  .offset-lg-1 {
    margin-left: 8.33333333%;
  }
  .offset-lg-2 {
    margin-left: 16.66666667%;
  }
  .offset-lg-3 {
    margin-left: 25%;
  }
  .offset-lg-4 {
    margin-left: 33.33333333%;
  }
  .offset-lg-5 {
    margin-left: 41.66666667%;
  }
  .offset-lg-6 {
    margin-left: 50%;
  }
  .offset-lg-7 {
    margin-left: 58.33333333%;
  }
  .offset-lg-8 {
    margin-left: 66.66666667%;
  }
  .offset-lg-9 {
    margin-left: 75%;
  }
  .offset-lg-10 {
    margin-left: 83.33333333%;
  }
  .offset-lg-11 {
    margin-left: 91.66666667%;
  }
  .g-lg-0,
.gx-lg-0 {
    --bs-gutter-x: 0;
  }
  .g-lg-0,
.gy-lg-0 {
    --bs-gutter-y: 0;
  }
  .g-lg-1,
.gx-lg-1 {
    --bs-gutter-x: 0.25rem;
  }
  .g-lg-1,
.gy-lg-1 {
    --bs-gutter-y: 0.25rem;
  }
  .g-lg-2,
.gx-lg-2 {
    --bs-gutter-x: 0.5rem;
  }
  .g-lg-2,
.gy-lg-2 {
    --bs-gutter-y: 0.5rem;
  }
  .g-lg-3,
.gx-lg-3 {
    --bs-gutter-x: 1rem;
  }
  .g-lg-3,
.gy-lg-3 {
    --bs-gutter-y: 1rem;
  }
  .g-lg-4,
.gx-lg-4 {
    --bs-gutter-x: 1.5rem;
  }
  .g-lg-4,
.gy-lg-4 {
    --bs-gutter-y: 1.5rem;
  }
  .g-lg-5,
.gx-lg-5 {
    --bs-gutter-x: 2rem;
  }
  .g-lg-5,
.gy-lg-5 {
    --bs-gutter-y: 2rem;
  }
  .g-lg-6,
.gx-lg-6 {
    --bs-gutter-x: 2.5rem;
  }
  .g-lg-6,
.gy-lg-6 {
    --bs-gutter-y: 2.5rem;
  }
  .g-lg-7,
.gx-lg-7 {
    --bs-gutter-x: 3rem;
  }
  .g-lg-7,
.gy-lg-7 {
    --bs-gutter-y: 3rem;
  }
  .g-lg-8,
.gx-lg-8 {
    --bs-gutter-x: 3.5rem;
  }
  .g-lg-8,
.gy-lg-8 {
    --bs-gutter-y: 3.5rem;
  }
  .g-lg-9,
.gx-lg-9 {
    --bs-gutter-x: 4rem;
  }
  .g-lg-9,
.gy-lg-9 {
    --bs-gutter-y: 4rem;
  }
  .g-lg-10,
.gx-lg-10 {
    --bs-gutter-x: 4.5rem;
  }
  .g-lg-10,
.gy-lg-10 {
    --bs-gutter-y: 4.5rem;
  }
}
@media (min-width: 1200px) {
  .col-xl {
    flex: 1 0 0%;
  }
  .row-cols-xl-auto > * {
    flex: 0 0 auto;
    width: auto;
  }
  .row-cols-xl-1 > * {
    flex: 0 0 auto;
    width: 100%;
  }
  .row-cols-xl-2 > * {
    flex: 0 0 auto;
    width: 50%;
  }
  .row-cols-xl-3 > * {
    flex: 0 0 auto;
    width: 33.33333333%;
  }
  .row-cols-xl-4 > * {
    flex: 0 0 auto;
    width: 25%;
  }
  .row-cols-xl-5 > * {
    flex: 0 0 auto;
    width: 20%;
  }
  .row-cols-xl-6 > * {
    flex: 0 0 auto;
    width: 16.66666667%;
  }
  .col-xl-auto {
    flex: 0 0 auto;
    width: auto;
  }
  .col-xl-1 {
    flex: 0 0 auto;
    width: 8.33333333%;
  }
  .col-xl-2 {
    flex: 0 0 auto;
    width: 16.66666667%;
  }
  .col-xl-3 {
    flex: 0 0 auto;
    width: 25%;
  }
  .col-xl-4 {
    flex: 0 0 auto;
    width: 33.33333333%;
  }
  .col-xl-5 {
    flex: 0 0 auto;
    width: 41.66666667%;
  }
  .col-xl-6 {
    flex: 0 0 auto;
    width: 50%;
  }
  .col-xl-7 {
    flex: 0 0 auto;
    width: 58.33333333%;
  }
  .col-xl-8 {
    flex: 0 0 auto;
    width: 66.66666667%;
  }
  .col-xl-9 {
    flex: 0 0 auto;
    width: 75%;
  }
  .col-xl-10 {
    flex: 0 0 auto;
    width: 83.33333333%;
  }
  .col-xl-11 {
    flex: 0 0 auto;
    width: 91.66666667%;
  }
  .col-xl-12 {
    flex: 0 0 auto;
    width: 100%;
  }
  .offset-xl-0 {
    margin-left: 0;
  }
  .offset-xl-1 {
    margin-left: 8.33333333%;
  }
  .offset-xl-2 {
    margin-left: 16.66666667%;
  }
  .offset-xl-3 {
    margin-left: 25%;
  }
  .offset-xl-4 {
    margin-left: 33.33333333%;
  }
  .offset-xl-5 {
    margin-left: 41.66666667%;
  }
  .offset-xl-6 {
    margin-left: 50%;
  }
  .offset-xl-7 {
    margin-left: 58.33333333%;
  }
  .offset-xl-8 {
    margin-left: 66.66666667%;
  }
  .offset-xl-9 {
    margin-left: 75%;
  }
  .offset-xl-10 {
    margin-left: 83.33333333%;
  }
  .offset-xl-11 {
    margin-left: 91.66666667%;
  }
  .g-xl-0,
.gx-xl-0 {
    --bs-gutter-x: 0;
  }
  .g-xl-0,
.gy-xl-0 {
    --bs-gutter-y: 0;
  }
  .g-xl-1,
.gx-xl-1 {
    --bs-gutter-x: 0.25rem;
  }
  .g-xl-1,
.gy-xl-1 {
    --bs-gutter-y: 0.25rem;
  }
  .g-xl-2,
.gx-xl-2 {
    --bs-gutter-x: 0.5rem;
  }
  .g-xl-2,
.gy-xl-2 {
    --bs-gutter-y: 0.5rem;
  }
  .g-xl-3,
.gx-xl-3 {
    --bs-gutter-x: 1rem;
  }
  .g-xl-3,
.gy-xl-3 {
    --bs-gutter-y: 1rem;
  }
  .g-xl-4,
.gx-xl-4 {
    --bs-gutter-x: 1.5rem;
  }
  .g-xl-4,
.gy-xl-4 {
    --bs-gutter-y: 1.5rem;
  }
  .g-xl-5,
.gx-xl-5 {
    --bs-gutter-x: 2rem;
  }
  .g-xl-5,
.gy-xl-5 {
    --bs-gutter-y: 2rem;
  }
  .g-xl-6,
.gx-xl-6 {
    --bs-gutter-x: 2.5rem;
  }
  .g-xl-6,
.gy-xl-6 {
    --bs-gutter-y: 2.5rem;
  }
  .g-xl-7,
.gx-xl-7 {
    --bs-gutter-x: 3rem;
  }
  .g-xl-7,
.gy-xl-7 {
    --bs-gutter-y: 3rem;
  }
  .g-xl-8,
.gx-xl-8 {
    --bs-gutter-x: 3.5rem;
  }
  .g-xl-8,
.gy-xl-8 {
    --bs-gutter-y: 3.5rem;
  }
  .g-xl-9,
.gx-xl-9 {
    --bs-gutter-x: 4rem;
  }
  .g-xl-9,
.gy-xl-9 {
    --bs-gutter-y: 4rem;
  }
  .g-xl-10,
.gx-xl-10 {
    --bs-gutter-x: 4.5rem;
  }
  .g-xl-10,
.gy-xl-10 {
    --bs-gutter-y: 4.5rem;
  }
}
@media (min-width: 1400px) {
  .col-xxl {
    flex: 1 0 0%;
  }
  .row-cols-xxl-auto > * {
    flex: 0 0 auto;
    width: auto;
  }
  .row-cols-xxl-1 > * {
    flex: 0 0 auto;
    width: 100%;
  }
  .row-cols-xxl-2 > * {
    flex: 0 0 auto;
    width: 50%;
  }
  .row-cols-xxl-3 > * {
    flex: 0 0 auto;
    width: 33.33333333%;
  }
  .row-cols-xxl-4 > * {
    flex: 0 0 auto;
    width: 25%;
  }
  .row-cols-xxl-5 > * {
    flex: 0 0 auto;
    width: 20%;
  }
  .row-cols-xxl-6 > * {
    flex: 0 0 auto;
    width: 16.66666667%;
  }
  .col-xxl-auto {
    flex: 0 0 auto;
    width: auto;
  }
  .col-xxl-1 {
    flex: 0 0 auto;
    width: 8.33333333%;
  }
  .col-xxl-2 {
    flex: 0 0 auto;
    width: 16.66666667%;
  }
  .col-xxl-3 {
    flex: 0 0 auto;
    width: 25%;
  }
  .col-xxl-4 {
    flex: 0 0 auto;
    width: 33.33333333%;
  }
  .col-xxl-5 {
    flex: 0 0 auto;
    width: 41.66666667%;
  }
  .col-xxl-6 {
    flex: 0 0 auto;
    width: 50%;
  }
  .col-xxl-7 {
    flex: 0 0 auto;
    width: 58.33333333%;
  }
  .col-xxl-8 {
    flex: 0 0 auto;
    width: 66.66666667%;
  }
  .col-xxl-9 {
    flex: 0 0 auto;
    width: 75%;
  }
  .col-xxl-10 {
    flex: 0 0 auto;
    width: 83.33333333%;
  }
  .col-xxl-11 {
    flex: 0 0 auto;
    width: 91.66666667%;
  }
  .col-xxl-12 {
    flex: 0 0 auto;
    width: 100%;
  }
  .offset-xxl-0 {
    margin-left: 0;
  }
  .offset-xxl-1 {
    margin-left: 8.33333333%;
  }
  .offset-xxl-2 {
    margin-left: 16.66666667%;
  }
  .offset-xxl-3 {
    margin-left: 25%;
  }
  .offset-xxl-4 {
    margin-left: 33.33333333%;
  }
  .offset-xxl-5 {
    margin-left: 41.66666667%;
  }
  .offset-xxl-6 {
    margin-left: 50%;
  }
  .offset-xxl-7 {
    margin-left: 58.33333333%;
  }
  .offset-xxl-8 {
    margin-left: 66.66666667%;
  }
  .offset-xxl-9 {
    margin-left: 75%;
  }
  .offset-xxl-10 {
    margin-left: 83.33333333%;
  }
  .offset-xxl-11 {
    margin-left: 91.66666667%;
  }
  .g-xxl-0,
.gx-xxl-0 {
    --bs-gutter-x: 0;
  }
  .g-xxl-0,
.gy-xxl-0 {
    --bs-gutter-y: 0;
  }
  .g-xxl-1,
.gx-xxl-1 {
    --bs-gutter-x: 0.25rem;
  }
  .g-xxl-1,
.gy-xxl-1 {
    --bs-gutter-y: 0.25rem;
  }
  .g-xxl-2,
.gx-xxl-2 {
    --bs-gutter-x: 0.5rem;
  }
  .g-xxl-2,
.gy-xxl-2 {
    --bs-gutter-y: 0.5rem;
  }
  .g-xxl-3,
.gx-xxl-3 {
    --bs-gutter-x: 1rem;
  }
  .g-xxl-3,
.gy-xxl-3 {
    --bs-gutter-y: 1rem;
  }
  .g-xxl-4,
.gx-xxl-4 {
    --bs-gutter-x: 1.5rem;
  }
  .g-xxl-4,
.gy-xxl-4 {
    --bs-gutter-y: 1.5rem;
  }
  .g-xxl-5,
.gx-xxl-5 {
    --bs-gutter-x: 2rem;
  }
  .g-xxl-5,
.gy-xxl-5 {
    --bs-gutter-y: 2rem;
  }
  .g-xxl-6,
.gx-xxl-6 {
    --bs-gutter-x: 2.5rem;
  }
  .g-xxl-6,
.gy-xxl-6 {
    --bs-gutter-y: 2.5rem;
  }
  .g-xxl-7,
.gx-xxl-7 {
    --bs-gutter-x: 3rem;
  }
  .g-xxl-7,
.gy-xxl-7 {
    --bs-gutter-y: 3rem;
  }
  .g-xxl-8,
.gx-xxl-8 {
    --bs-gutter-x: 3.5rem;
  }
  .g-xxl-8,
.gy-xxl-8 {
    --bs-gutter-y: 3.5rem;
  }
  .g-xxl-9,
.gx-xxl-9 {
    --bs-gutter-x: 4rem;
  }
  .g-xxl-9,
.gy-xxl-9 {
    --bs-gutter-y: 4rem;
  }
  .g-xxl-10,
.gx-xxl-10 {
    --bs-gutter-x: 4.5rem;
  }
  .g-xxl-10,
.gy-xxl-10 {
    --bs-gutter-y: 4.5rem;
  }
}
.table {
  --bs-table-color-type: initial;
  --bs-table-bg-type: initial;
  --bs-table-color-state: initial;
  --bs-table-bg-state: initial;
  --bs-table-color: var(--bs-emphasis-color);
  --bs-table-bg: var(--bs-body-bg);
  --bs-table-border-color: rgba(220, 224, 229, 0.6);
  --bs-table-accent-bg: transparent;
  --bs-table-striped-color: var(--bs-emphasis-color);
  --bs-table-striped-bg: #F5F7FA;
  --bs-table-active-color: var(--bs-emphasis-color);
  --bs-table-active-bg: rgba(var(--bs-emphasis-color-rgb), 0.1);
  --bs-table-hover-color: var(--bs-emphasis-color);
  --bs-table-hover-bg: rgba(220, 224, 229, 0.4);
  width: 100%;
  margin-bottom: 1rem;
  vertical-align: top;
  border-color: var(--bs-table-border-color);
}
.table > :not(caption) > * > * {
  padding: 0.75rem 0.75rem;
  color: var(--bs-table-color-state, var(--bs-table-color-type, var(--bs-table-color)));
  background-color: var(--bs-table-bg);
  border-bottom-width: var(--bs-border-width);
  box-shadow: inset 0 0 0 9999px var(--bs-table-bg-state, var(--bs-table-bg-type, var(--bs-table-accent-bg)));
}
.table > tbody {
  vertical-align: inherit;
}
.table > thead {
  vertical-align: bottom;
}

.table-group-divider {
  border-top: calc(var(--bs-border-width) * 2) solid currentcolor;
}

.caption-top {
  caption-side: top;
}

.table-sm > :not(caption) > * > * {
  padding: 0.5rem 0.5rem;
}

.table-bordered > :not(caption) > * {
  border-width: var(--bs-border-width) 0;
}
.table-bordered > :not(caption) > * > * {
  border-width: 0 var(--bs-border-width);
}

.table-borderless > :not(caption) > * > * {
  border-bottom-width: 0;
}
.table-borderless > :not(:first-child) {
  border-top-width: 0;
}

.table-striped > tbody > tr:nth-of-type(odd) > * {
  --bs-table-color-type: var(--bs-table-striped-color);
  --bs-table-bg-type: var(--bs-table-striped-bg);
}

.table-striped-columns > :not(caption) > tr > :nth-child(even) {
  --bs-table-color-type: var(--bs-table-striped-color);
  --bs-table-bg-type: var(--bs-table-striped-bg);
}

.table-active {
  --bs-table-color-state: var(--bs-table-active-color);
  --bs-table-bg-state: var(--bs-table-active-bg);
}

.table-hover > tbody > tr:hover > * {
  --bs-table-color-state: var(--bs-table-hover-color);
  --bs-table-bg-state: var(--bs-table-hover-bg);
}

.table-primary {
  --bs-table-color: #000;
  --bs-table-bg: #cef2dd;
  --bs-table-border-color: #a5c2b1;
  --bs-table-striped-bg: #c4e6d2;
  --bs-table-striped-color: #000;
  --bs-table-active-bg: #b9dac7;
  --bs-table-active-color: #000;
  --bs-table-hover-bg: #bfe0cc;
  --bs-table-hover-color: #000;
  color: var(--bs-table-color);
  border-color: var(--bs-table-border-color);
}

.table-secondary {
  --bs-table-color: #000;
  --bs-table-bg: #dcdee2;
  --bs-table-border-color: #b0b2b5;
  --bs-table-striped-bg: #d1d3d7;
  --bs-table-striped-color: #000;
  --bs-table-active-bg: #c6c8cb;
  --bs-table-active-color: #000;
  --bs-table-hover-bg: #cccdd1;
  --bs-table-hover-color: #000;
  color: var(--bs-table-color);
  border-color: var(--bs-table-border-color);
}

.table-success {
  --bs-table-color: #000;
  --bs-table-bg: #cde5e4;
  --bs-table-border-color: #a4b7b6;
  --bs-table-striped-bg: #c3dad9;
  --bs-table-striped-color: #000;
  --bs-table-active-bg: #b9cecd;
  --bs-table-active-color: #000;
  --bs-table-hover-bg: #bed4d3;
  --bs-table-hover-color: #000;
  color: var(--bs-table-color);
  border-color: var(--bs-table-border-color);
}

.table-info {
  --bs-table-color: #000;
  --bs-table-bg: #d6dbf2;
  --bs-table-border-color: #abafc2;
  --bs-table-striped-bg: #cbd0e6;
  --bs-table-striped-color: #000;
  --bs-table-active-bg: #c1c5da;
  --bs-table-active-color: #000;
  --bs-table-hover-bg: #c6cbe0;
  --bs-table-hover-color: #000;
  color: var(--bs-table-color);
  border-color: var(--bs-table-border-color);
}

.table-warning {
  --bs-table-color: #000;
  --bs-table-bg: #fdeae1;
  --bs-table-border-color: #cabbb4;
  --bs-table-striped-bg: #f0ded6;
  --bs-table-striped-color: #000;
  --bs-table-active-bg: #e4d3cb;
  --bs-table-active-color: #000;
  --bs-table-hover-bg: #ead8d0;
  --bs-table-hover-color: #000;
  color: var(--bs-table-color);
  border-color: var(--bs-table-border-color);
}

.table-danger {
  --bs-table-color: #000;
  --bs-table-bg: #e1d3d9;
  --bs-table-border-color: #b4a9ae;
  --bs-table-striped-bg: #d6c8ce;
  --bs-table-striped-color: #000;
  --bs-table-active-bg: #cbbec3;
  --bs-table-active-color: #000;
  --bs-table-hover-bg: #d0c3c9;
  --bs-table-hover-color: #000;
  color: var(--bs-table-color);
  border-color: var(--bs-table-border-color);
}

.table-light {
  --bs-table-color: #000;
  --bs-table-bg: #f8f9fa;
  --bs-table-border-color: #c6c7c8;
  --bs-table-striped-bg: #ecedee;
  --bs-table-striped-color: #000;
  --bs-table-active-bg: #dfe0e1;
  --bs-table-active-color: #000;
  --bs-table-hover-bg: #e5e6e7;
  --bs-table-hover-color: #000;
  color: var(--bs-table-color);
  border-color: var(--bs-table-border-color);
}

.table-dark {
  --bs-table-color: white;
  --bs-table-bg: #2d374b;
  --bs-table-border-color: #575f6f;
  --bs-table-striped-bg: #384154;
  --bs-table-striped-color: white;
  --bs-table-active-bg: #424b5d;
  --bs-table-active-color: white;
  --bs-table-hover-bg: #3d4659;
  --bs-table-hover-color: white;
  color: var(--bs-table-color);
  border-color: var(--bs-table-border-color);
}

.table-responsive {
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
}

@media (max-width: 575.98px) {
  .table-responsive-sm {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
  }
}
@media (max-width: 767.98px) {
  .table-responsive-md {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
  }
}
@media (max-width: 991.98px) {
  .table-responsive-lg {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
  }
}
@media (max-width: 1199.98px) {
  .table-responsive-xl {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
  }
}
@media (max-width: 1399.98px) {
  .table-responsive-xxl {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
  }
}
.form-label {
  margin-bottom: 0.5rem;
  font-size: 0.875rem;
  font-weight: 500;
}

.col-form-label {
  padding-top: 0.8125rem;
  padding-bottom: 0.8125rem;
  margin-bottom: 0;
  font-size: inherit;
  font-weight: 500;
  line-height: 1.5;
}

.col-form-label-lg {
  padding-top: 0.8125rem;
  padding-bottom: 0.8125rem;
  font-size: 1rem;
}

.col-form-label-sm {
  padding-top: 0.5625rem;
  padding-bottom: 0.5625rem;
  font-size: 0.8125rem;
}

.form-text {
  margin-top: 1rem;
  font-size: 0.875em;
  color: var(--bs-secondary-color);
}

.form-control {
  display: block;
  width: 100%;
  padding: 0.75rem 1.8125rem;
  font-size: 0.9375rem;
  font-weight: 400;
  line-height: 1.5;
  color: #51596C;
  appearance: none;
  background-color: var(--bs-body-bg);
  background-clip: padding-box;
  border: 0.0625rem solid rgba(220, 224, 229, 0.6);
  border-radius: 0.4rem;
  box-shadow: var(--bs-box-shadow-inset);
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
@media (prefers-reduced-motion: reduce) {
  .form-control {
    transition: none;
  }
}
.form-control[type=file] {
  overflow: hidden;
}
.form-control[type=file]:not(:disabled):not([readonly]) {
  cursor: pointer;
}
.form-control:focus {
  color: #51596C;
  background-color: var(--bs-body-bg);
  border-color: rgba(140, 152, 164, 0.25);
  outline: 0;
  box-shadow: var(--bs-box-shadow-inset), 0 0 1rem 0 rgba(140, 152, 164, 0.25);
}
.form-control::-webkit-date-and-time-value {
  min-width: 85px;
  height: 1.5em;
  margin: 0;
}
.form-control::-webkit-datetime-edit {
  display: block;
  padding: 0;
}
.form-control::placeholder {
  color: #8C98A4;
  opacity: 1;
}
.form-control:disabled {
  background-color: var(--bs-secondary-bg);
  opacity: 1;
}
.form-control::file-selector-button {
  padding: 0.75rem 1.8125rem;
  margin: -0.75rem -1.8125rem;
  margin-inline-end: 1.8125rem;
  color: #51596C;
  background-color: var(--bs-tertiary-bg);
  pointer-events: none;
  border-color: inherit;
  border-style: solid;
  border-width: 0;
  border-inline-end-width: 0.0625rem;
  border-radius: 0;
  transition: all 0.2s ease-in-out;
}
@media (prefers-reduced-motion: reduce) {
  .form-control::file-selector-button {
    transition: none;
  }
}
.form-control:hover:not(:disabled):not([readonly])::file-selector-button {
  background-color: var(--bs-secondary-bg);
}

.form-control-plaintext {
  display: block;
  width: 100%;
  padding: 0.75rem 0;
  margin-bottom: 0;
  line-height: 1.5;
  color: var(--bs-body-color);
  background-color: transparent;
  border: solid transparent;
  border-width: 0.0625rem 0;
}
.form-control-plaintext:focus {
  outline: 0;
}
.form-control-plaintext.form-control-sm, .form-control-plaintext.form-control-lg {
  padding-right: 0;
  padding-left: 0;
}

.form-control-sm {
  min-height: calc(1.5em + 1rem + calc(0.0625rem * 2));
  padding: 0.5rem 0.875rem;
  font-size: 0.8125rem;
  border-radius: 0.4rem;
}
.form-control-sm::file-selector-button {
  padding: 0.5rem 0.875rem;
  margin: -0.5rem -0.875rem;
  margin-inline-end: 0.875rem;
}

.form-control-lg {
  min-height: calc(1.5em + 1.5rem + calc(0.0625rem * 2));
  padding: 0.75rem 1rem;
  font-size: 1rem;
  border-radius: 0.4rem;
}
.form-control-lg::file-selector-button {
  padding: 0.75rem 1rem;
  margin: -0.75rem -1rem;
  margin-inline-end: 1rem;
}

textarea.form-control {
  min-height: calc(1.5em + 1.5rem + calc(0.0625rem * 2));
}
textarea.form-control-sm {
  min-height: calc(1.5em + 1rem + calc(0.0625rem * 2));
}
textarea.form-control-lg {
  min-height: calc(1.5em + 1.5rem + calc(0.0625rem * 2));
}

.form-control-color {
  width: 3rem;
  height: calc(1.5em + 1.5rem + calc(0.0625rem * 2));
  padding: 0.75rem;
}
.form-control-color:not(:disabled):not([readonly]) {
  cursor: pointer;
}
.form-control-color::-moz-color-swatch {
  border: 0 !important;
  border-radius: 0.4rem;
}
.form-control-color::-webkit-color-swatch {
  border: 0 !important;
  border-radius: 0.4rem;
}
.form-control-color.form-control-sm {
  height: calc(1.5em + 1rem + calc(0.0625rem * 2));
}
.form-control-color.form-control-lg {
  height: calc(1.5em + 1.5rem + calc(0.0625rem * 2));
}

.form-select {
  --bs-form-select-bg-img: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%2351596C' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e");
  display: block;
  width: 100%;
  padding: 0.75rem 5.4375rem 0.75rem 1.8125rem;
  font-size: 0.9375rem;
  font-weight: 400;
  line-height: 1.5;
  color: #51596C;
  appearance: none;
  background-color: var(--bs-body-bg);
  background-image: var(--bs-form-select-bg-img), var(--bs-form-select-bg-icon, none);
  background-repeat: no-repeat;
  background-position: right 1.8125rem center;
  background-size: 16px 12px;
  border: 0.0625rem solid rgba(220, 224, 229, 0.6);
  border-radius: 0.4rem;
  box-shadow: var(--bs-box-shadow-inset);
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
@media (prefers-reduced-motion: reduce) {
  .form-select {
    transition: none;
  }
}
.form-select:focus {
  border-color: rgba(140, 152, 164, 0.25);
  outline: 0;
  box-shadow: var(--bs-box-shadow-inset), 0 0 1rem 0 rgba(140, 152, 164, 0.25);
}
.form-select[multiple], .form-select[size]:not([size="1"]) {
  padding-right: 1.8125rem;
  background-image: none;
}
.form-select:disabled {
  background-color: var(--bs-secondary-bg);
}
.form-select:-moz-focusring {
  color: transparent;
  text-shadow: 0 0 0 #51596C;
}

.form-select-sm {
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
  padding-left: 0.875rem;
  font-size: 0.8125rem;
  border-radius: 0.4rem;
}

.form-select-lg {
  padding-top: 0.75rem;
  padding-bottom: 0.75rem;
  padding-left: 1rem;
  font-size: 1rem;
  border-radius: 0.4rem;
}

[data-bs-theme=dark] .form-select {
  --bs-form-select-bg-img: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23dce0e5' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e");
}

.form-check {
  display: block;
  min-height: 1.5rem;
  padding-left: 1.5rem;
  margin-bottom: 0.125rem;
}
.form-check .form-check-input {
  float: left;
  margin-left: -1.5rem;
}

.form-check-reverse {
  padding-right: 1.5rem;
  padding-left: 0;
  text-align: right;
}
.form-check-reverse .form-check-input {
  float: right;
  margin-right: -1.5rem;
  margin-left: 0;
}

.form-check-input {
  --bs-form-check-bg: var(--bs-body-bg);
  flex-shrink: 0;
  width: 1rem;
  height: 1rem;
  margin-top: 0.25rem;
  vertical-align: top;
  appearance: none;
  background-color: var(--bs-form-check-bg);
  background-image: var(--bs-form-check-bg-image);
  background-repeat: no-repeat;
  background-position: center;
  background-size: contain;
  border: 1px solid #dce0e5;
  print-color-adjust: exact;
}
.form-check-input[type=checkbox] {
  border-radius: 0.25em;
}
.form-check-input[type=radio] {
  border-radius: 50%;
}
.form-check-input:active {
  filter: 100%;
}
.form-check-input:focus {
  border-color: rgba(140, 152, 164, 0.25);
  outline: 0;
  box-shadow: 0 0 0 0.25rem rgba(10, 191, 83, 0.25);
}
.form-check-input:checked {
  background-color: #0abf53;
  border-color: #0abf53;
}
.form-check-input:checked[type=checkbox] {
  --bs-form-check-bg-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3e%3cpath fill='none' stroke='white' stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='m6 10 3 3 6-6'/%3e%3c/svg%3e");
}
.form-check-input:checked[type=radio] {
  --bs-form-check-bg-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='2' fill='white'/%3e%3c/svg%3e");
}
.form-check-input[type=checkbox]:indeterminate {
  background-color: #0abf53;
  border-color: #0abf53;
  --bs-form-check-bg-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3e%3cpath fill='none' stroke='white' stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='M6 10h8'/%3e%3c/svg%3e");
}
.form-check-input:disabled {
  pointer-events: none;
  filter: none;
  opacity: 0.5;
}
.form-check-input[disabled] ~ .form-check-label, .form-check-input:disabled ~ .form-check-label {
  cursor: default;
  opacity: 0.5;
}

.form-check-label {
  color: #51596C;
}

.form-switch {
  padding-left: 2.5em;
}
.form-switch .form-check-input {
  --bs-form-switch-bg: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='white'/%3e%3c/svg%3e");
  width: 2em;
  margin-left: -2.5em;
  background-image: var(--bs-form-switch-bg);
  background-position: left center;
  border-radius: 2em;
  transition: background-position 0.15s ease-in-out;
}
@media (prefers-reduced-motion: reduce) {
  .form-switch .form-check-input {
    transition: none;
  }
}
.form-switch .form-check-input:focus {
  --bs-form-switch-bg: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='rgba%28140, 152, 164, 0.25%29'/%3e%3c/svg%3e");
}
.form-switch .form-check-input:checked {
  background-position: right center;
  --bs-form-switch-bg: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='white'/%3e%3c/svg%3e");
}
.form-switch.form-check-reverse {
  padding-right: 2.5em;
  padding-left: 0;
}
.form-switch.form-check-reverse .form-check-input {
  margin-right: -2.5em;
  margin-left: 0;
}

.form-check-inline {
  display: inline-block;
  margin-right: 1rem;
}

.btn-check {
  position: absolute;
  clip: rect(0, 0, 0, 0);
  pointer-events: none;
}
.btn-check[disabled] + .btn, .btn-check:disabled + .btn {
  pointer-events: none;
  filter: none;
  opacity: 0.65;
}

[data-bs-theme=dark] .form-switch .form-check-input:not(:checked):not(:focus) {
  --bs-form-switch-bg: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='rgba%28255, 255, 255, 0.25%29'/%3e%3c/svg%3e");
}

.form-range {
  width: 100%;
  height: 1rem;
  padding: 0;
  appearance: none;
  background-color: transparent;
}
.form-range:focus {
  outline: 0;
}
.form-range:focus::-webkit-slider-thumb {
  box-shadow: 0 0 0 1px white, 0 0 1rem 0 rgba(140, 152, 164, 0.25);
}
.form-range:focus::-moz-range-thumb {
  box-shadow: 0 0 0 1px white, 0 0 1rem 0 rgba(140, 152, 164, 0.25);
}
.form-range::-moz-focus-outer {
  border: 0;
}
.form-range::-webkit-slider-thumb {
  width: 1rem;
  height: 1rem;
  margin-top: -0.25rem;
  appearance: none;
  background-color: #0abf53;
  border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.1rem 0.25rem rgba(0, 0, 0, 0.1);
  transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
@media (prefers-reduced-motion: reduce) {
  .form-range::-webkit-slider-thumb {
    transition: none;
  }
}
.form-range::-webkit-slider-thumb:active {
  background-color: #b6eccb;
}
.form-range::-webkit-slider-runnable-track {
  width: 100%;
  height: 0.5rem;
  color: transparent;
  cursor: pointer;
  background-color: var(--bs-secondary-bg);
  border-color: transparent;
  border-radius: 1rem;
  box-shadow: var(--bs-box-shadow-inset);
}
.form-range::-moz-range-thumb {
  width: 1rem;
  height: 1rem;
  appearance: none;
  background-color: #0abf53;
  border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.1rem 0.25rem rgba(0, 0, 0, 0.1);
  transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
@media (prefers-reduced-motion: reduce) {
  .form-range::-moz-range-thumb {
    transition: none;
  }
}
.form-range::-moz-range-thumb:active {
  background-color: #b6eccb;
}
.form-range::-moz-range-track {
  width: 100%;
  height: 0.5rem;
  color: transparent;
  cursor: pointer;
  background-color: var(--bs-secondary-bg);
  border-color: transparent;
  border-radius: 1rem;
  box-shadow: var(--bs-box-shadow-inset);
}
.form-range:disabled {
  pointer-events: none;
}
.form-range:disabled::-webkit-slider-thumb {
  background-color: var(--bs-secondary-color);
}
.form-range:disabled::-moz-range-thumb {
  background-color: var(--bs-secondary-color);
}

.form-floating {
  position: relative;
}
.form-floating > .form-control,
.form-floating > .form-control-plaintext,
.form-floating > .form-select {
  height: calc(3.5rem + calc(0.0625rem * 2));
  min-height: calc(3.5rem + calc(0.0625rem * 2));
  line-height: 1.25;
}
.form-floating > label {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 2;
  height: 100%;
  padding: 1rem 1.8125rem;
  overflow: hidden;
  text-align: start;
  text-overflow: ellipsis;
  white-space: nowrap;
  pointer-events: none;
  border: 0.0625rem solid transparent;
  transform-origin: 0 0;
  transition: opacity 0.1s ease-in-out, transform 0.1s ease-in-out;
}
@media (prefers-reduced-motion: reduce) {
  .form-floating > label {
    transition: none;
  }
}
.form-floating > .form-control,
.form-floating > .form-control-plaintext {
  padding: 1rem 1.8125rem;
}
.form-floating > .form-control::placeholder,
.form-floating > .form-control-plaintext::placeholder {
  color: transparent;
}
.form-floating > .form-control:focus, .form-floating > .form-control:not(:placeholder-shown),
.form-floating > .form-control-plaintext:focus,
.form-floating > .form-control-plaintext:not(:placeholder-shown) {
  padding-top: 1.625rem;
  padding-bottom: 0.625rem;
}
.form-floating > .form-control:-webkit-autofill,
.form-floating > .form-control-plaintext:-webkit-autofill {
  padding-top: 1.625rem;
  padding-bottom: 0.625rem;
}
.form-floating > .form-select {
  padding-top: 1.625rem;
  padding-bottom: 0.625rem;
}
.form-floating > .form-control:focus ~ label,
.form-floating > .form-control:not(:placeholder-shown) ~ label,
.form-floating > .form-control-plaintext ~ label,
.form-floating > .form-select ~ label {
  color: rgba(var(--bs-body-color-rgb), 0.65);
  transform: scale(0.85) translateY(-0.5rem) translateX(0.15rem);
}
.form-floating > .form-control:focus ~ label::after,
.form-floating > .form-control:not(:placeholder-shown) ~ label::after,
.form-floating > .form-control-plaintext ~ label::after,
.form-floating > .form-select ~ label::after {
  position: absolute;
  inset: 1rem 0.90625rem;
  z-index: -1;
  height: 1.5em;
  content: "";
  background-color: var(--bs-body-bg);
  border-radius: 0.4rem;
}
.form-floating > .form-control:-webkit-autofill ~ label {
  color: rgba(var(--bs-body-color-rgb), 0.65);
  transform: scale(0.85) translateY(-0.5rem) translateX(0.15rem);
}
.form-floating > .form-control-plaintext ~ label {
  border-width: 0.0625rem 0;
}
.form-floating > :disabled ~ label,
.form-floating > .form-control:disabled ~ label {
  color: #8C98A4;
}
.form-floating > :disabled ~ label::after,
.form-floating > .form-control:disabled ~ label::after {
  background-color: var(--bs-secondary-bg);
}

.input-group {
  position: relative;
  display: flex;
  flex-wrap: wrap;
  align-items: stretch;
  width: 100%;
}
.input-group > .form-control,
.input-group > .form-select,
.input-group > .form-floating {
  position: relative;
  flex: 1 1 auto;
  width: 1%;
  min-width: 0;
}
.input-group > .form-control:focus,
.input-group > .form-select:focus,
.input-group > .form-floating:focus-within {
  z-index: 5;
}
.input-group .btn {
  position: relative;
  z-index: 2;
}
.input-group .btn:focus {
  z-index: 5;
}

.input-group-text {
  display: flex;
  align-items: center;
  padding: 0.75rem 0.90625rem;
  font-size: 0.9375rem;
  font-weight: 400;
  line-height: 1.5;
  color: #8C98A4;
  text-align: center;
  white-space: nowrap;
  background-color: white;
  border: 0.0625rem solid rgba(220, 224, 229, 0.6);
  border-radius: 0.4rem;
}

.input-group-lg > .form-control,
.input-group-lg > .form-select,
.input-group-lg > .input-group-text,
.input-group-lg > .btn {
  padding: 0.75rem 1rem;
  font-size: 1rem;
  border-radius: 0.4rem;
}

.input-group-sm > .form-control,
.input-group-sm > .form-select,
.input-group-sm > .input-group-text,
.input-group-sm > .btn {
  padding: 0.5rem 0.875rem;
  font-size: 0.8125rem;
  border-radius: 0.4rem;
}

.input-group-lg > .form-select,
.input-group-sm > .form-select {
  padding-right: 7.25rem;
}

.input-group:not(.has-validation) > :not(:last-child):not(.dropdown-toggle):not(.dropdown-menu):not(.form-floating),
.input-group:not(.has-validation) > .dropdown-toggle:nth-last-child(n+3),
.input-group:not(.has-validation) > .form-floating:not(:last-child) > .form-control,
.input-group:not(.has-validation) > .form-floating:not(:last-child) > .form-select {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
.input-group.has-validation > :nth-last-child(n+3):not(.dropdown-toggle):not(.dropdown-menu):not(.form-floating),
.input-group.has-validation > .dropdown-toggle:nth-last-child(n+4),
.input-group.has-validation > .form-floating:nth-last-child(n+3) > .form-control,
.input-group.has-validation > .form-floating:nth-last-child(n+3) > .form-select {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
.input-group > :not(:first-child):not(.dropdown-menu):not(.valid-tooltip):not(.valid-feedback):not(.invalid-tooltip):not(.invalid-feedback) {
  margin-left: calc(0.0625rem * -1);
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}
.input-group > .form-floating:not(:first-child) > .form-control,
.input-group > .form-floating:not(:first-child) > .form-select {
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}

.valid-feedback {
  display: none;
  width: 100%;
  margin-top: 0.25rem;
  font-size: 0.875em;
  color: var(--bs-form-valid-color);
}

.valid-tooltip {
  position: absolute;
  top: 100%;
  z-index: 5;
  display: none;
  max-width: 100%;
  padding: 0.25rem 0.5rem;
  margin-top: 0.1rem;
  font-size: 0.8125rem;
  color: #fff;
  background-color: var(--bs-success);
  border-radius: var(--bs-border-radius);
}

.was-validated :valid ~ .valid-feedback,
.was-validated :valid ~ .valid-tooltip,
.is-valid ~ .valid-feedback,
.is-valid ~ .valid-tooltip {
  display: block;
}

.was-validated .form-control:valid, .form-control.is-valid {
  border-color: var(--bs-form-valid-border-color);
}
.was-validated .form-control:valid:focus, .form-control.is-valid:focus {
  border-color: var(--bs-form-valid-border-color);
  box-shadow: 0 0 1rem 0 rgba(var(--bs-success-rgb), 0.25);
}

.was-validated .form-select:valid, .form-select.is-valid {
  border-color: var(--bs-form-valid-border-color);
}
.was-validated .form-select:valid:focus, .form-select.is-valid:focus {
  border-color: var(--bs-form-valid-border-color);
  box-shadow: 0 0 1rem 0 rgba(var(--bs-success-rgb), 0.25);
}

.was-validated .form-check-input:valid, .form-check-input.is-valid {
  border-color: var(--bs-form-valid-border-color);
}
.was-validated .form-check-input:valid:checked, .form-check-input.is-valid:checked {
  background-color: var(--bs-form-valid-color);
}
.was-validated .form-check-input:valid:focus, .form-check-input.is-valid:focus {
  box-shadow: 0 0 1rem 0 rgba(var(--bs-success-rgb), 0.25);
}
.was-validated .form-check-input:valid ~ .form-check-label, .form-check-input.is-valid ~ .form-check-label {
  color: var(--bs-form-valid-color);
}

.form-check-inline .form-check-input ~ .valid-feedback {
  margin-left: 0.5em;
}

.was-validated .input-group > .form-control:not(:focus):valid, .input-group > .form-control:not(:focus).is-valid,
.was-validated .input-group > .form-select:not(:focus):valid,
.input-group > .form-select:not(:focus).is-valid,
.was-validated .input-group > .form-floating:not(:focus-within):valid,
.input-group > .form-floating:not(:focus-within).is-valid {
  z-index: 3;
}

.invalid-feedback {
  display: none;
  width: 100%;
  margin-top: 0.25rem;
  font-size: 0.875em;
  color: var(--bs-form-invalid-color);
}

.invalid-tooltip {
  position: absolute;
  top: 100%;
  z-index: 5;
  display: none;
  max-width: 100%;
  padding: 0.25rem 0.5rem;
  margin-top: 0.1rem;
  font-size: 0.8125rem;
  color: #fff;
  background-color: var(--bs-danger);
  border-radius: var(--bs-border-radius);
}

.was-validated :invalid ~ .invalid-feedback,
.was-validated :invalid ~ .invalid-tooltip,
.is-invalid ~ .invalid-feedback,
.is-invalid ~ .invalid-tooltip {
  display: block;
}

.was-validated .form-control:invalid, .form-control.is-invalid {
  border-color: var(--bs-form-invalid-border-color);
}
.was-validated .form-control:invalid:focus, .form-control.is-invalid:focus {
  border-color: var(--bs-form-invalid-border-color);
  box-shadow: 0 0 1rem 0 rgba(var(--bs-danger-rgb), 0.25);
}

.was-validated .form-select:invalid, .form-select.is-invalid {
  border-color: var(--bs-form-invalid-border-color);
}
.was-validated .form-select:invalid:focus, .form-select.is-invalid:focus {
  border-color: var(--bs-form-invalid-border-color);
  box-shadow: 0 0 1rem 0 rgba(var(--bs-danger-rgb), 0.25);
}

.was-validated .form-check-input:invalid, .form-check-input.is-invalid {
  border-color: var(--bs-form-invalid-border-color);
}
.was-validated .form-check-input:invalid:checked, .form-check-input.is-invalid:checked {
  background-color: var(--bs-form-invalid-color);
}
.was-validated .form-check-input:invalid:focus, .form-check-input.is-invalid:focus {
  box-shadow: 0 0 1rem 0 rgba(var(--bs-danger-rgb), 0.25);
}
.was-validated .form-check-input:invalid ~ .form-check-label, .form-check-input.is-invalid ~ .form-check-label {
  color: var(--bs-form-invalid-color);
}

.form-check-inline .form-check-input ~ .invalid-feedback {
  margin-left: 0.5em;
}

.was-validated .input-group > .form-control:not(:focus):invalid, .input-group > .form-control:not(:focus).is-invalid,
.was-validated .input-group > .form-select:not(:focus):invalid,
.input-group > .form-select:not(:focus).is-invalid,
.was-validated .input-group > .form-floating:not(:focus-within):invalid,
.input-group > .form-floating:not(:focus-within).is-invalid {
  z-index: 4;
}

.btn {
  --bs-btn-padding-x: 1.8125rem;
  --bs-btn-padding-y: 0.75rem;
  --bs-btn-font-family: ;
  --bs-btn-font-size: 0.9375rem;
  --bs-btn-font-weight: 700;
  --bs-btn-line-height: 1.5;
  --bs-btn-color: var(--bs-body-color);
  --bs-btn-bg: transparent;
  --bs-btn-border-width: 0.125rem;
  --bs-btn-border-color: transparent;
  --bs-btn-border-radius: 0.6rem;
  --bs-btn-hover-border-color: transparent;
  --bs-btn-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.15), 0 1px 1px rgba(0, 0, 0, 0.075);
  --bs-btn-disabled-opacity: 0.65;
  --bs-btn-focus-box-shadow: 0 0 0 0 rgba(var(--bs-btn-focus-shadow-rgb), .5);
  display: inline-block;
  padding: var(--bs-btn-padding-y) var(--bs-btn-padding-x);
  font-family: var(--bs-btn-font-family);
  font-size: var(--bs-btn-font-size);
  font-weight: var(--bs-btn-font-weight);
  line-height: var(--bs-btn-line-height);
  color: var(--bs-btn-color);
  text-align: center;
  vertical-align: middle;
  cursor: pointer;
  user-select: none;
  border: var(--bs-btn-border-width) solid var(--bs-btn-border-color);
  border-radius: var(--bs-btn-border-radius);
  background-color: var(--bs-btn-bg);
  box-shadow: var(--bs-btn-box-shadow);
  transition: all 0.2s ease-in-out;
}
@media (prefers-reduced-motion: reduce) {
  .btn {
    transition: none;
  }
}
.btn:hover {
  color: var(--bs-btn-hover-color);
  background-color: var(--bs-btn-hover-bg);
  border-color: var(--bs-btn-hover-border-color);
}
.btn-check + .btn:hover {
  color: var(--bs-btn-color);
  background-color: var(--bs-btn-bg);
  border-color: var(--bs-btn-border-color);
}
.btn:focus-visible {
  color: var(--bs-btn-hover-color);
  background-color: var(--bs-btn-hover-bg);
  border-color: var(--bs-btn-hover-border-color);
  outline: 0;
  box-shadow: var(--bs-btn-box-shadow), var(--bs-btn-focus-box-shadow);
}
.btn-check:focus-visible + .btn {
  border-color: var(--bs-btn-hover-border-color);
  outline: 0;
  box-shadow: var(--bs-btn-box-shadow), var(--bs-btn-focus-box-shadow);
}
.btn-check:checked + .btn, :not(.btn-check) + .btn:active, .btn:first-child:active, .btn.active, .btn.show {
  color: var(--bs-btn-active-color);
  background-color: var(--bs-btn-active-bg);
  border-color: var(--bs-btn-active-border-color);
  box-shadow: var(--bs-btn-active-shadow);
}
.btn-check:checked + .btn:focus-visible, :not(.btn-check) + .btn:active:focus-visible, .btn:first-child:active:focus-visible, .btn.active:focus-visible, .btn.show:focus-visible {
  box-shadow: var(--bs-btn-active-shadow), var(--bs-btn-focus-box-shadow);
}
.btn:disabled, .btn.disabled, fieldset:disabled .btn {
  color: var(--bs-btn-disabled-color);
  pointer-events: none;
  background-color: var(--bs-btn-disabled-bg);
  border-color: var(--bs-btn-disabled-border-color);
  opacity: var(--bs-btn-disabled-opacity);
  box-shadow: none;
}

.btn-primary {
  --bs-btn-color: white;
  --bs-btn-bg: #0abf53;
  --bs-btn-border-color: #0abf53;
  --bs-btn-hover-color: white;
  --bs-btn-hover-bg: #09a247;
  --bs-btn-hover-border-color: #089942;
  --bs-btn-focus-shadow-rgb: 47, 201, 109;
  --bs-btn-active-color: white;
  --bs-btn-active-bg: #089942;
  --bs-btn-active-border-color: #088f3e;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-disabled-color: white;
  --bs-btn-disabled-bg: #0abf53;
  --bs-btn-disabled-border-color: #0abf53;
}

.btn-secondary {
  --bs-btn-color: white;
  --bs-btn-bg: #51596c;
  --bs-btn-border-color: #51596c;
  --bs-btn-hover-color: white;
  --bs-btn-hover-bg: #454c5c;
  --bs-btn-hover-border-color: #414756;
  --bs-btn-focus-shadow-rgb: 107, 114, 130;
  --bs-btn-active-color: white;
  --bs-btn-active-bg: #414756;
  --bs-btn-active-border-color: #3d4351;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-disabled-color: white;
  --bs-btn-disabled-bg: #51596c;
  --bs-btn-disabled-border-color: #51596c;
}

.btn-success {
  --bs-btn-color: white;
  --bs-btn-bg: #077c76;
  --bs-btn-border-color: #077c76;
  --bs-btn-hover-color: white;
  --bs-btn-hover-bg: #066964;
  --bs-btn-hover-border-color: #06635e;
  --bs-btn-focus-shadow-rgb: 44, 144, 139;
  --bs-btn-active-color: white;
  --bs-btn-active-bg: #06635e;
  --bs-btn-active-border-color: #055d59;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-disabled-color: white;
  --bs-btn-disabled-bg: #077c76;
  --bs-btn-disabled-border-color: #077c76;
}

.btn-info {
  --bs-btn-color: white;
  --bs-btn-bg: #334ac0;
  --bs-btn-border-color: #334ac0;
  --bs-btn-hover-color: white;
  --bs-btn-hover-bg: #2b3fa3;
  --bs-btn-hover-border-color: #293b9a;
  --bs-btn-focus-shadow-rgb: 82, 101, 201;
  --bs-btn-active-color: white;
  --bs-btn-active-bg: #293b9a;
  --bs-btn-active-border-color: #263890;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-disabled-color: white;
  --bs-btn-disabled-bg: #334ac0;
  --bs-btn-disabled-border-color: #334ac0;
}

.btn-warning {
  --bs-btn-color: #000;
  --bs-btn-bg: #f39568;
  --bs-btn-border-color: #f39568;
  --bs-btn-hover-color: #000;
  --bs-btn-hover-bg: #f5a57f;
  --bs-btn-hover-border-color: #f4a077;
  --bs-btn-focus-shadow-rgb: 207, 127, 88;
  --bs-btn-active-color: #000;
  --bs-btn-active-bg: #f5aa86;
  --bs-btn-active-border-color: #f4a077;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-disabled-color: #000;
  --bs-btn-disabled-bg: #f39568;
  --bs-btn-disabled-border-color: #f39568;
}

.btn-danger {
  --bs-btn-color: white;
  --bs-btn-bg: #692340;
  --bs-btn-border-color: #692340;
  --bs-btn-hover-color: white;
  --bs-btn-hover-bg: #591e36;
  --bs-btn-hover-border-color: #541c33;
  --bs-btn-focus-shadow-rgb: 128, 68, 93;
  --bs-btn-active-color: white;
  --bs-btn-active-bg: #541c33;
  --bs-btn-active-border-color: #4f1a30;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-disabled-color: white;
  --bs-btn-disabled-bg: #692340;
  --bs-btn-disabled-border-color: #692340;
}

.btn-light {
  --bs-btn-color: #000;
  --bs-btn-bg: #f8f9fa;
  --bs-btn-border-color: #f8f9fa;
  --bs-btn-hover-color: #000;
  --bs-btn-hover-bg: #d3d4d5;
  --bs-btn-hover-border-color: #c6c7c8;
  --bs-btn-focus-shadow-rgb: 211, 212, 213;
  --bs-btn-active-color: #000;
  --bs-btn-active-bg: #c6c7c8;
  --bs-btn-active-border-color: #babbbc;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-disabled-color: #000;
  --bs-btn-disabled-bg: #f8f9fa;
  --bs-btn-disabled-border-color: #f8f9fa;
}

.btn-dark {
  --bs-btn-color: white;
  --bs-btn-bg: #2d374b;
  --bs-btn-border-color: #2d374b;
  --bs-btn-hover-color: white;
  --bs-btn-hover-bg: #4d5566;
  --bs-btn-hover-border-color: #424b5d;
  --bs-btn-focus-shadow-rgb: 77, 85, 102;
  --bs-btn-active-color: white;
  --bs-btn-active-bg: #575f6f;
  --bs-btn-active-border-color: #424b5d;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-disabled-color: white;
  --bs-btn-disabled-bg: #2d374b;
  --bs-btn-disabled-border-color: #2d374b;
}

.btn-outline-primary {
  --bs-btn-color: #0abf53;
  --bs-btn-border-color: #0abf53;
  --bs-btn-hover-color: white;
  --bs-btn-hover-bg: #0abf53;
  --bs-btn-hover-border-color: #0abf53;
  --bs-btn-focus-shadow-rgb: 10, 191, 83;
  --bs-btn-active-color: white;
  --bs-btn-active-bg: #0abf53;
  --bs-btn-active-border-color: #0abf53;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-disabled-color: #0abf53;
  --bs-btn-disabled-bg: transparent;
  --bs-btn-disabled-border-color: #0abf53;
  --bs-gradient: none;
}

.btn-outline-secondary {
  --bs-btn-color: #51596c;
  --bs-btn-border-color: #51596c;
  --bs-btn-hover-color: white;
  --bs-btn-hover-bg: #51596c;
  --bs-btn-hover-border-color: #51596c;
  --bs-btn-focus-shadow-rgb: 81, 89, 108;
  --bs-btn-active-color: white;
  --bs-btn-active-bg: #51596c;
  --bs-btn-active-border-color: #51596c;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-disabled-color: #51596c;
  --bs-btn-disabled-bg: transparent;
  --bs-btn-disabled-border-color: #51596c;
  --bs-gradient: none;
}

.btn-outline-success {
  --bs-btn-color: #077c76;
  --bs-btn-border-color: #077c76;
  --bs-btn-hover-color: white;
  --bs-btn-hover-bg: #077c76;
  --bs-btn-hover-border-color: #077c76;
  --bs-btn-focus-shadow-rgb: 7, 124, 118;
  --bs-btn-active-color: white;
  --bs-btn-active-bg: #077c76;
  --bs-btn-active-border-color: #077c76;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-disabled-color: #077c76;
  --bs-btn-disabled-bg: transparent;
  --bs-btn-disabled-border-color: #077c76;
  --bs-gradient: none;
}

.btn-outline-info {
  --bs-btn-color: #334ac0;
  --bs-btn-border-color: #334ac0;
  --bs-btn-hover-color: white;
  --bs-btn-hover-bg: #334ac0;
  --bs-btn-hover-border-color: #334ac0;
  --bs-btn-focus-shadow-rgb: 51, 74, 192;
  --bs-btn-active-color: white;
  --bs-btn-active-bg: #334ac0;
  --bs-btn-active-border-color: #334ac0;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-disabled-color: #334ac0;
  --bs-btn-disabled-bg: transparent;
  --bs-btn-disabled-border-color: #334ac0;
  --bs-gradient: none;
}

.btn-outline-warning {
  --bs-btn-color: #f39568;
  --bs-btn-border-color: #f39568;
  --bs-btn-hover-color: #000;
  --bs-btn-hover-bg: #f39568;
  --bs-btn-hover-border-color: #f39568;
  --bs-btn-focus-shadow-rgb: 243, 149, 104;
  --bs-btn-active-color: #000;
  --bs-btn-active-bg: #f39568;
  --bs-btn-active-border-color: #f39568;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-disabled-color: #f39568;
  --bs-btn-disabled-bg: transparent;
  --bs-btn-disabled-border-color: #f39568;
  --bs-gradient: none;
}

.btn-outline-danger {
  --bs-btn-color: #692340;
  --bs-btn-border-color: #692340;
  --bs-btn-hover-color: white;
  --bs-btn-hover-bg: #692340;
  --bs-btn-hover-border-color: #692340;
  --bs-btn-focus-shadow-rgb: 105, 35, 64;
  --bs-btn-active-color: white;
  --bs-btn-active-bg: #692340;
  --bs-btn-active-border-color: #692340;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-disabled-color: #692340;
  --bs-btn-disabled-bg: transparent;
  --bs-btn-disabled-border-color: #692340;
  --bs-gradient: none;
}

.btn-outline-light {
  --bs-btn-color: #f8f9fa;
  --bs-btn-border-color: #f8f9fa;
  --bs-btn-hover-color: #000;
  --bs-btn-hover-bg: #f8f9fa;
  --bs-btn-hover-border-color: #f8f9fa;
  --bs-btn-focus-shadow-rgb: 248, 249, 250;
  --bs-btn-active-color: #000;
  --bs-btn-active-bg: #f8f9fa;
  --bs-btn-active-border-color: #f8f9fa;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-disabled-color: #f8f9fa;
  --bs-btn-disabled-bg: transparent;
  --bs-btn-disabled-border-color: #f8f9fa;
  --bs-gradient: none;
}

.btn-outline-dark {
  --bs-btn-color: #2d374b;
  --bs-btn-border-color: #2d374b;
  --bs-btn-hover-color: white;
  --bs-btn-hover-bg: #2d374b;
  --bs-btn-hover-border-color: #2d374b;
  --bs-btn-focus-shadow-rgb: 45, 55, 75;
  --bs-btn-active-color: white;
  --bs-btn-active-bg: #2d374b;
  --bs-btn-active-border-color: #2d374b;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-disabled-color: #2d374b;
  --bs-btn-disabled-bg: transparent;
  --bs-btn-disabled-border-color: #2d374b;
  --bs-gradient: none;
}

.btn-link {
  --bs-btn-font-weight: 400;
  --bs-btn-color: var(--bs-link-color);
  --bs-btn-bg: transparent;
  --bs-btn-border-color: transparent;
  --bs-btn-hover-color: var(--bs-link-hover-color);
  --bs-btn-hover-border-color: transparent;
  --bs-btn-active-color: var(--bs-link-hover-color);
  --bs-btn-active-border-color: transparent;
  --bs-btn-disabled-color: #8C98A4;
  --bs-btn-disabled-border-color: transparent;
  --bs-btn-box-shadow: 0 0 0 #000;
  --bs-btn-focus-shadow-rgb: 47, 201, 109;
  text-decoration: none;
}
.btn-link:focus-visible {
  color: var(--bs-btn-color);
}
.btn-link:hover {
  color: var(--bs-btn-hover-color);
}

.btn-lg, .btn-group-lg > .btn {
  --bs-btn-padding-y: 0.75rem;
  --bs-btn-padding-x: 1rem;
  --bs-btn-font-size: 1rem;
  --bs-btn-border-radius: 0.8rem;
}

.btn-sm, .btn-group-sm > .btn {
  --bs-btn-padding-y: 0.5rem;
  --bs-btn-padding-x: 0.875rem;
  --bs-btn-font-size: 0.8125rem;
  --bs-btn-border-radius: 0.4rem;
}

.fade {
  transition: opacity 0.15s linear;
}
@media (prefers-reduced-motion: reduce) {
  .fade {
    transition: none;
  }
}
.fade:not(.show) {
  opacity: 0;
}

.collapse:not(.show) {
  display: none;
}

.collapsing {
  height: 0;
  overflow: hidden;
  transition: height 0.35s ease;
}
@media (prefers-reduced-motion: reduce) {
  .collapsing {
    transition: none;
  }
}
.collapsing.collapse-horizontal {
  width: 0;
  height: auto;
  transition: width 0.35s ease;
}
@media (prefers-reduced-motion: reduce) {
  .collapsing.collapse-horizontal {
    transition: none;
  }
}

.dropup,
.dropend,
.dropdown,
.dropstart,
.dropup-center,
.dropdown-center {
  position: relative;
}

.dropdown-toggle {
  white-space: nowrap;
}

.dropdown-menu {
  --bs-dropdown-zindex: 1000;
  --bs-dropdown-min-width: 10rem;
  --bs-dropdown-padding-x: 0.5rem;
  --bs-dropdown-padding-y: 0.5rem;
  --bs-dropdown-spacer: 0.625rem;
  --bs-dropdown-font-size: 1rem;
  --bs-dropdown-color: #2d374b;
  --bs-dropdown-bg: var(--bs-body-bg);
  --bs-dropdown-border-color: var(--bs-border-color-translucent);
  --bs-dropdown-border-radius: 0.8rem;
  --bs-dropdown-border-width: 0;
  --bs-dropdown-inner-border-radius: calc(0.8rem - 0);
  --bs-dropdown-divider-bg: #dce0e5;
  --bs-dropdown-divider-margin-y: 0.5rem;
  --bs-dropdown-box-shadow: 0rem 0.1875rem 0.375rem rgba(140, 152, 164, 0.25);
  --bs-dropdown-link-color: var(--bs-body-color);
  --bs-dropdown-link-hover-color: var(--bs-body-color);
  --bs-dropdown-link-hover-bg: rgba(189, 197, 209, 0.2);
  --bs-dropdown-link-active-color: #2d374b;
  --bs-dropdown-link-active-bg: rgba(189, 197, 209, 0.2);
  --bs-dropdown-link-disabled-color: var(--bs-tertiary-color);
  --bs-dropdown-item-padding-x: 1rem;
  --bs-dropdown-item-padding-y: 0.5rem;
  --bs-dropdown-header-color: #2d374b;
  --bs-dropdown-header-padding-x: 1rem;
  --bs-dropdown-header-padding-y: 0.5rem;
  position: absolute;
  z-index: var(--bs-dropdown-zindex);
  display: none;
  min-width: var(--bs-dropdown-min-width);
  padding: var(--bs-dropdown-padding-y) var(--bs-dropdown-padding-x);
  margin: 0;
  font-size: var(--bs-dropdown-font-size);
  color: var(--bs-dropdown-color);
  text-align: left;
  list-style: none;
  background-color: var(--bs-dropdown-bg);
  background-clip: padding-box;
  border: var(--bs-dropdown-border-width) solid var(--bs-dropdown-border-color);
  border-radius: var(--bs-dropdown-border-radius);
  box-shadow: var(--bs-dropdown-box-shadow);
}
.dropdown-menu[data-bs-popper] {
  top: 100%;
  left: 0;
  margin-top: var(--bs-dropdown-spacer);
}

.dropdown-menu-start {
  --bs-position: start;
}
.dropdown-menu-start[data-bs-popper] {
  right: auto;
  left: 0;
}

.dropdown-menu-end {
  --bs-position: end;
}
.dropdown-menu-end[data-bs-popper] {
  right: 0;
  left: auto;
}

@media (min-width: 576px) {
  .dropdown-menu-sm-start {
    --bs-position: start;
  }
  .dropdown-menu-sm-start[data-bs-popper] {
    right: auto;
    left: 0;
  }
  .dropdown-menu-sm-end {
    --bs-position: end;
  }
  .dropdown-menu-sm-end[data-bs-popper] {
    right: 0;
    left: auto;
  }
}
@media (min-width: 768px) {
  .dropdown-menu-md-start {
    --bs-position: start;
  }
  .dropdown-menu-md-start[data-bs-popper] {
    right: auto;
    left: 0;
  }
  .dropdown-menu-md-end {
    --bs-position: end;
  }
  .dropdown-menu-md-end[data-bs-popper] {
    right: 0;
    left: auto;
  }
}
@media (min-width: 992px) {
  .dropdown-menu-lg-start {
    --bs-position: start;
  }
  .dropdown-menu-lg-start[data-bs-popper] {
    right: auto;
    left: 0;
  }
  .dropdown-menu-lg-end {
    --bs-position: end;
  }
  .dropdown-menu-lg-end[data-bs-popper] {
    right: 0;
    left: auto;
  }
}
@media (min-width: 1200px) {
  .dropdown-menu-xl-start {
    --bs-position: start;
  }
  .dropdown-menu-xl-start[data-bs-popper] {
    right: auto;
    left: 0;
  }
  .dropdown-menu-xl-end {
    --bs-position: end;
  }
  .dropdown-menu-xl-end[data-bs-popper] {
    right: 0;
    left: auto;
  }
}
@media (min-width: 1400px) {
  .dropdown-menu-xxl-start {
    --bs-position: start;
  }
  .dropdown-menu-xxl-start[data-bs-popper] {
    right: auto;
    left: 0;
  }
  .dropdown-menu-xxl-end {
    --bs-position: end;
  }
  .dropdown-menu-xxl-end[data-bs-popper] {
    right: 0;
    left: auto;
  }
}
.dropup .dropdown-menu[data-bs-popper] {
  top: auto;
  bottom: 100%;
  margin-top: 0;
  margin-bottom: var(--bs-dropdown-spacer);
}
.dropend .dropdown-menu[data-bs-popper] {
  top: 0;
  right: auto;
  left: 100%;
  margin-top: 0;
  margin-left: var(--bs-dropdown-spacer);
}
.dropend .dropdown-toggle::after {
  vertical-align: 0;
}

.dropstart .dropdown-menu[data-bs-popper] {
  top: 0;
  right: 100%;
  left: auto;
  margin-top: 0;
  margin-right: var(--bs-dropdown-spacer);
}
.dropstart .dropdown-toggle::before {
  vertical-align: 0;
}

.dropdown-divider {
  height: 0;
  margin: var(--bs-dropdown-divider-margin-y) 0;
  overflow: hidden;
  border-top: 1px solid var(--bs-dropdown-divider-bg);
  opacity: 1;
}

.dropdown-item {
  display: block;
  width: 100%;
  padding: var(--bs-dropdown-item-padding-y) var(--bs-dropdown-item-padding-x);
  clear: both;
  font-weight: 400;
  color: var(--bs-dropdown-link-color);
  text-align: inherit;
  white-space: nowrap;
  background-color: transparent;
  border: 0;
  border-radius: var(--bs-dropdown-item-border-radius, 0);
}
.dropdown-item:hover, .dropdown-item:focus {
  color: var(--bs-dropdown-link-hover-color);
  background-color: var(--bs-dropdown-link-hover-bg);
}
.dropdown-item.active, .dropdown-item:active {
  color: var(--bs-dropdown-link-active-color);
  text-decoration: none;
  background-color: var(--bs-dropdown-link-active-bg);
}
.dropdown-item.disabled, .dropdown-item:disabled {
  color: var(--bs-dropdown-link-disabled-color);
  pointer-events: none;
  background-color: transparent;
}

.dropdown-menu.show {
  display: block;
}

.dropdown-header {
  display: block;
  padding: var(--bs-dropdown-header-padding-y) var(--bs-dropdown-header-padding-x);
  margin-bottom: 0;
  font-size: 0.8125rem;
  color: var(--bs-dropdown-header-color);
  white-space: nowrap;
}

.dropdown-item-text {
  display: block;
  padding: var(--bs-dropdown-item-padding-y) var(--bs-dropdown-item-padding-x);
  color: var(--bs-dropdown-link-color);
}

.dropdown-menu-dark {
  --bs-dropdown-color: #dce0e5;
  --bs-dropdown-bg: #51596C;
  --bs-dropdown-border-color: var(--bs-border-color-translucent);
  --bs-dropdown-box-shadow: ;
  --bs-dropdown-link-color: #dce0e5;
  --bs-dropdown-link-hover-color: white;
  --bs-dropdown-divider-bg: #dce0e5;
  --bs-dropdown-link-hover-bg: rgba(255, 255, 255, 0.15);
  --bs-dropdown-link-active-color: #2d374b;
  --bs-dropdown-link-active-bg: rgba(189, 197, 209, 0.2);
  --bs-dropdown-link-disabled-color: #97A4AF;
  --bs-dropdown-header-color: #97A4AF;
}

.btn-group,
.btn-group-vertical {
  position: relative;
  display: inline-flex;
  vertical-align: middle;
}
.btn-group > .btn,
.btn-group-vertical > .btn {
  position: relative;
  flex: 1 1 auto;
}
.btn-group > .btn-check:checked + .btn,
.btn-group > .btn-check:focus + .btn,
.btn-group > .btn:hover,
.btn-group > .btn:focus,
.btn-group > .btn:active,
.btn-group > .btn.active,
.btn-group-vertical > .btn-check:checked + .btn,
.btn-group-vertical > .btn-check:focus + .btn,
.btn-group-vertical > .btn:hover,
.btn-group-vertical > .btn:focus,
.btn-group-vertical > .btn:active,
.btn-group-vertical > .btn.active {
  z-index: 1;
}

.btn-toolbar {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-start;
}
.btn-toolbar .input-group {
  width: auto;
}

.btn-group {
  border-radius: 0.6rem;
}
.btn-group > :not(.btn-check:first-child) + .btn,
.btn-group > .btn-group:not(:first-child) {
  margin-left: calc(0.125rem * -1);
}
.btn-group > .btn:not(:last-child):not(.dropdown-toggle),
.btn-group > .btn.dropdown-toggle-split:first-child,
.btn-group > .btn-group:not(:last-child) > .btn {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
.btn-group > .btn:nth-child(n+3),
.btn-group > :not(.btn-check) + .btn,
.btn-group > .btn-group:not(:first-child) > .btn {
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}

.dropdown-toggle-split {
  padding-right: 1.359375rem;
  padding-left: 1.359375rem;
}
.dropdown-toggle-split::after, .dropup .dropdown-toggle-split::after, .dropend .dropdown-toggle-split::after {
  margin-left: 0;
}
.dropstart .dropdown-toggle-split::before {
  margin-right: 0;
}

.btn-sm + .dropdown-toggle-split, .btn-group-sm > .btn + .dropdown-toggle-split {
  padding-right: 0.65625rem;
  padding-left: 0.65625rem;
}

.btn-lg + .dropdown-toggle-split, .btn-group-lg > .btn + .dropdown-toggle-split {
  padding-right: 0.75rem;
  padding-left: 0.75rem;
}

.btn-group.show .dropdown-toggle {
  box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
}
.btn-group.show .dropdown-toggle.btn-link {
  box-shadow: none;
}

.btn-group-vertical {
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
}
.btn-group-vertical > .btn,
.btn-group-vertical > .btn-group {
  width: 100%;
}
.btn-group-vertical > .btn:not(:first-child),
.btn-group-vertical > .btn-group:not(:first-child) {
  margin-top: calc(0.125rem * -1);
}
.btn-group-vertical > .btn:not(:last-child):not(.dropdown-toggle),
.btn-group-vertical > .btn-group:not(:last-child) > .btn {
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}
.btn-group-vertical > .btn ~ .btn,
.btn-group-vertical > .btn-group:not(:first-child) > .btn {
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}

.nav {
  --bs-nav-link-padding-x: 1rem;
  --bs-nav-link-padding-y: 0.5rem;
  --bs-nav-link-font-weight: ;
  --bs-nav-link-color: #2d374b;
  --bs-nav-link-hover-color: #07853a;
  --bs-nav-link-disabled-color: var(--bs-secondary-color);
  display: flex;
  flex-wrap: wrap;
  padding-left: 0;
  margin-bottom: 0;
  list-style: none;
}

.nav-link {
  display: block;
  padding: var(--bs-nav-link-padding-y) var(--bs-nav-link-padding-x);
  font-size: var(--bs-nav-link-font-size);
  font-weight: var(--bs-nav-link-font-weight);
  color: var(--bs-nav-link-color);
  background: none;
  border: 0;
  transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out;
}
@media (prefers-reduced-motion: reduce) {
  .nav-link {
    transition: none;
  }
}
.nav-link:hover, .nav-link:focus {
  color: var(--bs-nav-link-hover-color);
}
.nav-link:focus-visible {
  outline: 0;
  box-shadow: 0 0 0 0.25rem rgba(10, 191, 83, 0.25);
}
.nav-link.disabled, .nav-link:disabled {
  color: var(--bs-nav-link-disabled-color);
  pointer-events: none;
  cursor: default;
}

.nav-tabs {
  --bs-nav-tabs-border-width: 0.1875rem;
  --bs-nav-tabs-border-color: rgba(220, 224, 229, 0.6);
  --bs-nav-tabs-border-radius: 0;
  --bs-nav-tabs-link-hover-border-color: rgba(220, 224, 229, 0.6);
  --bs-nav-tabs-link-active-color: #0abf53;
  --bs-nav-tabs-link-active-bg: transparent;
  --bs-nav-tabs-link-active-border-color: #0abf53;
  border-bottom: var(--bs-nav-tabs-border-width) solid var(--bs-nav-tabs-border-color);
}
.nav-tabs .nav-link {
  margin-bottom: calc(-1 * var(--bs-nav-tabs-border-width));
  border: var(--bs-nav-tabs-border-width) solid transparent;
  border-top-left-radius: var(--bs-nav-tabs-border-radius);
  border-top-right-radius: var(--bs-nav-tabs-border-radius);
}
.nav-tabs .nav-link:hover, .nav-tabs .nav-link:focus {
  isolation: isolate;
  border-color: var(--bs-nav-tabs-link-hover-border-color);
}
.nav-tabs .nav-link.active,
.nav-tabs .nav-item.show .nav-link {
  color: var(--bs-nav-tabs-link-active-color);
  background-color: var(--bs-nav-tabs-link-active-bg);
  border-color: var(--bs-nav-tabs-link-active-border-color);
}
.nav-tabs .dropdown-menu {
  margin-top: calc(-1 * var(--bs-nav-tabs-border-width));
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}

.nav-pills {
  --bs-nav-pills-border-radius: var(--bs-border-radius);
  --bs-nav-pills-link-active-color: initial;
  --bs-nav-pills-link-active-bg: white;
}
.nav-pills .nav-link {
  border-radius: var(--bs-nav-pills-border-radius);
}
.nav-pills .nav-link.active,
.nav-pills .show > .nav-link {
  color: var(--bs-nav-pills-link-active-color);
  background-color: var(--bs-nav-pills-link-active-bg);
}

.nav-underline {
  --bs-nav-underline-gap: 1rem;
  --bs-nav-underline-border-width: 0.125rem;
  --bs-nav-underline-link-active-color: var(--bs-emphasis-color);
  gap: var(--bs-nav-underline-gap);
}
.nav-underline .nav-link {
  padding-right: 0;
  padding-left: 0;
  border-bottom: var(--bs-nav-underline-border-width) solid transparent;
}
.nav-underline .nav-link:hover, .nav-underline .nav-link:focus {
  border-bottom-color: currentcolor;
}
.nav-underline .nav-link.active,
.nav-underline .show > .nav-link {
  font-weight: 700;
  color: var(--bs-nav-underline-link-active-color);
  border-bottom-color: currentcolor;
}

.nav-fill > .nav-link,
.nav-fill .nav-item {
  flex: 1 1 auto;
  text-align: center;
}

.nav-justified > .nav-link,
.nav-justified .nav-item {
  flex-basis: 0;
  flex-grow: 1;
  text-align: center;
}

.nav-fill .nav-item .nav-link,
.nav-justified .nav-item .nav-link {
  width: 100%;
}

.tab-content > .tab-pane {
  display: none;
}
.tab-content > .active {
  display: block;
}

.navbar {
  --bs-navbar-padding-x: 0;
  --bs-navbar-padding-y: 0.75rem;
  --bs-navbar-color: #2d374b;
  --bs-navbar-hover-color: #2d374b;
  --bs-navbar-disabled-color: rgba(var(--bs-emphasis-color-rgb), 0.3);
  --bs-navbar-active-color: rgba(var(--bs-emphasis-color-rgb), 1);
  --bs-navbar-brand-padding-y: 0.40625rem;
  --bs-navbar-brand-margin-end: 1.5rem;
  --bs-navbar-brand-font-size: 1.125rem;
  --bs-navbar-brand-color: #51596C;
  --bs-navbar-brand-hover-color: rgba(var(--bs-emphasis-color-rgb), 1);
  --bs-navbar-nav-link-padding-x: 0.75rem;
  --bs-navbar-toggler-padding-y: 0.5rem;
  --bs-navbar-toggler-padding-x: 0.5rem;
  --bs-navbar-toggler-font-size: 1.125rem;
  --bs-navbar-toggler-icon-bg: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%2881, 89, 108, 0.75%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
  --bs-navbar-toggler-border-color: rgba(var(--bs-emphasis-color-rgb), 0.15);
  --bs-navbar-toggler-border-radius: 0.6rem;
  --bs-navbar-toggler-focus-width: 0;
  --bs-navbar-toggler-transition: box-shadow 0.15s ease-in-out;
  position: relative;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  padding: var(--bs-navbar-padding-y) var(--bs-navbar-padding-x);
}
.navbar > .container,
.navbar > .container-fluid,
.navbar > .container-sm,
.navbar > .container-md,
.navbar > .container-lg,
.navbar > .container-xl {
  display: flex;
  flex-wrap: inherit;
  align-items: center;
  justify-content: space-between;
}
.navbar-brand {
  padding-top: var(--bs-navbar-brand-padding-y);
  padding-bottom: var(--bs-navbar-brand-padding-y);
  margin-right: var(--bs-navbar-brand-margin-end);
  font-size: var(--bs-navbar-brand-font-size);
  color: var(--bs-navbar-brand-color);
  white-space: nowrap;
}
.navbar-brand:hover, .navbar-brand:focus {
  color: var(--bs-navbar-brand-hover-color);
}

.navbar-nav {
  --bs-nav-link-padding-x: 0;
  --bs-nav-link-padding-y: 0.5rem;
  --bs-nav-link-font-weight: ;
  --bs-nav-link-color: var(--bs-navbar-color);
  --bs-nav-link-hover-color: var(--bs-navbar-hover-color);
  --bs-nav-link-disabled-color: var(--bs-navbar-disabled-color);
  display: flex;
  flex-direction: column;
  padding-left: 0;
  margin-bottom: 0;
  list-style: none;
}
.navbar-nav .nav-link.active, .navbar-nav .nav-link.show {
  color: var(--bs-navbar-active-color);
}
.navbar-nav .dropdown-menu {
  position: static;
}

.navbar-text {
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
  color: var(--bs-navbar-color);
}
.navbar-text a,
.navbar-text a:hover,
.navbar-text a:focus {
  color: var(--bs-navbar-active-color);
}

.navbar-collapse {
  flex-basis: 100%;
  flex-grow: 1;
  align-items: center;
}

.navbar-toggler {
  padding: var(--bs-navbar-toggler-padding-y) var(--bs-navbar-toggler-padding-x);
  font-size: var(--bs-navbar-toggler-font-size);
  line-height: 1;
  color: var(--bs-navbar-color);
  background-color: transparent;
  border: var(--bs-border-width) solid var(--bs-navbar-toggler-border-color);
  border-radius: var(--bs-navbar-toggler-border-radius);
  transition: var(--bs-navbar-toggler-transition);
}
@media (prefers-reduced-motion: reduce) {
  .navbar-toggler {
    transition: none;
  }
}
.navbar-toggler:hover {
  text-decoration: none;
}
.navbar-toggler:focus {
  text-decoration: none;
  outline: 0;
  box-shadow: 0 0 0 var(--bs-navbar-toggler-focus-width);
}

.navbar-toggler-icon {
  display: inline-block;
  width: 1.5em;
  height: 1.5em;
  vertical-align: middle;
  background-image: var(--bs-navbar-toggler-icon-bg);
  background-repeat: no-repeat;
  background-position: center;
  background-size: 100%;
}

.navbar-nav-scroll {
  max-height: var(--bs-scroll-height, 75vh);
  overflow-y: auto;
}

@media (min-width: 576px) {
  .navbar-expand-sm {
    flex-wrap: nowrap;
    justify-content: flex-start;
  }
  .navbar-expand-sm .navbar-nav {
    flex-direction: row;
  }
  .navbar-expand-sm .navbar-nav .dropdown-menu {
    position: absolute;
  }
  .navbar-expand-sm .navbar-nav .nav-link {
    padding-right: var(--bs-navbar-nav-link-padding-x);
    padding-left: var(--bs-navbar-nav-link-padding-x);
  }
  .navbar-expand-sm .navbar-nav-scroll {
    overflow: visible;
  }
  .navbar-expand-sm .navbar-collapse {
    display: flex !important;
    flex-basis: auto;
  }
  .navbar-expand-sm .navbar-toggler {
    display: none;
  }
  .navbar-expand-sm .offcanvas {
    position: static;
    z-index: auto;
    flex-grow: 1;
    width: auto !important;
    height: auto !important;
    visibility: visible !important;
    background-color: transparent !important;
    border: 0 !important;
    transform: none !important;
    box-shadow: none;
    transition: none;
  }
  .navbar-expand-sm .offcanvas .offcanvas-header {
    display: none;
  }
  .navbar-expand-sm .offcanvas .offcanvas-body {
    display: flex;
    flex-grow: 0;
    padding: 0;
    overflow-y: visible;
  }
}
@media (min-width: 768px) {
  .navbar-expand-md {
    flex-wrap: nowrap;
    justify-content: flex-start;
  }
  .navbar-expand-md .navbar-nav {
    flex-direction: row;
  }
  .navbar-expand-md .navbar-nav .dropdown-menu {
    position: absolute;
  }
  .navbar-expand-md .navbar-nav .nav-link {
    padding-right: var(--bs-navbar-nav-link-padding-x);
    padding-left: var(--bs-navbar-nav-link-padding-x);
  }
  .navbar-expand-md .navbar-nav-scroll {
    overflow: visible;
  }
  .navbar-expand-md .navbar-collapse {
    display: flex !important;
    flex-basis: auto;
  }
  .navbar-expand-md .navbar-toggler {
    display: none;
  }
  .navbar-expand-md .offcanvas {
    position: static;
    z-index: auto;
    flex-grow: 1;
    width: auto !important;
    height: auto !important;
    visibility: visible !important;
    background-color: transparent !important;
    border: 0 !important;
    transform: none !important;
    box-shadow: none;
    transition: none;
  }
  .navbar-expand-md .offcanvas .offcanvas-header {
    display: none;
  }
  .navbar-expand-md .offcanvas .offcanvas-body {
    display: flex;
    flex-grow: 0;
    padding: 0;
    overflow-y: visible;
  }
}
@media (min-width: 992px) {
  .navbar-expand-lg {
    flex-wrap: nowrap;
    justify-content: flex-start;
  }
  .navbar-expand-lg .navbar-nav {
    flex-direction: row;
  }
  .navbar-expand-lg .navbar-nav .dropdown-menu {
    position: absolute;
  }
  .navbar-expand-lg .navbar-nav .nav-link {
    padding-right: var(--bs-navbar-nav-link-padding-x);
    padding-left: var(--bs-navbar-nav-link-padding-x);
  }
  .navbar-expand-lg .navbar-nav-scroll {
    overflow: visible;
  }
  .navbar-expand-lg .navbar-collapse {
    display: flex !important;
    flex-basis: auto;
  }
  .navbar-expand-lg .navbar-toggler {
    display: none;
  }
  .navbar-expand-lg .offcanvas {
    position: static;
    z-index: auto;
    flex-grow: 1;
    width: auto !important;
    height: auto !important;
    visibility: visible !important;
    background-color: transparent !important;
    border: 0 !important;
    transform: none !important;
    box-shadow: none;
    transition: none;
  }
  .navbar-expand-lg .offcanvas .offcanvas-header {
    display: none;
  }
  .navbar-expand-lg .offcanvas .offcanvas-body {
    display: flex;
    flex-grow: 0;
    padding: 0;
    overflow-y: visible;
  }
}
@media (min-width: 1200px) {
  .navbar-expand-xl {
    flex-wrap: nowrap;
    justify-content: flex-start;
  }
  .navbar-expand-xl .navbar-nav {
    flex-direction: row;
  }
  .navbar-expand-xl .navbar-nav .dropdown-menu {
    position: absolute;
  }
  .navbar-expand-xl .navbar-nav .nav-link {
    padding-right: var(--bs-navbar-nav-link-padding-x);
    padding-left: var(--bs-navbar-nav-link-padding-x);
  }
  .navbar-expand-xl .navbar-nav-scroll {
    overflow: visible;
  }
  .navbar-expand-xl .navbar-collapse {
    display: flex !important;
    flex-basis: auto;
  }
  .navbar-expand-xl .navbar-toggler {
    display: none;
  }
  .navbar-expand-xl .offcanvas {
    position: static;
    z-index: auto;
    flex-grow: 1;
    width: auto !important;
    height: auto !important;
    visibility: visible !important;
    background-color: transparent !important;
    border: 0 !important;
    transform: none !important;
    box-shadow: none;
    transition: none;
  }
  .navbar-expand-xl .offcanvas .offcanvas-header {
    display: none;
  }
  .navbar-expand-xl .offcanvas .offcanvas-body {
    display: flex;
    flex-grow: 0;
    padding: 0;
    overflow-y: visible;
  }
}
@media (min-width: 1400px) {
  .navbar-expand-xxl {
    flex-wrap: nowrap;
    justify-content: flex-start;
  }
  .navbar-expand-xxl .navbar-nav {
    flex-direction: row;
  }
  .navbar-expand-xxl .navbar-nav .dropdown-menu {
    position: absolute;
  }
  .navbar-expand-xxl .navbar-nav .nav-link {
    padding-right: var(--bs-navbar-nav-link-padding-x);
    padding-left: var(--bs-navbar-nav-link-padding-x);
  }
  .navbar-expand-xxl .navbar-nav-scroll {
    overflow: visible;
  }
  .navbar-expand-xxl .navbar-collapse {
    display: flex !important;
    flex-basis: auto;
  }
  .navbar-expand-xxl .navbar-toggler {
    display: none;
  }
  .navbar-expand-xxl .offcanvas {
    position: static;
    z-index: auto;
    flex-grow: 1;
    width: auto !important;
    height: auto !important;
    visibility: visible !important;
    background-color: transparent !important;
    border: 0 !important;
    transform: none !important;
    box-shadow: none;
    transition: none;
  }
  .navbar-expand-xxl .offcanvas .offcanvas-header {
    display: none;
  }
  .navbar-expand-xxl .offcanvas .offcanvas-body {
    display: flex;
    flex-grow: 0;
    padding: 0;
    overflow-y: visible;
  }
}
.navbar-expand {
  flex-wrap: nowrap;
  justify-content: flex-start;
}
.navbar-expand .navbar-nav {
  flex-direction: row;
}
.navbar-expand .navbar-nav .dropdown-menu {
  position: absolute;
}
.navbar-expand .navbar-nav .nav-link {
  padding-right: var(--bs-navbar-nav-link-padding-x);
  padding-left: var(--bs-navbar-nav-link-padding-x);
}
.navbar-expand .navbar-nav-scroll {
  overflow: visible;
}
.navbar-expand .navbar-collapse {
  display: flex !important;
  flex-basis: auto;
}
.navbar-expand .navbar-toggler {
  display: none;
}
.navbar-expand .offcanvas {
  position: static;
  z-index: auto;
  flex-grow: 1;
  width: auto !important;
  height: auto !important;
  visibility: visible !important;
  background-color: transparent !important;
  border: 0 !important;
  transform: none !important;
  box-shadow: none;
  transition: none;
}
.navbar-expand .offcanvas .offcanvas-header {
  display: none;
}
.navbar-expand .offcanvas .offcanvas-body {
  display: flex;
  flex-grow: 0;
  padding: 0;
  overflow-y: visible;
}

.navbar-dark,
.navbar[data-bs-theme=dark] {
  --bs-navbar-color: rgba(255, 255, 255, 0.55);
  --bs-navbar-hover-color: white;
  --bs-navbar-disabled-color: rgba(255, 255, 255, 0.25);
  --bs-navbar-active-color: white;
  --bs-navbar-brand-color: white;
  --bs-navbar-brand-hover-color: white;
  --bs-navbar-toggler-border-color: rgba(255, 255, 255, 0.1);
  --bs-navbar-toggler-icon-bg: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%28255, 255, 255, 0.55%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
}

[data-bs-theme=dark] .navbar-toggler-icon {
  --bs-navbar-toggler-icon-bg: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%28255, 255, 255, 0.55%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
}

.card {
  --bs-card-spacer-y: 1.75rem;
  --bs-card-spacer-x: 1.75rem;
  --bs-card-title-spacer-y: 0.25rem;
  --bs-card-title-color: ;
  --bs-card-subtitle-color: ;
  --bs-card-border-width: var(--bs-border-width);
  --bs-card-border-color: rgba(220, 224, 229, 0.6);
  --bs-card-border-radius: 0.8rem;
  --bs-card-box-shadow: 0rem 1rem 1.75rem 0rem rgba(45, 55, 75, 0.1);
  --bs-card-inner-border-radius: calc(0.8rem - (var(--bs-border-width)));
  --bs-card-cap-padding-y: 1.75rem;
  --bs-card-cap-padding-x: 1.75rem;
  --bs-card-cap-bg: transparent;
  --bs-card-cap-color: ;
  --bs-card-height: ;
  --bs-card-color: ;
  --bs-card-bg: white;
  --bs-card-img-overlay-padding: 1.75rem 1.75rem;
  --bs-card-group-margin: 15px;
  position: relative;
  display: flex;
  flex-direction: column;
  min-width: 0;
  height: var(--bs-card-height);
  color: var(--bs-body-color);
  word-wrap: break-word;
  background-color: var(--bs-card-bg);
  background-clip: border-box;
  border: var(--bs-card-border-width) solid var(--bs-card-border-color);
  border-radius: var(--bs-card-border-radius);
  box-shadow: var(--bs-card-box-shadow);
}
.card > hr {
  margin-right: 0;
  margin-left: 0;
}
.card > .list-group {
  border-top: inherit;
  border-bottom: inherit;
}
.card > .list-group:first-child {
  border-top-width: 0;
  border-top-left-radius: var(--bs-card-inner-border-radius);
  border-top-right-radius: var(--bs-card-inner-border-radius);
}
.card > .list-group:last-child {
  border-bottom-width: 0;
  border-bottom-right-radius: var(--bs-card-inner-border-radius);
  border-bottom-left-radius: var(--bs-card-inner-border-radius);
}
.card > .card-header + .list-group,
.card > .list-group + .card-footer {
  border-top: 0;
}

.card-body {
  flex: 1 1 auto;
  padding: var(--bs-card-spacer-y) var(--bs-card-spacer-x);
  color: var(--bs-card-color);
}

.card-title {
  margin-bottom: var(--bs-card-title-spacer-y);
  color: var(--bs-card-title-color);
}

.card-subtitle {
  margin-top: calc(-0.5 * var(--bs-card-title-spacer-y));
  margin-bottom: 0;
  color: var(--bs-card-subtitle-color);
}

.card-text:last-child {
  margin-bottom: 0;
}

.card-link + .card-link {
  margin-left: var(--bs-card-spacer-x);
}

.card-header {
  padding: var(--bs-card-cap-padding-y) var(--bs-card-cap-padding-x);
  margin-bottom: 0;
  color: var(--bs-card-cap-color);
  background-color: var(--bs-card-cap-bg);
  border-bottom: var(--bs-card-border-width) solid var(--bs-card-border-color);
}
.card-header:first-child {
  border-radius: var(--bs-card-inner-border-radius) var(--bs-card-inner-border-radius) 0 0;
}

.card-footer {
  padding: var(--bs-card-cap-padding-y) var(--bs-card-cap-padding-x);
  color: var(--bs-card-cap-color);
  background-color: var(--bs-card-cap-bg);
  border-top: var(--bs-card-border-width) solid var(--bs-card-border-color);
}
.card-footer:last-child {
  border-radius: 0 0 var(--bs-card-inner-border-radius) var(--bs-card-inner-border-radius);
}

.card-header-tabs {
  margin-right: calc(-0.5 * var(--bs-card-cap-padding-x));
  margin-bottom: calc(-1 * var(--bs-card-cap-padding-y));
  margin-left: calc(-0.5 * var(--bs-card-cap-padding-x));
  border-bottom: 0;
}
.card-header-tabs .nav-link.active {
  background-color: var(--bs-card-bg);
  border-bottom-color: var(--bs-card-bg);
}

.card-header-pills {
  margin-right: calc(-0.5 * var(--bs-card-cap-padding-x));
  margin-left: calc(-0.5 * var(--bs-card-cap-padding-x));
}

.card-img-overlay {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  padding: var(--bs-card-img-overlay-padding);
  border-radius: var(--bs-card-inner-border-radius);
}

.card-img,
.card-img-top,
.card-img-bottom {
  width: 100%;
}

.card-img,
.card-img-top {
  border-top-left-radius: var(--bs-card-inner-border-radius);
  border-top-right-radius: var(--bs-card-inner-border-radius);
}

.card-img,
.card-img-bottom {
  border-bottom-right-radius: var(--bs-card-inner-border-radius);
  border-bottom-left-radius: var(--bs-card-inner-border-radius);
}

.card-group > .card {
  margin-bottom: var(--bs-card-group-margin);
}
@media (min-width: 576px) {
  .card-group {
    display: flex;
    flex-flow: row wrap;
  }
  .card-group > .card {
    flex: 1 0 0%;
    margin-bottom: 0;
  }
  .card-group > .card + .card {
    margin-left: 0;
    border-left: 0;
  }
  .card-group > .card:not(:last-child) {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
  }
  .card-group > .card:not(:last-child) .card-img-top,
.card-group > .card:not(:last-child) .card-header {
    border-top-right-radius: 0;
  }
  .card-group > .card:not(:last-child) .card-img-bottom,
.card-group > .card:not(:last-child) .card-footer {
    border-bottom-right-radius: 0;
  }
  .card-group > .card:not(:first-child) {
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
  }
  .card-group > .card:not(:first-child) .card-img-top,
.card-group > .card:not(:first-child) .card-header {
    border-top-left-radius: 0;
  }
  .card-group > .card:not(:first-child) .card-img-bottom,
.card-group > .card:not(:first-child) .card-footer {
    border-bottom-left-radius: 0;
  }
}

.accordion {
  --bs-accordion-color: var(--bs-body-color);
  --bs-accordion-bg: var(--bs-body-bg);
  --bs-accordion-transition: all 0.2s ease-in-out, border-radius 0.15s ease;
  --bs-accordion-border-color: rgba(220, 224, 229, 0.6);
  --bs-accordion-border-width: var(--bs-border-width);
  --bs-accordion-border-radius: var(--bs-border-radius);
  --bs-accordion-inner-border-radius: calc(var(--bs-border-radius) - (var(--bs-border-width)));
  --bs-accordion-btn-padding-x: 2rem;
  --bs-accordion-btn-padding-y: 1.5rem;
  --bs-accordion-btn-color: #2d374b;
  --bs-accordion-btn-bg: var(--bs-accordion-bg);
  --bs-accordion-btn-icon: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%232d374b'%3E%3Cpath d='M19,11.5v1a.5.5,0,0,1-.5.5H13v5.5a.5.5,0,0,1-.5.5h-1a.5.5,0,0,1-.5-.5V13H5.5a.5.5,0,0,1-.5-.5v-1a.5.5,0,0,1,.5-.5H11V5.5a.5.5,0,0,1,.5-.5h1a.5.5,0,0,1,.5.5V11h5.5A.5.5,0,0,1,19,11.5Z'/%3E%3C/svg%3E");
  --bs-accordion-btn-icon-width: 1.25rem;
  --bs-accordion-btn-icon-transform: rotate(0deg);
  --bs-accordion-btn-icon-transition: transform 0.2s ease-in-out;
  --bs-accordion-btn-active-icon: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%232d374b'%3E%3Cpath d='M5.5,13a.5.5,0,0,1-.5-.5v-1a.5.5,0,0,1,.5-.5h13a.5.5,0,0,1,.5.5v1a.5.5,0,0,1-.5.5Z'/%3E%3C/svg%3E");
  --bs-accordion-btn-focus-border-color: rgba(140, 152, 164, 0.25);
  --bs-accordion-btn-focus-box-shadow: 0 0 1rem 0 rgba(140, 152, 164, 0.25);
  --bs-accordion-body-padding-x: 2rem;
  --bs-accordion-body-padding-y: 1.5rem;
  --bs-accordion-active-color: #2d374b;
  --bs-accordion-active-bg: #F5F7FA;
}

.accordion-button {
  position: relative;
  display: flex;
  align-items: center;
  width: 100%;
  padding: var(--bs-accordion-btn-padding-y) var(--bs-accordion-btn-padding-x);
  font-size: 1rem;
  color: var(--bs-accordion-btn-color);
  text-align: left;
  background-color: var(--bs-accordion-btn-bg);
  border: 0;
  border-radius: 0;
  overflow-anchor: none;
  transition: var(--bs-accordion-transition);
}
@media (prefers-reduced-motion: reduce) {
  .accordion-button {
    transition: none;
  }
}
.accordion-button:not(.collapsed) {
  color: var(--bs-accordion-active-color);
  background-color: var(--bs-accordion-active-bg);
  box-shadow: inset 0 calc(-1 * var(--bs-accordion-border-width)) 0 var(--bs-accordion-border-color);
}
.accordion-button:not(.collapsed)::after {
  background-image: var(--bs-accordion-btn-active-icon);
  transform: var(--bs-accordion-btn-icon-transform);
}
.accordion-button::after {
  flex-shrink: 0;
  width: var(--bs-accordion-btn-icon-width);
  height: var(--bs-accordion-btn-icon-width);
  margin-left: auto;
  content: "";
  background-image: var(--bs-accordion-btn-icon);
  background-repeat: no-repeat;
  background-size: var(--bs-accordion-btn-icon-width);
  transition: var(--bs-accordion-btn-icon-transition);
}
@media (prefers-reduced-motion: reduce) {
  .accordion-button::after {
    transition: none;
  }
}
.accordion-button:hover {
  z-index: 2;
}
.accordion-button:focus {
  z-index: 3;
  border-color: var(--bs-accordion-btn-focus-border-color);
  outline: 0;
  box-shadow: var(--bs-accordion-btn-focus-box-shadow);
}

.accordion-header {
  margin-bottom: 0;
}

.accordion-item {
  color: var(--bs-accordion-color);
  background-color: var(--bs-accordion-bg);
  border: var(--bs-accordion-border-width) solid var(--bs-accordion-border-color);
}
.accordion-item:first-of-type {
  border-top-left-radius: var(--bs-accordion-border-radius);
  border-top-right-radius: var(--bs-accordion-border-radius);
}
.accordion-item:first-of-type .accordion-button {
  border-top-left-radius: var(--bs-accordion-inner-border-radius);
  border-top-right-radius: var(--bs-accordion-inner-border-radius);
}
.accordion-item:not(:first-of-type) {
  border-top: 0;
}
.accordion-item:last-of-type {
  border-bottom-right-radius: var(--bs-accordion-border-radius);
  border-bottom-left-radius: var(--bs-accordion-border-radius);
}
.accordion-item:last-of-type .accordion-button.collapsed {
  border-bottom-right-radius: var(--bs-accordion-inner-border-radius);
  border-bottom-left-radius: var(--bs-accordion-inner-border-radius);
}
.accordion-item:last-of-type .accordion-collapse {
  border-bottom-right-radius: var(--bs-accordion-border-radius);
  border-bottom-left-radius: var(--bs-accordion-border-radius);
}

.accordion-body {
  padding: var(--bs-accordion-body-padding-y) var(--bs-accordion-body-padding-x);
}

.accordion-flush .accordion-collapse {
  border-width: 0;
}
.accordion-flush .accordion-item {
  border-right: 0;
  border-left: 0;
  border-radius: 0;
}
.accordion-flush .accordion-item:first-child {
  border-top: 0;
}
.accordion-flush .accordion-item:last-child {
  border-bottom: 0;
}
.accordion-flush .accordion-item .accordion-button, .accordion-flush .accordion-item .accordion-button.collapsed {
  border-radius: 0;
}

[data-bs-theme=dark] .accordion-button::after {
  --bs-accordion-btn-icon: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%236cd998'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
  --bs-accordion-btn-active-icon: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%236cd998'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
}

.breadcrumb {
  --bs-breadcrumb-padding-x: 0;
  --bs-breadcrumb-padding-y: 0;
  --bs-breadcrumb-margin-bottom: 1rem;
  --bs-breadcrumb-bg: transparent;
  --bs-breadcrumb-border-radius: ;
  --bs-breadcrumb-divider-color: #97A4AF;
  --bs-breadcrumb-item-padding-x: 0.5rem;
  --bs-breadcrumb-item-active-color: var(--bs-secondary-color);
  display: flex;
  flex-wrap: wrap;
  padding: var(--bs-breadcrumb-padding-y) var(--bs-breadcrumb-padding-x);
  margin-bottom: var(--bs-breadcrumb-margin-bottom);
  font-size: var(--bs-breadcrumb-font-size);
  list-style: none;
  background-color: var(--bs-breadcrumb-bg);
  border-radius: var(--bs-breadcrumb-border-radius);
}

.breadcrumb-item + .breadcrumb-item {
  padding-left: var(--bs-breadcrumb-item-padding-x);
}
.breadcrumb-item + .breadcrumb-item::before {
  float: left;
  padding-right: var(--bs-breadcrumb-item-padding-x);
  color: var(--bs-breadcrumb-divider-color);
  content: var(--bs-breadcrumb-divider, "/") /* rtl: var(--bs-breadcrumb-divider, "/") */;
}
.breadcrumb-item.active {
  color: var(--bs-breadcrumb-item-active-color);
}

.pagination {
  --bs-pagination-padding-x: 0.75rem;
  --bs-pagination-padding-y: 0.375rem;
  --bs-pagination-font-size: 1rem;
  --bs-pagination-color: #677788;
  --bs-pagination-bg: transparent;
  --bs-pagination-border-width: 0;
  --bs-pagination-border-color: var(--bs-border-color);
  --bs-pagination-border-radius: 50%;
  --bs-pagination-hover-color: #07853a;
  --bs-pagination-hover-bg: transparent;
  --bs-pagination-hover-border-color: var(--bs-border-color);
  --bs-pagination-focus-color: var(--bs-link-hover-color);
  --bs-pagination-focus-bg: var(--bs-secondary-bg);
  --bs-pagination-focus-box-shadow: 0 0 0 0.25rem rgba(10, 191, 83, 0.25);
  --bs-pagination-active-color: white;
  --bs-pagination-active-bg: #0abf53;
  --bs-pagination-active-border-color: #0abf53;
  --bs-pagination-disabled-color: var(--bs-secondary-color);
  --bs-pagination-disabled-bg: var(--bs-secondary-bg);
  --bs-pagination-disabled-border-color: var(--bs-border-color);
  display: flex;
  padding-left: 0;
  list-style: none;
}

.page-link {
  position: relative;
  display: block;
  padding: var(--bs-pagination-padding-y) var(--bs-pagination-padding-x);
  font-size: var(--bs-pagination-font-size);
  color: var(--bs-pagination-color);
  background-color: var(--bs-pagination-bg);
  border: var(--bs-pagination-border-width) solid var(--bs-pagination-border-color);
  transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
@media (prefers-reduced-motion: reduce) {
  .page-link {
    transition: none;
  }
}
.page-link:hover {
  z-index: 2;
  color: var(--bs-pagination-hover-color);
  background-color: var(--bs-pagination-hover-bg);
  border-color: var(--bs-pagination-hover-border-color);
}
.page-link:focus {
  z-index: 3;
  color: var(--bs-pagination-focus-color);
  background-color: var(--bs-pagination-focus-bg);
  outline: 0;
  box-shadow: var(--bs-pagination-focus-box-shadow);
}
.page-link.active, .active > .page-link {
  z-index: 3;
  color: var(--bs-pagination-active-color);
  background-color: var(--bs-pagination-active-bg);
  border-color: var(--bs-pagination-active-border-color);
}
.page-link.disabled, .disabled > .page-link {
  color: var(--bs-pagination-disabled-color);
  pointer-events: none;
  background-color: var(--bs-pagination-disabled-bg);
  border-color: var(--bs-pagination-disabled-border-color);
}

.page-item:not(:first-child) .page-link {
  margin-left: calc(0 * -1);
}
.page-item:first-child .page-link {
  border-top-left-radius: var(--bs-pagination-border-radius);
  border-bottom-left-radius: var(--bs-pagination-border-radius);
}
.page-item:last-child .page-link {
  border-top-right-radius: var(--bs-pagination-border-radius);
  border-bottom-right-radius: var(--bs-pagination-border-radius);
}

.pagination-lg {
  --bs-pagination-padding-x: 1.25rem;
  --bs-pagination-padding-y: 0.75rem;
  --bs-pagination-font-size: 1.125rem;
  --bs-pagination-border-radius: var(--bs-border-radius-lg);
}

.pagination-sm {
  --bs-pagination-padding-x: 0.5rem;
  --bs-pagination-padding-y: 0.25rem;
  --bs-pagination-font-size: 0.8125rem;
  --bs-pagination-border-radius: var(--bs-border-radius-sm);
}

.badge {
  --bs-badge-padding-x: 0.65em;
  --bs-badge-padding-y: 0.35em;
  --bs-badge-font-size: 0.75em;
  --bs-badge-font-weight: 500;
  --bs-badge-color: white;
  --bs-badge-border-radius: var(--bs-border-radius);
  display: inline-block;
  padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
  font-size: var(--bs-badge-font-size);
  font-weight: var(--bs-badge-font-weight);
  line-height: 1;
  color: var(--bs-badge-color);
  text-align: center;
  white-space: nowrap;
  vertical-align: baseline;
  border-radius: var(--bs-badge-border-radius);
}
.badge:empty {
  display: none;
}

.btn .badge {
  position: relative;
  top: -1px;
}

.alert {
  --bs-alert-bg: transparent;
  --bs-alert-padding-x: 1rem;
  --bs-alert-padding-y: 1rem;
  --bs-alert-margin-bottom: 1rem;
  --bs-alert-color: inherit;
  --bs-alert-border-color: transparent;
  --bs-alert-border: var(--bs-border-width) solid var(--bs-alert-border-color);
  --bs-alert-border-radius: var(--bs-border-radius);
  --bs-alert-link-color: inherit;
  position: relative;
  padding: var(--bs-alert-padding-y) var(--bs-alert-padding-x);
  margin-bottom: var(--bs-alert-margin-bottom);
  color: var(--bs-alert-color);
  background-color: var(--bs-alert-bg);
  border: var(--bs-alert-border);
  border-radius: var(--bs-alert-border-radius);
}

.alert-heading {
  color: inherit;
}

.alert-link {
  font-weight: 700;
  color: var(--bs-alert-link-color);
}

.alert-dismissible {
  padding-right: 3rem;
}
.alert-dismissible .btn-close {
  position: absolute;
  top: 0;
  right: 0;
  z-index: 2;
  padding: 1.25rem 1rem;
}

.alert-primary {
  --bs-alert-color: var(--bs-primary-text-emphasis);
  --bs-alert-bg: var(--bs-primary-bg-subtle);
  --bs-alert-border-color: var(--bs-primary-border-subtle);
  --bs-alert-link-color: var(--bs-primary-text-emphasis);
}

.alert-secondary {
  --bs-alert-color: var(--bs-secondary-text-emphasis);
  --bs-alert-bg: var(--bs-secondary-bg-subtle);
  --bs-alert-border-color: var(--bs-secondary-border-subtle);
  --bs-alert-link-color: var(--bs-secondary-text-emphasis);
}

.alert-success {
  --bs-alert-color: var(--bs-success-text-emphasis);
  --bs-alert-bg: var(--bs-success-bg-subtle);
  --bs-alert-border-color: var(--bs-success-border-subtle);
  --bs-alert-link-color: var(--bs-success-text-emphasis);
}

.alert-info {
  --bs-alert-color: var(--bs-info-text-emphasis);
  --bs-alert-bg: var(--bs-info-bg-subtle);
  --bs-alert-border-color: var(--bs-info-border-subtle);
  --bs-alert-link-color: var(--bs-info-text-emphasis);
}

.alert-warning {
  --bs-alert-color: var(--bs-warning-text-emphasis);
  --bs-alert-bg: var(--bs-warning-bg-subtle);
  --bs-alert-border-color: var(--bs-warning-border-subtle);
  --bs-alert-link-color: var(--bs-warning-text-emphasis);
}

.alert-danger {
  --bs-alert-color: var(--bs-danger-text-emphasis);
  --bs-alert-bg: var(--bs-danger-bg-subtle);
  --bs-alert-border-color: var(--bs-danger-border-subtle);
  --bs-alert-link-color: var(--bs-danger-text-emphasis);
}

.alert-light {
  --bs-alert-color: var(--bs-light-text-emphasis);
  --bs-alert-bg: var(--bs-light-bg-subtle);
  --bs-alert-border-color: var(--bs-light-border-subtle);
  --bs-alert-link-color: var(--bs-light-text-emphasis);
}

.alert-dark {
  --bs-alert-color: var(--bs-dark-text-emphasis);
  --bs-alert-bg: var(--bs-dark-bg-subtle);
  --bs-alert-border-color: var(--bs-dark-border-subtle);
  --bs-alert-link-color: var(--bs-dark-text-emphasis);
}

@keyframes progress-bar-stripes {
  0% {
    background-position-x: 0.5rem;
  }
}
.progress,
.progress-stacked {
  --bs-progress-height: 0.5rem;
  --bs-progress-font-size: 0.75rem;
  --bs-progress-bg: #dce0e5;
  --bs-progress-border-radius: var(--bs-border-radius);
  --bs-progress-box-shadow: var(--bs-box-shadow-inset);
  --bs-progress-bar-color: white;
  --bs-progress-bar-bg: #0abf53;
  --bs-progress-bar-transition: width 0.6s ease;
  display: flex;
  height: var(--bs-progress-height);
  overflow: hidden;
  font-size: var(--bs-progress-font-size);
  background-color: var(--bs-progress-bg);
  border-radius: var(--bs-progress-border-radius);
  box-shadow: var(--bs-progress-box-shadow);
}

.progress-bar {
  display: flex;
  flex-direction: column;
  justify-content: center;
  overflow: hidden;
  color: var(--bs-progress-bar-color);
  text-align: center;
  white-space: nowrap;
  background-color: var(--bs-progress-bar-bg);
  transition: var(--bs-progress-bar-transition);
}
@media (prefers-reduced-motion: reduce) {
  .progress-bar {
    transition: none;
  }
}

.progress-bar-striped {
  background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
  background-size: var(--bs-progress-height) var(--bs-progress-height);
}

.progress-stacked > .progress {
  overflow: visible;
}

.progress-stacked > .progress > .progress-bar {
  width: 100%;
}

.progress-bar-animated {
  animation: 1s linear infinite progress-bar-stripes;
}
@media (prefers-reduced-motion: reduce) {
  .progress-bar-animated {
    animation: none;
  }
}

.list-group {
  --bs-list-group-color: var(--bs-body-color);
  --bs-list-group-bg: var(--bs-body-bg);
  --bs-list-group-border-color: #dce0e5;
  --bs-list-group-border-width: var(--bs-border-width);
  --bs-list-group-border-radius: var(--bs-border-radius);
  --bs-list-group-item-padding-x: 1rem;
  --bs-list-group-item-padding-y: 0.75rem;
  --bs-list-group-action-color: var(--bs-secondary-color);
  --bs-list-group-action-hover-color: var(--bs-emphasis-color);
  --bs-list-group-action-hover-bg: var(--bs-tertiary-bg);
  --bs-list-group-action-active-color: var(--bs-body-color);
  --bs-list-group-action-active-bg: var(--bs-secondary-bg);
  --bs-list-group-disabled-color: var(--bs-secondary-color);
  --bs-list-group-disabled-bg: var(--bs-body-bg);
  --bs-list-group-active-color: white;
  --bs-list-group-active-bg: #0abf53;
  --bs-list-group-active-border-color: #0abf53;
  display: flex;
  flex-direction: column;
  padding-left: 0;
  margin-bottom: 0;
  border-radius: var(--bs-list-group-border-radius);
}

.list-group-numbered {
  list-style-type: none;
  counter-reset: section;
}
.list-group-numbered > .list-group-item::before {
  content: counters(section, ".") ". ";
  counter-increment: section;
}

.list-group-item-action {
  width: 100%;
  color: var(--bs-list-group-action-color);
  text-align: inherit;
}
.list-group-item-action:hover, .list-group-item-action:focus {
  z-index: 1;
  color: var(--bs-list-group-action-hover-color);
  text-decoration: none;
  background-color: var(--bs-list-group-action-hover-bg);
}
.list-group-item-action:active {
  color: var(--bs-list-group-action-active-color);
  background-color: var(--bs-list-group-action-active-bg);
}

.list-group-item {
  position: relative;
  display: block;
  padding: var(--bs-list-group-item-padding-y) var(--bs-list-group-item-padding-x);
  color: var(--bs-list-group-color);
  background-color: var(--bs-list-group-bg);
  border: var(--bs-list-group-border-width) solid var(--bs-list-group-border-color);
}
.list-group-item:first-child {
  border-top-left-radius: inherit;
  border-top-right-radius: inherit;
}
.list-group-item:last-child {
  border-bottom-right-radius: inherit;
  border-bottom-left-radius: inherit;
}
.list-group-item.disabled, .list-group-item:disabled {
  color: var(--bs-list-group-disabled-color);
  pointer-events: none;
  background-color: var(--bs-list-group-disabled-bg);
}
.list-group-item.active {
  z-index: 2;
  color: var(--bs-list-group-active-color);
  background-color: var(--bs-list-group-active-bg);
  border-color: var(--bs-list-group-active-border-color);
}
.list-group-item + .list-group-item {
  border-top-width: 0;
}
.list-group-item + .list-group-item.active {
  margin-top: calc(-1 * var(--bs-list-group-border-width));
  border-top-width: var(--bs-list-group-border-width);
}

.list-group-horizontal {
  flex-direction: row;
}
.list-group-horizontal > .list-group-item:first-child:not(:last-child) {
  border-bottom-left-radius: var(--bs-list-group-border-radius);
  border-top-right-radius: 0;
}
.list-group-horizontal > .list-group-item:last-child:not(:first-child) {
  border-top-right-radius: var(--bs-list-group-border-radius);
  border-bottom-left-radius: 0;
}
.list-group-horizontal > .list-group-item.active {
  margin-top: 0;
}
.list-group-horizontal > .list-group-item + .list-group-item {
  border-top-width: var(--bs-list-group-border-width);
  border-left-width: 0;
}
.list-group-horizontal > .list-group-item + .list-group-item.active {
  margin-left: calc(-1 * var(--bs-list-group-border-width));
  border-left-width: var(--bs-list-group-border-width);
}

@media (min-width: 576px) {
  .list-group-horizontal-sm {
    flex-direction: row;
  }
  .list-group-horizontal-sm > .list-group-item:first-child:not(:last-child) {
    border-bottom-left-radius: var(--bs-list-group-border-radius);
    border-top-right-radius: 0;
  }
  .list-group-horizontal-sm > .list-group-item:last-child:not(:first-child) {
    border-top-right-radius: var(--bs-list-group-border-radius);
    border-bottom-left-radius: 0;
  }
  .list-group-horizontal-sm > .list-group-item.active {
    margin-top: 0;
  }
  .list-group-horizontal-sm > .list-group-item + .list-group-item {
    border-top-width: var(--bs-list-group-border-width);
    border-left-width: 0;
  }
  .list-group-horizontal-sm > .list-group-item + .list-group-item.active {
    margin-left: calc(-1 * var(--bs-list-group-border-width));
    border-left-width: var(--bs-list-group-border-width);
  }
}
@media (min-width: 768px) {
  .list-group-horizontal-md {
    flex-direction: row;
  }
  .list-group-horizontal-md > .list-group-item:first-child:not(:last-child) {
    border-bottom-left-radius: var(--bs-list-group-border-radius);
    border-top-right-radius: 0;
  }
  .list-group-horizontal-md > .list-group-item:last-child:not(:first-child) {
    border-top-right-radius: var(--bs-list-group-border-radius);
    border-bottom-left-radius: 0;
  }
  .list-group-horizontal-md > .list-group-item.active {
    margin-top: 0;
  }
  .list-group-horizontal-md > .list-group-item + .list-group-item {
    border-top-width: var(--bs-list-group-border-width);
    border-left-width: 0;
  }
  .list-group-horizontal-md > .list-group-item + .list-group-item.active {
    margin-left: calc(-1 * var(--bs-list-group-border-width));
    border-left-width: var(--bs-list-group-border-width);
  }
}
@media (min-width: 992px) {
  .list-group-horizontal-lg {
    flex-direction: row;
  }
  .list-group-horizontal-lg > .list-group-item:first-child:not(:last-child) {
    border-bottom-left-radius: var(--bs-list-group-border-radius);
    border-top-right-radius: 0;
  }
  .list-group-horizontal-lg > .list-group-item:last-child:not(:first-child) {
    border-top-right-radius: var(--bs-list-group-border-radius);
    border-bottom-left-radius: 0;
  }
  .list-group-horizontal-lg > .list-group-item.active {
    margin-top: 0;
  }
  .list-group-horizontal-lg > .list-group-item + .list-group-item {
    border-top-width: var(--bs-list-group-border-width);
    border-left-width: 0;
  }
  .list-group-horizontal-lg > .list-group-item + .list-group-item.active {
    margin-left: calc(-1 * var(--bs-list-group-border-width));
    border-left-width: var(--bs-list-group-border-width);
  }
}
@media (min-width: 1200px) {
  .list-group-horizontal-xl {
    flex-direction: row;
  }
  .list-group-horizontal-xl > .list-group-item:first-child:not(:last-child) {
    border-bottom-left-radius: var(--bs-list-group-border-radius);
    border-top-right-radius: 0;
  }
  .list-group-horizontal-xl > .list-group-item:last-child:not(:first-child) {
    border-top-right-radius: var(--bs-list-group-border-radius);
    border-bottom-left-radius: 0;
  }
  .list-group-horizontal-xl > .list-group-item.active {
    margin-top: 0;
  }
  .list-group-horizontal-xl > .list-group-item + .list-group-item {
    border-top-width: var(--bs-list-group-border-width);
    border-left-width: 0;
  }
  .list-group-horizontal-xl > .list-group-item + .list-group-item.active {
    margin-left: calc(-1 * var(--bs-list-group-border-width));
    border-left-width: var(--bs-list-group-border-width);
  }
}
@media (min-width: 1400px) {
  .list-group-horizontal-xxl {
    flex-direction: row;
  }
  .list-group-horizontal-xxl > .list-group-item:first-child:not(:last-child) {
    border-bottom-left-radius: var(--bs-list-group-border-radius);
    border-top-right-radius: 0;
  }
  .list-group-horizontal-xxl > .list-group-item:last-child:not(:first-child) {
    border-top-right-radius: var(--bs-list-group-border-radius);
    border-bottom-left-radius: 0;
  }
  .list-group-horizontal-xxl > .list-group-item.active {
    margin-top: 0;
  }
  .list-group-horizontal-xxl > .list-group-item + .list-group-item {
    border-top-width: var(--bs-list-group-border-width);
    border-left-width: 0;
  }
  .list-group-horizontal-xxl > .list-group-item + .list-group-item.active {
    margin-left: calc(-1 * var(--bs-list-group-border-width));
    border-left-width: var(--bs-list-group-border-width);
  }
}
.list-group-flush {
  border-radius: 0;
}
.list-group-flush > .list-group-item {
  border-width: 0 0 var(--bs-list-group-border-width);
}
.list-group-flush > .list-group-item:last-child {
  border-bottom-width: 0;
}

.list-group-item-primary {
  --bs-list-group-color: var(--bs-primary-text-emphasis);
  --bs-list-group-bg: var(--bs-primary-bg-subtle);
  --bs-list-group-border-color: var(--bs-primary-border-subtle);
  --bs-list-group-action-hover-color: var(--bs-emphasis-color);
  --bs-list-group-action-hover-bg: var(--bs-primary-border-subtle);
  --bs-list-group-action-active-color: var(--bs-emphasis-color);
  --bs-list-group-action-active-bg: var(--bs-primary-border-subtle);
  --bs-list-group-active-color: var(--bs-primary-bg-subtle);
  --bs-list-group-active-bg: var(--bs-primary-text-emphasis);
  --bs-list-group-active-border-color: var(--bs-primary-text-emphasis);
}

.list-group-item-secondary {
  --bs-list-group-color: var(--bs-secondary-text-emphasis);
  --bs-list-group-bg: var(--bs-secondary-bg-subtle);
  --bs-list-group-border-color: var(--bs-secondary-border-subtle);
  --bs-list-group-action-hover-color: var(--bs-emphasis-color);
  --bs-list-group-action-hover-bg: var(--bs-secondary-border-subtle);
  --bs-list-group-action-active-color: var(--bs-emphasis-color);
  --bs-list-group-action-active-bg: var(--bs-secondary-border-subtle);
  --bs-list-group-active-color: var(--bs-secondary-bg-subtle);
  --bs-list-group-active-bg: var(--bs-secondary-text-emphasis);
  --bs-list-group-active-border-color: var(--bs-secondary-text-emphasis);
}

.list-group-item-success {
  --bs-list-group-color: var(--bs-success-text-emphasis);
  --bs-list-group-bg: var(--bs-success-bg-subtle);
  --bs-list-group-border-color: var(--bs-success-border-subtle);
  --bs-list-group-action-hover-color: var(--bs-emphasis-color);
  --bs-list-group-action-hover-bg: var(--bs-success-border-subtle);
  --bs-list-group-action-active-color: var(--bs-emphasis-color);
  --bs-list-group-action-active-bg: var(--bs-success-border-subtle);
  --bs-list-group-active-color: var(--bs-success-bg-subtle);
  --bs-list-group-active-bg: var(--bs-success-text-emphasis);
  --bs-list-group-active-border-color: var(--bs-success-text-emphasis);
}

.list-group-item-info {
  --bs-list-group-color: var(--bs-info-text-emphasis);
  --bs-list-group-bg: var(--bs-info-bg-subtle);
  --bs-list-group-border-color: var(--bs-info-border-subtle);
  --bs-list-group-action-hover-color: var(--bs-emphasis-color);
  --bs-list-group-action-hover-bg: var(--bs-info-border-subtle);
  --bs-list-group-action-active-color: var(--bs-emphasis-color);
  --bs-list-group-action-active-bg: var(--bs-info-border-subtle);
  --bs-list-group-active-color: var(--bs-info-bg-subtle);
  --bs-list-group-active-bg: var(--bs-info-text-emphasis);
  --bs-list-group-active-border-color: var(--bs-info-text-emphasis);
}

.list-group-item-warning {
  --bs-list-group-color: var(--bs-warning-text-emphasis);
  --bs-list-group-bg: var(--bs-warning-bg-subtle);
  --bs-list-group-border-color: var(--bs-warning-border-subtle);
  --bs-list-group-action-hover-color: var(--bs-emphasis-color);
  --bs-list-group-action-hover-bg: var(--bs-warning-border-subtle);
  --bs-list-group-action-active-color: var(--bs-emphasis-color);
  --bs-list-group-action-active-bg: var(--bs-warning-border-subtle);
  --bs-list-group-active-color: var(--bs-warning-bg-subtle);
  --bs-list-group-active-bg: var(--bs-warning-text-emphasis);
  --bs-list-group-active-border-color: var(--bs-warning-text-emphasis);
}

.list-group-item-danger {
  --bs-list-group-color: var(--bs-danger-text-emphasis);
  --bs-list-group-bg: var(--bs-danger-bg-subtle);
  --bs-list-group-border-color: var(--bs-danger-border-subtle);
  --bs-list-group-action-hover-color: var(--bs-emphasis-color);
  --bs-list-group-action-hover-bg: var(--bs-danger-border-subtle);
  --bs-list-group-action-active-color: var(--bs-emphasis-color);
  --bs-list-group-action-active-bg: var(--bs-danger-border-subtle);
  --bs-list-group-active-color: var(--bs-danger-bg-subtle);
  --bs-list-group-active-bg: var(--bs-danger-text-emphasis);
  --bs-list-group-active-border-color: var(--bs-danger-text-emphasis);
}

.list-group-item-light {
  --bs-list-group-color: var(--bs-light-text-emphasis);
  --bs-list-group-bg: var(--bs-light-bg-subtle);
  --bs-list-group-border-color: var(--bs-light-border-subtle);
  --bs-list-group-action-hover-color: var(--bs-emphasis-color);
  --bs-list-group-action-hover-bg: var(--bs-light-border-subtle);
  --bs-list-group-action-active-color: var(--bs-emphasis-color);
  --bs-list-group-action-active-bg: var(--bs-light-border-subtle);
  --bs-list-group-active-color: var(--bs-light-bg-subtle);
  --bs-list-group-active-bg: var(--bs-light-text-emphasis);
  --bs-list-group-active-border-color: var(--bs-light-text-emphasis);
}

.list-group-item-dark {
  --bs-list-group-color: var(--bs-dark-text-emphasis);
  --bs-list-group-bg: var(--bs-dark-bg-subtle);
  --bs-list-group-border-color: var(--bs-dark-border-subtle);
  --bs-list-group-action-hover-color: var(--bs-emphasis-color);
  --bs-list-group-action-hover-bg: var(--bs-dark-border-subtle);
  --bs-list-group-action-active-color: var(--bs-emphasis-color);
  --bs-list-group-action-active-bg: var(--bs-dark-border-subtle);
  --bs-list-group-active-color: var(--bs-dark-bg-subtle);
  --bs-list-group-active-bg: var(--bs-dark-text-emphasis);
  --bs-list-group-active-border-color: var(--bs-dark-text-emphasis);
}

.btn-close {
  --bs-btn-close-color: #000;
  --bs-btn-close-bg: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23000'%3e%3cpath d='M.293.293a1 1 0 0 1 1.414 0L8 6.586 14.293.293a1 1 0 1 1 1.414 1.414L9.414 8l6.293 6.293a1 1 0 0 1-1.414 1.414L8 9.414l-6.293 6.293a1 1 0 0 1-1.414-1.414L6.586 8 .293 1.707a1 1 0 0 1 0-1.414z'/%3e%3c/svg%3e");
  --bs-btn-close-opacity: 0.5;
  --bs-btn-close-hover-opacity: 0.75;
  --bs-btn-close-focus-shadow: 0 0 0 0.25rem rgba(10, 191, 83, 0.25);
  --bs-btn-close-focus-opacity: 1;
  --bs-btn-close-disabled-opacity: 0.25;
  --bs-btn-close-white-filter: invert(1) grayscale(100%) brightness(200%);
  box-sizing: content-box;
  width: 1em;
  height: 1em;
  padding: 0.25em 0.25em;
  color: var(--bs-btn-close-color);
  background: transparent var(--bs-btn-close-bg) center/1em auto no-repeat;
  border: 0;
  border-radius: 0.6rem;
  opacity: var(--bs-btn-close-opacity);
}
.btn-close:hover {
  color: var(--bs-btn-close-color);
  text-decoration: none;
  opacity: var(--bs-btn-close-hover-opacity);
}
.btn-close:focus {
  outline: 0;
  box-shadow: var(--bs-btn-close-focus-shadow);
  opacity: var(--bs-btn-close-focus-opacity);
}
.btn-close:disabled, .btn-close.disabled {
  pointer-events: none;
  user-select: none;
  opacity: var(--bs-btn-close-disabled-opacity);
}

.btn-close-white {
  filter: var(--bs-btn-close-white-filter);
}

[data-bs-theme=dark] .btn-close {
  filter: var(--bs-btn-close-white-filter);
}

.toast {
  --bs-toast-zindex: 1090;
  --bs-toast-padding-x: 1rem;
  --bs-toast-padding-y: 1rem;
  --bs-toast-spacing: 30px;
  --bs-toast-max-width: 350px;
  --bs-toast-font-size: 0.875rem;
  --bs-toast-color: ;
  --bs-toast-bg: rgba(var(--bs-body-bg-rgb), 0.85);
  --bs-toast-border-width: var(--bs-border-width);
  --bs-toast-border-color: rgba(220, 224, 229, 0.6);
  --bs-toast-border-radius: 0.8rem;
  --bs-toast-box-shadow: 0rem 0.1875rem 0.375rem rgba(140, 152, 164, 0.25);
  --bs-toast-header-color: var(--bs-secondary-color);
  --bs-toast-header-bg: rgba(var(--bs-body-bg-rgb), 0.85);
  --bs-toast-header-border-color: rgba(220, 224, 229, 0.6);
  width: var(--bs-toast-max-width);
  max-width: 100%;
  font-size: var(--bs-toast-font-size);
  color: var(--bs-toast-color);
  pointer-events: auto;
  background-color: var(--bs-toast-bg);
  background-clip: padding-box;
  border: var(--bs-toast-border-width) solid var(--bs-toast-border-color);
  box-shadow: var(--bs-toast-box-shadow);
  border-radius: var(--bs-toast-border-radius);
}
.toast.showing {
  opacity: 0;
}
.toast:not(.show) {
  display: none;
}

.toast-container {
  --bs-toast-zindex: 1090;
  position: absolute;
  z-index: var(--bs-toast-zindex);
  width: max-content;
  max-width: 100%;
  pointer-events: none;
}
.toast-container > :not(:last-child) {
  margin-bottom: var(--bs-toast-spacing);
}

.toast-header {
  display: flex;
  align-items: center;
  padding: var(--bs-toast-padding-y) var(--bs-toast-padding-x);
  color: var(--bs-toast-header-color);
  background-color: var(--bs-toast-header-bg);
  background-clip: padding-box;
  border-bottom: var(--bs-toast-border-width) solid var(--bs-toast-header-border-color);
  border-top-left-radius: calc(var(--bs-toast-border-radius) - var(--bs-toast-border-width));
  border-top-right-radius: calc(var(--bs-toast-border-radius) - var(--bs-toast-border-width));
}
.toast-header .btn-close {
  margin-right: calc(-0.5 * var(--bs-toast-padding-x));
  margin-left: var(--bs-toast-padding-x);
}

.toast-body {
  padding: var(--bs-toast-padding-x);
  word-wrap: break-word;
}

.modal {
  --bs-modal-zindex: 101;
  --bs-modal-width: 550px;
  --bs-modal-padding: 1.5rem;
  --bs-modal-margin: 0.5rem;
  --bs-modal-color: ;
  --bs-modal-bg: var(--bs-body-bg);
  --bs-modal-border-color: transparent;
  --bs-modal-border-width: var(--bs-border-width);
  --bs-modal-border-radius: var(--bs-border-radius-lg);
  --bs-modal-box-shadow: var(--bs-box-shadow-sm);
  --bs-modal-inner-border-radius: calc(var(--bs-border-radius-lg) - (var(--bs-border-width)));
  --bs-modal-header-padding-x: 1.5rem;
  --bs-modal-header-padding-y: 1rem;
  --bs-modal-header-padding: 1rem 1.5rem;
  --bs-modal-header-border-color: var(--bs-border-color);
  --bs-modal-header-border-width: 0;
  --bs-modal-title-line-height: 1.5;
  --bs-modal-footer-gap: 0.5rem;
  --bs-modal-footer-bg: ;
  --bs-modal-footer-border-color: var(--bs-border-color);
  --bs-modal-footer-border-width: 0;
  position: fixed;
  top: 0;
  left: 0;
  z-index: var(--bs-modal-zindex);
  display: none;
  width: 100%;
  height: 100%;
  overflow-x: hidden;
  overflow-y: auto;
  outline: 0;
}

.modal-dialog {
  position: relative;
  width: auto;
  margin: var(--bs-modal-margin);
  pointer-events: none;
}
.modal.fade .modal-dialog {
  transition: transform 0.3s ease-out;
  transform: translate(0, -50px);
}
@media (prefers-reduced-motion: reduce) {
  .modal.fade .modal-dialog {
    transition: none;
  }
}
.modal.show .modal-dialog {
  transform: none;
}
.modal.modal-static .modal-dialog {
  transform: scale(1.02);
}

.modal-dialog-scrollable {
  height: calc(100% - var(--bs-modal-margin) * 2);
}
.modal-dialog-scrollable .modal-content {
  max-height: 100%;
  overflow: hidden;
}
.modal-dialog-scrollable .modal-body {
  overflow-y: auto;
}

.modal-dialog-centered {
  display: flex;
  align-items: center;
  min-height: calc(100% - var(--bs-modal-margin) * 2);
}

.modal-content {
  position: relative;
  display: flex;
  flex-direction: column;
  width: 100%;
  color: var(--bs-modal-color);
  pointer-events: auto;
  background-color: var(--bs-modal-bg);
  background-clip: padding-box;
  border: var(--bs-modal-border-width) solid var(--bs-modal-border-color);
  border-radius: var(--bs-modal-border-radius);
  box-shadow: var(--bs-modal-box-shadow);
  outline: 0;
}

.modal-backdrop {
  --bs-backdrop-zindex: 100;
  --bs-backdrop-bg: rgba(45, 55, 75, 0.25);
  --bs-backdrop-opacity: 1;
  position: fixed;
  top: 0;
  left: 0;
  z-index: var(--bs-backdrop-zindex);
  width: 100vw;
  height: 100vh;
  background-color: var(--bs-backdrop-bg);
}
.modal-backdrop.fade {
  opacity: 0;
}
.modal-backdrop.show {
  opacity: var(--bs-backdrop-opacity);
}

.modal-header {
  display: flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: space-between;
  padding: var(--bs-modal-header-padding);
  border-bottom: var(--bs-modal-header-border-width) solid var(--bs-modal-header-border-color);
  border-top-left-radius: var(--bs-modal-inner-border-radius);
  border-top-right-radius: var(--bs-modal-inner-border-radius);
}
.modal-header .btn-close {
  padding: calc(var(--bs-modal-header-padding-y) * 0.5) calc(var(--bs-modal-header-padding-x) * 0.5);
  margin: calc(-0.5 * var(--bs-modal-header-padding-y)) calc(-0.5 * var(--bs-modal-header-padding-x)) calc(-0.5 * var(--bs-modal-header-padding-y)) auto;
}

.modal-title {
  margin-bottom: 0;
  line-height: var(--bs-modal-title-line-height);
}

.modal-body {
  position: relative;
  flex: 1 1 auto;
  padding: var(--bs-modal-padding);
}

.modal-footer {
  display: flex;
  flex-shrink: 0;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-end;
  padding: calc(var(--bs-modal-padding) - var(--bs-modal-footer-gap) * 0.5);
  background-color: var(--bs-modal-footer-bg);
  border-top: var(--bs-modal-footer-border-width) solid var(--bs-modal-footer-border-color);
  border-bottom-right-radius: var(--bs-modal-inner-border-radius);
  border-bottom-left-radius: var(--bs-modal-inner-border-radius);
}
.modal-footer > * {
  margin: calc(var(--bs-modal-footer-gap) * 0.5);
}

@media (min-width: 576px) {
  .modal {
    --bs-modal-margin: 1.75rem;
    --bs-modal-box-shadow: var(--bs-box-shadow);
  }
  .modal-dialog {
    max-width: var(--bs-modal-width);
    margin-right: auto;
    margin-left: auto;
  }
  .modal-sm {
    --bs-modal-width: 400px;
  }
}
@media (min-width: 992px) {
  .modal-lg,
.modal-xl {
    --bs-modal-width: 800px;
  }
}
@media (min-width: 1200px) {
  .modal-xl {
    --bs-modal-width: 1140px;
  }
}
.modal-fullscreen {
  width: 100vw;
  max-width: none;
  height: 100%;
  margin: 0;
}
.modal-fullscreen .modal-content {
  height: 100%;
  border: 0;
  border-radius: 0;
}
.modal-fullscreen .modal-header,
.modal-fullscreen .modal-footer {
  border-radius: 0;
}
.modal-fullscreen .modal-body {
  overflow-y: auto;
}

@media (max-width: 575.98px) {
  .modal-fullscreen-sm-down {
    width: 100vw;
    max-width: none;
    height: 100%;
    margin: 0;
  }
  .modal-fullscreen-sm-down .modal-content {
    height: 100%;
    border: 0;
    border-radius: 0;
  }
  .modal-fullscreen-sm-down .modal-header,
.modal-fullscreen-sm-down .modal-footer {
    border-radius: 0;
  }
  .modal-fullscreen-sm-down .modal-body {
    overflow-y: auto;
  }
}
@media (max-width: 767.98px) {
  .modal-fullscreen-md-down {
    width: 100vw;
    max-width: none;
    height: 100%;
    margin: 0;
  }
  .modal-fullscreen-md-down .modal-content {
    height: 100%;
    border: 0;
    border-radius: 0;
  }
  .modal-fullscreen-md-down .modal-header,
.modal-fullscreen-md-down .modal-footer {
    border-radius: 0;
  }
  .modal-fullscreen-md-down .modal-body {
    overflow-y: auto;
  }
}
@media (max-width: 991.98px) {
  .modal-fullscreen-lg-down {
    width: 100vw;
    max-width: none;
    height: 100%;
    margin: 0;
  }
  .modal-fullscreen-lg-down .modal-content {
    height: 100%;
    border: 0;
    border-radius: 0;
  }
  .modal-fullscreen-lg-down .modal-header,
.modal-fullscreen-lg-down .modal-footer {
    border-radius: 0;
  }
  .modal-fullscreen-lg-down .modal-body {
    overflow-y: auto;
  }
}
@media (max-width: 1199.98px) {
  .modal-fullscreen-xl-down {
    width: 100vw;
    max-width: none;
    height: 100%;
    margin: 0;
  }
  .modal-fullscreen-xl-down .modal-content {
    height: 100%;
    border: 0;
    border-radius: 0;
  }
  .modal-fullscreen-xl-down .modal-header,
.modal-fullscreen-xl-down .modal-footer {
    border-radius: 0;
  }
  .modal-fullscreen-xl-down .modal-body {
    overflow-y: auto;
  }
}
@media (max-width: 1399.98px) {
  .modal-fullscreen-xxl-down {
    width: 100vw;
    max-width: none;
    height: 100%;
    margin: 0;
  }
  .modal-fullscreen-xxl-down .modal-content {
    height: 100%;
    border: 0;
    border-radius: 0;
  }
  .modal-fullscreen-xxl-down .modal-header,
.modal-fullscreen-xxl-down .modal-footer {
    border-radius: 0;
  }
  .modal-fullscreen-xxl-down .modal-body {
    overflow-y: auto;
  }
}
.tooltip {
  --bs-tooltip-zindex: 1080;
  --bs-tooltip-max-width: 200px;
  --bs-tooltip-padding-x: 0.5rem;
  --bs-tooltip-padding-y: 0.25rem;
  --bs-tooltip-margin: ;
  --bs-tooltip-font-size: 0.8125rem;
  --bs-tooltip-color: var(--bs-body-bg);
  --bs-tooltip-bg: #2d374b;
  --bs-tooltip-border-radius: var(--bs-border-radius);
  --bs-tooltip-opacity: 1;
  --bs-tooltip-arrow-width: 0.8rem;
  --bs-tooltip-arrow-height: 0.4rem;
  z-index: var(--bs-tooltip-zindex);
  display: block;
  margin: var(--bs-tooltip-margin);
  font-family: "Inter", sans-serif;
  font-style: normal;
  font-weight: 400;
  line-height: 1.5;
  text-align: left;
  text-align: start;
  text-decoration: none;
  text-shadow: none;
  text-transform: none;
  letter-spacing: normal;
  word-break: normal;
  white-space: normal;
  word-spacing: normal;
  line-break: auto;
  font-size: var(--bs-tooltip-font-size);
  word-wrap: break-word;
  opacity: 0;
}
.tooltip.show {
  opacity: var(--bs-tooltip-opacity);
}
.tooltip .tooltip-arrow {
  display: block;
  width: var(--bs-tooltip-arrow-width);
  height: var(--bs-tooltip-arrow-height);
}
.tooltip .tooltip-arrow::before {
  position: absolute;
  content: "";
  border-color: transparent;
  border-style: solid;
}

.bs-tooltip-top .tooltip-arrow, .bs-tooltip-auto[data-popper-placement^=top] .tooltip-arrow {
  bottom: calc(-1 * var(--bs-tooltip-arrow-height));
}
.bs-tooltip-top .tooltip-arrow::before, .bs-tooltip-auto[data-popper-placement^=top] .tooltip-arrow::before {
  top: -1px;
  border-width: var(--bs-tooltip-arrow-height) calc(var(--bs-tooltip-arrow-width) * 0.5) 0;
  border-top-color: var(--bs-tooltip-bg);
}

/* rtl:begin:ignore */
.bs-tooltip-end .tooltip-arrow, .bs-tooltip-auto[data-popper-placement^=right] .tooltip-arrow {
  left: calc(-1 * var(--bs-tooltip-arrow-height));
  width: var(--bs-tooltip-arrow-height);
  height: var(--bs-tooltip-arrow-width);
}
.bs-tooltip-end .tooltip-arrow::before, .bs-tooltip-auto[data-popper-placement^=right] .tooltip-arrow::before {
  right: -1px;
  border-width: calc(var(--bs-tooltip-arrow-width) * 0.5) var(--bs-tooltip-arrow-height) calc(var(--bs-tooltip-arrow-width) * 0.5) 0;
  border-right-color: var(--bs-tooltip-bg);
}

/* rtl:end:ignore */
.bs-tooltip-bottom .tooltip-arrow, .bs-tooltip-auto[data-popper-placement^=bottom] .tooltip-arrow {
  top: calc(-1 * var(--bs-tooltip-arrow-height));
}
.bs-tooltip-bottom .tooltip-arrow::before, .bs-tooltip-auto[data-popper-placement^=bottom] .tooltip-arrow::before {
  bottom: -1px;
  border-width: 0 calc(var(--bs-tooltip-arrow-width) * 0.5) var(--bs-tooltip-arrow-height);
  border-bottom-color: var(--bs-tooltip-bg);
}

/* rtl:begin:ignore */
.bs-tooltip-start .tooltip-arrow, .bs-tooltip-auto[data-popper-placement^=left] .tooltip-arrow {
  right: calc(-1 * var(--bs-tooltip-arrow-height));
  width: var(--bs-tooltip-arrow-height);
  height: var(--bs-tooltip-arrow-width);
}
.bs-tooltip-start .tooltip-arrow::before, .bs-tooltip-auto[data-popper-placement^=left] .tooltip-arrow::before {
  left: -1px;
  border-width: calc(var(--bs-tooltip-arrow-width) * 0.5) 0 calc(var(--bs-tooltip-arrow-width) * 0.5) var(--bs-tooltip-arrow-height);
  border-left-color: var(--bs-tooltip-bg);
}

/* rtl:end:ignore */
.tooltip-inner {
  max-width: var(--bs-tooltip-max-width);
  padding: var(--bs-tooltip-padding-y) var(--bs-tooltip-padding-x);
  color: var(--bs-tooltip-color);
  text-align: center;
  background-color: var(--bs-tooltip-bg);
  border-radius: var(--bs-tooltip-border-radius);
}

.popover {
  --bs-popover-zindex: 1070;
  --bs-popover-max-width: 276px;
  --bs-popover-font-size: 1rem;
  --bs-popover-bg: var(--bs-body-bg);
  --bs-popover-border-width: var(--bs-border-width);
  --bs-popover-border-color: transparent;
  --bs-popover-border-radius: var(--bs-border-radius-lg);
  --bs-popover-inner-border-radius: calc(var(--bs-border-radius-lg) - var(--bs-border-width));
  --bs-popover-box-shadow: 0rem 1rem 1.75rem 0rem rgba(45, 55, 75, 0.1);
  --bs-popover-header-padding-x: 1.5rem;
  --bs-popover-header-padding-y: 1rem;
  --bs-popover-header-font-size: 1rem;
  --bs-popover-header-color: #2d374b;
  --bs-popover-header-bg: #f3f6f9;
  --bs-popover-body-padding-x: 1.5rem;
  --bs-popover-body-padding-y: 1.5rem;
  --bs-popover-body-color: var(--bs-body-color);
  --bs-popover-arrow-width: 1rem;
  --bs-popover-arrow-height: 0.5rem;
  --bs-popover-arrow-border: var(--bs-popover-border-color);
  z-index: var(--bs-popover-zindex);
  display: block;
  max-width: var(--bs-popover-max-width);
  font-family: "Inter", sans-serif;
  font-style: normal;
  font-weight: 400;
  line-height: 1.5;
  text-align: left;
  text-align: start;
  text-decoration: none;
  text-shadow: none;
  text-transform: none;
  letter-spacing: normal;
  word-break: normal;
  white-space: normal;
  word-spacing: normal;
  line-break: auto;
  font-size: var(--bs-popover-font-size);
  word-wrap: break-word;
  background-color: var(--bs-popover-bg);
  background-clip: padding-box;
  border: var(--bs-popover-border-width) solid var(--bs-popover-border-color);
  border-radius: var(--bs-popover-border-radius);
  box-shadow: var(--bs-popover-box-shadow);
}
.popover .popover-arrow {
  display: block;
  width: var(--bs-popover-arrow-width);
  height: var(--bs-popover-arrow-height);
}
.popover .popover-arrow::before, .popover .popover-arrow::after {
  position: absolute;
  display: block;
  content: "";
  border-color: transparent;
  border-style: solid;
  border-width: 0;
}

.bs-popover-top > .popover-arrow, .bs-popover-auto[data-popper-placement^=top] > .popover-arrow {
  bottom: calc(-1 * (var(--bs-popover-arrow-height)) - var(--bs-popover-border-width));
}
.bs-popover-top > .popover-arrow::before, .bs-popover-auto[data-popper-placement^=top] > .popover-arrow::before, .bs-popover-top > .popover-arrow::after, .bs-popover-auto[data-popper-placement^=top] > .popover-arrow::after {
  border-width: var(--bs-popover-arrow-height) calc(var(--bs-popover-arrow-width) * 0.5) 0;
}
.bs-popover-top > .popover-arrow::before, .bs-popover-auto[data-popper-placement^=top] > .popover-arrow::before {
  bottom: 0;
  border-top-color: var(--bs-popover-arrow-border);
}
.bs-popover-top > .popover-arrow::after, .bs-popover-auto[data-popper-placement^=top] > .popover-arrow::after {
  bottom: var(--bs-popover-border-width);
  border-top-color: var(--bs-popover-bg);
}

/* rtl:begin:ignore */
.bs-popover-end > .popover-arrow, .bs-popover-auto[data-popper-placement^=right] > .popover-arrow {
  left: calc(-1 * (var(--bs-popover-arrow-height)) - var(--bs-popover-border-width));
  width: var(--bs-popover-arrow-height);
  height: var(--bs-popover-arrow-width);
}
.bs-popover-end > .popover-arrow::before, .bs-popover-auto[data-popper-placement^=right] > .popover-arrow::before, .bs-popover-end > .popover-arrow::after, .bs-popover-auto[data-popper-placement^=right] > .popover-arrow::after {
  border-width: calc(var(--bs-popover-arrow-width) * 0.5) var(--bs-popover-arrow-height) calc(var(--bs-popover-arrow-width) * 0.5) 0;
}
.bs-popover-end > .popover-arrow::before, .bs-popover-auto[data-popper-placement^=right] > .popover-arrow::before {
  left: 0;
  border-right-color: var(--bs-popover-arrow-border);
}
.bs-popover-end > .popover-arrow::after, .bs-popover-auto[data-popper-placement^=right] > .popover-arrow::after {
  left: var(--bs-popover-border-width);
  border-right-color: var(--bs-popover-bg);
}

/* rtl:end:ignore */
.bs-popover-bottom > .popover-arrow, .bs-popover-auto[data-popper-placement^=bottom] > .popover-arrow {
  top: calc(-1 * (var(--bs-popover-arrow-height)) - var(--bs-popover-border-width));
}
.bs-popover-bottom > .popover-arrow::before, .bs-popover-auto[data-popper-placement^=bottom] > .popover-arrow::before, .bs-popover-bottom > .popover-arrow::after, .bs-popover-auto[data-popper-placement^=bottom] > .popover-arrow::after {
  border-width: 0 calc(var(--bs-popover-arrow-width) * 0.5) var(--bs-popover-arrow-height);
}
.bs-popover-bottom > .popover-arrow::before, .bs-popover-auto[data-popper-placement^=bottom] > .popover-arrow::before {
  top: 0;
  border-bottom-color: var(--bs-popover-arrow-border);
}
.bs-popover-bottom > .popover-arrow::after, .bs-popover-auto[data-popper-placement^=bottom] > .popover-arrow::after {
  top: var(--bs-popover-border-width);
  border-bottom-color: var(--bs-popover-bg);
}
.bs-popover-bottom .popover-header::before, .bs-popover-auto[data-popper-placement^=bottom] .popover-header::before {
  position: absolute;
  top: 0;
  left: 50%;
  display: block;
  width: var(--bs-popover-arrow-width);
  margin-left: calc(-0.5 * var(--bs-popover-arrow-width));
  content: "";
  border-bottom: var(--bs-popover-border-width) solid var(--bs-popover-header-bg);
}

/* rtl:begin:ignore */
.bs-popover-start > .popover-arrow, .bs-popover-auto[data-popper-placement^=left] > .popover-arrow {
  right: calc(-1 * (var(--bs-popover-arrow-height)) - var(--bs-popover-border-width));
  width: var(--bs-popover-arrow-height);
  height: var(--bs-popover-arrow-width);
}
.bs-popover-start > .popover-arrow::before, .bs-popover-auto[data-popper-placement^=left] > .popover-arrow::before, .bs-popover-start > .popover-arrow::after, .bs-popover-auto[data-popper-placement^=left] > .popover-arrow::after {
  border-width: calc(var(--bs-popover-arrow-width) * 0.5) 0 calc(var(--bs-popover-arrow-width) * 0.5) var(--bs-popover-arrow-height);
}
.bs-popover-start > .popover-arrow::before, .bs-popover-auto[data-popper-placement^=left] > .popover-arrow::before {
  right: 0;
  border-left-color: var(--bs-popover-arrow-border);
}
.bs-popover-start > .popover-arrow::after, .bs-popover-auto[data-popper-placement^=left] > .popover-arrow::after {
  right: var(--bs-popover-border-width);
  border-left-color: var(--bs-popover-bg);
}

/* rtl:end:ignore */
.popover-header {
  padding: var(--bs-popover-header-padding-y) var(--bs-popover-header-padding-x);
  margin-bottom: 0;
  font-size: var(--bs-popover-header-font-size);
  color: var(--bs-popover-header-color);
  background-color: var(--bs-popover-header-bg);
  border-bottom: var(--bs-popover-border-width) solid var(--bs-popover-border-color);
  border-top-left-radius: var(--bs-popover-inner-border-radius);
  border-top-right-radius: var(--bs-popover-inner-border-radius);
}
.popover-header:empty {
  display: none;
}

.popover-body {
  padding: var(--bs-popover-body-padding-y) var(--bs-popover-body-padding-x);
  color: var(--bs-popover-body-color);
}

.carousel {
  position: relative;
}

.carousel.pointer-event {
  touch-action: pan-y;
}

.carousel-inner {
  position: relative;
  width: 100%;
  overflow: hidden;
}
.carousel-inner::after {
  display: block;
  clear: both;
  content: "";
}

.carousel-item {
  position: relative;
  display: none;
  float: left;
  width: 100%;
  margin-right: -100%;
  backface-visibility: hidden;
  transition: transform 0.6s ease-in-out;
}
@media (prefers-reduced-motion: reduce) {
  .carousel-item {
    transition: none;
  }
}

.carousel-item.active,
.carousel-item-next,
.carousel-item-prev {
  display: block;
}

.carousel-item-next:not(.carousel-item-start),
.active.carousel-item-end {
  transform: translateX(100%);
}

.carousel-item-prev:not(.carousel-item-end),
.active.carousel-item-start {
  transform: translateX(-100%);
}

.carousel-fade .carousel-item {
  opacity: 0;
  transition-property: opacity;
  transform: none;
}
.carousel-fade .carousel-item.active,
.carousel-fade .carousel-item-next.carousel-item-start,
.carousel-fade .carousel-item-prev.carousel-item-end {
  z-index: 1;
  opacity: 1;
}
.carousel-fade .active.carousel-item-start,
.carousel-fade .active.carousel-item-end {
  z-index: 0;
  opacity: 0;
  transition: opacity 0s 0.6s;
}
@media (prefers-reduced-motion: reduce) {
  .carousel-fade .active.carousel-item-start,
.carousel-fade .active.carousel-item-end {
    transition: none;
  }
}

.carousel-control-prev,
.carousel-control-next {
  position: absolute;
  top: 0;
  bottom: 0;
  z-index: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 15%;
  padding: 0;
  color: white;
  text-align: center;
  background: none;
  border: 0;
  opacity: 0.5;
  transition: opacity 0.15s ease;
}
@media (prefers-reduced-motion: reduce) {
  .carousel-control-prev,
.carousel-control-next {
    transition: none;
  }
}
.carousel-control-prev:hover, .carousel-control-prev:focus,
.carousel-control-next:hover,
.carousel-control-next:focus {
  color: white;
  text-decoration: none;
  outline: 0;
  opacity: 0.9;
}

.carousel-control-prev {
  left: 0;
}

.carousel-control-next {
  right: 0;
}

.carousel-control-prev-icon,
.carousel-control-next-icon {
  display: inline-block;
  width: 2rem;
  height: 2rem;
  background-repeat: no-repeat;
  background-position: 50%;
  background-size: 100% 100%;
}

/* rtl:options: {
  "autoRename": true,
  "stringMap":[ {
    "name"    : "prev-next",
    "search"  : "prev",
    "replace" : "next"
  } ]
} */
.carousel-control-prev-icon {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='white'%3e%3cpath d='M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z'/%3e%3c/svg%3e");
}

.carousel-control-next-icon {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='white'%3e%3cpath d='M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
}

.carousel-indicators {
  position: absolute;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 2;
  display: flex;
  justify-content: center;
  padding: 0;
  margin-right: 15%;
  margin-bottom: 1rem;
  margin-left: 15%;
}
.carousel-indicators [data-bs-target] {
  box-sizing: content-box;
  flex: 0 1 auto;
  width: 30px;
  height: 3px;
  padding: 0;
  margin-right: 3px;
  margin-left: 3px;
  text-indent: -999px;
  cursor: pointer;
  background-color: white;
  background-clip: padding-box;
  border: 0;
  border-top: 10px solid transparent;
  border-bottom: 10px solid transparent;
  opacity: 0.5;
  transition: opacity 0.6s ease;
}
@media (prefers-reduced-motion: reduce) {
  .carousel-indicators [data-bs-target] {
    transition: none;
  }
}
.carousel-indicators .active {
  opacity: 1;
}

.carousel-caption {
  position: absolute;
  right: 15%;
  bottom: 1.25rem;
  left: 15%;
  padding-top: 1.25rem;
  padding-bottom: 1.25rem;
  color: white;
  text-align: center;
}

.carousel-dark .carousel-control-prev-icon,
.carousel-dark .carousel-control-next-icon {
  filter: invert(1) grayscale(100);
}
.carousel-dark .carousel-indicators [data-bs-target] {
  background-color: #000;
}
.carousel-dark .carousel-caption {
  color: #000;
}

[data-bs-theme=dark] .carousel .carousel-control-prev-icon,
[data-bs-theme=dark] .carousel .carousel-control-next-icon, [data-bs-theme=dark].carousel .carousel-control-prev-icon,
[data-bs-theme=dark].carousel .carousel-control-next-icon {
  filter: invert(1) grayscale(100);
}
[data-bs-theme=dark] .carousel .carousel-indicators [data-bs-target], [data-bs-theme=dark].carousel .carousel-indicators [data-bs-target] {
  background-color: #000;
}
[data-bs-theme=dark] .carousel .carousel-caption, [data-bs-theme=dark].carousel .carousel-caption {
  color: #000;
}

.spinner-grow,
.spinner-border {
  display: inline-block;
  width: var(--bs-spinner-width);
  height: var(--bs-spinner-height);
  vertical-align: var(--bs-spinner-vertical-align);
  border-radius: 50%;
  animation: var(--bs-spinner-animation-speed) linear infinite var(--bs-spinner-animation-name);
}

@keyframes spinner-border {
  to {
    transform: rotate(360deg) /* rtl:ignore */;
  }
}
.spinner-border {
  --bs-spinner-width: 2rem;
  --bs-spinner-height: 2rem;
  --bs-spinner-vertical-align: -0.125em;
  --bs-spinner-border-width: 0.25em;
  --bs-spinner-animation-speed: 0.75s;
  --bs-spinner-animation-name: spinner-border;
  border: var(--bs-spinner-border-width) solid currentcolor;
  border-right-color: transparent;
}

.spinner-border-sm {
  --bs-spinner-width: 1rem;
  --bs-spinner-height: 1rem;
  --bs-spinner-border-width: 0.2em;
}

@keyframes spinner-grow {
  0% {
    transform: scale(0);
  }
  50% {
    opacity: 1;
    transform: none;
  }
}
.spinner-grow {
  --bs-spinner-width: 2rem;
  --bs-spinner-height: 2rem;
  --bs-spinner-vertical-align: -0.125em;
  --bs-spinner-animation-speed: 0.75s;
  --bs-spinner-animation-name: spinner-grow;
  background-color: currentcolor;
  opacity: 0;
}

.spinner-grow-sm {
  --bs-spinner-width: 1rem;
  --bs-spinner-height: 1rem;
}

@media (prefers-reduced-motion: reduce) {
  .spinner-border,
.spinner-grow {
    --bs-spinner-animation-speed: 1.5s;
  }
}
.offcanvas, .offcanvas-xxl, .offcanvas-xl, .offcanvas-lg, .offcanvas-md, .offcanvas-sm {
  --bs-offcanvas-zindex: 1045;
  --bs-offcanvas-width: 400px;
  --bs-offcanvas-height: 30vh;
  --bs-offcanvas-padding-x: 1.5rem;
  --bs-offcanvas-padding-y: 1.5rem;
  --bs-offcanvas-color: var(--bs-body-color);
  --bs-offcanvas-bg: var(--bs-body-bg);
  --bs-offcanvas-border-width: var(--bs-border-width);
  --bs-offcanvas-border-color: transparent;
  --bs-offcanvas-box-shadow: var(--bs-box-shadow-sm);
  --bs-offcanvas-transition: transform 0.3s ease-in-out;
  --bs-offcanvas-title-line-height: 1.5;
}

@media (max-width: 575.98px) {
  .offcanvas-sm {
    position: fixed;
    bottom: 0;
    z-index: var(--bs-offcanvas-zindex);
    display: flex;
    flex-direction: column;
    max-width: 100%;
    color: var(--bs-offcanvas-color);
    visibility: hidden;
    background-color: var(--bs-offcanvas-bg);
    background-clip: padding-box;
    outline: 0;
    box-shadow: var(--bs-offcanvas-box-shadow);
    transition: var(--bs-offcanvas-transition);
  }
}
@media (max-width: 575.98px) and (prefers-reduced-motion: reduce) {
  .offcanvas-sm {
    transition: none;
  }
}
@media (max-width: 575.98px) {
  .offcanvas-sm.offcanvas-start {
    top: 0;
    left: 0;
    width: var(--bs-offcanvas-width);
    border-right: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateX(-100%);
  }
}
@media (max-width: 575.98px) {
  .offcanvas-sm.offcanvas-end {
    top: 0;
    right: 0;
    width: var(--bs-offcanvas-width);
    border-left: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateX(100%);
  }
}
@media (max-width: 575.98px) {
  .offcanvas-sm.offcanvas-top {
    top: 0;
    right: 0;
    left: 0;
    height: var(--bs-offcanvas-height);
    max-height: 100%;
    border-bottom: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateY(-100%);
  }
}
@media (max-width: 575.98px) {
  .offcanvas-sm.offcanvas-bottom {
    right: 0;
    left: 0;
    height: var(--bs-offcanvas-height);
    max-height: 100%;
    border-top: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateY(100%);
  }
}
@media (max-width: 575.98px) {
  .offcanvas-sm.showing, .offcanvas-sm.show:not(.hiding) {
    transform: none;
  }
}
@media (max-width: 575.98px) {
  .offcanvas-sm.showing, .offcanvas-sm.hiding, .offcanvas-sm.show {
    visibility: visible;
  }
}
@media (min-width: 576px) {
  .offcanvas-sm {
    --bs-offcanvas-height: auto;
    --bs-offcanvas-border-width: 0;
    background-color: transparent !important;
  }
  .offcanvas-sm .offcanvas-header {
    display: none;
  }
  .offcanvas-sm .offcanvas-body {
    display: flex;
    flex-grow: 0;
    padding: 0;
    overflow-y: visible;
    background-color: transparent !important;
  }
}

@media (max-width: 767.98px) {
  .offcanvas-md {
    position: fixed;
    bottom: 0;
    z-index: var(--bs-offcanvas-zindex);
    display: flex;
    flex-direction: column;
    max-width: 100%;
    color: var(--bs-offcanvas-color);
    visibility: hidden;
    background-color: var(--bs-offcanvas-bg);
    background-clip: padding-box;
    outline: 0;
    box-shadow: var(--bs-offcanvas-box-shadow);
    transition: var(--bs-offcanvas-transition);
  }
}
@media (max-width: 767.98px) and (prefers-reduced-motion: reduce) {
  .offcanvas-md {
    transition: none;
  }
}
@media (max-width: 767.98px) {
  .offcanvas-md.offcanvas-start {
    top: 0;
    left: 0;
    width: var(--bs-offcanvas-width);
    border-right: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateX(-100%);
  }
}
@media (max-width: 767.98px) {
  .offcanvas-md.offcanvas-end {
    top: 0;
    right: 0;
    width: var(--bs-offcanvas-width);
    border-left: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateX(100%);
  }
}
@media (max-width: 767.98px) {
  .offcanvas-md.offcanvas-top {
    top: 0;
    right: 0;
    left: 0;
    height: var(--bs-offcanvas-height);
    max-height: 100%;
    border-bottom: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateY(-100%);
  }
}
@media (max-width: 767.98px) {
  .offcanvas-md.offcanvas-bottom {
    right: 0;
    left: 0;
    height: var(--bs-offcanvas-height);
    max-height: 100%;
    border-top: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateY(100%);
  }
}
@media (max-width: 767.98px) {
  .offcanvas-md.showing, .offcanvas-md.show:not(.hiding) {
    transform: none;
  }
}
@media (max-width: 767.98px) {
  .offcanvas-md.showing, .offcanvas-md.hiding, .offcanvas-md.show {
    visibility: visible;
  }
}
@media (min-width: 768px) {
  .offcanvas-md {
    --bs-offcanvas-height: auto;
    --bs-offcanvas-border-width: 0;
    background-color: transparent !important;
  }
  .offcanvas-md .offcanvas-header {
    display: none;
  }
  .offcanvas-md .offcanvas-body {
    display: flex;
    flex-grow: 0;
    padding: 0;
    overflow-y: visible;
    background-color: transparent !important;
  }
}

@media (max-width: 991.98px) {
  .offcanvas-lg {
    position: fixed;
    bottom: 0;
    z-index: var(--bs-offcanvas-zindex);
    display: flex;
    flex-direction: column;
    max-width: 100%;
    color: var(--bs-offcanvas-color);
    visibility: hidden;
    background-color: var(--bs-offcanvas-bg);
    background-clip: padding-box;
    outline: 0;
    box-shadow: var(--bs-offcanvas-box-shadow);
    transition: var(--bs-offcanvas-transition);
  }
}
@media (max-width: 991.98px) and (prefers-reduced-motion: reduce) {
  .offcanvas-lg {
    transition: none;
  }
}
@media (max-width: 991.98px) {
  .offcanvas-lg.offcanvas-start {
    top: 0;
    left: 0;
    width: var(--bs-offcanvas-width);
    border-right: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateX(-100%);
  }
}
@media (max-width: 991.98px) {
  .offcanvas-lg.offcanvas-end {
    top: 0;
    right: 0;
    width: var(--bs-offcanvas-width);
    border-left: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateX(100%);
  }
}
@media (max-width: 991.98px) {
  .offcanvas-lg.offcanvas-top {
    top: 0;
    right: 0;
    left: 0;
    height: var(--bs-offcanvas-height);
    max-height: 100%;
    border-bottom: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateY(-100%);
  }
}
@media (max-width: 991.98px) {
  .offcanvas-lg.offcanvas-bottom {
    right: 0;
    left: 0;
    height: var(--bs-offcanvas-height);
    max-height: 100%;
    border-top: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateY(100%);
  }
}
@media (max-width: 991.98px) {
  .offcanvas-lg.showing, .offcanvas-lg.show:not(.hiding) {
    transform: none;
  }
}
@media (max-width: 991.98px) {
  .offcanvas-lg.showing, .offcanvas-lg.hiding, .offcanvas-lg.show {
    visibility: visible;
  }
}
@media (min-width: 992px) {
  .offcanvas-lg {
    --bs-offcanvas-height: auto;
    --bs-offcanvas-border-width: 0;
    background-color: transparent !important;
  }
  .offcanvas-lg .offcanvas-header {
    display: none;
  }
  .offcanvas-lg .offcanvas-body {
    display: flex;
    flex-grow: 0;
    padding: 0;
    overflow-y: visible;
    background-color: transparent !important;
  }
}

@media (max-width: 1199.98px) {
  .offcanvas-xl {
    position: fixed;
    bottom: 0;
    z-index: var(--bs-offcanvas-zindex);
    display: flex;
    flex-direction: column;
    max-width: 100%;
    color: var(--bs-offcanvas-color);
    visibility: hidden;
    background-color: var(--bs-offcanvas-bg);
    background-clip: padding-box;
    outline: 0;
    box-shadow: var(--bs-offcanvas-box-shadow);
    transition: var(--bs-offcanvas-transition);
  }
}
@media (max-width: 1199.98px) and (prefers-reduced-motion: reduce) {
  .offcanvas-xl {
    transition: none;
  }
}
@media (max-width: 1199.98px) {
  .offcanvas-xl.offcanvas-start {
    top: 0;
    left: 0;
    width: var(--bs-offcanvas-width);
    border-right: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateX(-100%);
  }
}
@media (max-width: 1199.98px) {
  .offcanvas-xl.offcanvas-end {
    top: 0;
    right: 0;
    width: var(--bs-offcanvas-width);
    border-left: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateX(100%);
  }
}
@media (max-width: 1199.98px) {
  .offcanvas-xl.offcanvas-top {
    top: 0;
    right: 0;
    left: 0;
    height: var(--bs-offcanvas-height);
    max-height: 100%;
    border-bottom: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateY(-100%);
  }
}
@media (max-width: 1199.98px) {
  .offcanvas-xl.offcanvas-bottom {
    right: 0;
    left: 0;
    height: var(--bs-offcanvas-height);
    max-height: 100%;
    border-top: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateY(100%);
  }
}
@media (max-width: 1199.98px) {
  .offcanvas-xl.showing, .offcanvas-xl.show:not(.hiding) {
    transform: none;
  }
}
@media (max-width: 1199.98px) {
  .offcanvas-xl.showing, .offcanvas-xl.hiding, .offcanvas-xl.show {
    visibility: visible;
  }
}
@media (min-width: 1200px) {
  .offcanvas-xl {
    --bs-offcanvas-height: auto;
    --bs-offcanvas-border-width: 0;
    background-color: transparent !important;
  }
  .offcanvas-xl .offcanvas-header {
    display: none;
  }
  .offcanvas-xl .offcanvas-body {
    display: flex;
    flex-grow: 0;
    padding: 0;
    overflow-y: visible;
    background-color: transparent !important;
  }
}

@media (max-width: 1399.98px) {
  .offcanvas-xxl {
    position: fixed;
    bottom: 0;
    z-index: var(--bs-offcanvas-zindex);
    display: flex;
    flex-direction: column;
    max-width: 100%;
    color: var(--bs-offcanvas-color);
    visibility: hidden;
    background-color: var(--bs-offcanvas-bg);
    background-clip: padding-box;
    outline: 0;
    box-shadow: var(--bs-offcanvas-box-shadow);
    transition: var(--bs-offcanvas-transition);
  }
}
@media (max-width: 1399.98px) and (prefers-reduced-motion: reduce) {
  .offcanvas-xxl {
    transition: none;
  }
}
@media (max-width: 1399.98px) {
  .offcanvas-xxl.offcanvas-start {
    top: 0;
    left: 0;
    width: var(--bs-offcanvas-width);
    border-right: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateX(-100%);
  }
}
@media (max-width: 1399.98px) {
  .offcanvas-xxl.offcanvas-end {
    top: 0;
    right: 0;
    width: var(--bs-offcanvas-width);
    border-left: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateX(100%);
  }
}
@media (max-width: 1399.98px) {
  .offcanvas-xxl.offcanvas-top {
    top: 0;
    right: 0;
    left: 0;
    height: var(--bs-offcanvas-height);
    max-height: 100%;
    border-bottom: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateY(-100%);
  }
}
@media (max-width: 1399.98px) {
  .offcanvas-xxl.offcanvas-bottom {
    right: 0;
    left: 0;
    height: var(--bs-offcanvas-height);
    max-height: 100%;
    border-top: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
    transform: translateY(100%);
  }
}
@media (max-width: 1399.98px) {
  .offcanvas-xxl.showing, .offcanvas-xxl.show:not(.hiding) {
    transform: none;
  }
}
@media (max-width: 1399.98px) {
  .offcanvas-xxl.showing, .offcanvas-xxl.hiding, .offcanvas-xxl.show {
    visibility: visible;
  }
}
@media (min-width: 1400px) {
  .offcanvas-xxl {
    --bs-offcanvas-height: auto;
    --bs-offcanvas-border-width: 0;
    background-color: transparent !important;
  }
  .offcanvas-xxl .offcanvas-header {
    display: none;
  }
  .offcanvas-xxl .offcanvas-body {
    display: flex;
    flex-grow: 0;
    padding: 0;
    overflow-y: visible;
    background-color: transparent !important;
  }
}

.offcanvas {
  position: fixed;
  bottom: 0;
  z-index: var(--bs-offcanvas-zindex);
  display: flex;
  flex-direction: column;
  max-width: 100%;
  color: var(--bs-offcanvas-color);
  visibility: hidden;
  background-color: var(--bs-offcanvas-bg);
  background-clip: padding-box;
  outline: 0;
  box-shadow: var(--bs-offcanvas-box-shadow);
  transition: var(--bs-offcanvas-transition);
}
@media (prefers-reduced-motion: reduce) {
  .offcanvas {
    transition: none;
  }
}
.offcanvas.offcanvas-start {
  top: 0;
  left: 0;
  width: var(--bs-offcanvas-width);
  border-right: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
  transform: translateX(-100%);
}
.offcanvas.offcanvas-end {
  top: 0;
  right: 0;
  width: var(--bs-offcanvas-width);
  border-left: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
  transform: translateX(100%);
}
.offcanvas.offcanvas-top {
  top: 0;
  right: 0;
  left: 0;
  height: var(--bs-offcanvas-height);
  max-height: 100%;
  border-bottom: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
  transform: translateY(-100%);
}
.offcanvas.offcanvas-bottom {
  right: 0;
  left: 0;
  height: var(--bs-offcanvas-height);
  max-height: 100%;
  border-top: var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);
  transform: translateY(100%);
}
.offcanvas.showing, .offcanvas.show:not(.hiding) {
  transform: none;
}
.offcanvas.showing, .offcanvas.hiding, .offcanvas.show {
  visibility: visible;
}

.offcanvas-backdrop {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 1040;
  width: 100vw;
  height: 100vh;
  background-color: rgba(45, 55, 75, 0.25);
}
.offcanvas-backdrop.fade {
  opacity: 0;
}
.offcanvas-backdrop.show {
  opacity: 1;
}

.offcanvas-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--bs-offcanvas-padding-y) var(--bs-offcanvas-padding-x);
}
.offcanvas-header .btn-close {
  padding: calc(var(--bs-offcanvas-padding-y) * 0.5) calc(var(--bs-offcanvas-padding-x) * 0.5);
  margin-top: calc(-0.5 * var(--bs-offcanvas-padding-y));
  margin-right: calc(-0.5 * var(--bs-offcanvas-padding-x));
  margin-bottom: calc(-0.5 * var(--bs-offcanvas-padding-y));
}

.offcanvas-title {
  margin-bottom: 0;
  line-height: var(--bs-offcanvas-title-line-height);
}

.offcanvas-body {
  flex-grow: 1;
  padding: var(--bs-offcanvas-padding-y) var(--bs-offcanvas-padding-x);
  overflow-y: auto;
}

.placeholder {
  display: inline-block;
  min-height: 1em;
  vertical-align: middle;
  cursor: wait;
  background-color: currentcolor;
  opacity: 0.5;
}
.placeholder.btn::before {
  display: inline-block;
  content: "";
}

.placeholder-xs {
  min-height: 0.6em;
}

.placeholder-sm {
  min-height: 0.8em;
}

.placeholder-lg {
  min-height: 1.2em;
}

.placeholder-glow .placeholder {
  animation: placeholder-glow 2s ease-in-out infinite;
}

@keyframes placeholder-glow {
  50% {
    opacity: 0.2;
  }
}
.placeholder-wave {
  mask-image: linear-gradient(130deg, #000 55%, rgba(0, 0, 0, 0.8) 75%, #000 95%);
  mask-size: 200% 100%;
  animation: placeholder-wave 2s linear infinite;
}

@keyframes placeholder-wave {
  100% {
    mask-position: -200% 0%;
  }
}
.clearfix::after {
  display: block;
  clear: both;
  content: "";
}

.text-bg-primary {
  color: white !important;
  background-color: RGBA(var(--bs-primary-rgb), var(--bs-bg-opacity, 1)) !important;
}

.text-bg-secondary {
  color: white !important;
  background-color: RGBA(var(--bs-secondary-rgb), var(--bs-bg-opacity, 1)) !important;
}

.text-bg-success {
  color: white !important;
  background-color: RGBA(var(--bs-success-rgb), var(--bs-bg-opacity, 1)) !important;
}

.text-bg-info {
  color: white !important;
  background-color: RGBA(var(--bs-info-rgb), var(--bs-bg-opacity, 1)) !important;
}

.text-bg-warning {
  color: #000 !important;
  background-color: RGBA(var(--bs-warning-rgb), var(--bs-bg-opacity, 1)) !important;
}

.text-bg-danger {
  color: white !important;
  background-color: RGBA(var(--bs-danger-rgb), var(--bs-bg-opacity, 1)) !important;
}

.text-bg-light {
  color: #000 !important;
  background-color: RGBA(var(--bs-light-rgb), var(--bs-bg-opacity, 1)) !important;
}

.text-bg-dark {
  color: white !important;
  background-color: RGBA(var(--bs-dark-rgb), var(--bs-bg-opacity, 1)) !important;
}

.link-primary {
  color: RGBA(var(--bs-primary-rgb), var(--bs-link-opacity, 1)) !important;
  text-decoration-color: RGBA(var(--bs-primary-rgb), var(--bs-link-underline-opacity, 1)) !important;
}
.link-primary:hover, .link-primary:focus {
  color: RGBA(8, 153, 66, var(--bs-link-opacity, 1)) !important;
  text-decoration-color: RGBA(8, 153, 66, var(--bs-link-underline-opacity, 1)) !important;
}

.link-secondary {
  color: RGBA(var(--bs-secondary-rgb), var(--bs-link-opacity, 1)) !important;
  text-decoration-color: RGBA(var(--bs-secondary-rgb), var(--bs-link-underline-opacity, 1)) !important;
}
.link-secondary:hover, .link-secondary:focus {
  color: RGBA(65, 71, 86, var(--bs-link-opacity, 1)) !important;
  text-decoration-color: RGBA(65, 71, 86, var(--bs-link-underline-opacity, 1)) !important;
}

.link-success {
  color: RGBA(var(--bs-success-rgb), var(--bs-link-opacity, 1)) !important;
  text-decoration-color: RGBA(var(--bs-success-rgb), var(--bs-link-underline-opacity, 1)) !important;
}
.link-success:hover, .link-success:focus {
  color: RGBA(6, 99, 94, var(--bs-link-opacity, 1)) !important;
  text-decoration-color: RGBA(6, 99, 94, var(--bs-link-underline-opacity, 1)) !important;
}

.link-info {
  color: RGBA(var(--bs-info-rgb), var(--bs-link-opacity, 1)) !important;
  text-decoration-color: RGBA(var(--bs-info-rgb), var(--bs-link-underline-opacity, 1)) !important;
}
.link-info:hover, .link-info:focus {
  color: RGBA(41, 59, 154, var(--bs-link-opacity, 1)) !important;
  text-decoration-color: RGBA(41, 59, 154, var(--bs-link-underline-opacity, 1)) !important;
}

.link-warning {
  color: RGBA(var(--bs-warning-rgb), var(--bs-link-opacity, 1)) !important;
  text-decoration-color: RGBA(var(--bs-warning-rgb), var(--bs-link-underline-opacity, 1)) !important;
}
.link-warning:hover, .link-warning:focus {
  color: RGBA(245, 170, 134, var(--bs-link-opacity, 1)) !important;
  text-decoration-color: RGBA(245, 170, 134, var(--bs-link-underline-opacity, 1)) !important;
}

.link-danger {
  color: RGBA(var(--bs-danger-rgb), var(--bs-link-opacity, 1)) !important;
  text-decoration-color: RGBA(var(--bs-danger-rgb), var(--bs-link-underline-opacity, 1)) !important;
}
.link-danger:hover, .link-danger:focus {
  color: RGBA(84, 28, 51, var(--bs-link-opacity, 1)) !important;
  text-decoration-color: RGBA(84, 28, 51, var(--bs-link-underline-opacity, 1)) !important;
}

.link-light {
  color: RGBA(var(--bs-light-rgb), var(--bs-link-opacity, 1)) !important;
  text-decoration-color: RGBA(var(--bs-light-rgb), var(--bs-link-underline-opacity, 1)) !important;
}
.link-light:hover, .link-light:focus {
  color: RGBA(249, 250, 251, var(--bs-link-opacity, 1)) !important;
  text-decoration-color: RGBA(249, 250, 251, var(--bs-link-underline-opacity, 1)) !important;
}

.link-dark {
  color: RGBA(var(--bs-dark-rgb), var(--bs-link-opacity, 1)) !important;
  text-decoration-color: RGBA(var(--bs-dark-rgb), var(--bs-link-underline-opacity, 1)) !important;
}
.link-dark:hover, .link-dark:focus {
  color: RGBA(36, 44, 60, var(--bs-link-opacity, 1)) !important;
  text-decoration-color: RGBA(36, 44, 60, var(--bs-link-underline-opacity, 1)) !important;
}

.link-body-emphasis {
  color: RGBA(var(--bs-emphasis-color-rgb), var(--bs-link-opacity, 1)) !important;
  text-decoration-color: RGBA(var(--bs-emphasis-color-rgb), var(--bs-link-underline-opacity, 1)) !important;
}
.link-body-emphasis:hover, .link-body-emphasis:focus {
  color: RGBA(var(--bs-emphasis-color-rgb), var(--bs-link-opacity, 0.75)) !important;
  text-decoration-color: RGBA(var(--bs-emphasis-color-rgb), var(--bs-link-underline-opacity, 0.75)) !important;
}

.focus-ring:focus {
  outline: 0;
  box-shadow: var(--bs-focus-ring-x, 0) var(--bs-focus-ring-y, 0) var(--bs-focus-ring-blur, 0) var(--bs-focus-ring-width) var(--bs-focus-ring-color);
}

.icon-link {
  display: inline-flex;
  gap: 0.375rem;
  align-items: center;
  text-decoration-color: rgba(var(--bs-link-color-rgb), var(--bs-link-opacity, 0.5));
  text-underline-offset: 0.25em;
  backface-visibility: hidden;
}
.icon-link > .bi {
  flex-shrink: 0;
  width: 1em;
  height: 1em;
  fill: currentcolor;
  transition: 0.2s ease-in-out transform;
}
@media (prefers-reduced-motion: reduce) {
  .icon-link > .bi {
    transition: none;
  }
}

.icon-link-hover:hover > .bi, .icon-link-hover:focus-visible > .bi {
  transform: var(--bs-icon-link-transform, translate3d(0.25em, 0, 0));
}

.ratio {
  position: relative;
  width: 100%;
}
.ratio::before {
  display: block;
  padding-top: var(--bs-aspect-ratio);
  content: "";
}
.ratio > * {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
}

.ratio-1x1 {
  --bs-aspect-ratio: 100%;
}

.ratio-4x3 {
  --bs-aspect-ratio: 75%;
}

.ratio-16x9 {
  --bs-aspect-ratio: 56.25%;
}

.ratio-21x9 {
  --bs-aspect-ratio: 42.8571428571%;
}

.fixed-top {
  position: fixed;
  top: 0;
  right: 0;
  left: 0;
  z-index: 1030;
}

.fixed-bottom {
  position: fixed;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 1030;
}

.sticky-top {
  position: sticky;
  top: 0;
  z-index: 1020;
}

.sticky-bottom {
  position: sticky;
  bottom: 0;
  z-index: 1020;
}

@media (min-width: 576px) {
  .sticky-sm-top {
    position: sticky;
    top: 0;
    z-index: 1020;
  }
  .sticky-sm-bottom {
    position: sticky;
    bottom: 0;
    z-index: 1020;
  }
}
@media (min-width: 768px) {
  .sticky-md-top {
    position: sticky;
    top: 0;
    z-index: 1020;
  }
  .sticky-md-bottom {
    position: sticky;
    bottom: 0;
    z-index: 1020;
  }
}
@media (min-width: 992px) {
  .sticky-lg-top {
    position: sticky;
    top: 0;
    z-index: 1020;
  }
  .sticky-lg-bottom {
    position: sticky;
    bottom: 0;
    z-index: 1020;
  }
}
@media (min-width: 1200px) {
  .sticky-xl-top {
    position: sticky;
    top: 0;
    z-index: 1020;
  }
  .sticky-xl-bottom {
    position: sticky;
    bottom: 0;
    z-index: 1020;
  }
}
@media (min-width: 1400px) {
  .sticky-xxl-top {
    position: sticky;
    top: 0;
    z-index: 1020;
  }
  .sticky-xxl-bottom {
    position: sticky;
    bottom: 0;
    z-index: 1020;
  }
}
.hstack {
  display: flex;
  flex-direction: row;
  align-items: center;
  align-self: stretch;
}

.vstack {
  display: flex;
  flex: 1 1 auto;
  flex-direction: column;
  align-self: stretch;
}

.visually-hidden,
.visually-hidden-focusable:not(:focus):not(:focus-within) {
  width: 1px !important;
  height: 1px !important;
  padding: 0 !important;
  margin: -1px !important;
  overflow: hidden !important;
  clip: rect(0, 0, 0, 0) !important;
  white-space: nowrap !important;
  border: 0 !important;
}
.visually-hidden:not(caption),
.visually-hidden-focusable:not(:focus):not(:focus-within):not(caption) {
  position: absolute !important;
}

.stretched-link::after {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 1;
  content: "";
}

.text-truncate {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.vr {
  display: inline-block;
  align-self: stretch;
  width: var(--bs-border-width);
  min-height: 1em;
  background-color: currentcolor;
  opacity: 1;
}

.align-baseline {
  vertical-align: baseline !important;
}

.align-top {
  vertical-align: top !important;
}

.align-middle {
  vertical-align: middle !important;
}

.align-bottom {
  vertical-align: bottom !important;
}

.align-text-bottom {
  vertical-align: text-bottom !important;
}

.align-text-top {
  vertical-align: text-top !important;
}

.float-start {
  float: left !important;
}

.float-end {
  float: right !important;
}

.float-none {
  float: none !important;
}

.object-fit-contain {
  object-fit: contain !important;
}

.object-fit-cover {
  object-fit: cover !important;
}

.object-fit-fill {
  object-fit: fill !important;
}

.object-fit-scale {
  object-fit: scale-down !important;
}

.object-fit-none {
  object-fit: none !important;
}

.opacity-0 {
  opacity: 0 !important;
}

.opacity-25 {
  opacity: 0.25 !important;
}

.opacity-50 {
  opacity: 0.5 !important;
}

.opacity-75 {
  opacity: 0.75 !important;
}

.opacity-100 {
  opacity: 1 !important;
}

.overflow-auto {
  overflow: auto !important;
}

.overflow-hidden {
  overflow: hidden !important;
}

.overflow-visible {
  overflow: visible !important;
}

.overflow-scroll {
  overflow: scroll !important;
}

.overflow-x-auto {
  overflow-x: auto !important;
}

.overflow-x-hidden {
  overflow-x: hidden !important;
}

.overflow-x-visible {
  overflow-x: visible !important;
}

.overflow-x-scroll {
  overflow-x: scroll !important;
}

.overflow-y-auto {
  overflow-y: auto !important;
}

.overflow-y-hidden {
  overflow-y: hidden !important;
}

.overflow-y-visible {
  overflow-y: visible !important;
}

.overflow-y-scroll {
  overflow-y: scroll !important;
}

.d-inline {
  display: inline !important;
}

.d-inline-block {
  display: inline-block !important;
}

.d-block {
  display: block !important;
}

.d-grid {
  display: grid !important;
}

.d-inline-grid {
  display: inline-grid !important;
}

.d-table {
  display: table !important;
}

.d-table-row {
  display: table-row !important;
}

.d-table-cell {
  display: table-cell !important;
}

.d-flex {
  display: flex !important;
}

.d-inline-flex {
  display: inline-flex !important;
}

.d-none {
  display: none !important;
}

.shadow {
  box-shadow: var(--bs-box-shadow) !important;
}

.shadow-sm {
  box-shadow: var(--bs-box-shadow-sm) !important;
}

.shadow-lg {
  box-shadow: var(--bs-box-shadow-lg) !important;
}

.shadow-none {
  box-shadow: none !important;
}

.shadow-xl {
  box-shadow: 0 2.75rem 5.5rem -3.5rem rgba(45, 55, 75, 0.2), 0 2rem 4rem -2rem rgba(45, 55, 75, 0.3) !important;
}

.focus-ring-primary {
  --bs-focus-ring-color: rgba(var(--bs-primary-rgb), var(--bs-focus-ring-opacity));
}

.focus-ring-secondary {
  --bs-focus-ring-color: rgba(var(--bs-secondary-rgb), var(--bs-focus-ring-opacity));
}

.focus-ring-success {
  --bs-focus-ring-color: rgba(var(--bs-success-rgb), var(--bs-focus-ring-opacity));
}

.focus-ring-info {
  --bs-focus-ring-color: rgba(var(--bs-info-rgb), var(--bs-focus-ring-opacity));
}

.focus-ring-warning {
  --bs-focus-ring-color: rgba(var(--bs-warning-rgb), var(--bs-focus-ring-opacity));
}

.focus-ring-danger {
  --bs-focus-ring-color: rgba(var(--bs-danger-rgb), var(--bs-focus-ring-opacity));
}

.focus-ring-light {
  --bs-focus-ring-color: rgba(var(--bs-light-rgb), var(--bs-focus-ring-opacity));
}

.focus-ring-dark {
  --bs-focus-ring-color: rgba(var(--bs-dark-rgb), var(--bs-focus-ring-opacity));
}

.position-static {
  position: static !important;
}

.position-relative {
  position: relative !important;
}

.position-absolute {
  position: absolute !important;
}

.position-fixed {
  position: fixed !important;
}

.position-sticky {
  position: sticky !important;
}

.top-0 {
  top: 0 !important;
}

.top-50 {
  top: 50% !important;
}

.top-100 {
  top: 100% !important;
}

.top-auto {
  top: auto !important;
}

.bottom-0 {
  bottom: 0 !important;
}

.bottom-50 {
  bottom: 50% !important;
}

.bottom-100 {
  bottom: 100% !important;
}

.bottom-auto {
  bottom: auto !important;
}

.start-0 {
  left: 0 !important;
}

.start-50 {
  left: 50% !important;
}

.start-100 {
  left: 100% !important;
}

.start-auto {
  left: auto !important;
}

.end-0 {
  right: 0 !important;
}

.end-50 {
  right: 50% !important;
}

.end-100 {
  right: 100% !important;
}

.end-auto {
  right: auto !important;
}

.translate-middle {
  transform: translate(-50%, -50%) !important;
}

.translate-middle-x {
  transform: translateX(-50%) !important;
}

.translate-middle-y {
  transform: translateY(-50%) !important;
}

.border {
  border: var(--bs-border-width) var(--bs-border-style) var(--bs-border-color) !important;
}

.border-0 {
  border: 0 !important;
}

.border-top {
  border-top: var(--bs-border-width) var(--bs-border-style) var(--bs-border-color) !important;
}

.border-top-0 {
  border-top: 0 !important;
}

.border-end {
  border-right: var(--bs-border-width) var(--bs-border-style) var(--bs-border-color) !important;
}

.border-end-0 {
  border-right: 0 !important;
}

.border-bottom {
  border-bottom: var(--bs-border-width) var(--bs-border-style) var(--bs-border-color) !important;
}

.border-bottom-0 {
  border-bottom: 0 !important;
}

.border-start {
  border-left: var(--bs-border-width) var(--bs-border-style) var(--bs-border-color) !important;
}

.border-start-0 {
  border-left: 0 !important;
}

.border-primary {
  --bs-border-opacity: 1;
  border-color: rgba(var(--bs-primary-rgb), var(--bs-border-opacity)) !important;
}

.border-secondary {
  --bs-border-opacity: 1;
  border-color: rgba(var(--bs-secondary-rgb), var(--bs-border-opacity)) !important;
}

.border-success {
  --bs-border-opacity: 1;
  border-color: rgba(var(--bs-success-rgb), var(--bs-border-opacity)) !important;
}

.border-info {
  --bs-border-opacity: 1;
  border-color: rgba(var(--bs-info-rgb), var(--bs-border-opacity)) !important;
}

.border-warning {
  --bs-border-opacity: 1;
  border-color: rgba(var(--bs-warning-rgb), var(--bs-border-opacity)) !important;
}

.border-danger {
  --bs-border-opacity: 1;
  border-color: rgba(var(--bs-danger-rgb), var(--bs-border-opacity)) !important;
}

.border-light {
  --bs-border-opacity: 1;
  border-color: rgba(var(--bs-light-rgb), var(--bs-border-opacity)) !important;
}

.border-dark {
  --bs-border-opacity: 1;
  border-color: rgba(var(--bs-dark-rgb), var(--bs-border-opacity)) !important;
}

.border-black {
  --bs-border-opacity: 1;
  border-color: rgba(var(--bs-black-rgb), var(--bs-border-opacity)) !important;
}

.border-white {
  --bs-border-opacity: 1;
  border-color: rgba(var(--bs-white-rgb), var(--bs-border-opacity)) !important;
}

.border-white-10 {
  --bs-border-opacity: 1;
  border-color: rgba(255, 255, 255, 0.1) !important;
}

.border-primary-subtle {
  border-color: var(--bs-primary-border-subtle) !important;
}

.border-secondary-subtle {
  border-color: var(--bs-secondary-border-subtle) !important;
}

.border-success-subtle {
  border-color: var(--bs-success-border-subtle) !important;
}

.border-info-subtle {
  border-color: var(--bs-info-border-subtle) !important;
}

.border-warning-subtle {
  border-color: var(--bs-warning-border-subtle) !important;
}

.border-danger-subtle {
  border-color: var(--bs-danger-border-subtle) !important;
}

.border-light-subtle {
  border-color: var(--bs-light-border-subtle) !important;
}

.border-dark-subtle {
  border-color: var(--bs-dark-border-subtle) !important;
}

.border-1 {
  border-width: 1px !important;
}

.border-2 {
  border-width: 2px !important;
}

.border-3 {
  border-width: 3px !important;
}

.border-4 {
  border-width: 4px !important;
}

.border-5 {
  border-width: 5px !important;
}

.border-opacity-10 {
  --bs-border-opacity: 0.1;
}

.border-opacity-25 {
  --bs-border-opacity: 0.25;
}

.border-opacity-50 {
  --bs-border-opacity: 0.5;
}

.border-opacity-75 {
  --bs-border-opacity: 0.75;
}

.border-opacity-100 {
  --bs-border-opacity: 1;
}

.w-25 {
  width: 25% !important;
}

.w-50 {
  width: 50% !important;
}

.w-75 {
  width: 75% !important;
}

.w-100 {
  width: 100% !important;
}

.w-auto {
  width: auto !important;
}

.w-65 {
  width: 65% !important;
}

.w-85 {
  width: 85% !important;
}

.mw-100 {
  max-width: 100% !important;
}

.vw-100 {
  width: 100vw !important;
}

.min-vw-100 {
  min-width: 100vw !important;
}

.h-25 {
  height: 25% !important;
}

.h-50 {
  height: 50% !important;
}

.h-75 {
  height: 75% !important;
}

.h-100 {
  height: 100% !important;
}

.h-auto {
  height: auto !important;
}

.h-65 {
  height: 65% !important;
}

.mh-100 {
  max-height: 100% !important;
}

.vh-100 {
  height: 100vh !important;
}

.min-vh-100 {
  min-height: 100vh !important;
}

.min-vh-35 {
  min-height: 35vh !important;
}

.min-vh-75 {
  min-height: 75vh !important;
}

.flex-fill {
  flex: 1 1 auto !important;
}

.flex-row {
  flex-direction: row !important;
}

.flex-column {
  flex-direction: column !important;
}

.flex-row-reverse {
  flex-direction: row-reverse !important;
}

.flex-column-reverse {
  flex-direction: column-reverse !important;
}

.flex-grow-0 {
  flex-grow: 0 !important;
}

.flex-grow-1 {
  flex-grow: 1 !important;
}

.flex-shrink-0 {
  flex-shrink: 0 !important;
}

.flex-shrink-1 {
  flex-shrink: 1 !important;
}

.flex-wrap {
  flex-wrap: wrap !important;
}

.flex-nowrap {
  flex-wrap: nowrap !important;
}

.flex-wrap-reverse {
  flex-wrap: wrap-reverse !important;
}

.justify-content-start {
  justify-content: flex-start !important;
}

.justify-content-end {
  justify-content: flex-end !important;
}

.justify-content-center {
  justify-content: center !important;
}

.justify-content-between {
  justify-content: space-between !important;
}

.justify-content-around {
  justify-content: space-around !important;
}

.justify-content-evenly {
  justify-content: space-evenly !important;
}

.align-items-start {
  align-items: flex-start !important;
}

.align-items-end {
  align-items: flex-end !important;
}

.align-items-center {
  align-items: center !important;
}

.align-items-baseline {
  align-items: baseline !important;
}

.align-items-stretch {
  align-items: stretch !important;
}

.align-content-start {
  align-content: flex-start !important;
}

.align-content-end {
  align-content: flex-end !important;
}

.align-content-center {
  align-content: center !important;
}

.align-content-between {
  align-content: space-between !important;
}

.align-content-around {
  align-content: space-around !important;
}

.align-content-stretch {
  align-content: stretch !important;
}

.align-self-auto {
  align-self: auto !important;
}

.align-self-start {
  align-self: flex-start !important;
}

.align-self-end {
  align-self: flex-end !important;
}

.align-self-center {
  align-self: center !important;
}

.align-self-baseline {
  align-self: baseline !important;
}

.align-self-stretch {
  align-self: stretch !important;
}

.order-first {
  order: -1 !important;
}

.order-0 {
  order: 0 !important;
}

.order-1 {
  order: 1 !important;
}

.order-2 {
  order: 2 !important;
}

.order-3 {
  order: 3 !important;
}

.order-4 {
  order: 4 !important;
}

.order-5 {
  order: 5 !important;
}

.order-last {
  order: 6 !important;
}

.m-0 {
  margin: 0 !important;
}

.m-1 {
  margin: 0.25rem !important;
}

.m-2 {
  margin: 0.5rem !important;
}

.m-3 {
  margin: 1rem !important;
}

.m-4 {
  margin: 1.5rem !important;
}

.m-5 {
  margin: 2rem !important;
}

.m-6 {
  margin: 2.5rem !important;
}

.m-7 {
  margin: 3rem !important;
}

.m-8 {
  margin: 3.5rem !important;
}

.m-9 {
  margin: 4rem !important;
}

.m-10 {
  margin: 4.5rem !important;
}

.m-auto {
  margin: auto !important;
}

.mx-0 {
  margin-right: 0 !important;
  margin-left: 0 !important;
}

.mx-1 {
  margin-right: 0.25rem !important;
  margin-left: 0.25rem !important;
}

.mx-2 {
  margin-right: 0.5rem !important;
  margin-left: 0.5rem !important;
}

.mx-3 {
  margin-right: 1rem !important;
  margin-left: 1rem !important;
}

.mx-4 {
  margin-right: 1.5rem !important;
  margin-left: 1.5rem !important;
}

.mx-5 {
  margin-right: 2rem !important;
  margin-left: 2rem !important;
}

.mx-6 {
  margin-right: 2.5rem !important;
  margin-left: 2.5rem !important;
}

.mx-7 {
  margin-right: 3rem !important;
  margin-left: 3rem !important;
}

.mx-8 {
  margin-right: 3.5rem !important;
  margin-left: 3.5rem !important;
}

.mx-9 {
  margin-right: 4rem !important;
  margin-left: 4rem !important;
}

.mx-10 {
  margin-right: 4.5rem !important;
  margin-left: 4.5rem !important;
}

.mx-auto {
  margin-right: auto !important;
  margin-left: auto !important;
}

.my-0 {
  margin-top: 0 !important;
  margin-bottom: 0 !important;
}

.my-1 {
  margin-top: 0.25rem !important;
  margin-bottom: 0.25rem !important;
}

.my-2 {
  margin-top: 0.5rem !important;
  margin-bottom: 0.5rem !important;
}

.my-3 {
  margin-top: 1rem !important;
  margin-bottom: 1rem !important;
}

.my-4 {
  margin-top: 1.5rem !important;
  margin-bottom: 1.5rem !important;
}

.my-5 {
  margin-top: 2rem !important;
  margin-bottom: 2rem !important;
}

.my-6 {
  margin-top: 2.5rem !important;
  margin-bottom: 2.5rem !important;
}

.my-7 {
  margin-top: 3rem !important;
  margin-bottom: 3rem !important;
}

.my-8 {
  margin-top: 3.5rem !important;
  margin-bottom: 3.5rem !important;
}

.my-9 {
  margin-top: 4rem !important;
  margin-bottom: 4rem !important;
}

.my-10 {
  margin-top: 4.5rem !important;
  margin-bottom: 4.5rem !important;
}

.my-auto {
  margin-top: auto !important;
  margin-bottom: auto !important;
}

.mt-0 {
  margin-top: 0 !important;
}

.mt-1 {
  margin-top: 0.25rem !important;
}

.mt-2 {
  margin-top: 0.5rem !important;
}

.mt-3 {
  margin-top: 1rem !important;
}

.mt-4 {
  margin-top: 1.5rem !important;
}

.mt-5 {
  margin-top: 2rem !important;
}

.mt-6 {
  margin-top: 2.5rem !important;
}

.mt-7 {
  margin-top: 3rem !important;
}

.mt-8 {
  margin-top: 3.5rem !important;
}

.mt-9 {
  margin-top: 4rem !important;
}

.mt-10 {
  margin-top: 4.5rem !important;
}

.mt-auto {
  margin-top: auto !important;
}

.me-0 {
  margin-right: 0 !important;
}

.me-1 {
  margin-right: 0.25rem !important;
}

.me-2 {
  margin-right: 0.5rem !important;
}

.me-3 {
  margin-right: 1rem !important;
}

.me-4 {
  margin-right: 1.5rem !important;
}

.me-5 {
  margin-right: 2rem !important;
}

.me-6 {
  margin-right: 2.5rem !important;
}

.me-7 {
  margin-right: 3rem !important;
}

.me-8 {
  margin-right: 3.5rem !important;
}

.me-9 {
  margin-right: 4rem !important;
}

.me-10 {
  margin-right: 4.5rem !important;
}

.me-auto {
  margin-right: auto !important;
}

.mb-0 {
  margin-bottom: 0 !important;
}

.mb-1 {
  margin-bottom: 0.25rem !important;
}

.mb-2 {
  margin-bottom: 0.5rem !important;
}

.mb-3 {
  margin-bottom: 1rem !important;
}

.mb-4 {
  margin-bottom: 1.5rem !important;
}

.mb-5 {
  margin-bottom: 2rem !important;
}

.mb-6 {
  margin-bottom: 2.5rem !important;
}

.mb-7 {
  margin-bottom: 3rem !important;
}

.mb-8 {
  margin-bottom: 3.5rem !important;
}

.mb-9 {
  margin-bottom: 4rem !important;
}

.mb-10 {
  margin-bottom: 4.5rem !important;
}

.mb-auto {
  margin-bottom: auto !important;
}

.ms-0 {
  margin-left: 0 !important;
}

.ms-1 {
  margin-left: 0.25rem !important;
}

.ms-2 {
  margin-left: 0.5rem !important;
}

.ms-3 {
  margin-left: 1rem !important;
}

.ms-4 {
  margin-left: 1.5rem !important;
}

.ms-5 {
  margin-left: 2rem !important;
}

.ms-6 {
  margin-left: 2.5rem !important;
}

.ms-7 {
  margin-left: 3rem !important;
}

.ms-8 {
  margin-left: 3.5rem !important;
}

.ms-9 {
  margin-left: 4rem !important;
}

.ms-10 {
  margin-left: 4.5rem !important;
}

.ms-auto {
  margin-left: auto !important;
}

.m-n1 {
  margin: -0.25rem !important;
}

.m-n2 {
  margin: -0.5rem !important;
}

.m-n3 {
  margin: -1rem !important;
}

.m-n4 {
  margin: -1.5rem !important;
}

.m-n5 {
  margin: -2rem !important;
}

.m-n6 {
  margin: -2.5rem !important;
}

.m-n7 {
  margin: -3rem !important;
}

.m-n8 {
  margin: -3.5rem !important;
}

.m-n9 {
  margin: -4rem !important;
}

.m-n10 {
  margin: -4.5rem !important;
}

.mx-n1 {
  margin-right: -0.25rem !important;
  margin-left: -0.25rem !important;
}

.mx-n2 {
  margin-right: -0.5rem !important;
  margin-left: -0.5rem !important;
}

.mx-n3 {
  margin-right: -1rem !important;
  margin-left: -1rem !important;
}

.mx-n4 {
  margin-right: -1.5rem !important;
  margin-left: -1.5rem !important;
}

.mx-n5 {
  margin-right: -2rem !important;
  margin-left: -2rem !important;
}

.mx-n6 {
  margin-right: -2.5rem !important;
  margin-left: -2.5rem !important;
}

.mx-n7 {
  margin-right: -3rem !important;
  margin-left: -3rem !important;
}

.mx-n8 {
  margin-right: -3.5rem !important;
  margin-left: -3.5rem !important;
}

.mx-n9 {
  margin-right: -4rem !important;
  margin-left: -4rem !important;
}

.mx-n10 {
  margin-right: -4.5rem !important;
  margin-left: -4.5rem !important;
}

.my-n1 {
  margin-top: -0.25rem !important;
  margin-bottom: -0.25rem !important;
}

.my-n2 {
  margin-top: -0.5rem !important;
  margin-bottom: -0.5rem !important;
}

.my-n3 {
  margin-top: -1rem !important;
  margin-bottom: -1rem !important;
}

.my-n4 {
  margin-top: -1.5rem !important;
  margin-bottom: -1.5rem !important;
}

.my-n5 {
  margin-top: -2rem !important;
  margin-bottom: -2rem !important;
}

.my-n6 {
  margin-top: -2.5rem !important;
  margin-bottom: -2.5rem !important;
}

.my-n7 {
  margin-top: -3rem !important;
  margin-bottom: -3rem !important;
}

.my-n8 {
  margin-top: -3.5rem !important;
  margin-bottom: -3.5rem !important;
}

.my-n9 {
  margin-top: -4rem !important;
  margin-bottom: -4rem !important;
}

.my-n10 {
  margin-top: -4.5rem !important;
  margin-bottom: -4.5rem !important;
}

.mt-n1 {
  margin-top: -0.25rem !important;
}

.mt-n2 {
  margin-top: -0.5rem !important;
}

.mt-n3 {
  margin-top: -1rem !important;
}

.mt-n4 {
  margin-top: -1.5rem !important;
}

.mt-n5 {
  margin-top: -2rem !important;
}

.mt-n6 {
  margin-top: -2.5rem !important;
}

.mt-n7 {
  margin-top: -3rem !important;
}

.mt-n8 {
  margin-top: -3.5rem !important;
}

.mt-n9 {
  margin-top: -4rem !important;
}

.mt-n10 {
  margin-top: -4.5rem !important;
}

.me-n1 {
  margin-right: -0.25rem !important;
}

.me-n2 {
  margin-right: -0.5rem !important;
}

.me-n3 {
  margin-right: -1rem !important;
}

.me-n4 {
  margin-right: -1.5rem !important;
}

.me-n5 {
  margin-right: -2rem !important;
}

.me-n6 {
  margin-right: -2.5rem !important;
}

.me-n7 {
  margin-right: -3rem !important;
}

.me-n8 {
  margin-right: -3.5rem !important;
}

.me-n9 {
  margin-right: -4rem !important;
}

.me-n10 {
  margin-right: -4.5rem !important;
}

.mb-n1 {
  margin-bottom: -0.25rem !important;
}

.mb-n2 {
  margin-bottom: -0.5rem !important;
}

.mb-n3 {
  margin-bottom: -1rem !important;
}

.mb-n4 {
  margin-bottom: -1.5rem !important;
}

.mb-n5 {
  margin-bottom: -2rem !important;
}

.mb-n6 {
  margin-bottom: -2.5rem !important;
}

.mb-n7 {
  margin-bottom: -3rem !important;
}

.mb-n8 {
  margin-bottom: -3.5rem !important;
}

.mb-n9 {
  margin-bottom: -4rem !important;
}

.mb-n10 {
  margin-bottom: -4.5rem !important;
}

.ms-n1 {
  margin-left: -0.25rem !important;
}

.ms-n2 {
  margin-left: -0.5rem !important;
}

.ms-n3 {
  margin-left: -1rem !important;
}

.ms-n4 {
  margin-left: -1.5rem !important;
}

.ms-n5 {
  margin-left: -2rem !important;
}

.ms-n6 {
  margin-left: -2.5rem !important;
}

.ms-n7 {
  margin-left: -3rem !important;
}

.ms-n8 {
  margin-left: -3.5rem !important;
}

.ms-n9 {
  margin-left: -4rem !important;
}

.ms-n10 {
  margin-left: -4.5rem !important;
}

.p-0 {
  padding: 0 !important;
}

.p-1 {
  padding: 0.25rem !important;
}

.p-2 {
  padding: 0.5rem !important;
}

.p-3 {
  padding: 1rem !important;
}

.p-4 {
  padding: 1.5rem !important;
}

.p-5 {
  padding: 2rem !important;
}

.p-6 {
  padding: 2.5rem !important;
}

.p-7 {
  padding: 3rem !important;
}

.p-8 {
  padding: 3.5rem !important;
}

.p-9 {
  padding: 4rem !important;
}

.p-10 {
  padding: 4.5rem !important;
}

.px-0 {
  padding-right: 0 !important;
  padding-left: 0 !important;
}

.px-1 {
  padding-right: 0.25rem !important;
  padding-left: 0.25rem !important;
}

.px-2 {
  padding-right: 0.5rem !important;
  padding-left: 0.5rem !important;
}

.px-3 {
  padding-right: 1rem !important;
  padding-left: 1rem !important;
}

.px-4 {
  padding-right: 1.5rem !important;
  padding-left: 1.5rem !important;
}

.px-5 {
  padding-right: 2rem !important;
  padding-left: 2rem !important;
}

.px-6 {
  padding-right: 2.5rem !important;
  padding-left: 2.5rem !important;
}

.px-7 {
  padding-right: 3rem !important;
  padding-left: 3rem !important;
}

.px-8 {
  padding-right: 3.5rem !important;
  padding-left: 3.5rem !important;
}

.px-9 {
  padding-right: 4rem !important;
  padding-left: 4rem !important;
}

.px-10 {
  padding-right: 4.5rem !important;
  padding-left: 4.5rem !important;
}

.py-0 {
  padding-top: 0 !important;
  padding-bottom: 0 !important;
}

.py-1 {
  padding-top: 0.25rem !important;
  padding-bottom: 0.25rem !important;
}

.py-2 {
  padding-top: 0.5rem !important;
  padding-bottom: 0.5rem !important;
}

.py-3 {
  padding-top: 1rem !important;
  padding-bottom: 1rem !important;
}

.py-4 {
  padding-top: 1.5rem !important;
  padding-bottom: 1.5rem !important;
}

.py-5 {
  padding-top: 2rem !important;
  padding-bottom: 2rem !important;
}

.py-6 {
  padding-top: 2.5rem !important;
  padding-bottom: 2.5rem !important;
}

.py-7 {
  padding-top: 3rem !important;
  padding-bottom: 3rem !important;
}

.py-8 {
  padding-top: 3.5rem !important;
  padding-bottom: 3.5rem !important;
}

.py-9 {
  padding-top: 4rem !important;
  padding-bottom: 4rem !important;
}

.py-10 {
  padding-top: 4.5rem !important;
  padding-bottom: 4.5rem !important;
}

.pt-0 {
  padding-top: 0 !important;
}

.pt-1 {
  padding-top: 0.25rem !important;
}

.pt-2 {
  padding-top: 0.5rem !important;
}

.pt-3 {
  padding-top: 1rem !important;
}

.pt-4 {
  padding-top: 1.5rem !important;
}

.pt-5 {
  padding-top: 2rem !important;
}

.pt-6 {
  padding-top: 2.5rem !important;
}

.pt-7 {
  padding-top: 3rem !important;
}

.pt-8 {
  padding-top: 3.5rem !important;
}

.pt-9 {
  padding-top: 4rem !important;
}

.pt-10 {
  padding-top: 4.5rem !important;
}

.pe-0 {
  padding-right: 0 !important;
}

.pe-1 {
  padding-right: 0.25rem !important;
}

.pe-2 {
  padding-right: 0.5rem !important;
}

.pe-3 {
  padding-right: 1rem !important;
}

.pe-4 {
  padding-right: 1.5rem !important;
}

.pe-5 {
  padding-right: 2rem !important;
}

.pe-6 {
  padding-right: 2.5rem !important;
}

.pe-7 {
  padding-right: 3rem !important;
}

.pe-8 {
  padding-right: 3.5rem !important;
}

.pe-9 {
  padding-right: 4rem !important;
}

.pe-10 {
  padding-right: 4.5rem !important;
}

.pb-0 {
  padding-bottom: 0 !important;
}

.pb-1 {
  padding-bottom: 0.25rem !important;
}

.pb-2 {
  padding-bottom: 0.5rem !important;
}

.pb-3 {
  padding-bottom: 1rem !important;
}

.pb-4 {
  padding-bottom: 1.5rem !important;
}

.pb-5 {
  padding-bottom: 2rem !important;
}

.pb-6 {
  padding-bottom: 2.5rem !important;
}

.pb-7 {
  padding-bottom: 3rem !important;
}

.pb-8 {
  padding-bottom: 3.5rem !important;
}

.pb-9 {
  padding-bottom: 4rem !important;
}

.pb-10 {
  padding-bottom: 4.5rem !important;
}

.ps-0 {
  padding-left: 0 !important;
}

.ps-1 {
  padding-left: 0.25rem !important;
}

.ps-2 {
  padding-left: 0.5rem !important;
}

.ps-3 {
  padding-left: 1rem !important;
}

.ps-4 {
  padding-left: 1.5rem !important;
}

.ps-5 {
  padding-left: 2rem !important;
}

.ps-6 {
  padding-left: 2.5rem !important;
}

.ps-7 {
  padding-left: 3rem !important;
}

.ps-8 {
  padding-left: 3.5rem !important;
}

.ps-9 {
  padding-left: 4rem !important;
}

.ps-10 {
  padding-left: 4.5rem !important;
}

.gap-0 {
  gap: 0 !important;
}

.gap-1 {
  gap: 0.25rem !important;
}

.gap-2 {
  gap: 0.5rem !important;
}

.gap-3 {
  gap: 1rem !important;
}

.gap-4 {
  gap: 1.5rem !important;
}

.gap-5 {
  gap: 2rem !important;
}

.gap-6 {
  gap: 2.5rem !important;
}

.gap-7 {
  gap: 3rem !important;
}

.gap-8 {
  gap: 3.5rem !important;
}

.gap-9 {
  gap: 4rem !important;
}

.gap-10 {
  gap: 4.5rem !important;
}

.row-gap-0 {
  row-gap: 0 !important;
}

.row-gap-1 {
  row-gap: 0.25rem !important;
}

.row-gap-2 {
  row-gap: 0.5rem !important;
}

.row-gap-3 {
  row-gap: 1rem !important;
}

.row-gap-4 {
  row-gap: 1.5rem !important;
}

.row-gap-5 {
  row-gap: 2rem !important;
}

.row-gap-6 {
  row-gap: 2.5rem !important;
}

.row-gap-7 {
  row-gap: 3rem !important;
}

.row-gap-8 {
  row-gap: 3.5rem !important;
}

.row-gap-9 {
  row-gap: 4rem !important;
}

.row-gap-10 {
  row-gap: 4.5rem !important;
}

.column-gap-0 {
  column-gap: 0 !important;
}

.column-gap-1 {
  column-gap: 0.25rem !important;
}

.column-gap-2 {
  column-gap: 0.5rem !important;
}

.column-gap-3 {
  column-gap: 1rem !important;
}

.column-gap-4 {
  column-gap: 1.5rem !important;
}

.column-gap-5 {
  column-gap: 2rem !important;
}

.column-gap-6 {
  column-gap: 2.5rem !important;
}

.column-gap-7 {
  column-gap: 3rem !important;
}

.column-gap-8 {
  column-gap: 3.5rem !important;
}

.column-gap-9 {
  column-gap: 4rem !important;
}

.column-gap-10 {
  column-gap: 4.5rem !important;
}

.font-monospace {
  font-family: var(--bs-font-monospace) !important;
}

.fs-1 {
  font-size: calc(1.35rem + 1.2vw) !important;
}

.fs-2 {
  font-size: calc(1.3rem + 0.6vw) !important;
}

.fs-3 {
  font-size: 1.25rem !important;
}

.fs-4 {
  font-size: 1rem !important;
}

.fs-5 {
  font-size: 0.875rem !important;
}

.fs-6 {
  font-size: 0.8125rem !important;
}

.fst-italic {
  font-style: italic !important;
}

.fst-normal {
  font-style: normal !important;
}

.fw-lighter {
  font-weight: lighter !important;
}

.fw-light {
  font-weight: 300 !important;
}

.fw-normal {
  font-weight: 400 !important;
}

.fw-medium {
  font-weight: 500 !important;
}

.fw-semibold {
  font-weight: 600 !important;
}

.fw-bold {
  font-weight: 700 !important;
}

.fw-bolder {
  font-weight: bolder !important;
}

.lh-1 {
  line-height: 1 !important;
}

.lh-sm {
  line-height: 1.25 !important;
}

.lh-base {
  line-height: 1.5 !important;
}

.lh-lg {
  line-height: 2 !important;
}

.text-start {
  text-align: left !important;
}

.text-end {
  text-align: right !important;
}

.text-center {
  text-align: center !important;
}

.text-decoration-none {
  text-decoration: none !important;
}

.text-decoration-underline {
  text-decoration: underline !important;
}

.text-decoration-line-through {
  text-decoration: line-through !important;
}

.text-lowercase {
  text-transform: lowercase !important;
}

.text-uppercase {
  text-transform: uppercase !important;
}

.text-capitalize {
  text-transform: capitalize !important;
}

.text-wrap {
  white-space: normal !important;
}

.text-nowrap {
  white-space: nowrap !important;
}

/* rtl:begin:remove */
.text-break {
  word-wrap: break-word !important;
  word-break: break-word !important;
}

/* rtl:end:remove */
.text-primary {
  --bs-text-opacity: 1;
  color: rgba(var(--bs-primary-rgb), var(--bs-text-opacity)) !important;
}

.text-secondary {
  --bs-text-opacity: 1;
  color: rgba(var(--bs-secondary-rgb), var(--bs-text-opacity)) !important;
}

.text-success {
  --bs-text-opacity: 1;
  color: rgba(var(--bs-success-rgb), var(--bs-text-opacity)) !important;
}

.text-info {
  --bs-text-opacity: 1;
  color: rgba(var(--bs-info-rgb), var(--bs-text-opacity)) !important;
}

.text-warning {
  --bs-text-opacity: 1;
  color: rgba(var(--bs-warning-rgb), var(--bs-text-opacity)) !important;
}

.text-danger {
  --bs-text-opacity: 1;
  color: rgba(var(--bs-danger-rgb), var(--bs-text-opacity)) !important;
}

.text-light {
  --bs-text-opacity: 1;
  color: rgba(var(--bs-light-rgb), var(--bs-text-opacity)) !important;
}

.text-dark {
  --bs-text-opacity: 1;
  color: rgba(var(--bs-dark-rgb), var(--bs-text-opacity)) !important;
}

.text-black {
  --bs-text-opacity: 1;
  color: rgba(var(--bs-black-rgb), var(--bs-text-opacity)) !important;
}

.text-white {
  --bs-text-opacity: 1;
  color: rgba(var(--bs-white-rgb), var(--bs-text-opacity)) !important;
}

.text-body {
  --bs-text-opacity: 1;
  color: rgba(var(--bs-body-color-rgb), var(--bs-text-opacity)) !important;
}

.text-muted {
  --bs-text-opacity: 1;
  color: var(--bs-secondary-color) !important;
}

.text-black-50 {
  --bs-text-opacity: 1;
  color: rgba(0, 0, 0, 0.5) !important;
}

.text-white-50 {
  --bs-text-opacity: 1;
  color: rgba(255, 255, 255, 0.5) !important;
}

.text-body-secondary {
  --bs-text-opacity: 1;
  color: var(--bs-secondary-color) !important;
}

.text-body-tertiary {
  --bs-text-opacity: 1;
  color: var(--bs-tertiary-color) !important;
}

.text-body-emphasis {
  --bs-text-opacity: 1;
  color: var(--bs-emphasis-color) !important;
}

.text-reset {
  --bs-text-opacity: 1;
  color: inherit !important;
}

.text-white-70 {
  --bs-text-opacity: 1;
  color: rgba(255, 255, 255, 0.7) !important;
}

.text-opacity-25 {
  --bs-text-opacity: 0.25;
}

.text-opacity-50 {
  --bs-text-opacity: 0.5;
}

.text-opacity-75 {
  --bs-text-opacity: 0.75;
}

.text-opacity-100 {
  --bs-text-opacity: 1;
}

.text-primary-emphasis {
  color: var(--bs-primary-text-emphasis) !important;
}

.text-secondary-emphasis {
  color: var(--bs-secondary-text-emphasis) !important;
}

.text-success-emphasis {
  color: var(--bs-success-text-emphasis) !important;
}

.text-info-emphasis {
  color: var(--bs-info-text-emphasis) !important;
}

.text-warning-emphasis {
  color: var(--bs-warning-text-emphasis) !important;
}

.text-danger-emphasis {
  color: var(--bs-danger-text-emphasis) !important;
}

.text-light-emphasis {
  color: var(--bs-light-text-emphasis) !important;
}

.text-dark-emphasis {
  color: var(--bs-dark-text-emphasis) !important;
}

.link-opacity-10 {
  --bs-link-opacity: 0.1;
}

.link-opacity-10-hover:hover {
  --bs-link-opacity: 0.1;
}

.link-opacity-25 {
  --bs-link-opacity: 0.25;
}

.link-opacity-25-hover:hover {
  --bs-link-opacity: 0.25;
}

.link-opacity-50 {
  --bs-link-opacity: 0.5;
}

.link-opacity-50-hover:hover {
  --bs-link-opacity: 0.5;
}

.link-opacity-75 {
  --bs-link-opacity: 0.75;
}

.link-opacity-75-hover:hover {
  --bs-link-opacity: 0.75;
}

.link-opacity-100 {
  --bs-link-opacity: 1;
}

.link-opacity-100-hover:hover {
  --bs-link-opacity: 1;
}

.link-offset-1 {
  text-underline-offset: 0.125em !important;
}

.link-offset-1-hover:hover {
  text-underline-offset: 0.125em !important;
}

.link-offset-2 {
  text-underline-offset: 0.25em !important;
}

.link-offset-2-hover:hover {
  text-underline-offset: 0.25em !important;
}

.link-offset-3 {
  text-underline-offset: 0.375em !important;
}

.link-offset-3-hover:hover {
  text-underline-offset: 0.375em !important;
}

.link-underline-primary {
  --bs-link-underline-opacity: 1;
  text-decoration-color: rgba(var(--bs-primary-rgb), var(--bs-link-underline-opacity)) !important;
}

.link-underline-secondary {
  --bs-link-underline-opacity: 1;
  text-decoration-color: rgba(var(--bs-secondary-rgb), var(--bs-link-underline-opacity)) !important;
}

.link-underline-success {
  --bs-link-underline-opacity: 1;
  text-decoration-color: rgba(var(--bs-success-rgb), var(--bs-link-underline-opacity)) !important;
}

.link-underline-info {
  --bs-link-underline-opacity: 1;
  text-decoration-color: rgba(var(--bs-info-rgb), var(--bs-link-underline-opacity)) !important;
}

.link-underline-warning {
  --bs-link-underline-opacity: 1;
  text-decoration-color: rgba(var(--bs-warning-rgb), var(--bs-link-underline-opacity)) !important;
}

.link-underline-danger {
  --bs-link-underline-opacity: 1;
  text-decoration-color: rgba(var(--bs-danger-rgb), var(--bs-link-underline-opacity)) !important;
}

.link-underline-light {
  --bs-link-underline-opacity: 1;
  text-decoration-color: rgba(var(--bs-light-rgb), var(--bs-link-underline-opacity)) !important;
}

.link-underline-dark {
  --bs-link-underline-opacity: 1;
  text-decoration-color: rgba(var(--bs-dark-rgb), var(--bs-link-underline-opacity)) !important;
}

.link-underline {
  --bs-link-underline-opacity: 1;
  text-decoration-color: rgba(var(--bs-link-color-rgb), var(--bs-link-underline-opacity, 1)) !important;
}

.link-underline-opacity-0 {
  --bs-link-underline-opacity: 0;
}

.link-underline-opacity-0-hover:hover {
  --bs-link-underline-opacity: 0;
}

.link-underline-opacity-10 {
  --bs-link-underline-opacity: 0.1;
}

.link-underline-opacity-10-hover:hover {
  --bs-link-underline-opacity: 0.1;
}

.link-underline-opacity-25 {
  --bs-link-underline-opacity: 0.25;
}

.link-underline-opacity-25-hover:hover {
  --bs-link-underline-opacity: 0.25;
}

.link-underline-opacity-50 {
  --bs-link-underline-opacity: 0.5;
}

.link-underline-opacity-50-hover:hover {
  --bs-link-underline-opacity: 0.5;
}

.link-underline-opacity-75 {
  --bs-link-underline-opacity: 0.75;
}

.link-underline-opacity-75-hover:hover {
  --bs-link-underline-opacity: 0.75;
}

.link-underline-opacity-100 {
  --bs-link-underline-opacity: 1;
}

.link-underline-opacity-100-hover:hover {
  --bs-link-underline-opacity: 1;
}

.bg-primary {
  --bs-bg-opacity: 1;
  background-color: rgba(var(--bs-primary-rgb), var(--bs-bg-opacity)) !important;
}

.bg-secondary {
  --bs-bg-opacity: 1;
  background-color: rgba(var(--bs-secondary-rgb), var(--bs-bg-opacity)) !important;
}

.bg-success {
  --bs-bg-opacity: 1;
  background-color: rgba(var(--bs-success-rgb), var(--bs-bg-opacity)) !important;
}

.bg-info {
  --bs-bg-opacity: 1;
  background-color: rgba(var(--bs-info-rgb), var(--bs-bg-opacity)) !important;
}

.bg-warning {
  --bs-bg-opacity: 1;
  background-color: rgba(var(--bs-warning-rgb), var(--bs-bg-opacity)) !important;
}

.bg-danger {
  --bs-bg-opacity: 1;
  background-color: rgba(var(--bs-danger-rgb), var(--bs-bg-opacity)) !important;
}

.bg-light {
  --bs-bg-opacity: 1;
  background-color: rgba(var(--bs-light-rgb), var(--bs-bg-opacity)) !important;
}

.bg-dark {
  --bs-bg-opacity: 1;
  background-color: rgba(var(--bs-dark-rgb), var(--bs-bg-opacity)) !important;
}

.bg-black {
  --bs-bg-opacity: 1;
  background-color: rgba(var(--bs-black-rgb), var(--bs-bg-opacity)) !important;
}

.bg-white {
  --bs-bg-opacity: 1;
  background-color: rgba(var(--bs-white-rgb), var(--bs-bg-opacity)) !important;
}

.bg-body {
  --bs-bg-opacity: 1;
  background-color: rgba(var(--bs-body-bg-rgb), var(--bs-bg-opacity)) !important;
}

.bg-transparent {
  --bs-bg-opacity: 1;
  background-color: transparent !important;
}

.bg-body-secondary {
  --bs-bg-opacity: 1;
  background-color: rgba(var(--bs-secondary-bg-rgb), var(--bs-bg-opacity)) !important;
}

.bg-body-tertiary {
  --bs-bg-opacity: 1;
  background-color: rgba(var(--bs-tertiary-bg-rgb), var(--bs-bg-opacity)) !important;
}

.bg-opacity-10 {
  --bs-bg-opacity: 0.1;
}

.bg-opacity-25 {
  --bs-bg-opacity: 0.25;
}

.bg-opacity-50 {
  --bs-bg-opacity: 0.5;
}

.bg-opacity-75 {
  --bs-bg-opacity: 0.75;
}

.bg-opacity-100 {
  --bs-bg-opacity: 1;
}

.bg-primary-subtle {
  background-color: var(--bs-primary-bg-subtle) !important;
}

.bg-secondary-subtle {
  background-color: var(--bs-secondary-bg-subtle) !important;
}

.bg-success-subtle {
  background-color: var(--bs-success-bg-subtle) !important;
}

.bg-info-subtle {
  background-color: var(--bs-info-bg-subtle) !important;
}

.bg-warning-subtle {
  background-color: var(--bs-warning-bg-subtle) !important;
}

.bg-danger-subtle {
  background-color: var(--bs-danger-bg-subtle) !important;
}

.bg-light-subtle {
  background-color: var(--bs-light-bg-subtle) !important;
}

.bg-dark-subtle {
  background-color: var(--bs-dark-bg-subtle) !important;
}

.bg-gradient {
  background-image: var(--bs-gradient) !important;
}

.user-select-all {
  user-select: all !important;
}

.user-select-auto {
  user-select: auto !important;
}

.user-select-none {
  user-select: none !important;
}

.pe-none {
  pointer-events: none !important;
}

.pe-auto {
  pointer-events: auto !important;
}

.rounded {
  border-radius: var(--bs-border-radius) !important;
}

.rounded-0 {
  border-radius: 0 !important;
}

.rounded-1 {
  border-radius: var(--bs-border-radius-sm) !important;
}

.rounded-2 {
  border-radius: var(--bs-border-radius) !important;
}

.rounded-3 {
  border-radius: var(--bs-border-radius-lg) !important;
}

.rounded-4 {
  border-radius: var(--bs-border-radius-xl) !important;
}

.rounded-5 {
  border-radius: var(--bs-border-radius-xxl) !important;
}

.rounded-circle {
  border-radius: 50% !important;
}

.rounded-pill {
  border-radius: var(--bs-border-radius-pill) !important;
}

.rounded-top {
  border-top-left-radius: var(--bs-border-radius) !important;
  border-top-right-radius: var(--bs-border-radius) !important;
}

.rounded-top-0 {
  border-top-left-radius: 0 !important;
  border-top-right-radius: 0 !important;
}

.rounded-top-1 {
  border-top-left-radius: var(--bs-border-radius-sm) !important;
  border-top-right-radius: var(--bs-border-radius-sm) !important;
}

.rounded-top-2 {
  border-top-left-radius: var(--bs-border-radius) !important;
  border-top-right-radius: var(--bs-border-radius) !important;
}

.rounded-top-3 {
  border-top-left-radius: var(--bs-border-radius-lg) !important;
  border-top-right-radius: var(--bs-border-radius-lg) !important;
}

.rounded-top-4 {
  border-top-left-radius: var(--bs-border-radius-xl) !important;
  border-top-right-radius: var(--bs-border-radius-xl) !important;
}

.rounded-top-5 {
  border-top-left-radius: var(--bs-border-radius-xxl) !important;
  border-top-right-radius: var(--bs-border-radius-xxl) !important;
}

.rounded-top-circle {
  border-top-left-radius: 50% !important;
  border-top-right-radius: 50% !important;
}

.rounded-top-pill {
  border-top-left-radius: var(--bs-border-radius-pill) !important;
  border-top-right-radius: var(--bs-border-radius-pill) !important;
}

.rounded-end {
  border-top-right-radius: var(--bs-border-radius) !important;
  border-bottom-right-radius: var(--bs-border-radius) !important;
}

.rounded-end-0 {
  border-top-right-radius: 0 !important;
  border-bottom-right-radius: 0 !important;
}

.rounded-end-1 {
  border-top-right-radius: var(--bs-border-radius-sm) !important;
  border-bottom-right-radius: var(--bs-border-radius-sm) !important;
}

.rounded-end-2 {
  border-top-right-radius: var(--bs-border-radius) !important;
  border-bottom-right-radius: var(--bs-border-radius) !important;
}

.rounded-end-3 {
  border-top-right-radius: var(--bs-border-radius-lg) !important;
  border-bottom-right-radius: var(--bs-border-radius-lg) !important;
}

.rounded-end-4 {
  border-top-right-radius: var(--bs-border-radius-xl) !important;
  border-bottom-right-radius: var(--bs-border-radius-xl) !important;
}

.rounded-end-5 {
  border-top-right-radius: var(--bs-border-radius-xxl) !important;
  border-bottom-right-radius: var(--bs-border-radius-xxl) !important;
}

.rounded-end-circle {
  border-top-right-radius: 50% !important;
  border-bottom-right-radius: 50% !important;
}

.rounded-end-pill {
  border-top-right-radius: var(--bs-border-radius-pill) !important;
  border-bottom-right-radius: var(--bs-border-radius-pill) !important;
}

.rounded-bottom {
  border-bottom-right-radius: var(--bs-border-radius) !important;
  border-bottom-left-radius: var(--bs-border-radius) !important;
}

.rounded-bottom-0 {
  border-bottom-right-radius: 0 !important;
  border-bottom-left-radius: 0 !important;
}

.rounded-bottom-1 {
  border-bottom-right-radius: var(--bs-border-radius-sm) !important;
  border-bottom-left-radius: var(--bs-border-radius-sm) !important;
}

.rounded-bottom-2 {
  border-bottom-right-radius: var(--bs-border-radius) !important;
  border-bottom-left-radius: var(--bs-border-radius) !important;
}

.rounded-bottom-3 {
  border-bottom-right-radius: var(--bs-border-radius-lg) !important;
  border-bottom-left-radius: var(--bs-border-radius-lg) !important;
}

.rounded-bottom-4 {
  border-bottom-right-radius: var(--bs-border-radius-xl) !important;
  border-bottom-left-radius: var(--bs-border-radius-xl) !important;
}

.rounded-bottom-5 {
  border-bottom-right-radius: var(--bs-border-radius-xxl) !important;
  border-bottom-left-radius: var(--bs-border-radius-xxl) !important;
}

.rounded-bottom-circle {
  border-bottom-right-radius: 50% !important;
  border-bottom-left-radius: 50% !important;
}

.rounded-bottom-pill {
  border-bottom-right-radius: var(--bs-border-radius-pill) !important;
  border-bottom-left-radius: var(--bs-border-radius-pill) !important;
}

.rounded-start {
  border-bottom-left-radius: var(--bs-border-radius) !important;
  border-top-left-radius: var(--bs-border-radius) !important;
}

.rounded-start-0 {
  border-bottom-left-radius: 0 !important;
  border-top-left-radius: 0 !important;
}

.rounded-start-1 {
  border-bottom-left-radius: var(--bs-border-radius-sm) !important;
  border-top-left-radius: var(--bs-border-radius-sm) !important;
}

.rounded-start-2 {
  border-bottom-left-radius: var(--bs-border-radius) !important;
  border-top-left-radius: var(--bs-border-radius) !important;
}

.rounded-start-3 {
  border-bottom-left-radius: var(--bs-border-radius-lg) !important;
  border-top-left-radius: var(--bs-border-radius-lg) !important;
}

.rounded-start-4 {
  border-bottom-left-radius: var(--bs-border-radius-xl) !important;
  border-top-left-radius: var(--bs-border-radius-xl) !important;
}

.rounded-start-5 {
  border-bottom-left-radius: var(--bs-border-radius-xxl) !important;
  border-top-left-radius: var(--bs-border-radius-xxl) !important;
}

.rounded-start-circle {
  border-bottom-left-radius: 50% !important;
  border-top-left-radius: 50% !important;
}

.rounded-start-pill {
  border-bottom-left-radius: var(--bs-border-radius-pill) !important;
  border-top-left-radius: var(--bs-border-radius-pill) !important;
}

.visible {
  visibility: visible !important;
}

.invisible {
  visibility: hidden !important;
}

.zi-n1 {
  z-index: -1 !important;
}

.zi-0 {
  z-index: 0 !important;
}

.zi-1 {
  z-index: 1 !important;
}

.zi-2 {
  z-index: 2 !important;
}

.zi-3 {
  z-index: 3 !important;
}

.content-space-t-0 {
  padding-top: 0 !important;
}

.content-space-t-1 {
  padding-top: 3.5rem !important;
}

.content-space-t-2 {
  padding-top: 5rem !important;
}

.content-space-t-3 {
  padding-top: 7.5rem !important;
}

.content-space-t-4 {
  padding-top: 10rem !important;
}

.content-space-t-auto {
  padding-top: auto !important;
}

.content-space-b-0 {
  padding-bottom: 0 !important;
}

.content-space-b-1 {
  padding-bottom: 3.5rem !important;
}

.content-space-b-2 {
  padding-bottom: 5rem !important;
}

.content-space-b-3 {
  padding-bottom: 7.5rem !important;
}

.content-space-b-4 {
  padding-bottom: 10rem !important;
}

.content-space-b-auto {
  padding-bottom: auto !important;
}

.content-space-0 {
  padding-top: 0 !important;
  padding-bottom: 0 !important;
}

.content-space-1 {
  padding-top: 3.5rem !important;
  padding-bottom: 3.5rem !important;
}

.content-space-2 {
  padding-top: 5rem !important;
  padding-bottom: 5rem !important;
}

.content-space-3 {
  padding-top: 7.5rem !important;
  padding-bottom: 7.5rem !important;
}

.content-space-4 {
  padding-top: 10rem !important;
  padding-bottom: 10rem !important;
}

.content-space-auto {
  padding-top: auto !important;
  padding-bottom: auto !important;
}

.bg-soft-primary {
  background-color: rgba(10, 191, 83, 0.075) !important;
}

.bg-soft-secondary {
  background-color: rgba(81, 89, 108, 0.075) !important;
}

.bg-soft-success {
  background-color: rgba(7, 124, 118, 0.075) !important;
}

.bg-soft-info {
  background-color: rgba(51, 74, 192, 0.075) !important;
}

.bg-soft-warning {
  background-color: rgba(243, 149, 104, 0.075) !important;
}

.bg-soft-danger {
  background-color: rgba(105, 35, 64, 0.075) !important;
}

.bg-soft-light {
  background-color: rgba(245, 247, 250, 0.075) !important;
}

.bg-soft-dark {
  background-color: rgba(45, 55, 75, 0.075) !important;
}

.min-h-100 {
  min-height: 100% !important;
}

@media (min-width: 576px) {
  .float-sm-start {
    float: left !important;
  }
  .float-sm-end {
    float: right !important;
  }
  .float-sm-none {
    float: none !important;
  }
  .object-fit-sm-contain {
    object-fit: contain !important;
  }
  .object-fit-sm-cover {
    object-fit: cover !important;
  }
  .object-fit-sm-fill {
    object-fit: fill !important;
  }
  .object-fit-sm-scale {
    object-fit: scale-down !important;
  }
  .object-fit-sm-none {
    object-fit: none !important;
  }
  .d-sm-inline {
    display: inline !important;
  }
  .d-sm-inline-block {
    display: inline-block !important;
  }
  .d-sm-block {
    display: block !important;
  }
  .d-sm-grid {
    display: grid !important;
  }
  .d-sm-inline-grid {
    display: inline-grid !important;
  }
  .d-sm-table {
    display: table !important;
  }
  .d-sm-table-row {
    display: table-row !important;
  }
  .d-sm-table-cell {
    display: table-cell !important;
  }
  .d-sm-flex {
    display: flex !important;
  }
  .d-sm-inline-flex {
    display: inline-flex !important;
  }
  .d-sm-none {
    display: none !important;
  }
  .position-sm-static {
    position: static !important;
  }
  .position-sm-relative {
    position: relative !important;
  }
  .position-sm-absolute {
    position: absolute !important;
  }
  .position-sm-fixed {
    position: fixed !important;
  }
  .position-sm-sticky {
    position: sticky !important;
  }
  .top-sm-0 {
    top: 0 !important;
  }
  .top-sm-50 {
    top: 50% !important;
  }
  .top-sm-100 {
    top: 100% !important;
  }
  .top-sm-auto {
    top: auto !important;
  }
  .bottom-sm-0 {
    bottom: 0 !important;
  }
  .bottom-sm-50 {
    bottom: 50% !important;
  }
  .bottom-sm-100 {
    bottom: 100% !important;
  }
  .bottom-sm-auto {
    bottom: auto !important;
  }
  .start-sm-0 {
    left: 0 !important;
  }
  .start-sm-50 {
    left: 50% !important;
  }
  .start-sm-100 {
    left: 100% !important;
  }
  .start-sm-auto {
    left: auto !important;
  }
  .end-sm-0 {
    right: 0 !important;
  }
  .end-sm-50 {
    right: 50% !important;
  }
  .end-sm-100 {
    right: 100% !important;
  }
  .end-sm-auto {
    right: auto !important;
  }
  .translate-middle-sm {
    transform: translate(-50%, -50%) !important;
  }
  .translate-middle-sm-x {
    transform: translateX(-50%) !important;
  }
  .translate-middle-sm-y {
    transform: translateY(-50%) !important;
  }
  .w-sm-25 {
    width: 25% !important;
  }
  .w-sm-50 {
    width: 50% !important;
  }
  .w-sm-75 {
    width: 75% !important;
  }
  .w-sm-100 {
    width: 100% !important;
  }
  .w-sm-auto {
    width: auto !important;
  }
  .w-sm-65 {
    width: 65% !important;
  }
  .w-sm-85 {
    width: 85% !important;
  }
  .h-sm-25 {
    height: 25% !important;
  }
  .h-sm-50 {
    height: 50% !important;
  }
  .h-sm-75 {
    height: 75% !important;
  }
  .h-sm-100 {
    height: 100% !important;
  }
  .h-sm-auto {
    height: auto !important;
  }
  .h-sm-65 {
    height: 65% !important;
  }
  .vh-sm-100 {
    height: 100vh !important;
  }
  .min-vh-sm-100 {
    min-height: 100vh !important;
  }
  .min-vh-sm-35 {
    min-height: 35vh !important;
  }
  .min-vh-sm-75 {
    min-height: 75vh !important;
  }
  .flex-sm-fill {
    flex: 1 1 auto !important;
  }
  .flex-sm-row {
    flex-direction: row !important;
  }
  .flex-sm-column {
    flex-direction: column !important;
  }
  .flex-sm-row-reverse {
    flex-direction: row-reverse !important;
  }
  .flex-sm-column-reverse {
    flex-direction: column-reverse !important;
  }
  .flex-sm-grow-0 {
    flex-grow: 0 !important;
  }
  .flex-sm-grow-1 {
    flex-grow: 1 !important;
  }
  .flex-sm-shrink-0 {
    flex-shrink: 0 !important;
  }
  .flex-sm-shrink-1 {
    flex-shrink: 1 !important;
  }
  .flex-sm-wrap {
    flex-wrap: wrap !important;
  }
  .flex-sm-nowrap {
    flex-wrap: nowrap !important;
  }
  .flex-sm-wrap-reverse {
    flex-wrap: wrap-reverse !important;
  }
  .justify-content-sm-start {
    justify-content: flex-start !important;
  }
  .justify-content-sm-end {
    justify-content: flex-end !important;
  }
  .justify-content-sm-center {
    justify-content: center !important;
  }
  .justify-content-sm-between {
    justify-content: space-between !important;
  }
  .justify-content-sm-around {
    justify-content: space-around !important;
  }
  .justify-content-sm-evenly {
    justify-content: space-evenly !important;
  }
  .align-items-sm-start {
    align-items: flex-start !important;
  }
  .align-items-sm-end {
    align-items: flex-end !important;
  }
  .align-items-sm-center {
    align-items: center !important;
  }
  .align-items-sm-baseline {
    align-items: baseline !important;
  }
  .align-items-sm-stretch {
    align-items: stretch !important;
  }
  .align-content-sm-start {
    align-content: flex-start !important;
  }
  .align-content-sm-end {
    align-content: flex-end !important;
  }
  .align-content-sm-center {
    align-content: center !important;
  }
  .align-content-sm-between {
    align-content: space-between !important;
  }
  .align-content-sm-around {
    align-content: space-around !important;
  }
  .align-content-sm-stretch {
    align-content: stretch !important;
  }
  .align-self-sm-auto {
    align-self: auto !important;
  }
  .align-self-sm-start {
    align-self: flex-start !important;
  }
  .align-self-sm-end {
    align-self: flex-end !important;
  }
  .align-self-sm-center {
    align-self: center !important;
  }
  .align-self-sm-baseline {
    align-self: baseline !important;
  }
  .align-self-sm-stretch {
    align-self: stretch !important;
  }
  .order-sm-first {
    order: -1 !important;
  }
  .order-sm-0 {
    order: 0 !important;
  }
  .order-sm-1 {
    order: 1 !important;
  }
  .order-sm-2 {
    order: 2 !important;
  }
  .order-sm-3 {
    order: 3 !important;
  }
  .order-sm-4 {
    order: 4 !important;
  }
  .order-sm-5 {
    order: 5 !important;
  }
  .order-sm-last {
    order: 6 !important;
  }
  .m-sm-0 {
    margin: 0 !important;
  }
  .m-sm-1 {
    margin: 0.25rem !important;
  }
  .m-sm-2 {
    margin: 0.5rem !important;
  }
  .m-sm-3 {
    margin: 1rem !important;
  }
  .m-sm-4 {
    margin: 1.5rem !important;
  }
  .m-sm-5 {
    margin: 2rem !important;
  }
  .m-sm-6 {
    margin: 2.5rem !important;
  }
  .m-sm-7 {
    margin: 3rem !important;
  }
  .m-sm-8 {
    margin: 3.5rem !important;
  }
  .m-sm-9 {
    margin: 4rem !important;
  }
  .m-sm-10 {
    margin: 4.5rem !important;
  }
  .m-sm-auto {
    margin: auto !important;
  }
  .mx-sm-0 {
    margin-right: 0 !important;
    margin-left: 0 !important;
  }
  .mx-sm-1 {
    margin-right: 0.25rem !important;
    margin-left: 0.25rem !important;
  }
  .mx-sm-2 {
    margin-right: 0.5rem !important;
    margin-left: 0.5rem !important;
  }
  .mx-sm-3 {
    margin-right: 1rem !important;
    margin-left: 1rem !important;
  }
  .mx-sm-4 {
    margin-right: 1.5rem !important;
    margin-left: 1.5rem !important;
  }
  .mx-sm-5 {
    margin-right: 2rem !important;
    margin-left: 2rem !important;
  }
  .mx-sm-6 {
    margin-right: 2.5rem !important;
    margin-left: 2.5rem !important;
  }
  .mx-sm-7 {
    margin-right: 3rem !important;
    margin-left: 3rem !important;
  }
  .mx-sm-8 {
    margin-right: 3.5rem !important;
    margin-left: 3.5rem !important;
  }
  .mx-sm-9 {
    margin-right: 4rem !important;
    margin-left: 4rem !important;
  }
  .mx-sm-10 {
    margin-right: 4.5rem !important;
    margin-left: 4.5rem !important;
  }
  .mx-sm-auto {
    margin-right: auto !important;
    margin-left: auto !important;
  }
  .my-sm-0 {
    margin-top: 0 !important;
    margin-bottom: 0 !important;
  }
  .my-sm-1 {
    margin-top: 0.25rem !important;
    margin-bottom: 0.25rem !important;
  }
  .my-sm-2 {
    margin-top: 0.5rem !important;
    margin-bottom: 0.5rem !important;
  }
  .my-sm-3 {
    margin-top: 1rem !important;
    margin-bottom: 1rem !important;
  }
  .my-sm-4 {
    margin-top: 1.5rem !important;
    margin-bottom: 1.5rem !important;
  }
  .my-sm-5 {
    margin-top: 2rem !important;
    margin-bottom: 2rem !important;
  }
  .my-sm-6 {
    margin-top: 2.5rem !important;
    margin-bottom: 2.5rem !important;
  }
  .my-sm-7 {
    margin-top: 3rem !important;
    margin-bottom: 3rem !important;
  }
  .my-sm-8 {
    margin-top: 3.5rem !important;
    margin-bottom: 3.5rem !important;
  }
  .my-sm-9 {
    margin-top: 4rem !important;
    margin-bottom: 4rem !important;
  }
  .my-sm-10 {
    margin-top: 4.5rem !important;
    margin-bottom: 4.5rem !important;
  }
  .my-sm-auto {
    margin-top: auto !important;
    margin-bottom: auto !important;
  }
  .mt-sm-0 {
    margin-top: 0 !important;
  }
  .mt-sm-1 {
    margin-top: 0.25rem !important;
  }
  .mt-sm-2 {
    margin-top: 0.5rem !important;
  }
  .mt-sm-3 {
    margin-top: 1rem !important;
  }
  .mt-sm-4 {
    margin-top: 1.5rem !important;
  }
  .mt-sm-5 {
    margin-top: 2rem !important;
  }
  .mt-sm-6 {
    margin-top: 2.5rem !important;
  }
  .mt-sm-7 {
    margin-top: 3rem !important;
  }
  .mt-sm-8 {
    margin-top: 3.5rem !important;
  }
  .mt-sm-9 {
    margin-top: 4rem !important;
  }
  .mt-sm-10 {
    margin-top: 4.5rem !important;
  }
  .mt-sm-auto {
    margin-top: auto !important;
  }
  .me-sm-0 {
    margin-right: 0 !important;
  }
  .me-sm-1 {
    margin-right: 0.25rem !important;
  }
  .me-sm-2 {
    margin-right: 0.5rem !important;
  }
  .me-sm-3 {
    margin-right: 1rem !important;
  }
  .me-sm-4 {
    margin-right: 1.5rem !important;
  }
  .me-sm-5 {
    margin-right: 2rem !important;
  }
  .me-sm-6 {
    margin-right: 2.5rem !important;
  }
  .me-sm-7 {
    margin-right: 3rem !important;
  }
  .me-sm-8 {
    margin-right: 3.5rem !important;
  }
  .me-sm-9 {
    margin-right: 4rem !important;
  }
  .me-sm-10 {
    margin-right: 4.5rem !important;
  }
  .me-sm-auto {
    margin-right: auto !important;
  }
  .mb-sm-0 {
    margin-bottom: 0 !important;
  }
  .mb-sm-1 {
    margin-bottom: 0.25rem !important;
  }
  .mb-sm-2 {
    margin-bottom: 0.5rem !important;
  }
  .mb-sm-3 {
    margin-bottom: 1rem !important;
  }
  .mb-sm-4 {
    margin-bottom: 1.5rem !important;
  }
  .mb-sm-5 {
    margin-bottom: 2rem !important;
  }
  .mb-sm-6 {
    margin-bottom: 2.5rem !important;
  }
  .mb-sm-7 {
    margin-bottom: 3rem !important;
  }
  .mb-sm-8 {
    margin-bottom: 3.5rem !important;
  }
  .mb-sm-9 {
    margin-bottom: 4rem !important;
  }
  .mb-sm-10 {
    margin-bottom: 4.5rem !important;
  }
  .mb-sm-auto {
    margin-bottom: auto !important;
  }
  .ms-sm-0 {
    margin-left: 0 !important;
  }
  .ms-sm-1 {
    margin-left: 0.25rem !important;
  }
  .ms-sm-2 {
    margin-left: 0.5rem !important;
  }
  .ms-sm-3 {
    margin-left: 1rem !important;
  }
  .ms-sm-4 {
    margin-left: 1.5rem !important;
  }
  .ms-sm-5 {
    margin-left: 2rem !important;
  }
  .ms-sm-6 {
    margin-left: 2.5rem !important;
  }
  .ms-sm-7 {
    margin-left: 3rem !important;
  }
  .ms-sm-8 {
    margin-left: 3.5rem !important;
  }
  .ms-sm-9 {
    margin-left: 4rem !important;
  }
  .ms-sm-10 {
    margin-left: 4.5rem !important;
  }
  .ms-sm-auto {
    margin-left: auto !important;
  }
  .m-sm-n1 {
    margin: -0.25rem !important;
  }
  .m-sm-n2 {
    margin: -0.5rem !important;
  }
  .m-sm-n3 {
    margin: -1rem !important;
  }
  .m-sm-n4 {
    margin: -1.5rem !important;
  }
  .m-sm-n5 {
    margin: -2rem !important;
  }
  .m-sm-n6 {
    margin: -2.5rem !important;
  }
  .m-sm-n7 {
    margin: -3rem !important;
  }
  .m-sm-n8 {
    margin: -3.5rem !important;
  }
  .m-sm-n9 {
    margin: -4rem !important;
  }
  .m-sm-n10 {
    margin: -4.5rem !important;
  }
  .mx-sm-n1 {
    margin-right: -0.25rem !important;
    margin-left: -0.25rem !important;
  }
  .mx-sm-n2 {
    margin-right: -0.5rem !important;
    margin-left: -0.5rem !important;
  }
  .mx-sm-n3 {
    margin-right: -1rem !important;
    margin-left: -1rem !important;
  }
  .mx-sm-n4 {
    margin-right: -1.5rem !important;
    margin-left: -1.5rem !important;
  }
  .mx-sm-n5 {
    margin-right: -2rem !important;
    margin-left: -2rem !important;
  }
  .mx-sm-n6 {
    margin-right: -2.5rem !important;
    margin-left: -2.5rem !important;
  }
  .mx-sm-n7 {
    margin-right: -3rem !important;
    margin-left: -3rem !important;
  }
  .mx-sm-n8 {
    margin-right: -3.5rem !important;
    margin-left: -3.5rem !important;
  }
  .mx-sm-n9 {
    margin-right: -4rem !important;
    margin-left: -4rem !important;
  }
  .mx-sm-n10 {
    margin-right: -4.5rem !important;
    margin-left: -4.5rem !important;
  }
  .my-sm-n1 {
    margin-top: -0.25rem !important;
    margin-bottom: -0.25rem !important;
  }
  .my-sm-n2 {
    margin-top: -0.5rem !important;
    margin-bottom: -0.5rem !important;
  }
  .my-sm-n3 {
    margin-top: -1rem !important;
    margin-bottom: -1rem !important;
  }
  .my-sm-n4 {
    margin-top: -1.5rem !important;
    margin-bottom: -1.5rem !important;
  }
  .my-sm-n5 {
    margin-top: -2rem !important;
    margin-bottom: -2rem !important;
  }
  .my-sm-n6 {
    margin-top: -2.5rem !important;
    margin-bottom: -2.5rem !important;
  }
  .my-sm-n7 {
    margin-top: -3rem !important;
    margin-bottom: -3rem !important;
  }
  .my-sm-n8 {
    margin-top: -3.5rem !important;
    margin-bottom: -3.5rem !important;
  }
  .my-sm-n9 {
    margin-top: -4rem !important;
    margin-bottom: -4rem !important;
  }
  .my-sm-n10 {
    margin-top: -4.5rem !important;
    margin-bottom: -4.5rem !important;
  }
  .mt-sm-n1 {
    margin-top: -0.25rem !important;
  }
  .mt-sm-n2 {
    margin-top: -0.5rem !important;
  }
  .mt-sm-n3 {
    margin-top: -1rem !important;
  }
  .mt-sm-n4 {
    margin-top: -1.5rem !important;
  }
  .mt-sm-n5 {
    margin-top: -2rem !important;
  }
  .mt-sm-n6 {
    margin-top: -2.5rem !important;
  }
  .mt-sm-n7 {
    margin-top: -3rem !important;
  }
  .mt-sm-n8 {
    margin-top: -3.5rem !important;
  }
  .mt-sm-n9 {
    margin-top: -4rem !important;
  }
  .mt-sm-n10 {
    margin-top: -4.5rem !important;
  }
  .me-sm-n1 {
    margin-right: -0.25rem !important;
  }
  .me-sm-n2 {
    margin-right: -0.5rem !important;
  }
  .me-sm-n3 {
    margin-right: -1rem !important;
  }
  .me-sm-n4 {
    margin-right: -1.5rem !important;
  }
  .me-sm-n5 {
    margin-right: -2rem !important;
  }
  .me-sm-n6 {
    margin-right: -2.5rem !important;
  }
  .me-sm-n7 {
    margin-right: -3rem !important;
  }
  .me-sm-n8 {
    margin-right: -3.5rem !important;
  }
  .me-sm-n9 {
    margin-right: -4rem !important;
  }
  .me-sm-n10 {
    margin-right: -4.5rem !important;
  }
  .mb-sm-n1 {
    margin-bottom: -0.25rem !important;
  }
  .mb-sm-n2 {
    margin-bottom: -0.5rem !important;
  }
  .mb-sm-n3 {
    margin-bottom: -1rem !important;
  }
  .mb-sm-n4 {
    margin-bottom: -1.5rem !important;
  }
  .mb-sm-n5 {
    margin-bottom: -2rem !important;
  }
  .mb-sm-n6 {
    margin-bottom: -2.5rem !important;
  }
  .mb-sm-n7 {
    margin-bottom: -3rem !important;
  }
  .mb-sm-n8 {
    margin-bottom: -3.5rem !important;
  }
  .mb-sm-n9 {
    margin-bottom: -4rem !important;
  }
  .mb-sm-n10 {
    margin-bottom: -4.5rem !important;
  }
  .ms-sm-n1 {
    margin-left: -0.25rem !important;
  }
  .ms-sm-n2 {
    margin-left: -0.5rem !important;
  }
  .ms-sm-n3 {
    margin-left: -1rem !important;
  }
  .ms-sm-n4 {
    margin-left: -1.5rem !important;
  }
  .ms-sm-n5 {
    margin-left: -2rem !important;
  }
  .ms-sm-n6 {
    margin-left: -2.5rem !important;
  }
  .ms-sm-n7 {
    margin-left: -3rem !important;
  }
  .ms-sm-n8 {
    margin-left: -3.5rem !important;
  }
  .ms-sm-n9 {
    margin-left: -4rem !important;
  }
  .ms-sm-n10 {
    margin-left: -4.5rem !important;
  }
  .p-sm-0 {
    padding: 0 !important;
  }
  .p-sm-1 {
    padding: 0.25rem !important;
  }
  .p-sm-2 {
    padding: 0.5rem !important;
  }
  .p-sm-3 {
    padding: 1rem !important;
  }
  .p-sm-4 {
    padding: 1.5rem !important;
  }
  .p-sm-5 {
    padding: 2rem !important;
  }
  .p-sm-6 {
    padding: 2.5rem !important;
  }
  .p-sm-7 {
    padding: 3rem !important;
  }
  .p-sm-8 {
    padding: 3.5rem !important;
  }
  .p-sm-9 {
    padding: 4rem !important;
  }
  .p-sm-10 {
    padding: 4.5rem !important;
  }
  .px-sm-0 {
    padding-right: 0 !important;
    padding-left: 0 !important;
  }
  .px-sm-1 {
    padding-right: 0.25rem !important;
    padding-left: 0.25rem !important;
  }
  .px-sm-2 {
    padding-right: 0.5rem !important;
    padding-left: 0.5rem !important;
  }
  .px-sm-3 {
    padding-right: 1rem !important;
    padding-left: 1rem !important;
  }
  .px-sm-4 {
    padding-right: 1.5rem !important;
    padding-left: 1.5rem !important;
  }
  .px-sm-5 {
    padding-right: 2rem !important;
    padding-left: 2rem !important;
  }
  .px-sm-6 {
    padding-right: 2.5rem !important;
    padding-left: 2.5rem !important;
  }
  .px-sm-7 {
    padding-right: 3rem !important;
    padding-left: 3rem !important;
  }
  .px-sm-8 {
    padding-right: 3.5rem !important;
    padding-left: 3.5rem !important;
  }
  .px-sm-9 {
    padding-right: 4rem !important;
    padding-left: 4rem !important;
  }
  .px-sm-10 {
    padding-right: 4.5rem !important;
    padding-left: 4.5rem !important;
  }
  .py-sm-0 {
    padding-top: 0 !important;
    padding-bottom: 0 !important;
  }
  .py-sm-1 {
    padding-top: 0.25rem !important;
    padding-bottom: 0.25rem !important;
  }
  .py-sm-2 {
    padding-top: 0.5rem !important;
    padding-bottom: 0.5rem !important;
  }
  .py-sm-3 {
    padding-top: 1rem !important;
    padding-bottom: 1rem !important;
  }
  .py-sm-4 {
    padding-top: 1.5rem !important;
    padding-bottom: 1.5rem !important;
  }
  .py-sm-5 {
    padding-top: 2rem !important;
    padding-bottom: 2rem !important;
  }
  .py-sm-6 {
    padding-top: 2.5rem !important;
    padding-bottom: 2.5rem !important;
  }
  .py-sm-7 {
    padding-top: 3rem !important;
    padding-bottom: 3rem !important;
  }
  .py-sm-8 {
    padding-top: 3.5rem !important;
    padding-bottom: 3.5rem !important;
  }
  .py-sm-9 {
    padding-top: 4rem !important;
    padding-bottom: 4rem !important;
  }
  .py-sm-10 {
    padding-top: 4.5rem !important;
    padding-bottom: 4.5rem !important;
  }
  .pt-sm-0 {
    padding-top: 0 !important;
  }
  .pt-sm-1 {
    padding-top: 0.25rem !important;
  }
  .pt-sm-2 {
    padding-top: 0.5rem !important;
  }
  .pt-sm-3 {
    padding-top: 1rem !important;
  }
  .pt-sm-4 {
    padding-top: 1.5rem !important;
  }
  .pt-sm-5 {
    padding-top: 2rem !important;
  }
  .pt-sm-6 {
    padding-top: 2.5rem !important;
  }
  .pt-sm-7 {
    padding-top: 3rem !important;
  }
  .pt-sm-8 {
    padding-top: 3.5rem !important;
  }
  .pt-sm-9 {
    padding-top: 4rem !important;
  }
  .pt-sm-10 {
    padding-top: 4.5rem !important;
  }
  .pe-sm-0 {
    padding-right: 0 !important;
  }
  .pe-sm-1 {
    padding-right: 0.25rem !important;
  }
  .pe-sm-2 {
    padding-right: 0.5rem !important;
  }
  .pe-sm-3 {
    padding-right: 1rem !important;
  }
  .pe-sm-4 {
    padding-right: 1.5rem !important;
  }
  .pe-sm-5 {
    padding-right: 2rem !important;
  }
  .pe-sm-6 {
    padding-right: 2.5rem !important;
  }
  .pe-sm-7 {
    padding-right: 3rem !important;
  }
  .pe-sm-8 {
    padding-right: 3.5rem !important;
  }
  .pe-sm-9 {
    padding-right: 4rem !important;
  }
  .pe-sm-10 {
    padding-right: 4.5rem !important;
  }
  .pb-sm-0 {
    padding-bottom: 0 !important;
  }
  .pb-sm-1 {
    padding-bottom: 0.25rem !important;
  }
  .pb-sm-2 {
    padding-bottom: 0.5rem !important;
  }
  .pb-sm-3 {
    padding-bottom: 1rem !important;
  }
  .pb-sm-4 {
    padding-bottom: 1.5rem !important;
  }
  .pb-sm-5 {
    padding-bottom: 2rem !important;
  }
  .pb-sm-6 {
    padding-bottom: 2.5rem !important;
  }
  .pb-sm-7 {
    padding-bottom: 3rem !important;
  }
  .pb-sm-8 {
    padding-bottom: 3.5rem !important;
  }
  .pb-sm-9 {
    padding-bottom: 4rem !important;
  }
  .pb-sm-10 {
    padding-bottom: 4.5rem !important;
  }
  .ps-sm-0 {
    padding-left: 0 !important;
  }
  .ps-sm-1 {
    padding-left: 0.25rem !important;
  }
  .ps-sm-2 {
    padding-left: 0.5rem !important;
  }
  .ps-sm-3 {
    padding-left: 1rem !important;
  }
  .ps-sm-4 {
    padding-left: 1.5rem !important;
  }
  .ps-sm-5 {
    padding-left: 2rem !important;
  }
  .ps-sm-6 {
    padding-left: 2.5rem !important;
  }
  .ps-sm-7 {
    padding-left: 3rem !important;
  }
  .ps-sm-8 {
    padding-left: 3.5rem !important;
  }
  .ps-sm-9 {
    padding-left: 4rem !important;
  }
  .ps-sm-10 {
    padding-left: 4.5rem !important;
  }
  .gap-sm-0 {
    gap: 0 !important;
  }
  .gap-sm-1 {
    gap: 0.25rem !important;
  }
  .gap-sm-2 {
    gap: 0.5rem !important;
  }
  .gap-sm-3 {
    gap: 1rem !important;
  }
  .gap-sm-4 {
    gap: 1.5rem !important;
  }
  .gap-sm-5 {
    gap: 2rem !important;
  }
  .gap-sm-6 {
    gap: 2.5rem !important;
  }
  .gap-sm-7 {
    gap: 3rem !important;
  }
  .gap-sm-8 {
    gap: 3.5rem !important;
  }
  .gap-sm-9 {
    gap: 4rem !important;
  }
  .gap-sm-10 {
    gap: 4.5rem !important;
  }
  .row-gap-sm-0 {
    row-gap: 0 !important;
  }
  .row-gap-sm-1 {
    row-gap: 0.25rem !important;
  }
  .row-gap-sm-2 {
    row-gap: 0.5rem !important;
  }
  .row-gap-sm-3 {
    row-gap: 1rem !important;
  }
  .row-gap-sm-4 {
    row-gap: 1.5rem !important;
  }
  .row-gap-sm-5 {
    row-gap: 2rem !important;
  }
  .row-gap-sm-6 {
    row-gap: 2.5rem !important;
  }
  .row-gap-sm-7 {
    row-gap: 3rem !important;
  }
  .row-gap-sm-8 {
    row-gap: 3.5rem !important;
  }
  .row-gap-sm-9 {
    row-gap: 4rem !important;
  }
  .row-gap-sm-10 {
    row-gap: 4.5rem !important;
  }
  .column-gap-sm-0 {
    column-gap: 0 !important;
  }
  .column-gap-sm-1 {
    column-gap: 0.25rem !important;
  }
  .column-gap-sm-2 {
    column-gap: 0.5rem !important;
  }
  .column-gap-sm-3 {
    column-gap: 1rem !important;
  }
  .column-gap-sm-4 {
    column-gap: 1.5rem !important;
  }
  .column-gap-sm-5 {
    column-gap: 2rem !important;
  }
  .column-gap-sm-6 {
    column-gap: 2.5rem !important;
  }
  .column-gap-sm-7 {
    column-gap: 3rem !important;
  }
  .column-gap-sm-8 {
    column-gap: 3.5rem !important;
  }
  .column-gap-sm-9 {
    column-gap: 4rem !important;
  }
  .column-gap-sm-10 {
    column-gap: 4.5rem !important;
  }
  .text-sm-start {
    text-align: left !important;
  }
  .text-sm-end {
    text-align: right !important;
  }
  .text-sm-center {
    text-align: center !important;
  }
  .content-space-t-sm-0 {
    padding-top: 0 !important;
  }
  .content-space-t-sm-1 {
    padding-top: 3.5rem !important;
  }
  .content-space-t-sm-2 {
    padding-top: 5rem !important;
  }
  .content-space-t-sm-3 {
    padding-top: 7.5rem !important;
  }
  .content-space-t-sm-4 {
    padding-top: 10rem !important;
  }
  .content-space-t-sm-auto {
    padding-top: auto !important;
  }
  .content-space-b-sm-0 {
    padding-bottom: 0 !important;
  }
  .content-space-b-sm-1 {
    padding-bottom: 3.5rem !important;
  }
  .content-space-b-sm-2 {
    padding-bottom: 5rem !important;
  }
  .content-space-b-sm-3 {
    padding-bottom: 7.5rem !important;
  }
  .content-space-b-sm-4 {
    padding-bottom: 10rem !important;
  }
  .content-space-b-sm-auto {
    padding-bottom: auto !important;
  }
  .content-space-sm-0 {
    padding-top: 0 !important;
    padding-bottom: 0 !important;
  }
  .content-space-sm-1 {
    padding-top: 3.5rem !important;
    padding-bottom: 3.5rem !important;
  }
  .content-space-sm-2 {
    padding-top: 5rem !important;
    padding-bottom: 5rem !important;
  }
  .content-space-sm-3 {
    padding-top: 7.5rem !important;
    padding-bottom: 7.5rem !important;
  }
  .content-space-sm-4 {
    padding-top: 10rem !important;
    padding-bottom: 10rem !important;
  }
  .content-space-sm-auto {
    padding-top: auto !important;
    padding-bottom: auto !important;
  }
}
@media (min-width: 768px) {
  .float-md-start {
    float: left !important;
  }
  .float-md-end {
    float: right !important;
  }
  .float-md-none {
    float: none !important;
  }
  .object-fit-md-contain {
    object-fit: contain !important;
  }
  .object-fit-md-cover {
    object-fit: cover !important;
  }
  .object-fit-md-fill {
    object-fit: fill !important;
  }
  .object-fit-md-scale {
    object-fit: scale-down !important;
  }
  .object-fit-md-none {
    object-fit: none !important;
  }
  .d-md-inline {
    display: inline !important;
  }
  .d-md-inline-block {
    display: inline-block !important;
  }
  .d-md-block {
    display: block !important;
  }
  .d-md-grid {
    display: grid !important;
  }
  .d-md-inline-grid {
    display: inline-grid !important;
  }
  .d-md-table {
    display: table !important;
  }
  .d-md-table-row {
    display: table-row !important;
  }
  .d-md-table-cell {
    display: table-cell !important;
  }
  .d-md-flex {
    display: flex !important;
  }
  .d-md-inline-flex {
    display: inline-flex !important;
  }
  .d-md-none {
    display: none !important;
  }
  .position-md-static {
    position: static !important;
  }
  .position-md-relative {
    position: relative !important;
  }
  .position-md-absolute {
    position: absolute !important;
  }
  .position-md-fixed {
    position: fixed !important;
  }
  .position-md-sticky {
    position: sticky !important;
  }
  .top-md-0 {
    top: 0 !important;
  }
  .top-md-50 {
    top: 50% !important;
  }
  .top-md-100 {
    top: 100% !important;
  }
  .top-md-auto {
    top: auto !important;
  }
  .bottom-md-0 {
    bottom: 0 !important;
  }
  .bottom-md-50 {
    bottom: 50% !important;
  }
  .bottom-md-100 {
    bottom: 100% !important;
  }
  .bottom-md-auto {
    bottom: auto !important;
  }
  .start-md-0 {
    left: 0 !important;
  }
  .start-md-50 {
    left: 50% !important;
  }
  .start-md-100 {
    left: 100% !important;
  }
  .start-md-auto {
    left: auto !important;
  }
  .end-md-0 {
    right: 0 !important;
  }
  .end-md-50 {
    right: 50% !important;
  }
  .end-md-100 {
    right: 100% !important;
  }
  .end-md-auto {
    right: auto !important;
  }
  .translate-middle-md {
    transform: translate(-50%, -50%) !important;
  }
  .translate-middle-md-x {
    transform: translateX(-50%) !important;
  }
  .translate-middle-md-y {
    transform: translateY(-50%) !important;
  }
  .w-md-25 {
    width: 25% !important;
  }
  .w-md-50 {
    width: 50% !important;
  }
  .w-md-75 {
    width: 75% !important;
  }
  .w-md-100 {
    width: 100% !important;
  }
  .w-md-auto {
    width: auto !important;
  }
  .w-md-65 {
    width: 65% !important;
  }
  .w-md-85 {
    width: 85% !important;
  }
  .h-md-25 {
    height: 25% !important;
  }
  .h-md-50 {
    height: 50% !important;
  }
  .h-md-75 {
    height: 75% !important;
  }
  .h-md-100 {
    height: 100% !important;
  }
  .h-md-auto {
    height: auto !important;
  }
  .h-md-65 {
    height: 65% !important;
  }
  .vh-md-100 {
    height: 100vh !important;
  }
  .min-vh-md-100 {
    min-height: 100vh !important;
  }
  .min-vh-md-35 {
    min-height: 35vh !important;
  }
  .min-vh-md-75 {
    min-height: 75vh !important;
  }
  .flex-md-fill {
    flex: 1 1 auto !important;
  }
  .flex-md-row {
    flex-direction: row !important;
  }
  .flex-md-column {
    flex-direction: column !important;
  }
  .flex-md-row-reverse {
    flex-direction: row-reverse !important;
  }
  .flex-md-column-reverse {
    flex-direction: column-reverse !important;
  }
  .flex-md-grow-0 {
    flex-grow: 0 !important;
  }
  .flex-md-grow-1 {
    flex-grow: 1 !important;
  }
  .flex-md-shrink-0 {
    flex-shrink: 0 !important;
  }
  .flex-md-shrink-1 {
    flex-shrink: 1 !important;
  }
  .flex-md-wrap {
    flex-wrap: wrap !important;
  }
  .flex-md-nowrap {
    flex-wrap: nowrap !important;
  }
  .flex-md-wrap-reverse {
    flex-wrap: wrap-reverse !important;
  }
  .justify-content-md-start {
    justify-content: flex-start !important;
  }
  .justify-content-md-end {
    justify-content: flex-end !important;
  }
  .justify-content-md-center {
    justify-content: center !important;
  }
  .justify-content-md-between {
    justify-content: space-between !important;
  }
  .justify-content-md-around {
    justify-content: space-around !important;
  }
  .justify-content-md-evenly {
    justify-content: space-evenly !important;
  }
  .align-items-md-start {
    align-items: flex-start !important;
  }
  .align-items-md-end {
    align-items: flex-end !important;
  }
  .align-items-md-center {
    align-items: center !important;
  }
  .align-items-md-baseline {
    align-items: baseline !important;
  }
  .align-items-md-stretch {
    align-items: stretch !important;
  }
  .align-content-md-start {
    align-content: flex-start !important;
  }
  .align-content-md-end {
    align-content: flex-end !important;
  }
  .align-content-md-center {
    align-content: center !important;
  }
  .align-content-md-between {
    align-content: space-between !important;
  }
  .align-content-md-around {
    align-content: space-around !important;
  }
  .align-content-md-stretch {
    align-content: stretch !important;
  }
  .align-self-md-auto {
    align-self: auto !important;
  }
  .align-self-md-start {
    align-self: flex-start !important;
  }
  .align-self-md-end {
    align-self: flex-end !important;
  }
  .align-self-md-center {
    align-self: center !important;
  }
  .align-self-md-baseline {
    align-self: baseline !important;
  }
  .align-self-md-stretch {
    align-self: stretch !important;
  }
  .order-md-first {
    order: -1 !important;
  }
  .order-md-0 {
    order: 0 !important;
  }
  .order-md-1 {
    order: 1 !important;
  }
  .order-md-2 {
    order: 2 !important;
  }
  .order-md-3 {
    order: 3 !important;
  }
  .order-md-4 {
    order: 4 !important;
  }
  .order-md-5 {
    order: 5 !important;
  }
  .order-md-last {
    order: 6 !important;
  }
  .m-md-0 {
    margin: 0 !important;
  }
  .m-md-1 {
    margin: 0.25rem !important;
  }
  .m-md-2 {
    margin: 0.5rem !important;
  }
  .m-md-3 {
    margin: 1rem !important;
  }
  .m-md-4 {
    margin: 1.5rem !important;
  }
  .m-md-5 {
    margin: 2rem !important;
  }
  .m-md-6 {
    margin: 2.5rem !important;
  }
  .m-md-7 {
    margin: 3rem !important;
  }
  .m-md-8 {
    margin: 3.5rem !important;
  }
  .m-md-9 {
    margin: 4rem !important;
  }
  .m-md-10 {
    margin: 4.5rem !important;
  }
  .m-md-auto {
    margin: auto !important;
  }
  .mx-md-0 {
    margin-right: 0 !important;
    margin-left: 0 !important;
  }
  .mx-md-1 {
    margin-right: 0.25rem !important;
    margin-left: 0.25rem !important;
  }
  .mx-md-2 {
    margin-right: 0.5rem !important;
    margin-left: 0.5rem !important;
  }
  .mx-md-3 {
    margin-right: 1rem !important;
    margin-left: 1rem !important;
  }
  .mx-md-4 {
    margin-right: 1.5rem !important;
    margin-left: 1.5rem !important;
  }
  .mx-md-5 {
    margin-right: 2rem !important;
    margin-left: 2rem !important;
  }
  .mx-md-6 {
    margin-right: 2.5rem !important;
    margin-left: 2.5rem !important;
  }
  .mx-md-7 {
    margin-right: 3rem !important;
    margin-left: 3rem !important;
  }
  .mx-md-8 {
    margin-right: 3.5rem !important;
    margin-left: 3.5rem !important;
  }
  .mx-md-9 {
    margin-right: 4rem !important;
    margin-left: 4rem !important;
  }
  .mx-md-10 {
    margin-right: 4.5rem !important;
    margin-left: 4.5rem !important;
  }
  .mx-md-auto {
    margin-right: auto !important;
    margin-left: auto !important;
  }
  .my-md-0 {
    margin-top: 0 !important;
    margin-bottom: 0 !important;
  }
  .my-md-1 {
    margin-top: 0.25rem !important;
    margin-bottom: 0.25rem !important;
  }
  .my-md-2 {
    margin-top: 0.5rem !important;
    margin-bottom: 0.5rem !important;
  }
  .my-md-3 {
    margin-top: 1rem !important;
    margin-bottom: 1rem !important;
  }
  .my-md-4 {
    margin-top: 1.5rem !important;
    margin-bottom: 1.5rem !important;
  }
  .my-md-5 {
    margin-top: 2rem !important;
    margin-bottom: 2rem !important;
  }
  .my-md-6 {
    margin-top: 2.5rem !important;
    margin-bottom: 2.5rem !important;
  }
  .my-md-7 {
    margin-top: 3rem !important;
    margin-bottom: 3rem !important;
  }
  .my-md-8 {
    margin-top: 3.5rem !important;
    margin-bottom: 3.5rem !important;
  }
  .my-md-9 {
    margin-top: 4rem !important;
    margin-bottom: 4rem !important;
  }
  .my-md-10 {
    margin-top: 4.5rem !important;
    margin-bottom: 4.5rem !important;
  }
  .my-md-auto {
    margin-top: auto !important;
    margin-bottom: auto !important;
  }
  .mt-md-0 {
    margin-top: 0 !important;
  }
  .mt-md-1 {
    margin-top: 0.25rem !important;
  }
  .mt-md-2 {
    margin-top: 0.5rem !important;
  }
  .mt-md-3 {
    margin-top: 1rem !important;
  }
  .mt-md-4 {
    margin-top: 1.5rem !important;
  }
  .mt-md-5 {
    margin-top: 2rem !important;
  }
  .mt-md-6 {
    margin-top: 2.5rem !important;
  }
  .mt-md-7 {
    margin-top: 3rem !important;
  }
  .mt-md-8 {
    margin-top: 3.5rem !important;
  }
  .mt-md-9 {
    margin-top: 4rem !important;
  }
  .mt-md-10 {
    margin-top: 4.5rem !important;
  }
  .mt-md-auto {
    margin-top: auto !important;
  }
  .me-md-0 {
    margin-right: 0 !important;
  }
  .me-md-1 {
    margin-right: 0.25rem !important;
  }
  .me-md-2 {
    margin-right: 0.5rem !important;
  }
  .me-md-3 {
    margin-right: 1rem !important;
  }
  .me-md-4 {
    margin-right: 1.5rem !important;
  }
  .me-md-5 {
    margin-right: 2rem !important;
  }
  .me-md-6 {
    margin-right: 2.5rem !important;
  }
  .me-md-7 {
    margin-right: 3rem !important;
  }
  .me-md-8 {
    margin-right: 3.5rem !important;
  }
  .me-md-9 {
    margin-right: 4rem !important;
  }
  .me-md-10 {
    margin-right: 4.5rem !important;
  }
  .me-md-auto {
    margin-right: auto !important;
  }
  .mb-md-0 {
    margin-bottom: 0 !important;
  }
  .mb-md-1 {
    margin-bottom: 0.25rem !important;
  }
  .mb-md-2 {
    margin-bottom: 0.5rem !important;
  }
  .mb-md-3 {
    margin-bottom: 1rem !important;
  }
  .mb-md-4 {
    margin-bottom: 1.5rem !important;
  }
  .mb-md-5 {
    margin-bottom: 2rem !important;
  }
  .mb-md-6 {
    margin-bottom: 2.5rem !important;
  }
  .mb-md-7 {
    margin-bottom: 3rem !important;
  }
  .mb-md-8 {
    margin-bottom: 3.5rem !important;
  }
  .mb-md-9 {
    margin-bottom: 4rem !important;
  }
  .mb-md-10 {
    margin-bottom: 4.5rem !important;
  }
  .mb-md-auto {
    margin-bottom: auto !important;
  }
  .ms-md-0 {
    margin-left: 0 !important;
  }
  .ms-md-1 {
    margin-left: 0.25rem !important;
  }
  .ms-md-2 {
    margin-left: 0.5rem !important;
  }
  .ms-md-3 {
    margin-left: 1rem !important;
  }
  .ms-md-4 {
    margin-left: 1.5rem !important;
  }
  .ms-md-5 {
    margin-left: 2rem !important;
  }
  .ms-md-6 {
    margin-left: 2.5rem !important;
  }
  .ms-md-7 {
    margin-left: 3rem !important;
  }
  .ms-md-8 {
    margin-left: 3.5rem !important;
  }
  .ms-md-9 {
    margin-left: 4rem !important;
  }
  .ms-md-10 {
    margin-left: 4.5rem !important;
  }
  .ms-md-auto {
    margin-left: auto !important;
  }
  .m-md-n1 {
    margin: -0.25rem !important;
  }
  .m-md-n2 {
    margin: -0.5rem !important;
  }
  .m-md-n3 {
    margin: -1rem !important;
  }
  .m-md-n4 {
    margin: -1.5rem !important;
  }
  .m-md-n5 {
    margin: -2rem !important;
  }
  .m-md-n6 {
    margin: -2.5rem !important;
  }
  .m-md-n7 {
    margin: -3rem !important;
  }
  .m-md-n8 {
    margin: -3.5rem !important;
  }
  .m-md-n9 {
    margin: -4rem !important;
  }
  .m-md-n10 {
    margin: -4.5rem !important;
  }
  .mx-md-n1 {
    margin-right: -0.25rem !important;
    margin-left: -0.25rem !important;
  }
  .mx-md-n2 {
    margin-right: -0.5rem !important;
    margin-left: -0.5rem !important;
  }
  .mx-md-n3 {
    margin-right: -1rem !important;
    margin-left: -1rem !important;
  }
  .mx-md-n4 {
    margin-right: -1.5rem !important;
    margin-left: -1.5rem !important;
  }
  .mx-md-n5 {
    margin-right: -2rem !important;
    margin-left: -2rem !important;
  }
  .mx-md-n6 {
    margin-right: -2.5rem !important;
    margin-left: -2.5rem !important;
  }
  .mx-md-n7 {
    margin-right: -3rem !important;
    margin-left: -3rem !important;
  }
  .mx-md-n8 {
    margin-right: -3.5rem !important;
    margin-left: -3.5rem !important;
  }
  .mx-md-n9 {
    margin-right: -4rem !important;
    margin-left: -4rem !important;
  }
  .mx-md-n10 {
    margin-right: -4.5rem !important;
    margin-left: -4.5rem !important;
  }
  .my-md-n1 {
    margin-top: -0.25rem !important;
    margin-bottom: -0.25rem !important;
  }
  .my-md-n2 {
    margin-top: -0.5rem !important;
    margin-bottom: -0.5rem !important;
  }
  .my-md-n3 {
    margin-top: -1rem !important;
    margin-bottom: -1rem !important;
  }
  .my-md-n4 {
    margin-top: -1.5rem !important;
    margin-bottom: -1.5rem !important;
  }
  .my-md-n5 {
    margin-top: -2rem !important;
    margin-bottom: -2rem !important;
  }
  .my-md-n6 {
    margin-top: -2.5rem !important;
    margin-bottom: -2.5rem !important;
  }
  .my-md-n7 {
    margin-top: -3rem !important;
    margin-bottom: -3rem !important;
  }
  .my-md-n8 {
    margin-top: -3.5rem !important;
    margin-bottom: -3.5rem !important;
  }
  .my-md-n9 {
    margin-top: -4rem !important;
    margin-bottom: -4rem !important;
  }
  .my-md-n10 {
    margin-top: -4.5rem !important;
    margin-bottom: -4.5rem !important;
  }
  .mt-md-n1 {
    margin-top: -0.25rem !important;
  }
  .mt-md-n2 {
    margin-top: -0.5rem !important;
  }
  .mt-md-n3 {
    margin-top: -1rem !important;
  }
  .mt-md-n4 {
    margin-top: -1.5rem !important;
  }
  .mt-md-n5 {
    margin-top: -2rem !important;
  }
  .mt-md-n6 {
    margin-top: -2.5rem !important;
  }
  .mt-md-n7 {
    margin-top: -3rem !important;
  }
  .mt-md-n8 {
    margin-top: -3.5rem !important;
  }
  .mt-md-n9 {
    margin-top: -4rem !important;
  }
  .mt-md-n10 {
    margin-top: -4.5rem !important;
  }
  .me-md-n1 {
    margin-right: -0.25rem !important;
  }
  .me-md-n2 {
    margin-right: -0.5rem !important;
  }
  .me-md-n3 {
    margin-right: -1rem !important;
  }
  .me-md-n4 {
    margin-right: -1.5rem !important;
  }
  .me-md-n5 {
    margin-right: -2rem !important;
  }
  .me-md-n6 {
    margin-right: -2.5rem !important;
  }
  .me-md-n7 {
    margin-right: -3rem !important;
  }
  .me-md-n8 {
    margin-right: -3.5rem !important;
  }
  .me-md-n9 {
    margin-right: -4rem !important;
  }
  .me-md-n10 {
    margin-right: -4.5rem !important;
  }
  .mb-md-n1 {
    margin-bottom: -0.25rem !important;
  }
  .mb-md-n2 {
    margin-bottom: -0.5rem !important;
  }
  .mb-md-n3 {
    margin-bottom: -1rem !important;
  }
  .mb-md-n4 {
    margin-bottom: -1.5rem !important;
  }
  .mb-md-n5 {
    margin-bottom: -2rem !important;
  }
  .mb-md-n6 {
    margin-bottom: -2.5rem !important;
  }
  .mb-md-n7 {
    margin-bottom: -3rem !important;
  }
  .mb-md-n8 {
    margin-bottom: -3.5rem !important;
  }
  .mb-md-n9 {
    margin-bottom: -4rem !important;
  }
  .mb-md-n10 {
    margin-bottom: -4.5rem !important;
  }
  .ms-md-n1 {
    margin-left: -0.25rem !important;
  }
  .ms-md-n2 {
    margin-left: -0.5rem !important;
  }
  .ms-md-n3 {
    margin-left: -1rem !important;
  }
  .ms-md-n4 {
    margin-left: -1.5rem !important;
  }
  .ms-md-n5 {
    margin-left: -2rem !important;
  }
  .ms-md-n6 {
    margin-left: -2.5rem !important;
  }
  .ms-md-n7 {
    margin-left: -3rem !important;
  }
  .ms-md-n8 {
    margin-left: -3.5rem !important;
  }
  .ms-md-n9 {
    margin-left: -4rem !important;
  }
  .ms-md-n10 {
    margin-left: -4.5rem !important;
  }
  .p-md-0 {
    padding: 0 !important;
  }
  .p-md-1 {
    padding: 0.25rem !important;
  }
  .p-md-2 {
    padding: 0.5rem !important;
  }
  .p-md-3 {
    padding: 1rem !important;
  }
  .p-md-4 {
    padding: 1.5rem !important;
  }
  .p-md-5 {
    padding: 2rem !important;
  }
  .p-md-6 {
    padding: 2.5rem !important;
  }
  .p-md-7 {
    padding: 3rem !important;
  }
  .p-md-8 {
    padding: 3.5rem !important;
  }
  .p-md-9 {
    padding: 4rem !important;
  }
  .p-md-10 {
    padding: 4.5rem !important;
  }
  .px-md-0 {
    padding-right: 0 !important;
    padding-left: 0 !important;
  }
  .px-md-1 {
    padding-right: 0.25rem !important;
    padding-left: 0.25rem !important;
  }
  .px-md-2 {
    padding-right: 0.5rem !important;
    padding-left: 0.5rem !important;
  }
  .px-md-3 {
    padding-right: 1rem !important;
    padding-left: 1rem !important;
  }
  .px-md-4 {
    padding-right: 1.5rem !important;
    padding-left: 1.5rem !important;
  }
  .px-md-5 {
    padding-right: 2rem !important;
    padding-left: 2rem !important;
  }
  .px-md-6 {
    padding-right: 2.5rem !important;
    padding-left: 2.5rem !important;
  }
  .px-md-7 {
    padding-right: 3rem !important;
    padding-left: 3rem !important;
  }
  .px-md-8 {
    padding-right: 3.5rem !important;
    padding-left: 3.5rem !important;
  }
  .px-md-9 {
    padding-right: 4rem !important;
    padding-left: 4rem !important;
  }
  .px-md-10 {
    padding-right: 4.5rem !important;
    padding-left: 4.5rem !important;
  }
  .py-md-0 {
    padding-top: 0 !important;
    padding-bottom: 0 !important;
  }
  .py-md-1 {
    padding-top: 0.25rem !important;
    padding-bottom: 0.25rem !important;
  }
  .py-md-2 {
    padding-top: 0.5rem !important;
    padding-bottom: 0.5rem !important;
  }
  .py-md-3 {
    padding-top: 1rem !important;
    padding-bottom: 1rem !important;
  }
  .py-md-4 {
    padding-top: 1.5rem !important;
    padding-bottom: 1.5rem !important;
  }
  .py-md-5 {
    padding-top: 2rem !important;
    padding-bottom: 2rem !important;
  }
  .py-md-6 {
    padding-top: 2.5rem !important;
    padding-bottom: 2.5rem !important;
  }
  .py-md-7 {
    padding-top: 3rem !important;
    padding-bottom: 3rem !important;
  }
  .py-md-8 {
    padding-top: 3.5rem !important;
    padding-bottom: 3.5rem !important;
  }
  .py-md-9 {
    padding-top: 4rem !important;
    padding-bottom: 4rem !important;
  }
  .py-md-10 {
    padding-top: 4.5rem !important;
    padding-bottom: 4.5rem !important;
  }
  .pt-md-0 {
    padding-top: 0 !important;
  }
  .pt-md-1 {
    padding-top: 0.25rem !important;
  }
  .pt-md-2 {
    padding-top: 0.5rem !important;
  }
  .pt-md-3 {
    padding-top: 1rem !important;
  }
  .pt-md-4 {
    padding-top: 1.5rem !important;
  }
  .pt-md-5 {
    padding-top: 2rem !important;
  }
  .pt-md-6 {
    padding-top: 2.5rem !important;
  }
  .pt-md-7 {
    padding-top: 3rem !important;
  }
  .pt-md-8 {
    padding-top: 3.5rem !important;
  }
  .pt-md-9 {
    padding-top: 4rem !important;
  }
  .pt-md-10 {
    padding-top: 4.5rem !important;
  }
  .pe-md-0 {
    padding-right: 0 !important;
  }
  .pe-md-1 {
    padding-right: 0.25rem !important;
  }
  .pe-md-2 {
    padding-right: 0.5rem !important;
  }
  .pe-md-3 {
    padding-right: 1rem !important;
  }
  .pe-md-4 {
    padding-right: 1.5rem !important;
  }
  .pe-md-5 {
    padding-right: 2rem !important;
  }
  .pe-md-6 {
    padding-right: 2.5rem !important;
  }
  .pe-md-7 {
    padding-right: 3rem !important;
  }
  .pe-md-8 {
    padding-right: 3.5rem !important;
  }
  .pe-md-9 {
    padding-right: 4rem !important;
  }
  .pe-md-10 {
    padding-right: 4.5rem !important;
  }
  .pb-md-0 {
    padding-bottom: 0 !important;
  }
  .pb-md-1 {
    padding-bottom: 0.25rem !important;
  }
  .pb-md-2 {
    padding-bottom: 0.5rem !important;
  }
  .pb-md-3 {
    padding-bottom: 1rem !important;
  }
  .pb-md-4 {
    padding-bottom: 1.5rem !important;
  }
  .pb-md-5 {
    padding-bottom: 2rem !important;
  }
  .pb-md-6 {
    padding-bottom: 2.5rem !important;
  }
  .pb-md-7 {
    padding-bottom: 3rem !important;
  }
  .pb-md-8 {
    padding-bottom: 3.5rem !important;
  }
  .pb-md-9 {
    padding-bottom: 4rem !important;
  }
  .pb-md-10 {
    padding-bottom: 4.5rem !important;
  }
  .ps-md-0 {
    padding-left: 0 !important;
  }
  .ps-md-1 {
    padding-left: 0.25rem !important;
  }
  .ps-md-2 {
    padding-left: 0.5rem !important;
  }
  .ps-md-3 {
    padding-left: 1rem !important;
  }
  .ps-md-4 {
    padding-left: 1.5rem !important;
  }
  .ps-md-5 {
    padding-left: 2rem !important;
  }
  .ps-md-6 {
    padding-left: 2.5rem !important;
  }
  .ps-md-7 {
    padding-left: 3rem !important;
  }
  .ps-md-8 {
    padding-left: 3.5rem !important;
  }
  .ps-md-9 {
    padding-left: 4rem !important;
  }
  .ps-md-10 {
    padding-left: 4.5rem !important;
  }
  .gap-md-0 {
    gap: 0 !important;
  }
  .gap-md-1 {
    gap: 0.25rem !important;
  }
  .gap-md-2 {
    gap: 0.5rem !important;
  }
  .gap-md-3 {
    gap: 1rem !important;
  }
  .gap-md-4 {
    gap: 1.5rem !important;
  }
  .gap-md-5 {
    gap: 2rem !important;
  }
  .gap-md-6 {
    gap: 2.5rem !important;
  }
  .gap-md-7 {
    gap: 3rem !important;
  }
  .gap-md-8 {
    gap: 3.5rem !important;
  }
  .gap-md-9 {
    gap: 4rem !important;
  }
  .gap-md-10 {
    gap: 4.5rem !important;
  }
  .row-gap-md-0 {
    row-gap: 0 !important;
  }
  .row-gap-md-1 {
    row-gap: 0.25rem !important;
  }
  .row-gap-md-2 {
    row-gap: 0.5rem !important;
  }
  .row-gap-md-3 {
    row-gap: 1rem !important;
  }
  .row-gap-md-4 {
    row-gap: 1.5rem !important;
  }
  .row-gap-md-5 {
    row-gap: 2rem !important;
  }
  .row-gap-md-6 {
    row-gap: 2.5rem !important;
  }
  .row-gap-md-7 {
    row-gap: 3rem !important;
  }
  .row-gap-md-8 {
    row-gap: 3.5rem !important;
  }
  .row-gap-md-9 {
    row-gap: 4rem !important;
  }
  .row-gap-md-10 {
    row-gap: 4.5rem !important;
  }
  .column-gap-md-0 {
    column-gap: 0 !important;
  }
  .column-gap-md-1 {
    column-gap: 0.25rem !important;
  }
  .column-gap-md-2 {
    column-gap: 0.5rem !important;
  }
  .column-gap-md-3 {
    column-gap: 1rem !important;
  }
  .column-gap-md-4 {
    column-gap: 1.5rem !important;
  }
  .column-gap-md-5 {
    column-gap: 2rem !important;
  }
  .column-gap-md-6 {
    column-gap: 2.5rem !important;
  }
  .column-gap-md-7 {
    column-gap: 3rem !important;
  }
  .column-gap-md-8 {
    column-gap: 3.5rem !important;
  }
  .column-gap-md-9 {
    column-gap: 4rem !important;
  }
  .column-gap-md-10 {
    column-gap: 4.5rem !important;
  }
  .text-md-start {
    text-align: left !important;
  }
  .text-md-end {
    text-align: right !important;
  }
  .text-md-center {
    text-align: center !important;
  }
  .content-space-t-md-0 {
    padding-top: 0 !important;
  }
  .content-space-t-md-1 {
    padding-top: 3.5rem !important;
  }
  .content-space-t-md-2 {
    padding-top: 5rem !important;
  }
  .content-space-t-md-3 {
    padding-top: 7.5rem !important;
  }
  .content-space-t-md-4 {
    padding-top: 10rem !important;
  }
  .content-space-t-md-auto {
    padding-top: auto !important;
  }
  .content-space-b-md-0 {
    padding-bottom: 0 !important;
  }
  .content-space-b-md-1 {
    padding-bottom: 3.5rem !important;
  }
  .content-space-b-md-2 {
    padding-bottom: 5rem !important;
  }
  .content-space-b-md-3 {
    padding-bottom: 7.5rem !important;
  }
  .content-space-b-md-4 {
    padding-bottom: 10rem !important;
  }
  .content-space-b-md-auto {
    padding-bottom: auto !important;
  }
  .content-space-md-0 {
    padding-top: 0 !important;
    padding-bottom: 0 !important;
  }
  .content-space-md-1 {
    padding-top: 3.5rem !important;
    padding-bottom: 3.5rem !important;
  }
  .content-space-md-2 {
    padding-top: 5rem !important;
    padding-bottom: 5rem !important;
  }
  .content-space-md-3 {
    padding-top: 7.5rem !important;
    padding-bottom: 7.5rem !important;
  }
  .content-space-md-4 {
    padding-top: 10rem !important;
    padding-bottom: 10rem !important;
  }
  .content-space-md-auto {
    padding-top: auto !important;
    padding-bottom: auto !important;
  }
}
@media (min-width: 992px) {
  .float-lg-start {
    float: left !important;
  }
  .float-lg-end {
    float: right !important;
  }
  .float-lg-none {
    float: none !important;
  }
  .object-fit-lg-contain {
    object-fit: contain !important;
  }
  .object-fit-lg-cover {
    object-fit: cover !important;
  }
  .object-fit-lg-fill {
    object-fit: fill !important;
  }
  .object-fit-lg-scale {
    object-fit: scale-down !important;
  }
  .object-fit-lg-none {
    object-fit: none !important;
  }
  .d-lg-inline {
    display: inline !important;
  }
  .d-lg-inline-block {
    display: inline-block !important;
  }
  .d-lg-block {
    display: block !important;
  }
  .d-lg-grid {
    display: grid !important;
  }
  .d-lg-inline-grid {
    display: inline-grid !important;
  }
  .d-lg-table {
    display: table !important;
  }
  .d-lg-table-row {
    display: table-row !important;
  }
  .d-lg-table-cell {
    display: table-cell !important;
  }
  .d-lg-flex {
    display: flex !important;
  }
  .d-lg-inline-flex {
    display: inline-flex !important;
  }
  .d-lg-none {
    display: none !important;
  }
  .position-lg-static {
    position: static !important;
  }
  .position-lg-relative {
    position: relative !important;
  }
  .position-lg-absolute {
    position: absolute !important;
  }
  .position-lg-fixed {
    position: fixed !important;
  }
  .position-lg-sticky {
    position: sticky !important;
  }
  .top-lg-0 {
    top: 0 !important;
  }
  .top-lg-50 {
    top: 50% !important;
  }
  .top-lg-100 {
    top: 100% !important;
  }
  .top-lg-auto {
    top: auto !important;
  }
  .bottom-lg-0 {
    bottom: 0 !important;
  }
  .bottom-lg-50 {
    bottom: 50% !important;
  }
  .bottom-lg-100 {
    bottom: 100% !important;
  }
  .bottom-lg-auto {
    bottom: auto !important;
  }
  .start-lg-0 {
    left: 0 !important;
  }
  .start-lg-50 {
    left: 50% !important;
  }
  .start-lg-100 {
    left: 100% !important;
  }
  .start-lg-auto {
    left: auto !important;
  }
  .end-lg-0 {
    right: 0 !important;
  }
  .end-lg-50 {
    right: 50% !important;
  }
  .end-lg-100 {
    right: 100% !important;
  }
  .end-lg-auto {
    right: auto !important;
  }
  .translate-middle-lg {
    transform: translate(-50%, -50%) !important;
  }
  .translate-middle-lg-x {
    transform: translateX(-50%) !important;
  }
  .translate-middle-lg-y {
    transform: translateY(-50%) !important;
  }
  .w-lg-25 {
    width: 25% !important;
  }
  .w-lg-50 {
    width: 50% !important;
  }
  .w-lg-75 {
    width: 75% !important;
  }
  .w-lg-100 {
    width: 100% !important;
  }
  .w-lg-auto {
    width: auto !important;
  }
  .w-lg-65 {
    width: 65% !important;
  }
  .w-lg-85 {
    width: 85% !important;
  }
  .h-lg-25 {
    height: 25% !important;
  }
  .h-lg-50 {
    height: 50% !important;
  }
  .h-lg-75 {
    height: 75% !important;
  }
  .h-lg-100 {
    height: 100% !important;
  }
  .h-lg-auto {
    height: auto !important;
  }
  .h-lg-65 {
    height: 65% !important;
  }
  .vh-lg-100 {
    height: 100vh !important;
  }
  .min-vh-lg-100 {
    min-height: 100vh !important;
  }
  .min-vh-lg-35 {
    min-height: 35vh !important;
  }
  .min-vh-lg-75 {
    min-height: 75vh !important;
  }
  .flex-lg-fill {
    flex: 1 1 auto !important;
  }
  .flex-lg-row {
    flex-direction: row !important;
  }
  .flex-lg-column {
    flex-direction: column !important;
  }
  .flex-lg-row-reverse {
    flex-direction: row-reverse !important;
  }
  .flex-lg-column-reverse {
    flex-direction: column-reverse !important;
  }
  .flex-lg-grow-0 {
    flex-grow: 0 !important;
  }
  .flex-lg-grow-1 {
    flex-grow: 1 !important;
  }
  .flex-lg-shrink-0 {
    flex-shrink: 0 !important;
  }
  .flex-lg-shrink-1 {
    flex-shrink: 1 !important;
  }
  .flex-lg-wrap {
    flex-wrap: wrap !important;
  }
  .flex-lg-nowrap {
    flex-wrap: nowrap !important;
  }
  .flex-lg-wrap-reverse {
    flex-wrap: wrap-reverse !important;
  }
  .justify-content-lg-start {
    justify-content: flex-start !important;
  }
  .justify-content-lg-end {
    justify-content: flex-end !important;
  }
  .justify-content-lg-center {
    justify-content: center !important;
  }
  .justify-content-lg-between {
    justify-content: space-between !important;
  }
  .justify-content-lg-around {
    justify-content: space-around !important;
  }
  .justify-content-lg-evenly {
    justify-content: space-evenly !important;
  }
  .align-items-lg-start {
    align-items: flex-start !important;
  }
  .align-items-lg-end {
    align-items: flex-end !important;
  }
  .align-items-lg-center {
    align-items: center !important;
  }
  .align-items-lg-baseline {
    align-items: baseline !important;
  }
  .align-items-lg-stretch {
    align-items: stretch !important;
  }
  .align-content-lg-start {
    align-content: flex-start !important;
  }
  .align-content-lg-end {
    align-content: flex-end !important;
  }
  .align-content-lg-center {
    align-content: center !important;
  }
  .align-content-lg-between {
    align-content: space-between !important;
  }
  .align-content-lg-around {
    align-content: space-around !important;
  }
  .align-content-lg-stretch {
    align-content: stretch !important;
  }
  .align-self-lg-auto {
    align-self: auto !important;
  }
  .align-self-lg-start {
    align-self: flex-start !important;
  }
  .align-self-lg-end {
    align-self: flex-end !important;
  }
  .align-self-lg-center {
    align-self: center !important;
  }
  .align-self-lg-baseline {
    align-self: baseline !important;
  }
  .align-self-lg-stretch {
    align-self: stretch !important;
  }
  .order-lg-first {
    order: -1 !important;
  }
  .order-lg-0 {
    order: 0 !important;
  }
  .order-lg-1 {
    order: 1 !important;
  }
  .order-lg-2 {
    order: 2 !important;
  }
  .order-lg-3 {
    order: 3 !important;
  }
  .order-lg-4 {
    order: 4 !important;
  }
  .order-lg-5 {
    order: 5 !important;
  }
  .order-lg-last {
    order: 6 !important;
  }
  .m-lg-0 {
    margin: 0 !important;
  }
  .m-lg-1 {
    margin: 0.25rem !important;
  }
  .m-lg-2 {
    margin: 0.5rem !important;
  }
  .m-lg-3 {
    margin: 1rem !important;
  }
  .m-lg-4 {
    margin: 1.5rem !important;
  }
  .m-lg-5 {
    margin: 2rem !important;
  }
  .m-lg-6 {
    margin: 2.5rem !important;
  }
  .m-lg-7 {
    margin: 3rem !important;
  }
  .m-lg-8 {
    margin: 3.5rem !important;
  }
  .m-lg-9 {
    margin: 4rem !important;
  }
  .m-lg-10 {
    margin: 4.5rem !important;
  }
  .m-lg-auto {
    margin: auto !important;
  }
  .mx-lg-0 {
    margin-right: 0 !important;
    margin-left: 0 !important;
  }
  .mx-lg-1 {
    margin-right: 0.25rem !important;
    margin-left: 0.25rem !important;
  }
  .mx-lg-2 {
    margin-right: 0.5rem !important;
    margin-left: 0.5rem !important;
  }
  .mx-lg-3 {
    margin-right: 1rem !important;
    margin-left: 1rem !important;
  }
  .mx-lg-4 {
    margin-right: 1.5rem !important;
    margin-left: 1.5rem !important;
  }
  .mx-lg-5 {
    margin-right: 2rem !important;
    margin-left: 2rem !important;
  }
  .mx-lg-6 {
    margin-right: 2.5rem !important;
    margin-left: 2.5rem !important;
  }
  .mx-lg-7 {
    margin-right: 3rem !important;
    margin-left: 3rem !important;
  }
  .mx-lg-8 {
    margin-right: 3.5rem !important;
    margin-left: 3.5rem !important;
  }
  .mx-lg-9 {
    margin-right: 4rem !important;
    margin-left: 4rem !important;
  }
  .mx-lg-10 {
    margin-right: 4.5rem !important;
    margin-left: 4.5rem !important;
  }
  .mx-lg-auto {
    margin-right: auto !important;
    margin-left: auto !important;
  }
  .my-lg-0 {
    margin-top: 0 !important;
    margin-bottom: 0 !important;
  }
  .my-lg-1 {
    margin-top: 0.25rem !important;
    margin-bottom: 0.25rem !important;
  }
  .my-lg-2 {
    margin-top: 0.5rem !important;
    margin-bottom: 0.5rem !important;
  }
  .my-lg-3 {
    margin-top: 1rem !important;
    margin-bottom: 1rem !important;
  }
  .my-lg-4 {
    margin-top: 1.5rem !important;
    margin-bottom: 1.5rem !important;
  }
  .my-lg-5 {
    margin-top: 2rem !important;
    margin-bottom: 2rem !important;
  }
  .my-lg-6 {
    margin-top: 2.5rem !important;
    margin-bottom: 2.5rem !important;
  }
  .my-lg-7 {
    margin-top: 3rem !important;
    margin-bottom: 3rem !important;
  }
  .my-lg-8 {
    margin-top: 3.5rem !important;
    margin-bottom: 3.5rem !important;
  }
  .my-lg-9 {
    margin-top: 4rem !important;
    margin-bottom: 4rem !important;
  }
  .my-lg-10 {
    margin-top: 4.5rem !important;
    margin-bottom: 4.5rem !important;
  }
  .my-lg-auto {
    margin-top: auto !important;
    margin-bottom: auto !important;
  }
  .mt-lg-0 {
    margin-top: 0 !important;
  }
  .mt-lg-1 {
    margin-top: 0.25rem !important;
  }
  .mt-lg-2 {
    margin-top: 0.5rem !important;
  }
  .mt-lg-3 {
    margin-top: 1rem !important;
  }
  .mt-lg-4 {
    margin-top: 1.5rem !important;
  }
  .mt-lg-5 {
    margin-top: 2rem !important;
  }
  .mt-lg-6 {
    margin-top: 2.5rem !important;
  }
  .mt-lg-7 {
    margin-top: 3rem !important;
  }
  .mt-lg-8 {
    margin-top: 3.5rem !important;
  }
  .mt-lg-9 {
    margin-top: 4rem !important;
  }
  .mt-lg-10 {
    margin-top: 4.5rem !important;
  }
  .mt-lg-auto {
    margin-top: auto !important;
  }
  .me-lg-0 {
    margin-right: 0 !important;
  }
  .me-lg-1 {
    margin-right: 0.25rem !important;
  }
  .me-lg-2 {
    margin-right: 0.5rem !important;
  }
  .me-lg-3 {
    margin-right: 1rem !important;
  }
  .me-lg-4 {
    margin-right: 1.5rem !important;
  }
  .me-lg-5 {
    margin-right: 2rem !important;
  }
  .me-lg-6 {
    margin-right: 2.5rem !important;
  }
  .me-lg-7 {
    margin-right: 3rem !important;
  }
  .me-lg-8 {
    margin-right: 3.5rem !important;
  }
  .me-lg-9 {
    margin-right: 4rem !important;
  }
  .me-lg-10 {
    margin-right: 4.5rem !important;
  }
  .me-lg-auto {
    margin-right: auto !important;
  }
  .mb-lg-0 {
    margin-bottom: 0 !important;
  }
  .mb-lg-1 {
    margin-bottom: 0.25rem !important;
  }
  .mb-lg-2 {
    margin-bottom: 0.5rem !important;
  }
  .mb-lg-3 {
    margin-bottom: 1rem !important;
  }
  .mb-lg-4 {
    margin-bottom: 1.5rem !important;
  }
  .mb-lg-5 {
    margin-bottom: 2rem !important;
  }
  .mb-lg-6 {
    margin-bottom: 2.5rem !important;
  }
  .mb-lg-7 {
    margin-bottom: 3rem !important;
  }
  .mb-lg-8 {
    margin-bottom: 3.5rem !important;
  }
  .mb-lg-9 {
    margin-bottom: 4rem !important;
  }
  .mb-lg-10 {
    margin-bottom: 4.5rem !important;
  }
  .mb-lg-auto {
    margin-bottom: auto !important;
  }
  .ms-lg-0 {
    margin-left: 0 !important;
  }
  .ms-lg-1 {
    margin-left: 0.25rem !important;
  }
  .ms-lg-2 {
    margin-left: 0.5rem !important;
  }
  .ms-lg-3 {
    margin-left: 1rem !important;
  }
  .ms-lg-4 {
    margin-left: 1.5rem !important;
  }
  .ms-lg-5 {
    margin-left: 2rem !important;
  }
  .ms-lg-6 {
    margin-left: 2.5rem !important;
  }
  .ms-lg-7 {
    margin-left: 3rem !important;
  }
  .ms-lg-8 {
    margin-left: 3.5rem !important;
  }
  .ms-lg-9 {
    margin-left: 4rem !important;
  }
  .ms-lg-10 {
    margin-left: 4.5rem !important;
  }
  .ms-lg-auto {
    margin-left: auto !important;
  }
  .m-lg-n1 {
    margin: -0.25rem !important;
  }
  .m-lg-n2 {
    margin: -0.5rem !important;
  }
  .m-lg-n3 {
    margin: -1rem !important;
  }
  .m-lg-n4 {
    margin: -1.5rem !important;
  }
  .m-lg-n5 {
    margin: -2rem !important;
  }
  .m-lg-n6 {
    margin: -2.5rem !important;
  }
  .m-lg-n7 {
    margin: -3rem !important;
  }
  .m-lg-n8 {
    margin: -3.5rem !important;
  }
  .m-lg-n9 {
    margin: -4rem !important;
  }
  .m-lg-n10 {
    margin: -4.5rem !important;
  }
  .mx-lg-n1 {
    margin-right: -0.25rem !important;
    margin-left: -0.25rem !important;
  }
  .mx-lg-n2 {
    margin-right: -0.5rem !important;
    margin-left: -0.5rem !important;
  }
  .mx-lg-n3 {
    margin-right: -1rem !important;
    margin-left: -1rem !important;
  }
  .mx-lg-n4 {
    margin-right: -1.5rem !important;
    margin-left: -1.5rem !important;
  }
  .mx-lg-n5 {
    margin-right: -2rem !important;
    margin-left: -2rem !important;
  }
  .mx-lg-n6 {
    margin-right: -2.5rem !important;
    margin-left: -2.5rem !important;
  }
  .mx-lg-n7 {
    margin-right: -3rem !important;
    margin-left: -3rem !important;
  }
  .mx-lg-n8 {
    margin-right: -3.5rem !important;
    margin-left: -3.5rem !important;
  }
  .mx-lg-n9 {
    margin-right: -4rem !important;
    margin-left: -4rem !important;
  }
  .mx-lg-n10 {
    margin-right: -4.5rem !important;
    margin-left: -4.5rem !important;
  }
  .my-lg-n1 {
    margin-top: -0.25rem !important;
    margin-bottom: -0.25rem !important;
  }
  .my-lg-n2 {
    margin-top: -0.5rem !important;
    margin-bottom: -0.5rem !important;
  }
  .my-lg-n3 {
    margin-top: -1rem !important;
    margin-bottom: -1rem !important;
  }
  .my-lg-n4 {
    margin-top: -1.5rem !important;
    margin-bottom: -1.5rem !important;
  }
  .my-lg-n5 {
    margin-top: -2rem !important;
    margin-bottom: -2rem !important;
  }
  .my-lg-n6 {
    margin-top: -2.5rem !important;
    margin-bottom: -2.5rem !important;
  }
  .my-lg-n7 {
    margin-top: -3rem !important;
    margin-bottom: -3rem !important;
  }
  .my-lg-n8 {
    margin-top: -3.5rem !important;
    margin-bottom: -3.5rem !important;
  }
  .my-lg-n9 {
    margin-top: -4rem !important;
    margin-bottom: -4rem !important;
  }
  .my-lg-n10 {
    margin-top: -4.5rem !important;
    margin-bottom: -4.5rem !important;
  }
  .mt-lg-n1 {
    margin-top: -0.25rem !important;
  }
  .mt-lg-n2 {
    margin-top: -0.5rem !important;
  }
  .mt-lg-n3 {
    margin-top: -1rem !important;
  }
  .mt-lg-n4 {
    margin-top: -1.5rem !important;
  }
  .mt-lg-n5 {
    margin-top: -2rem !important;
  }
  .mt-lg-n6 {
    margin-top: -2.5rem !important;
  }
  .mt-lg-n7 {
    margin-top: -3rem !important;
  }
  .mt-lg-n8 {
    margin-top: -3.5rem !important;
  }
  .mt-lg-n9 {
    margin-top: -4rem !important;
  }
  .mt-lg-n10 {
    margin-top: -4.5rem !important;
  }
  .me-lg-n1 {
    margin-right: -0.25rem !important;
  }
  .me-lg-n2 {
    margin-right: -0.5rem !important;
  }
  .me-lg-n3 {
    margin-right: -1rem !important;
  }
  .me-lg-n4 {
    margin-right: -1.5rem !important;
  }
  .me-lg-n5 {
    margin-right: -2rem !important;
  }
  .me-lg-n6 {
    margin-right: -2.5rem !important;
  }
  .me-lg-n7 {
    margin-right: -3rem !important;
  }
  .me-lg-n8 {
    margin-right: -3.5rem !important;
  }
  .me-lg-n9 {
    margin-right: -4rem !important;
  }
  .me-lg-n10 {
    margin-right: -4.5rem !important;
  }
  .mb-lg-n1 {
    margin-bottom: -0.25rem !important;
  }
  .mb-lg-n2 {
    margin-bottom: -0.5rem !important;
  }
  .mb-lg-n3 {
    margin-bottom: -1rem !important;
  }
  .mb-lg-n4 {
    margin-bottom: -1.5rem !important;
  }
  .mb-lg-n5 {
    margin-bottom: -2rem !important;
  }
  .mb-lg-n6 {
    margin-bottom: -2.5rem !important;
  }
  .mb-lg-n7 {
    margin-bottom: -3rem !important;
  }
  .mb-lg-n8 {
    margin-bottom: -3.5rem !important;
  }
  .mb-lg-n9 {
    margin-bottom: -4rem !important;
  }
  .mb-lg-n10 {
    margin-bottom: -4.5rem !important;
  }
  .ms-lg-n1 {
    margin-left: -0.25rem !important;
  }
  .ms-lg-n2 {
    margin-left: -0.5rem !important;
  }
  .ms-lg-n3 {
    margin-left: -1rem !important;
  }
  .ms-lg-n4 {
    margin-left: -1.5rem !important;
  }
  .ms-lg-n5 {
    margin-left: -2rem !important;
  }
  .ms-lg-n6 {
    margin-left: -2.5rem !important;
  }
  .ms-lg-n7 {
    margin-left: -3rem !important;
  }
  .ms-lg-n8 {
    margin-left: -3.5rem !important;
  }
  .ms-lg-n9 {
    margin-left: -4rem !important;
  }
  .ms-lg-n10 {
    margin-left: -4.5rem !important;
  }
  .p-lg-0 {
    padding: 0 !important;
  }
  .p-lg-1 {
    padding: 0.25rem !important;
  }
  .p-lg-2 {
    padding: 0.5rem !important;
  }
  .p-lg-3 {
    padding: 1rem !important;
  }
  .p-lg-4 {
    padding: 1.5rem !important;
  }
  .p-lg-5 {
    padding: 2rem !important;
  }
  .p-lg-6 {
    padding: 2.5rem !important;
  }
  .p-lg-7 {
    padding: 3rem !important;
  }
  .p-lg-8 {
    padding: 3.5rem !important;
  }
  .p-lg-9 {
    padding: 4rem !important;
  }
  .p-lg-10 {
    padding: 4.5rem !important;
  }
  .px-lg-0 {
    padding-right: 0 !important;
    padding-left: 0 !important;
  }
  .px-lg-1 {
    padding-right: 0.25rem !important;
    padding-left: 0.25rem !important;
  }
  .px-lg-2 {
    padding-right: 0.5rem !important;
    padding-left: 0.5rem !important;
  }
  .px-lg-3 {
    padding-right: 1rem !important;
    padding-left: 1rem !important;
  }
  .px-lg-4 {
    padding-right: 1.5rem !important;
    padding-left: 1.5rem !important;
  }
  .px-lg-5 {
    padding-right: 2rem !important;
    padding-left: 2rem !important;
  }
  .px-lg-6 {
    padding-right: 2.5rem !important;
    padding-left: 2.5rem !important;
  }
  .px-lg-7 {
    padding-right: 3rem !important;
    padding-left: 3rem !important;
  }
  .px-lg-8 {
    padding-right: 3.5rem !important;
    padding-left: 3.5rem !important;
  }
  .px-lg-9 {
    padding-right: 4rem !important;
    padding-left: 4rem !important;
  }
  .px-lg-10 {
    padding-right: 4.5rem !important;
    padding-left: 4.5rem !important;
  }
  .py-lg-0 {
    padding-top: 0 !important;
    padding-bottom: 0 !important;
  }
  .py-lg-1 {
    padding-top: 0.25rem !important;
    padding-bottom: 0.25rem !important;
  }
  .py-lg-2 {
    padding-top: 0.5rem !important;
    padding-bottom: 0.5rem !important;
  }
  .py-lg-3 {
    padding-top: 1rem !important;
    padding-bottom: 1rem !important;
  }
  .py-lg-4 {
    padding-top: 1.5rem !important;
    padding-bottom: 1.5rem !important;
  }
  .py-lg-5 {
    padding-top: 2rem !important;
    padding-bottom: 2rem !important;
  }
  .py-lg-6 {
    padding-top: 2.5rem !important;
    padding-bottom: 2.5rem !important;
  }
  .py-lg-7 {
    padding-top: 3rem !important;
    padding-bottom: 3rem !important;
  }
  .py-lg-8 {
    padding-top: 3.5rem !important;
    padding-bottom: 3.5rem !important;
  }
  .py-lg-9 {
    padding-top: 4rem !important;
    padding-bottom: 4rem !important;
  }
  .py-lg-10 {
    padding-top: 4.5rem !important;
    padding-bottom: 4.5rem !important;
  }
  .pt-lg-0 {
    padding-top: 0 !important;
  }
  .pt-lg-1 {
    padding-top: 0.25rem !important;
  }
  .pt-lg-2 {
    padding-top: 0.5rem !important;
  }
  .pt-lg-3 {
    padding-top: 1rem !important;
  }
  .pt-lg-4 {
    padding-top: 1.5rem !important;
  }
  .pt-lg-5 {
    padding-top: 2rem !important;
  }
  .pt-lg-6 {
    padding-top: 2.5rem !important;
  }
  .pt-lg-7 {
    padding-top: 3rem !important;
  }
  .pt-lg-8 {
    padding-top: 3.5rem !important;
  }
  .pt-lg-9 {
    padding-top: 4rem !important;
  }
  .pt-lg-10 {
    padding-top: 4.5rem !important;
  }
  .pe-lg-0 {
    padding-right: 0 !important;
  }
  .pe-lg-1 {
    padding-right: 0.25rem !important;
  }
  .pe-lg-2 {
    padding-right: 0.5rem !important;
  }
  .pe-lg-3 {
    padding-right: 1rem !important;
  }
  .pe-lg-4 {
    padding-right: 1.5rem !important;
  }
  .pe-lg-5 {
    padding-right: 2rem !important;
  }
  .pe-lg-6 {
    padding-right: 2.5rem !important;
  }
  .pe-lg-7 {
    padding-right: 3rem !important;
  }
  .pe-lg-8 {
    padding-right: 3.5rem !important;
  }
  .pe-lg-9 {
    padding-right: 4rem !important;
  }
  .pe-lg-10 {
    padding-right: 4.5rem !important;
  }
  .pb-lg-0 {
    padding-bottom: 0 !important;
  }
  .pb-lg-1 {
    padding-bottom: 0.25rem !important;
  }
  .pb-lg-2 {
    padding-bottom: 0.5rem !important;
  }
  .pb-lg-3 {
    padding-bottom: 1rem !important;
  }
  .pb-lg-4 {
    padding-bottom: 1.5rem !important;
  }
  .pb-lg-5 {
    padding-bottom: 2rem !important;
  }
  .pb-lg-6 {
    padding-bottom: 2.5rem !important;
  }
  .pb-lg-7 {
    padding-bottom: 3rem !important;
  }
  .pb-lg-8 {
    padding-bottom: 3.5rem !important;
  }
  .pb-lg-9 {
    padding-bottom: 4rem !important;
  }
  .pb-lg-10 {
    padding-bottom: 4.5rem !important;
  }
  .ps-lg-0 {
    padding-left: 0 !important;
  }
  .ps-lg-1 {
    padding-left: 0.25rem !important;
  }
  .ps-lg-2 {
    padding-left: 0.5rem !important;
  }
  .ps-lg-3 {
    padding-left: 1rem !important;
  }
  .ps-lg-4 {
    padding-left: 1.5rem !important;
  }
  .ps-lg-5 {
    padding-left: 2rem !important;
  }
  .ps-lg-6 {
    padding-left: 2.5rem !important;
  }
  .ps-lg-7 {
    padding-left: 3rem !important;
  }
  .ps-lg-8 {
    padding-left: 3.5rem !important;
  }
  .ps-lg-9 {
    padding-left: 4rem !important;
  }
  .ps-lg-10 {
    padding-left: 4.5rem !important;
  }
  .gap-lg-0 {
    gap: 0 !important;
  }
  .gap-lg-1 {
    gap: 0.25rem !important;
  }
  .gap-lg-2 {
    gap: 0.5rem !important;
  }
  .gap-lg-3 {
    gap: 1rem !important;
  }
  .gap-lg-4 {
    gap: 1.5rem !important;
  }
  .gap-lg-5 {
    gap: 2rem !important;
  }
  .gap-lg-6 {
    gap: 2.5rem !important;
  }
  .gap-lg-7 {
    gap: 3rem !important;
  }
  .gap-lg-8 {
    gap: 3.5rem !important;
  }
  .gap-lg-9 {
    gap: 4rem !important;
  }
  .gap-lg-10 {
    gap: 4.5rem !important;
  }
  .row-gap-lg-0 {
    row-gap: 0 !important;
  }
  .row-gap-lg-1 {
    row-gap: 0.25rem !important;
  }
  .row-gap-lg-2 {
    row-gap: 0.5rem !important;
  }
  .row-gap-lg-3 {
    row-gap: 1rem !important;
  }
  .row-gap-lg-4 {
    row-gap: 1.5rem !important;
  }
  .row-gap-lg-5 {
    row-gap: 2rem !important;
  }
  .row-gap-lg-6 {
    row-gap: 2.5rem !important;
  }
  .row-gap-lg-7 {
    row-gap: 3rem !important;
  }
  .row-gap-lg-8 {
    row-gap: 3.5rem !important;
  }
  .row-gap-lg-9 {
    row-gap: 4rem !important;
  }
  .row-gap-lg-10 {
    row-gap: 4.5rem !important;
  }
  .column-gap-lg-0 {
    column-gap: 0 !important;
  }
  .column-gap-lg-1 {
    column-gap: 0.25rem !important;
  }
  .column-gap-lg-2 {
    column-gap: 0.5rem !important;
  }
  .column-gap-lg-3 {
    column-gap: 1rem !important;
  }
  .column-gap-lg-4 {
    column-gap: 1.5rem !important;
  }
  .column-gap-lg-5 {
    column-gap: 2rem !important;
  }
  .column-gap-lg-6 {
    column-gap: 2.5rem !important;
  }
  .column-gap-lg-7 {
    column-gap: 3rem !important;
  }
  .column-gap-lg-8 {
    column-gap: 3.5rem !important;
  }
  .column-gap-lg-9 {
    column-gap: 4rem !important;
  }
  .column-gap-lg-10 {
    column-gap: 4.5rem !important;
  }
  .text-lg-start {
    text-align: left !important;
  }
  .text-lg-end {
    text-align: right !important;
  }
  .text-lg-center {
    text-align: center !important;
  }
  .content-space-t-lg-0 {
    padding-top: 0 !important;
  }
  .content-space-t-lg-1 {
    padding-top: 3.5rem !important;
  }
  .content-space-t-lg-2 {
    padding-top: 5rem !important;
  }
  .content-space-t-lg-3 {
    padding-top: 7.5rem !important;
  }
  .content-space-t-lg-4 {
    padding-top: 10rem !important;
  }
  .content-space-t-lg-auto {
    padding-top: auto !important;
  }
  .content-space-b-lg-0 {
    padding-bottom: 0 !important;
  }
  .content-space-b-lg-1 {
    padding-bottom: 3.5rem !important;
  }
  .content-space-b-lg-2 {
    padding-bottom: 5rem !important;
  }
  .content-space-b-lg-3 {
    padding-bottom: 7.5rem !important;
  }
  .content-space-b-lg-4 {
    padding-bottom: 10rem !important;
  }
  .content-space-b-lg-auto {
    padding-bottom: auto !important;
  }
  .content-space-lg-0 {
    padding-top: 0 !important;
    padding-bottom: 0 !important;
  }
  .content-space-lg-1 {
    padding-top: 3.5rem !important;
    padding-bottom: 3.5rem !important;
  }
  .content-space-lg-2 {
    padding-top: 5rem !important;
    padding-bottom: 5rem !important;
  }
  .content-space-lg-3 {
    padding-top: 7.5rem !important;
    padding-bottom: 7.5rem !important;
  }
  .content-space-lg-4 {
    padding-top: 10rem !important;
    padding-bottom: 10rem !important;
  }
  .content-space-lg-auto {
    padding-top: auto !important;
    padding-bottom: auto !important;
  }
}
@media (min-width: 1200px) {
  .float-xl-start {
    float: left !important;
  }
  .float-xl-end {
    float: right !important;
  }
  .float-xl-none {
    float: none !important;
  }
  .object-fit-xl-contain {
    object-fit: contain !important;
  }
  .object-fit-xl-cover {
    object-fit: cover !important;
  }
  .object-fit-xl-fill {
    object-fit: fill !important;
  }
  .object-fit-xl-scale {
    object-fit: scale-down !important;
  }
  .object-fit-xl-none {
    object-fit: none !important;
  }
  .d-xl-inline {
    display: inline !important;
  }
  .d-xl-inline-block {
    display: inline-block !important;
  }
  .d-xl-block {
    display: block !important;
  }
  .d-xl-grid {
    display: grid !important;
  }
  .d-xl-inline-grid {
    display: inline-grid !important;
  }
  .d-xl-table {
    display: table !important;
  }
  .d-xl-table-row {
    display: table-row !important;
  }
  .d-xl-table-cell {
    display: table-cell !important;
  }
  .d-xl-flex {
    display: flex !important;
  }
  .d-xl-inline-flex {
    display: inline-flex !important;
  }
  .d-xl-none {
    display: none !important;
  }
  .position-xl-static {
    position: static !important;
  }
  .position-xl-relative {
    position: relative !important;
  }
  .position-xl-absolute {
    position: absolute !important;
  }
  .position-xl-fixed {
    position: fixed !important;
  }
  .position-xl-sticky {
    position: sticky !important;
  }
  .top-xl-0 {
    top: 0 !important;
  }
  .top-xl-50 {
    top: 50% !important;
  }
  .top-xl-100 {
    top: 100% !important;
  }
  .top-xl-auto {
    top: auto !important;
  }
  .bottom-xl-0 {
    bottom: 0 !important;
  }
  .bottom-xl-50 {
    bottom: 50% !important;
  }
  .bottom-xl-100 {
    bottom: 100% !important;
  }
  .bottom-xl-auto {
    bottom: auto !important;
  }
  .start-xl-0 {
    left: 0 !important;
  }
  .start-xl-50 {
    left: 50% !important;
  }
  .start-xl-100 {
    left: 100% !important;
  }
  .start-xl-auto {
    left: auto !important;
  }
  .end-xl-0 {
    right: 0 !important;
  }
  .end-xl-50 {
    right: 50% !important;
  }
  .end-xl-100 {
    right: 100% !important;
  }
  .end-xl-auto {
    right: auto !important;
  }
  .translate-middle-xl {
    transform: translate(-50%, -50%) !important;
  }
  .translate-middle-xl-x {
    transform: translateX(-50%) !important;
  }
  .translate-middle-xl-y {
    transform: translateY(-50%) !important;
  }
  .w-xl-25 {
    width: 25% !important;
  }
  .w-xl-50 {
    width: 50% !important;
  }
  .w-xl-75 {
    width: 75% !important;
  }
  .w-xl-100 {
    width: 100% !important;
  }
  .w-xl-auto {
    width: auto !important;
  }
  .w-xl-65 {
    width: 65% !important;
  }
  .w-xl-85 {
    width: 85% !important;
  }
  .h-xl-25 {
    height: 25% !important;
  }
  .h-xl-50 {
    height: 50% !important;
  }
  .h-xl-75 {
    height: 75% !important;
  }
  .h-xl-100 {
    height: 100% !important;
  }
  .h-xl-auto {
    height: auto !important;
  }
  .h-xl-65 {
    height: 65% !important;
  }
  .vh-xl-100 {
    height: 100vh !important;
  }
  .min-vh-xl-100 {
    min-height: 100vh !important;
  }
  .min-vh-xl-35 {
    min-height: 35vh !important;
  }
  .min-vh-xl-75 {
    min-height: 75vh !important;
  }
  .flex-xl-fill {
    flex: 1 1 auto !important;
  }
  .flex-xl-row {
    flex-direction: row !important;
  }
  .flex-xl-column {
    flex-direction: column !important;
  }
  .flex-xl-row-reverse {
    flex-direction: row-reverse !important;
  }
  .flex-xl-column-reverse {
    flex-direction: column-reverse !important;
  }
  .flex-xl-grow-0 {
    flex-grow: 0 !important;
  }
  .flex-xl-grow-1 {
    flex-grow: 1 !important;
  }
  .flex-xl-shrink-0 {
    flex-shrink: 0 !important;
  }
  .flex-xl-shrink-1 {
    flex-shrink: 1 !important;
  }
  .flex-xl-wrap {
    flex-wrap: wrap !important;
  }
  .flex-xl-nowrap {
    flex-wrap: nowrap !important;
  }
  .flex-xl-wrap-reverse {
    flex-wrap: wrap-reverse !important;
  }
  .justify-content-xl-start {
    justify-content: flex-start !important;
  }
  .justify-content-xl-end {
    justify-content: flex-end !important;
  }
  .justify-content-xl-center {
    justify-content: center !important;
  }
  .justify-content-xl-between {
    justify-content: space-between !important;
  }
  .justify-content-xl-around {
    justify-content: space-around !important;
  }
  .justify-content-xl-evenly {
    justify-content: space-evenly !important;
  }
  .align-items-xl-start {
    align-items: flex-start !important;
  }
  .align-items-xl-end {
    align-items: flex-end !important;
  }
  .align-items-xl-center {
    align-items: center !important;
  }
  .align-items-xl-baseline {
    align-items: baseline !important;
  }
  .align-items-xl-stretch {
    align-items: stretch !important;
  }
  .align-content-xl-start {
    align-content: flex-start !important;
  }
  .align-content-xl-end {
    align-content: flex-end !important;
  }
  .align-content-xl-center {
    align-content: center !important;
  }
  .align-content-xl-between {
    align-content: space-between !important;
  }
  .align-content-xl-around {
    align-content: space-around !important;
  }
  .align-content-xl-stretch {
    align-content: stretch !important;
  }
  .align-self-xl-auto {
    align-self: auto !important;
  }
  .align-self-xl-start {
    align-self: flex-start !important;
  }
  .align-self-xl-end {
    align-self: flex-end !important;
  }
  .align-self-xl-center {
    align-self: center !important;
  }
  .align-self-xl-baseline {
    align-self: baseline !important;
  }
  .align-self-xl-stretch {
    align-self: stretch !important;
  }
  .order-xl-first {
    order: -1 !important;
  }
  .order-xl-0 {
    order: 0 !important;
  }
  .order-xl-1 {
    order: 1 !important;
  }
  .order-xl-2 {
    order: 2 !important;
  }
  .order-xl-3 {
    order: 3 !important;
  }
  .order-xl-4 {
    order: 4 !important;
  }
  .order-xl-5 {
    order: 5 !important;
  }
  .order-xl-last {
    order: 6 !important;
  }
  .m-xl-0 {
    margin: 0 !important;
  }
  .m-xl-1 {
    margin: 0.25rem !important;
  }
  .m-xl-2 {
    margin: 0.5rem !important;
  }
  .m-xl-3 {
    margin: 1rem !important;
  }
  .m-xl-4 {
    margin: 1.5rem !important;
  }
  .m-xl-5 {
    margin: 2rem !important;
  }
  .m-xl-6 {
    margin: 2.5rem !important;
  }
  .m-xl-7 {
    margin: 3rem !important;
  }
  .m-xl-8 {
    margin: 3.5rem !important;
  }
  .m-xl-9 {
    margin: 4rem !important;
  }
  .m-xl-10 {
    margin: 4.5rem !important;
  }
  .m-xl-auto {
    margin: auto !important;
  }
  .mx-xl-0 {
    margin-right: 0 !important;
    margin-left: 0 !important;
  }
  .mx-xl-1 {
    margin-right: 0.25rem !important;
    margin-left: 0.25rem !important;
  }
  .mx-xl-2 {
    margin-right: 0.5rem !important;
    margin-left: 0.5rem !important;
  }
  .mx-xl-3 {
    margin-right: 1rem !important;
    margin-left: 1rem !important;
  }
  .mx-xl-4 {
    margin-right: 1.5rem !important;
    margin-left: 1.5rem !important;
  }
  .mx-xl-5 {
    margin-right: 2rem !important;
    margin-left: 2rem !important;
  }
  .mx-xl-6 {
    margin-right: 2.5rem !important;
    margin-left: 2.5rem !important;
  }
  .mx-xl-7 {
    margin-right: 3rem !important;
    margin-left: 3rem !important;
  }
  .mx-xl-8 {
    margin-right: 3.5rem !important;
    margin-left: 3.5rem !important;
  }
  .mx-xl-9 {
    margin-right: 4rem !important;
    margin-left: 4rem !important;
  }
  .mx-xl-10 {
    margin-right: 4.5rem !important;
    margin-left: 4.5rem !important;
  }
  .mx-xl-auto {
    margin-right: auto !important;
    margin-left: auto !important;
  }
  .my-xl-0 {
    margin-top: 0 !important;
    margin-bottom: 0 !important;
  }
  .my-xl-1 {
    margin-top: 0.25rem !important;
    margin-bottom: 0.25rem !important;
  }
  .my-xl-2 {
    margin-top: 0.5rem !important;
    margin-bottom: 0.5rem !important;
  }
  .my-xl-3 {
    margin-top: 1rem !important;
    margin-bottom: 1rem !important;
  }
  .my-xl-4 {
    margin-top: 1.5rem !important;
    margin-bottom: 1.5rem !important;
  }
  .my-xl-5 {
    margin-top: 2rem !important;
    margin-bottom: 2rem !important;
  }
  .my-xl-6 {
    margin-top: 2.5rem !important;
    margin-bottom: 2.5rem !important;
  }
  .my-xl-7 {
    margin-top: 3rem !important;
    margin-bottom: 3rem !important;
  }
  .my-xl-8 {
    margin-top: 3.5rem !important;
    margin-bottom: 3.5rem !important;
  }
  .my-xl-9 {
    margin-top: 4rem !important;
    margin-bottom: 4rem !important;
  }
  .my-xl-10 {
    margin-top: 4.5rem !important;
    margin-bottom: 4.5rem !important;
  }
  .my-xl-auto {
    margin-top: auto !important;
    margin-bottom: auto !important;
  }
  .mt-xl-0 {
    margin-top: 0 !important;
  }
  .mt-xl-1 {
    margin-top: 0.25rem !important;
  }
  .mt-xl-2 {
    margin-top: 0.5rem !important;
  }
  .mt-xl-3 {
    margin-top: 1rem !important;
  }
  .mt-xl-4 {
    margin-top: 1.5rem !important;
  }
  .mt-xl-5 {
    margin-top: 2rem !important;
  }
  .mt-xl-6 {
    margin-top: 2.5rem !important;
  }
  .mt-xl-7 {
    margin-top: 3rem !important;
  }
  .mt-xl-8 {
    margin-top: 3.5rem !important;
  }
  .mt-xl-9 {
    margin-top: 4rem !important;
  }
  .mt-xl-10 {
    margin-top: 4.5rem !important;
  }
  .mt-xl-auto {
    margin-top: auto !important;
  }
  .me-xl-0 {
    margin-right: 0 !important;
  }
  .me-xl-1 {
    margin-right: 0.25rem !important;
  }
  .me-xl-2 {
    margin-right: 0.5rem !important;
  }
  .me-xl-3 {
    margin-right: 1rem !important;
  }
  .me-xl-4 {
    margin-right: 1.5rem !important;
  }
  .me-xl-5 {
    margin-right: 2rem !important;
  }
  .me-xl-6 {
    margin-right: 2.5rem !important;
  }
  .me-xl-7 {
    margin-right: 3rem !important;
  }
  .me-xl-8 {
    margin-right: 3.5rem !important;
  }
  .me-xl-9 {
    margin-right: 4rem !important;
  }
  .me-xl-10 {
    margin-right: 4.5rem !important;
  }
  .me-xl-auto {
    margin-right: auto !important;
  }
  .mb-xl-0 {
    margin-bottom: 0 !important;
  }
  .mb-xl-1 {
    margin-bottom: 0.25rem !important;
  }
  .mb-xl-2 {
    margin-bottom: 0.5rem !important;
  }
  .mb-xl-3 {
    margin-bottom: 1rem !important;
  }
  .mb-xl-4 {
    margin-bottom: 1.5rem !important;
  }
  .mb-xl-5 {
    margin-bottom: 2rem !important;
  }
  .mb-xl-6 {
    margin-bottom: 2.5rem !important;
  }
  .mb-xl-7 {
    margin-bottom: 3rem !important;
  }
  .mb-xl-8 {
    margin-bottom: 3.5rem !important;
  }
  .mb-xl-9 {
    margin-bottom: 4rem !important;
  }
  .mb-xl-10 {
    margin-bottom: 4.5rem !important;
  }
  .mb-xl-auto {
    margin-bottom: auto !important;
  }
  .ms-xl-0 {
    margin-left: 0 !important;
  }
  .ms-xl-1 {
    margin-left: 0.25rem !important;
  }
  .ms-xl-2 {
    margin-left: 0.5rem !important;
  }
  .ms-xl-3 {
    margin-left: 1rem !important;
  }
  .ms-xl-4 {
    margin-left: 1.5rem !important;
  }
  .ms-xl-5 {
    margin-left: 2rem !important;
  }
  .ms-xl-6 {
    margin-left: 2.5rem !important;
  }
  .ms-xl-7 {
    margin-left: 3rem !important;
  }
  .ms-xl-8 {
    margin-left: 3.5rem !important;
  }
  .ms-xl-9 {
    margin-left: 4rem !important;
  }
  .ms-xl-10 {
    margin-left: 4.5rem !important;
  }
  .ms-xl-auto {
    margin-left: auto !important;
  }
  .m-xl-n1 {
    margin: -0.25rem !important;
  }
  .m-xl-n2 {
    margin: -0.5rem !important;
  }
  .m-xl-n3 {
    margin: -1rem !important;
  }
  .m-xl-n4 {
    margin: -1.5rem !important;
  }
  .m-xl-n5 {
    margin: -2rem !important;
  }
  .m-xl-n6 {
    margin: -2.5rem !important;
  }
  .m-xl-n7 {
    margin: -3rem !important;
  }
  .m-xl-n8 {
    margin: -3.5rem !important;
  }
  .m-xl-n9 {
    margin: -4rem !important;
  }
  .m-xl-n10 {
    margin: -4.5rem !important;
  }
  .mx-xl-n1 {
    margin-right: -0.25rem !important;
    margin-left: -0.25rem !important;
  }
  .mx-xl-n2 {
    margin-right: -0.5rem !important;
    margin-left: -0.5rem !important;
  }
  .mx-xl-n3 {
    margin-right: -1rem !important;
    margin-left: -1rem !important;
  }
  .mx-xl-n4 {
    margin-right: -1.5rem !important;
    margin-left: -1.5rem !important;
  }
  .mx-xl-n5 {
    margin-right: -2rem !important;
    margin-left: -2rem !important;
  }
  .mx-xl-n6 {
    margin-right: -2.5rem !important;
    margin-left: -2.5rem !important;
  }
  .mx-xl-n7 {
    margin-right: -3rem !important;
    margin-left: -3rem !important;
  }
  .mx-xl-n8 {
    margin-right: -3.5rem !important;
    margin-left: -3.5rem !important;
  }
  .mx-xl-n9 {
    margin-right: -4rem !important;
    margin-left: -4rem !important;
  }
  .mx-xl-n10 {
    margin-right: -4.5rem !important;
    margin-left: -4.5rem !important;
  }
  .my-xl-n1 {
    margin-top: -0.25rem !important;
    margin-bottom: -0.25rem !important;
  }
  .my-xl-n2 {
    margin-top: -0.5rem !important;
    margin-bottom: -0.5rem !important;
  }
  .my-xl-n3 {
    margin-top: -1rem !important;
    margin-bottom: -1rem !important;
  }
  .my-xl-n4 {
    margin-top: -1.5rem !important;
    margin-bottom: -1.5rem !important;
  }
  .my-xl-n5 {
    margin-top: -2rem !important;
    margin-bottom: -2rem !important;
  }
  .my-xl-n6 {
    margin-top: -2.5rem !important;
    margin-bottom: -2.5rem !important;
  }
  .my-xl-n7 {
    margin-top: -3rem !important;
    margin-bottom: -3rem !important;
  }
  .my-xl-n8 {
    margin-top: -3.5rem !important;
    margin-bottom: -3.5rem !important;
  }
  .my-xl-n9 {
    margin-top: -4rem !important;
    margin-bottom: -4rem !important;
  }
  .my-xl-n10 {
    margin-top: -4.5rem !important;
    margin-bottom: -4.5rem !important;
  }
  .mt-xl-n1 {
    margin-top: -0.25rem !important;
  }
  .mt-xl-n2 {
    margin-top: -0.5rem !important;
  }
  .mt-xl-n3 {
    margin-top: -1rem !important;
  }
  .mt-xl-n4 {
    margin-top: -1.5rem !important;
  }
  .mt-xl-n5 {
    margin-top: -2rem !important;
  }
  .mt-xl-n6 {
    margin-top: -2.5rem !important;
  }
  .mt-xl-n7 {
    margin-top: -3rem !important;
  }
  .mt-xl-n8 {
    margin-top: -3.5rem !important;
  }
  .mt-xl-n9 {
    margin-top: -4rem !important;
  }
  .mt-xl-n10 {
    margin-top: -4.5rem !important;
  }
  .me-xl-n1 {
    margin-right: -0.25rem !important;
  }
  .me-xl-n2 {
    margin-right: -0.5rem !important;
  }
  .me-xl-n3 {
    margin-right: -1rem !important;
  }
  .me-xl-n4 {
    margin-right: -1.5rem !important;
  }
  .me-xl-n5 {
    margin-right: -2rem !important;
  }
  .me-xl-n6 {
    margin-right: -2.5rem !important;
  }
  .me-xl-n7 {
    margin-right: -3rem !important;
  }
  .me-xl-n8 {
    margin-right: -3.5rem !important;
  }
  .me-xl-n9 {
    margin-right: -4rem !important;
  }
  .me-xl-n10 {
    margin-right: -4.5rem !important;
  }
  .mb-xl-n1 {
    margin-bottom: -0.25rem !important;
  }
  .mb-xl-n2 {
    margin-bottom: -0.5rem !important;
  }
  .mb-xl-n3 {
    margin-bottom: -1rem !important;
  }
  .mb-xl-n4 {
    margin-bottom: -1.5rem !important;
  }
  .mb-xl-n5 {
    margin-bottom: -2rem !important;
  }
  .mb-xl-n6 {
    margin-bottom: -2.5rem !important;
  }
  .mb-xl-n7 {
    margin-bottom: -3rem !important;
  }
  .mb-xl-n8 {
    margin-bottom: -3.5rem !important;
  }
  .mb-xl-n9 {
    margin-bottom: -4rem !important;
  }
  .mb-xl-n10 {
    margin-bottom: -4.5rem !important;
  }
  .ms-xl-n1 {
    margin-left: -0.25rem !important;
  }
  .ms-xl-n2 {
    margin-left: -0.5rem !important;
  }
  .ms-xl-n3 {
    margin-left: -1rem !important;
  }
  .ms-xl-n4 {
    margin-left: -1.5rem !important;
  }
  .ms-xl-n5 {
    margin-left: -2rem !important;
  }
  .ms-xl-n6 {
    margin-left: -2.5rem !important;
  }
  .ms-xl-n7 {
    margin-left: -3rem !important;
  }
  .ms-xl-n8 {
    margin-left: -3.5rem !important;
  }
  .ms-xl-n9 {
    margin-left: -4rem !important;
  }
  .ms-xl-n10 {
    margin-left: -4.5rem !important;
  }
  .p-xl-0 {
    padding: 0 !important;
  }
  .p-xl-1 {
    padding: 0.25rem !important;
  }
  .p-xl-2 {
    padding: 0.5rem !important;
  }
  .p-xl-3 {
    padding: 1rem !important;
  }
  .p-xl-4 {
    padding: 1.5rem !important;
  }
  .p-xl-5 {
    padding: 2rem !important;
  }
  .p-xl-6 {
    padding: 2.5rem !important;
  }
  .p-xl-7 {
    padding: 3rem !important;
  }
  .p-xl-8 {
    padding: 3.5rem !important;
  }
  .p-xl-9 {
    padding: 4rem !important;
  }
  .p-xl-10 {
    padding: 4.5rem !important;
  }
  .px-xl-0 {
    padding-right: 0 !important;
    padding-left: 0 !important;
  }
  .px-xl-1 {
    padding-right: 0.25rem !important;
    padding-left: 0.25rem !important;
  }
  .px-xl-2 {
    padding-right: 0.5rem !important;
    padding-left: 0.5rem !important;
  }
  .px-xl-3 {
    padding-right: 1rem !important;
    padding-left: 1rem !important;
  }
  .px-xl-4 {
    padding-right: 1.5rem !important;
    padding-left: 1.5rem !important;
  }
  .px-xl-5 {
    padding-right: 2rem !important;
    padding-left: 2rem !important;
  }
  .px-xl-6 {
    padding-right: 2.5rem !important;
    padding-left: 2.5rem !important;
  }
  .px-xl-7 {
    padding-right: 3rem !important;
    padding-left: 3rem !important;
  }
  .px-xl-8 {
    padding-right: 3.5rem !important;
    padding-left: 3.5rem !important;
  }
  .px-xl-9 {
    padding-right: 4rem !important;
    padding-left: 4rem !important;
  }
  .px-xl-10 {
    padding-right: 4.5rem !important;
    padding-left: 4.5rem !important;
  }
  .py-xl-0 {
    padding-top: 0 !important;
    padding-bottom: 0 !important;
  }
  .py-xl-1 {
    padding-top: 0.25rem !important;
    padding-bottom: 0.25rem !important;
  }
  .py-xl-2 {
    padding-top: 0.5rem !important;
    padding-bottom: 0.5rem !important;
  }
  .py-xl-3 {
    padding-top: 1rem !important;
    padding-bottom: 1rem !important;
  }
  .py-xl-4 {
    padding-top: 1.5rem !important;
    padding-bottom: 1.5rem !important;
  }
  .py-xl-5 {
    padding-top: 2rem !important;
    padding-bottom: 2rem !important;
  }
  .py-xl-6 {
    padding-top: 2.5rem !important;
    padding-bottom: 2.5rem !important;
  }
  .py-xl-7 {
    padding-top: 3rem !important;
    padding-bottom: 3rem !important;
  }
  .py-xl-8 {
    padding-top: 3.5rem !important;
    padding-bottom: 3.5rem !important;
  }
  .py-xl-9 {
    padding-top: 4rem !important;
    padding-bottom: 4rem !important;
  }
  .py-xl-10 {
    padding-top: 4.5rem !important;
    padding-bottom: 4.5rem !important;
  }
  .pt-xl-0 {
    padding-top: 0 !important;
  }
  .pt-xl-1 {
    padding-top: 0.25rem !important;
  }
  .pt-xl-2 {
    padding-top: 0.5rem !important;
  }
  .pt-xl-3 {
    padding-top: 1rem !important;
  }
  .pt-xl-4 {
    padding-top: 1.5rem !important;
  }
  .pt-xl-5 {
    padding-top: 2rem !important;
  }
  .pt-xl-6 {
    padding-top: 2.5rem !important;
  }
  .pt-xl-7 {
    padding-top: 3rem !important;
  }
  .pt-xl-8 {
    padding-top: 3.5rem !important;
  }
  .pt-xl-9 {
    padding-top: 4rem !important;
  }
  .pt-xl-10 {
    padding-top: 4.5rem !important;
  }
  .pe-xl-0 {
    padding-right: 0 !important;
  }
  .pe-xl-1 {
    padding-right: 0.25rem !important;
  }
  .pe-xl-2 {
    padding-right: 0.5rem !important;
  }
  .pe-xl-3 {
    padding-right: 1rem !important;
  }
  .pe-xl-4 {
    padding-right: 1.5rem !important;
  }
  .pe-xl-5 {
    padding-right: 2rem !important;
  }
  .pe-xl-6 {
    padding-right: 2.5rem !important;
  }
  .pe-xl-7 {
    padding-right: 3rem !important;
  }
  .pe-xl-8 {
    padding-right: 3.5rem !important;
  }
  .pe-xl-9 {
    padding-right: 4rem !important;
  }
  .pe-xl-10 {
    padding-right: 4.5rem !important;
  }
  .pb-xl-0 {
    padding-bottom: 0 !important;
  }
  .pb-xl-1 {
    padding-bottom: 0.25rem !important;
  }
  .pb-xl-2 {
    padding-bottom: 0.5rem !important;
  }
  .pb-xl-3 {
    padding-bottom: 1rem !important;
  }
  .pb-xl-4 {
    padding-bottom: 1.5rem !important;
  }
  .pb-xl-5 {
    padding-bottom: 2rem !important;
  }
  .pb-xl-6 {
    padding-bottom: 2.5rem !important;
  }
  .pb-xl-7 {
    padding-bottom: 3rem !important;
  }
  .pb-xl-8 {
    padding-bottom: 3.5rem !important;
  }
  .pb-xl-9 {
    padding-bottom: 4rem !important;
  }
  .pb-xl-10 {
    padding-bottom: 4.5rem !important;
  }
  .ps-xl-0 {
    padding-left: 0 !important;
  }
  .ps-xl-1 {
    padding-left: 0.25rem !important;
  }
  .ps-xl-2 {
    padding-left: 0.5rem !important;
  }
  .ps-xl-3 {
    padding-left: 1rem !important;
  }
  .ps-xl-4 {
    padding-left: 1.5rem !important;
  }
  .ps-xl-5 {
    padding-left: 2rem !important;
  }
  .ps-xl-6 {
    padding-left: 2.5rem !important;
  }
  .ps-xl-7 {
    padding-left: 3rem !important;
  }
  .ps-xl-8 {
    padding-left: 3.5rem !important;
  }
  .ps-xl-9 {
    padding-left: 4rem !important;
  }
  .ps-xl-10 {
    padding-left: 4.5rem !important;
  }
  .gap-xl-0 {
    gap: 0 !important;
  }
  .gap-xl-1 {
    gap: 0.25rem !important;
  }
  .gap-xl-2 {
    gap: 0.5rem !important;
  }
  .gap-xl-3 {
    gap: 1rem !important;
  }
  .gap-xl-4 {
    gap: 1.5rem !important;
  }
  .gap-xl-5 {
    gap: 2rem !important;
  }
  .gap-xl-6 {
    gap: 2.5rem !important;
  }
  .gap-xl-7 {
    gap: 3rem !important;
  }
  .gap-xl-8 {
    gap: 3.5rem !important;
  }
  .gap-xl-9 {
    gap: 4rem !important;
  }
  .gap-xl-10 {
    gap: 4.5rem !important;
  }
  .row-gap-xl-0 {
    row-gap: 0 !important;
  }
  .row-gap-xl-1 {
    row-gap: 0.25rem !important;
  }
  .row-gap-xl-2 {
    row-gap: 0.5rem !important;
  }
  .row-gap-xl-3 {
    row-gap: 1rem !important;
  }
  .row-gap-xl-4 {
    row-gap: 1.5rem !important;
  }
  .row-gap-xl-5 {
    row-gap: 2rem !important;
  }
  .row-gap-xl-6 {
    row-gap: 2.5rem !important;
  }
  .row-gap-xl-7 {
    row-gap: 3rem !important;
  }
  .row-gap-xl-8 {
    row-gap: 3.5rem !important;
  }
  .row-gap-xl-9 {
    row-gap: 4rem !important;
  }
  .row-gap-xl-10 {
    row-gap: 4.5rem !important;
  }
  .column-gap-xl-0 {
    column-gap: 0 !important;
  }
  .column-gap-xl-1 {
    column-gap: 0.25rem !important;
  }
  .column-gap-xl-2 {
    column-gap: 0.5rem !important;
  }
  .column-gap-xl-3 {
    column-gap: 1rem !important;
  }
  .column-gap-xl-4 {
    column-gap: 1.5rem !important;
  }
  .column-gap-xl-5 {
    column-gap: 2rem !important;
  }
  .column-gap-xl-6 {
    column-gap: 2.5rem !important;
  }
  .column-gap-xl-7 {
    column-gap: 3rem !important;
  }
  .column-gap-xl-8 {
    column-gap: 3.5rem !important;
  }
  .column-gap-xl-9 {
    column-gap: 4rem !important;
  }
  .column-gap-xl-10 {
    column-gap: 4.5rem !important;
  }
  .text-xl-start {
    text-align: left !important;
  }
  .text-xl-end {
    text-align: right !important;
  }
  .text-xl-center {
    text-align: center !important;
  }
  .content-space-t-xl-0 {
    padding-top: 0 !important;
  }
  .content-space-t-xl-1 {
    padding-top: 3.5rem !important;
  }
  .content-space-t-xl-2 {
    padding-top: 5rem !important;
  }
  .content-space-t-xl-3 {
    padding-top: 7.5rem !important;
  }
  .content-space-t-xl-4 {
    padding-top: 10rem !important;
  }
  .content-space-t-xl-auto {
    padding-top: auto !important;
  }
  .content-space-b-xl-0 {
    padding-bottom: 0 !important;
  }
  .content-space-b-xl-1 {
    padding-bottom: 3.5rem !important;
  }
  .content-space-b-xl-2 {
    padding-bottom: 5rem !important;
  }
  .content-space-b-xl-3 {
    padding-bottom: 7.5rem !important;
  }
  .content-space-b-xl-4 {
    padding-bottom: 10rem !important;
  }
  .content-space-b-xl-auto {
    padding-bottom: auto !important;
  }
  .content-space-xl-0 {
    padding-top: 0 !important;
    padding-bottom: 0 !important;
  }
  .content-space-xl-1 {
    padding-top: 3.5rem !important;
    padding-bottom: 3.5rem !important;
  }
  .content-space-xl-2 {
    padding-top: 5rem !important;
    padding-bottom: 5rem !important;
  }
  .content-space-xl-3 {
    padding-top: 7.5rem !important;
    padding-bottom: 7.5rem !important;
  }
  .content-space-xl-4 {
    padding-top: 10rem !important;
    padding-bottom: 10rem !important;
  }
  .content-space-xl-auto {
    padding-top: auto !important;
    padding-bottom: auto !important;
  }
}
@media (min-width: 1400px) {
  .float-xxl-start {
    float: left !important;
  }
  .float-xxl-end {
    float: right !important;
  }
  .float-xxl-none {
    float: none !important;
  }
  .object-fit-xxl-contain {
    object-fit: contain !important;
  }
  .object-fit-xxl-cover {
    object-fit: cover !important;
  }
  .object-fit-xxl-fill {
    object-fit: fill !important;
  }
  .object-fit-xxl-scale {
    object-fit: scale-down !important;
  }
  .object-fit-xxl-none {
    object-fit: none !important;
  }
  .d-xxl-inline {
    display: inline !important;
  }
  .d-xxl-inline-block {
    display: inline-block !important;
  }
  .d-xxl-block {
    display: block !important;
  }
  .d-xxl-grid {
    display: grid !important;
  }
  .d-xxl-inline-grid {
    display: inline-grid !important;
  }
  .d-xxl-table {
    display: table !important;
  }
  .d-xxl-table-row {
    display: table-row !important;
  }
  .d-xxl-table-cell {
    display: table-cell !important;
  }
  .d-xxl-flex {
    display: flex !important;
  }
  .d-xxl-inline-flex {
    display: inline-flex !important;
  }
  .d-xxl-none {
    display: none !important;
  }
  .position-xxl-static {
    position: static !important;
  }
  .position-xxl-relative {
    position: relative !important;
  }
  .position-xxl-absolute {
    position: absolute !important;
  }
  .position-xxl-fixed {
    position: fixed !important;
  }
  .position-xxl-sticky {
    position: sticky !important;
  }
  .top-xxl-0 {
    top: 0 !important;
  }
  .top-xxl-50 {
    top: 50% !important;
  }
  .top-xxl-100 {
    top: 100% !important;
  }
  .top-xxl-auto {
    top: auto !important;
  }
  .bottom-xxl-0 {
    bottom: 0 !important;
  }
  .bottom-xxl-50 {
    bottom: 50% !important;
  }
  .bottom-xxl-100 {
    bottom: 100% !important;
  }
  .bottom-xxl-auto {
    bottom: auto !important;
  }
  .start-xxl-0 {
    left: 0 !important;
  }
  .start-xxl-50 {
    left: 50% !important;
  }
  .start-xxl-100 {
    left: 100% !important;
  }
  .start-xxl-auto {
    left: auto !important;
  }
  .end-xxl-0 {
    right: 0 !important;
  }
  .end-xxl-50 {
    right: 50% !important;
  }
  .end-xxl-100 {
    right: 100% !important;
  }
  .end-xxl-auto {
    right: auto !important;
  }
  .translate-middle-xxl {
    transform: translate(-50%, -50%) !important;
  }
  .translate-middle-xxl-x {
    transform: translateX(-50%) !important;
  }
  .translate-middle-xxl-y {
    transform: translateY(-50%) !important;
  }
  .w-xxl-25 {
    width: 25% !important;
  }
  .w-xxl-50 {
    width: 50% !important;
  }
  .w-xxl-75 {
    width: 75% !important;
  }
  .w-xxl-100 {
    width: 100% !important;
  }
  .w-xxl-auto {
    width: auto !important;
  }
  .w-xxl-65 {
    width: 65% !important;
  }
  .w-xxl-85 {
    width: 85% !important;
  }
  .h-xxl-25 {
    height: 25% !important;
  }
  .h-xxl-50 {
    height: 50% !important;
  }
  .h-xxl-75 {
    height: 75% !important;
  }
  .h-xxl-100 {
    height: 100% !important;
  }
  .h-xxl-auto {
    height: auto !important;
  }
  .h-xxl-65 {
    height: 65% !important;
  }
  .vh-xxl-100 {
    height: 100vh !important;
  }
  .min-vh-xxl-100 {
    min-height: 100vh !important;
  }
  .min-vh-xxl-35 {
    min-height: 35vh !important;
  }
  .min-vh-xxl-75 {
    min-height: 75vh !important;
  }
  .flex-xxl-fill {
    flex: 1 1 auto !important;
  }
  .flex-xxl-row {
    flex-direction: row !important;
  }
  .flex-xxl-column {
    flex-direction: column !important;
  }
  .flex-xxl-row-reverse {
    flex-direction: row-reverse !important;
  }
  .flex-xxl-column-reverse {
    flex-direction: column-reverse !important;
  }
  .flex-xxl-grow-0 {
    flex-grow: 0 !important;
  }
  .flex-xxl-grow-1 {
    flex-grow: 1 !important;
  }
  .flex-xxl-shrink-0 {
    flex-shrink: 0 !important;
  }
  .flex-xxl-shrink-1 {
    flex-shrink: 1 !important;
  }
  .flex-xxl-wrap {
    flex-wrap: wrap !important;
  }
  .flex-xxl-nowrap {
    flex-wrap: nowrap !important;
  }
  .flex-xxl-wrap-reverse {
    flex-wrap: wrap-reverse !important;
  }
  .justify-content-xxl-start {
    justify-content: flex-start !important;
  }
  .justify-content-xxl-end {
    justify-content: flex-end !important;
  }
  .justify-content-xxl-center {
    justify-content: center !important;
  }
  .justify-content-xxl-between {
    justify-content: space-between !important;
  }
  .justify-content-xxl-around {
    justify-content: space-around !important;
  }
  .justify-content-xxl-evenly {
    justify-content: space-evenly !important;
  }
  .align-items-xxl-start {
    align-items: flex-start !important;
  }
  .align-items-xxl-end {
    align-items: flex-end !important;
  }
  .align-items-xxl-center {
    align-items: center !important;
  }
  .align-items-xxl-baseline {
    align-items: baseline !important;
  }
  .align-items-xxl-stretch {
    align-items: stretch !important;
  }
  .align-content-xxl-start {
    align-content: flex-start !important;
  }
  .align-content-xxl-end {
    align-content: flex-end !important;
  }
  .align-content-xxl-center {
    align-content: center !important;
  }
  .align-content-xxl-between {
    align-content: space-between !important;
  }
  .align-content-xxl-around {
    align-content: space-around !important;
  }
  .align-content-xxl-stretch {
    align-content: stretch !important;
  }
  .align-self-xxl-auto {
    align-self: auto !important;
  }
  .align-self-xxl-start {
    align-self: flex-start !important;
  }
  .align-self-xxl-end {
    align-self: flex-end !important;
  }
  .align-self-xxl-center {
    align-self: center !important;
  }
  .align-self-xxl-baseline {
    align-self: baseline !important;
  }
  .align-self-xxl-stretch {
    align-self: stretch !important;
  }
  .order-xxl-first {
    order: -1 !important;
  }
  .order-xxl-0 {
    order: 0 !important;
  }
  .order-xxl-1 {
    order: 1 !important;
  }
  .order-xxl-2 {
    order: 2 !important;
  }
  .order-xxl-3 {
    order: 3 !important;
  }
  .order-xxl-4 {
    order: 4 !important;
  }
  .order-xxl-5 {
    order: 5 !important;
  }
  .order-xxl-last {
    order: 6 !important;
  }
  .m-xxl-0 {
    margin: 0 !important;
  }
  .m-xxl-1 {
    margin: 0.25rem !important;
  }
  .m-xxl-2 {
    margin: 0.5rem !important;
  }
  .m-xxl-3 {
    margin: 1rem !important;
  }
  .m-xxl-4 {
    margin: 1.5rem !important;
  }
  .m-xxl-5 {
    margin: 2rem !important;
  }
  .m-xxl-6 {
    margin: 2.5rem !important;
  }
  .m-xxl-7 {
    margin: 3rem !important;
  }
  .m-xxl-8 {
    margin: 3.5rem !important;
  }
  .m-xxl-9 {
    margin: 4rem !important;
  }
  .m-xxl-10 {
    margin: 4.5rem !important;
  }
  .m-xxl-auto {
    margin: auto !important;
  }
  .mx-xxl-0 {
    margin-right: 0 !important;
    margin-left: 0 !important;
  }
  .mx-xxl-1 {
    margin-right: 0.25rem !important;
    margin-left: 0.25rem !important;
  }
  .mx-xxl-2 {
    margin-right: 0.5rem !important;
    margin-left: 0.5rem !important;
  }
  .mx-xxl-3 {
    margin-right: 1rem !important;
    margin-left: 1rem !important;
  }
  .mx-xxl-4 {
    margin-right: 1.5rem !important;
    margin-left: 1.5rem !important;
  }
  .mx-xxl-5 {
    margin-right: 2rem !important;
    margin-left: 2rem !important;
  }
  .mx-xxl-6 {
    margin-right: 2.5rem !important;
    margin-left: 2.5rem !important;
  }
  .mx-xxl-7 {
    margin-right: 3rem !important;
    margin-left: 3rem !important;
  }
  .mx-xxl-8 {
    margin-right: 3.5rem !important;
    margin-left: 3.5rem !important;
  }
  .mx-xxl-9 {
    margin-right: 4rem !important;
    margin-left: 4rem !important;
  }
  .mx-xxl-10 {
    margin-right: 4.5rem !important;
    margin-left: 4.5rem !important;
  }
  .mx-xxl-auto {
    margin-right: auto !important;
    margin-left: auto !important;
  }
  .my-xxl-0 {
    margin-top: 0 !important;
    margin-bottom: 0 !important;
  }
  .my-xxl-1 {
    margin-top: 0.25rem !important;
    margin-bottom: 0.25rem !important;
  }
  .my-xxl-2 {
    margin-top: 0.5rem !important;
    margin-bottom: 0.5rem !important;
  }
  .my-xxl-3 {
    margin-top: 1rem !important;
    margin-bottom: 1rem !important;
  }
  .my-xxl-4 {
    margin-top: 1.5rem !important;
    margin-bottom: 1.5rem !important;
  }
  .my-xxl-5 {
    margin-top: 2rem !important;
    margin-bottom: 2rem !important;
  }
  .my-xxl-6 {
    margin-top: 2.5rem !important;
    margin-bottom: 2.5rem !important;
  }
  .my-xxl-7 {
    margin-top: 3rem !important;
    margin-bottom: 3rem !important;
  }
  .my-xxl-8 {
    margin-top: 3.5rem !important;
    margin-bottom: 3.5rem !important;
  }
  .my-xxl-9 {
    margin-top: 4rem !important;
    margin-bottom: 4rem !important;
  }
  .my-xxl-10 {
    margin-top: 4.5rem !important;
    margin-bottom: 4.5rem !important;
  }
  .my-xxl-auto {
    margin-top: auto !important;
    margin-bottom: auto !important;
  }
  .mt-xxl-0 {
    margin-top: 0 !important;
  }
  .mt-xxl-1 {
    margin-top: 0.25rem !important;
  }
  .mt-xxl-2 {
    margin-top: 0.5rem !important;
  }
  .mt-xxl-3 {
    margin-top: 1rem !important;
  }
  .mt-xxl-4 {
    margin-top: 1.5rem !important;
  }
  .mt-xxl-5 {
    margin-top: 2rem !important;
  }
  .mt-xxl-6 {
    margin-top: 2.5rem !important;
  }
  .mt-xxl-7 {
    margin-top: 3rem !important;
  }
  .mt-xxl-8 {
    margin-top: 3.5rem !important;
  }
  .mt-xxl-9 {
    margin-top: 4rem !important;
  }
  .mt-xxl-10 {
    margin-top: 4.5rem !important;
  }
  .mt-xxl-auto {
    margin-top: auto !important;
  }
  .me-xxl-0 {
    margin-right: 0 !important;
  }
  .me-xxl-1 {
    margin-right: 0.25rem !important;
  }
  .me-xxl-2 {
    margin-right: 0.5rem !important;
  }
  .me-xxl-3 {
    margin-right: 1rem !important;
  }
  .me-xxl-4 {
    margin-right: 1.5rem !important;
  }
  .me-xxl-5 {
    margin-right: 2rem !important;
  }
  .me-xxl-6 {
    margin-right: 2.5rem !important;
  }
  .me-xxl-7 {
    margin-right: 3rem !important;
  }
  .me-xxl-8 {
    margin-right: 3.5rem !important;
  }
  .me-xxl-9 {
    margin-right: 4rem !important;
  }
  .me-xxl-10 {
    margin-right: 4.5rem !important;
  }
  .me-xxl-auto {
    margin-right: auto !important;
  }
  .mb-xxl-0 {
    margin-bottom: 0 !important;
  }
  .mb-xxl-1 {
    margin-bottom: 0.25rem !important;
  }
  .mb-xxl-2 {
    margin-bottom: 0.5rem !important;
  }
  .mb-xxl-3 {
    margin-bottom: 1rem !important;
  }
  .mb-xxl-4 {
    margin-bottom: 1.5rem !important;
  }
  .mb-xxl-5 {
    margin-bottom: 2rem !important;
  }
  .mb-xxl-6 {
    margin-bottom: 2.5rem !important;
  }
  .mb-xxl-7 {
    margin-bottom: 3rem !important;
  }
  .mb-xxl-8 {
    margin-bottom: 3.5rem !important;
  }
  .mb-xxl-9 {
    margin-bottom: 4rem !important;
  }
  .mb-xxl-10 {
    margin-bottom: 4.5rem !important;
  }
  .mb-xxl-auto {
    margin-bottom: auto !important;
  }
  .ms-xxl-0 {
    margin-left: 0 !important;
  }
  .ms-xxl-1 {
    margin-left: 0.25rem !important;
  }
  .ms-xxl-2 {
    margin-left: 0.5rem !important;
  }
  .ms-xxl-3 {
    margin-left: 1rem !important;
  }
  .ms-xxl-4 {
    margin-left: 1.5rem !important;
  }
  .ms-xxl-5 {
    margin-left: 2rem !important;
  }
  .ms-xxl-6 {
    margin-left: 2.5rem !important;
  }
  .ms-xxl-7 {
    margin-left: 3rem !important;
  }
  .ms-xxl-8 {
    margin-left: 3.5rem !important;
  }
  .ms-xxl-9 {
    margin-left: 4rem !important;
  }
  .ms-xxl-10 {
    margin-left: 4.5rem !important;
  }
  .ms-xxl-auto {
    margin-left: auto !important;
  }
  .m-xxl-n1 {
    margin: -0.25rem !important;
  }
  .m-xxl-n2 {
    margin: -0.5rem !important;
  }
  .m-xxl-n3 {
    margin: -1rem !important;
  }
  .m-xxl-n4 {
    margin: -1.5rem !important;
  }
  .m-xxl-n5 {
    margin: -2rem !important;
  }
  .m-xxl-n6 {
    margin: -2.5rem !important;
  }
  .m-xxl-n7 {
    margin: -3rem !important;
  }
  .m-xxl-n8 {
    margin: -3.5rem !important;
  }
  .m-xxl-n9 {
    margin: -4rem !important;
  }
  .m-xxl-n10 {
    margin: -4.5rem !important;
  }
  .mx-xxl-n1 {
    margin-right: -0.25rem !important;
    margin-left: -0.25rem !important;
  }
  .mx-xxl-n2 {
    margin-right: -0.5rem !important;
    margin-left: -0.5rem !important;
  }
  .mx-xxl-n3 {
    margin-right: -1rem !important;
    margin-left: -1rem !important;
  }
  .mx-xxl-n4 {
    margin-right: -1.5rem !important;
    margin-left: -1.5rem !important;
  }
  .mx-xxl-n5 {
    margin-right: -2rem !important;
    margin-left: -2rem !important;
  }
  .mx-xxl-n6 {
    margin-right: -2.5rem !important;
    margin-left: -2.5rem !important;
  }
  .mx-xxl-n7 {
    margin-right: -3rem !important;
    margin-left: -3rem !important;
  }
  .mx-xxl-n8 {
    margin-right: -3.5rem !important;
    margin-left: -3.5rem !important;
  }
  .mx-xxl-n9 {
    margin-right: -4rem !important;
    margin-left: -4rem !important;
  }
  .mx-xxl-n10 {
    margin-right: -4.5rem !important;
    margin-left: -4.5rem !important;
  }
  .my-xxl-n1 {
    margin-top: -0.25rem !important;
    margin-bottom: -0.25rem !important;
  }
  .my-xxl-n2 {
    margin-top: -0.5rem !important;
    margin-bottom: -0.5rem !important;
  }
  .my-xxl-n3 {
    margin-top: -1rem !important;
    margin-bottom: -1rem !important;
  }
  .my-xxl-n4 {
    margin-top: -1.5rem !important;
    margin-bottom: -1.5rem !important;
  }
  .my-xxl-n5 {
    margin-top: -2rem !important;
    margin-bottom: -2rem !important;
  }
  .my-xxl-n6 {
    margin-top: -2.5rem !important;
    margin-bottom: -2.5rem !important;
  }
  .my-xxl-n7 {
    margin-top: -3rem !important;
    margin-bottom: -3rem !important;
  }
  .my-xxl-n8 {
    margin-top: -3.5rem !important;
    margin-bottom: -3.5rem !important;
  }
  .my-xxl-n9 {
    margin-top: -4rem !important;
    margin-bottom: -4rem !important;
  }
  .my-xxl-n10 {
    margin-top: -4.5rem !important;
    margin-bottom: -4.5rem !important;
  }
  .mt-xxl-n1 {
    margin-top: -0.25rem !important;
  }
  .mt-xxl-n2 {
    margin-top: -0.5rem !important;
  }
  .mt-xxl-n3 {
    margin-top: -1rem !important;
  }
  .mt-xxl-n4 {
    margin-top: -1.5rem !important;
  }
  .mt-xxl-n5 {
    margin-top: -2rem !important;
  }
  .mt-xxl-n6 {
    margin-top: -2.5rem !important;
  }
  .mt-xxl-n7 {
    margin-top: -3rem !important;
  }
  .mt-xxl-n8 {
    margin-top: -3.5rem !important;
  }
  .mt-xxl-n9 {
    margin-top: -4rem !important;
  }
  .mt-xxl-n10 {
    margin-top: -4.5rem !important;
  }
  .me-xxl-n1 {
    margin-right: -0.25rem !important;
  }
  .me-xxl-n2 {
    margin-right: -0.5rem !important;
  }
  .me-xxl-n3 {
    margin-right: -1rem !important;
  }
  .me-xxl-n4 {
    margin-right: -1.5rem !important;
  }
  .me-xxl-n5 {
    margin-right: -2rem !important;
  }
  .me-xxl-n6 {
    margin-right: -2.5rem !important;
  }
  .me-xxl-n7 {
    margin-right: -3rem !important;
  }
  .me-xxl-n8 {
    margin-right: -3.5rem !important;
  }
  .me-xxl-n9 {
    margin-right: -4rem !important;
  }
  .me-xxl-n10 {
    margin-right: -4.5rem !important;
  }
  .mb-xxl-n1 {
    margin-bottom: -0.25rem !important;
  }
  .mb-xxl-n2 {
    margin-bottom: -0.5rem !important;
  }
  .mb-xxl-n3 {
    margin-bottom: -1rem !important;
  }
  .mb-xxl-n4 {
    margin-bottom: -1.5rem !important;
  }
  .mb-xxl-n5 {
    margin-bottom: -2rem !important;
  }
  .mb-xxl-n6 {
    margin-bottom: -2.5rem !important;
  }
  .mb-xxl-n7 {
    margin-bottom: -3rem !important;
  }
  .mb-xxl-n8 {
    margin-bottom: -3.5rem !important;
  }
  .mb-xxl-n9 {
    margin-bottom: -4rem !important;
  }
  .mb-xxl-n10 {
    margin-bottom: -4.5rem !important;
  }
  .ms-xxl-n1 {
    margin-left: -0.25rem !important;
  }
  .ms-xxl-n2 {
    margin-left: -0.5rem !important;
  }
  .ms-xxl-n3 {
    margin-left: -1rem !important;
  }
  .ms-xxl-n4 {
    margin-left: -1.5rem !important;
  }
  .ms-xxl-n5 {
    margin-left: -2rem !important;
  }
  .ms-xxl-n6 {
    margin-left: -2.5rem !important;
  }
  .ms-xxl-n7 {
    margin-left: -3rem !important;
  }
  .ms-xxl-n8 {
    margin-left: -3.5rem !important;
  }
  .ms-xxl-n9 {
    margin-left: -4rem !important;
  }
  .ms-xxl-n10 {
    margin-left: -4.5rem !important;
  }
  .p-xxl-0 {
    padding: 0 !important;
  }
  .p-xxl-1 {
    padding: 0.25rem !important;
  }
  .p-xxl-2 {
    padding: 0.5rem !important;
  }
  .p-xxl-3 {
    padding: 1rem !important;
  }
  .p-xxl-4 {
    padding: 1.5rem !important;
  }
  .p-xxl-5 {
    padding: 2rem !important;
  }
  .p-xxl-6 {
    padding: 2.5rem !important;
  }
  .p-xxl-7 {
    padding: 3rem !important;
  }
  .p-xxl-8 {
    padding: 3.5rem !important;
  }
  .p-xxl-9 {
    padding: 4rem !important;
  }
  .p-xxl-10 {
    padding: 4.5rem !important;
  }
  .px-xxl-0 {
    padding-right: 0 !important;
    padding-left: 0 !important;
  }
  .px-xxl-1 {
    padding-right: 0.25rem !important;
    padding-left: 0.25rem !important;
  }
  .px-xxl-2 {
    padding-right: 0.5rem !important;
    padding-left: 0.5rem !important;
  }
  .px-xxl-3 {
    padding-right: 1rem !important;
    padding-left: 1rem !important;
  }
  .px-xxl-4 {
    padding-right: 1.5rem !important;
    padding-left: 1.5rem !important;
  }
  .px-xxl-5 {
    padding-right: 2rem !important;
    padding-left: 2rem !important;
  }
  .px-xxl-6 {
    padding-right: 2.5rem !important;
    padding-left: 2.5rem !important;
  }
  .px-xxl-7 {
    padding-right: 3rem !important;
    padding-left: 3rem !important;
  }
  .px-xxl-8 {
    padding-right: 3.5rem !important;
    padding-left: 3.5rem !important;
  }
  .px-xxl-9 {
    padding-right: 4rem !important;
    padding-left: 4rem !important;
  }
  .px-xxl-10 {
    padding-right: 4.5rem !important;
    padding-left: 4.5rem !important;
  }
  .py-xxl-0 {
    padding-top: 0 !important;
    padding-bottom: 0 !important;
  }
  .py-xxl-1 {
    padding-top: 0.25rem !important;
    padding-bottom: 0.25rem !important;
  }
  .py-xxl-2 {
    padding-top: 0.5rem !important;
    padding-bottom: 0.5rem !important;
  }
  .py-xxl-3 {
    padding-top: 1rem !important;
    padding-bottom: 1rem !important;
  }
  .py-xxl-4 {
    padding-top: 1.5rem !important;
    padding-bottom: 1.5rem !important;
  }
  .py-xxl-5 {
    padding-top: 2rem !important;
    padding-bottom: 2rem !important;
  }
  .py-xxl-6 {
    padding-top: 2.5rem !important;
    padding-bottom: 2.5rem !important;
  }
  .py-xxl-7 {
    padding-top: 3rem !important;
    padding-bottom: 3rem !important;
  }
  .py-xxl-8 {
    padding-top: 3.5rem !important;
    padding-bottom: 3.5rem !important;
  }
  .py-xxl-9 {
    padding-top: 4rem !important;
    padding-bottom: 4rem !important;
  }
  .py-xxl-10 {
    padding-top: 4.5rem !important;
    padding-bottom: 4.5rem !important;
  }
  .pt-xxl-0 {
    padding-top: 0 !important;
  }
  .pt-xxl-1 {
    padding-top: 0.25rem !important;
  }
  .pt-xxl-2 {
    padding-top: 0.5rem !important;
  }
  .pt-xxl-3 {
    padding-top: 1rem !important;
  }
  .pt-xxl-4 {
    padding-top: 1.5rem !important;
  }
  .pt-xxl-5 {
    padding-top: 2rem !important;
  }
  .pt-xxl-6 {
    padding-top: 2.5rem !important;
  }
  .pt-xxl-7 {
    padding-top: 3rem !important;
  }
  .pt-xxl-8 {
    padding-top: 3.5rem !important;
  }
  .pt-xxl-9 {
    padding-top: 4rem !important;
  }
  .pt-xxl-10 {
    padding-top: 4.5rem !important;
  }
  .pe-xxl-0 {
    padding-right: 0 !important;
  }
  .pe-xxl-1 {
    padding-right: 0.25rem !important;
  }
  .pe-xxl-2 {
    padding-right: 0.5rem !important;
  }
  .pe-xxl-3 {
    padding-right: 1rem !important;
  }
  .pe-xxl-4 {
    padding-right: 1.5rem !important;
  }
  .pe-xxl-5 {
    padding-right: 2rem !important;
  }
  .pe-xxl-6 {
    padding-right: 2.5rem !important;
  }
  .pe-xxl-7 {
    padding-right: 3rem !important;
  }
  .pe-xxl-8 {
    padding-right: 3.5rem !important;
  }
  .pe-xxl-9 {
    padding-right: 4rem !important;
  }
  .pe-xxl-10 {
    padding-right: 4.5rem !important;
  }
  .pb-xxl-0 {
    padding-bottom: 0 !important;
  }
  .pb-xxl-1 {
    padding-bottom: 0.25rem !important;
  }
  .pb-xxl-2 {
    padding-bottom: 0.5rem !important;
  }
  .pb-xxl-3 {
    padding-bottom: 1rem !important;
  }
  .pb-xxl-4 {
    padding-bottom: 1.5rem !important;
  }
  .pb-xxl-5 {
    padding-bottom: 2rem !important;
  }
  .pb-xxl-6 {
    padding-bottom: 2.5rem !important;
  }
  .pb-xxl-7 {
    padding-bottom: 3rem !important;
  }
  .pb-xxl-8 {
    padding-bottom: 3.5rem !important;
  }
  .pb-xxl-9 {
    padding-bottom: 4rem !important;
  }
  .pb-xxl-10 {
    padding-bottom: 4.5rem !important;
  }
  .ps-xxl-0 {
    padding-left: 0 !important;
  }
  .ps-xxl-1 {
    padding-left: 0.25rem !important;
  }
  .ps-xxl-2 {
    padding-left: 0.5rem !important;
  }
  .ps-xxl-3 {
    padding-left: 1rem !important;
  }
  .ps-xxl-4 {
    padding-left: 1.5rem !important;
  }
  .ps-xxl-5 {
    padding-left: 2rem !important;
  }
  .ps-xxl-6 {
    padding-left: 2.5rem !important;
  }
  .ps-xxl-7 {
    padding-left: 3rem !important;
  }
  .ps-xxl-8 {
    padding-left: 3.5rem !important;
  }
  .ps-xxl-9 {
    padding-left: 4rem !important;
  }
  .ps-xxl-10 {
    padding-left: 4.5rem !important;
  }
  .gap-xxl-0 {
    gap: 0 !important;
  }
  .gap-xxl-1 {
    gap: 0.25rem !important;
  }
  .gap-xxl-2 {
    gap: 0.5rem !important;
  }
  .gap-xxl-3 {
    gap: 1rem !important;
  }
  .gap-xxl-4 {
    gap: 1.5rem !important;
  }
  .gap-xxl-5 {
    gap: 2rem !important;
  }
  .gap-xxl-6 {
    gap: 2.5rem !important;
  }
  .gap-xxl-7 {
    gap: 3rem !important;
  }
  .gap-xxl-8 {
    gap: 3.5rem !important;
  }
  .gap-xxl-9 {
    gap: 4rem !important;
  }
  .gap-xxl-10 {
    gap: 4.5rem !important;
  }
  .row-gap-xxl-0 {
    row-gap: 0 !important;
  }
  .row-gap-xxl-1 {
    row-gap: 0.25rem !important;
  }
  .row-gap-xxl-2 {
    row-gap: 0.5rem !important;
  }
  .row-gap-xxl-3 {
    row-gap: 1rem !important;
  }
  .row-gap-xxl-4 {
    row-gap: 1.5rem !important;
  }
  .row-gap-xxl-5 {
    row-gap: 2rem !important;
  }
  .row-gap-xxl-6 {
    row-gap: 2.5rem !important;
  }
  .row-gap-xxl-7 {
    row-gap: 3rem !important;
  }
  .row-gap-xxl-8 {
    row-gap: 3.5rem !important;
  }
  .row-gap-xxl-9 {
    row-gap: 4rem !important;
  }
  .row-gap-xxl-10 {
    row-gap: 4.5rem !important;
  }
  .column-gap-xxl-0 {
    column-gap: 0 !important;
  }
  .column-gap-xxl-1 {
    column-gap: 0.25rem !important;
  }
  .column-gap-xxl-2 {
    column-gap: 0.5rem !important;
  }
  .column-gap-xxl-3 {
    column-gap: 1rem !important;
  }
  .column-gap-xxl-4 {
    column-gap: 1.5rem !important;
  }
  .column-gap-xxl-5 {
    column-gap: 2rem !important;
  }
  .column-gap-xxl-6 {
    column-gap: 2.5rem !important;
  }
  .column-gap-xxl-7 {
    column-gap: 3rem !important;
  }
  .column-gap-xxl-8 {
    column-gap: 3.5rem !important;
  }
  .column-gap-xxl-9 {
    column-gap: 4rem !important;
  }
  .column-gap-xxl-10 {
    column-gap: 4.5rem !important;
  }
  .text-xxl-start {
    text-align: left !important;
  }
  .text-xxl-end {
    text-align: right !important;
  }
  .text-xxl-center {
    text-align: center !important;
  }
  .content-space-t-xxl-0 {
    padding-top: 0 !important;
  }
  .content-space-t-xxl-1 {
    padding-top: 3.5rem !important;
  }
  .content-space-t-xxl-2 {
    padding-top: 5rem !important;
  }
  .content-space-t-xxl-3 {
    padding-top: 7.5rem !important;
  }
  .content-space-t-xxl-4 {
    padding-top: 10rem !important;
  }
  .content-space-t-xxl-auto {
    padding-top: auto !important;
  }
  .content-space-b-xxl-0 {
    padding-bottom: 0 !important;
  }
  .content-space-b-xxl-1 {
    padding-bottom: 3.5rem !important;
  }
  .content-space-b-xxl-2 {
    padding-bottom: 5rem !important;
  }
  .content-space-b-xxl-3 {
    padding-bottom: 7.5rem !important;
  }
  .content-space-b-xxl-4 {
    padding-bottom: 10rem !important;
  }
  .content-space-b-xxl-auto {
    padding-bottom: auto !important;
  }
  .content-space-xxl-0 {
    padding-top: 0 !important;
    padding-bottom: 0 !important;
  }
  .content-space-xxl-1 {
    padding-top: 3.5rem !important;
    padding-bottom: 3.5rem !important;
  }
  .content-space-xxl-2 {
    padding-top: 5rem !important;
    padding-bottom: 5rem !important;
  }
  .content-space-xxl-3 {
    padding-top: 7.5rem !important;
    padding-bottom: 7.5rem !important;
  }
  .content-space-xxl-4 {
    padding-top: 10rem !important;
    padding-bottom: 10rem !important;
  }
  .content-space-xxl-auto {
    padding-top: auto !important;
    padding-bottom: auto !important;
  }
}
@media (min-width: 1200px) {
  .fs-1 {
    font-size: 2.25rem !important;
  }
  .fs-2 {
    font-size: 1.75rem !important;
  }
}
@media print {
  .d-print-inline {
    display: inline !important;
  }
  .d-print-inline-block {
    display: inline-block !important;
  }
  .d-print-block {
    display: block !important;
  }
  .d-print-grid {
    display: grid !important;
  }
  .d-print-inline-grid {
    display: inline-grid !important;
  }
  .d-print-table {
    display: table !important;
  }
  .d-print-table-row {
    display: table-row !important;
  }
  .d-print-table-cell {
    display: table-cell !important;
  }
  .d-print-flex {
    display: flex !important;
  }
  .d-print-inline-flex {
    display: inline-flex !important;
  }
  .d-print-none {
    display: none !important;
  }
}
/*------------------------------------
  Default Styles
------------------------------------*/
a {
  text-decoration: none;
}

:focus,
a:focus,
button:focus {
  outline-color: rgba(10, 191, 83, 0.5);
}

@media (max-width: 767.98px) {
  h1, .h1 {
    font-size: calc(1.525rem + 3.3vw);
  }
  h2, .h2 {
    font-size: calc(1.425rem + 2.1vw);
  }
}
figure {
  margin-bottom: 0;
}

p, ul {
  color: #2d374b;
}

dt {
  color: #2d374b;
}

dd {
  margin-bottom: 1rem;
}

/* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* Firefox */
input[type=number] {
  -moz-appearance: textfield;
}

/* Highlight Color */
::-moz-selection {
  color: #0abf53;
  background-color: rgba(10, 191, 83, 0.1);
}

::selection {
  color: #0abf53;
  background-color: rgba(10, 191, 83, 0.1);
}

.bg-primary ::-moz-selection {
  color: white;
  background-color: rgba(255, 255, 255, 0.1);
}

.bg-primary ::selection {
  color: white;
  background-color: rgba(255, 255, 255, 0.1);
}

/*------------------------------------
  Animation
------------------------------------*/
.animated {
  animation-duration: 1s;
  animation-fill-mode: both;
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
.fadeIn {
  animation-name: fadeIn;
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translate3d(0, 15px, 0);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
.fadeInUp {
  animation-name: fadeInUp;
}

@keyframes fadeOut {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}
.fadeOut {
  animation-name: fadeOut;
}

@keyframes fadeOutUp {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    transform: translate3d(0, -100%, 0);
  }
}
.fadeOutUp {
  animation-name: fadeOutUp;
}

@keyframes fadeOutDown {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    transform: translate3d(0, 100%, 0);
  }
}
.fadeOutDown {
  animation-name: fadeOutDown;
}

@keyframes slideInUp {
  from {
    transform: translate3d(0, 10px, 0);
    visibility: visible;
  }
  to {
    transform: translate3d(0, 0, 0);
  }
}
.slideInUp {
  animation-name: slideInUp;
}

@keyframes slideInDown {
  from {
    transform: translate3d(0, -10px, 0);
    visibility: visible;
  }
  to {
    transform: translate3d(0, 0, 0);
  }
}
.slideInDown {
  animation-name: slideInDown;
}

@keyframes fadeInLeft {
  from {
    opacity: 0;
    transform: translate3d(-100%, 0, 0);
  }
  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
}
.fadeInLeft {
  animation-name: fadeInLeft;
}

@keyframes fadeInRight {
  from {
    opacity: 0;
    transform: translate3d(100%, 0, 0);
  }
  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
}
.fadeInRight {
  animation-name: fadeInRight;
}

@keyframes fadeOutLeft {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    transform: translate3d(-100%, 0, 0);
  }
}
.fadeOutLeft {
  animation-name: fadeOutLeft;
}

@keyframes fadeOutRight {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    transform: translate3d(100%, 0, 0);
  }
}
.fadeOutRight {
  animation-name: fadeOutRight;
}

/*------------------------------------
  Accordion
------------------------------------*/
.accordion-button:focus {
  box-shadow: none;
}

.accordion-button {
  color: #2d374b;
  font-size: 1.125rem;
  font-weight: 500;
  padding: 1.5rem 2rem;
}
@media (max-width: 575.98px) {
  .accordion-button {
    padding: 1rem 1.3333333333rem;
  }
}
.accordion-button:hover {
  color: #2d374b;
}
.accordion-button:not(.collapsed) {
  font-weight: 700;
}
.accordion-button:not(.collapsed)::before {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%232d374b'%3E%3Cpath d='M5.5,13a.5.5,0,0,1-.5-.5v-1a.5.5,0,0,1,.5-.5h13a.5.5,0,0,1,.5.5v1a.5.5,0,0,1-.5.5Z'/%3E%3C/svg%3E");
  transform: rotate(0deg);
}
.accordion-button::before {
  flex-shrink: 0;
  width: 1.25rem;
  height: 1.25rem;
  margin-right: 1rem;
  content: "";
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%232d374b'%3E%3Cpath d='M19,11.5v1a.5.5,0,0,1-.5.5H13v5.5a.5.5,0,0,1-.5.5h-1a.5.5,0,0,1-.5-.5V13H5.5a.5.5,0,0,1-.5-.5v-1a.5.5,0,0,1,.5-.5H11V5.5a.5.5,0,0,1,.5-.5h1a.5.5,0,0,1,.5.5V11h5.5A.5.5,0,0,1,19,11.5Z'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-size: 1.25rem;
  transition: transform 0.2s ease-in-out;
}
@media (prefers-reduced-motion: reduce) {
  .accordion-button::before {
    transition: none;
  }
}
.accordion-button::after {
  display: none;
}

@media (max-width: 575.98px) {
  .accordion-button,
.accordion-body {
    padding: 1rem 1.3333333333rem;
  }
}

.accordion-body {
  padding-left: 4.25rem;
}

.accordion-collapse {
  background-color: #F5F7FA;
}

.accordion-flush .accordion-item {
  border-width: 0;
}
.accordion-flush .accordion-item:last-of-type .accordion-collapse {
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}
.accordion-flush .accordion-button:not(.collapsed) {
  box-shadow: none;
}
.accordion-flush .accordion-body {
  padding-top: 0;
}

/*------------------------------------
  Alert
------------------------------------*/
.alert .alert-link:hover {
  color: #07853a;
}

/*------------------------------------
  Alert Styles
------------------------------------*/
.alert-primary {
  color: white;
  background-color: #0abf53;
  border-color: #0abf53;
  box-shadow: 0 0.25rem 1.5rem rgba(10, 191, 83, 0.4), 0 0.25rem 1.5rem rgba(45, 55, 75, 0.1);
}
.alert-primary .alert-link {
  color: white;
}

.alert-secondary {
  color: white;
  background-color: #51596c;
  border-color: #51596c;
  box-shadow: 0 0.25rem 1.5rem rgba(81, 89, 108, 0.4), 0 0.25rem 1.5rem rgba(45, 55, 75, 0.1);
}
.alert-secondary .alert-link {
  color: white;
}

.alert-success {
  color: white;
  background-color: #077c76;
  border-color: #077c76;
  box-shadow: 0 0.25rem 1.5rem rgba(7, 124, 118, 0.4), 0 0.25rem 1.5rem rgba(45, 55, 75, 0.1);
}
.alert-success .alert-link {
  color: white;
}

.alert-info {
  color: white;
  background-color: #334ac0;
  border-color: #334ac0;
  box-shadow: 0 0.25rem 1.5rem rgba(51, 74, 192, 0.4), 0 0.25rem 1.5rem rgba(45, 55, 75, 0.1);
}
.alert-info .alert-link {
  color: white;
}

.alert-warning {
  color: #000;
  background-color: #f39568;
  border-color: #f39568;
  box-shadow: 0 0.25rem 1.5rem rgba(243, 149, 104, 0.4), 0 0.25rem 1.5rem rgba(45, 55, 75, 0.1);
}
.alert-warning .alert-link {
  color: #000;
}

.alert-danger {
  color: white;
  background-color: #692340;
  border-color: #692340;
  box-shadow: 0 0.25rem 1.5rem rgba(105, 35, 64, 0.4), 0 0.25rem 1.5rem rgba(45, 55, 75, 0.1);
}
.alert-danger .alert-link {
  color: white;
}

.alert-light {
  color: #000;
  background-color: #f8f9fa;
  border-color: #f8f9fa;
  box-shadow: 0 0.25rem 1.5rem rgba(248, 249, 250, 0.4), 0 0.25rem 1.5rem rgba(45, 55, 75, 0.1);
}
.alert-light .alert-link {
  color: #000;
}

.alert-dark {
  color: white;
  background-color: #2d374b;
  border-color: #2d374b;
  box-shadow: 0 0.25rem 1.5rem rgba(45, 55, 75, 0.4), 0 0.25rem 1.5rem rgba(45, 55, 75, 0.1);
}
.alert-dark .alert-link {
  color: white;
}

.alert-soft-primary {
  color: #0abf53;
  background-color: rgba(10, 191, 83, 0.075);
}
.alert-soft-primary .alert-link {
  color: #0abf53;
}

.alert-soft-secondary {
  color: #51596c;
  background-color: rgba(81, 89, 108, 0.075);
}
.alert-soft-secondary .alert-link {
  color: #51596c;
}

.alert-soft-success {
  color: #077c76;
  background-color: rgba(7, 124, 118, 0.075);
}
.alert-soft-success .alert-link {
  color: #077c76;
}

.alert-soft-info {
  color: #334ac0;
  background-color: rgba(51, 74, 192, 0.075);
}
.alert-soft-info .alert-link {
  color: #334ac0;
}

.alert-soft-warning {
  color: #f39568;
  background-color: rgba(243, 149, 104, 0.075);
}
.alert-soft-warning .alert-link {
  color: #f39568;
}

.alert-soft-danger {
  color: #692340;
  background-color: rgba(105, 35, 64, 0.075);
}
.alert-soft-danger .alert-link {
  color: #692340;
}

.alert-soft-light {
  color: #f8f9fa;
  background-color: rgba(248, 249, 250, 0.075);
}
.alert-soft-light .alert-link {
  color: #f8f9fa;
}

.alert-soft-dark {
  color: #2d374b;
  background-color: rgba(45, 55, 75, 0.075);
}
.alert-soft-dark .alert-link {
  color: #2d374b;
}

/*------------------------------------
  Avatar
------------------------------------*/
.avatar {
  position: relative;
  display: inline-block;
  width: 2.875rem;
  height: 2.875rem;
  border-radius: 0.6rem;
}
.avatar:not(img) {
  background-color: white;
}

.avatar-img {
  max-width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 0.6rem;
}

.avatar-initials {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 2.875rem;
  height: 2.875rem;
  font-size: 1rem;
  font-weight: 500;
  pointer-events: none;
  text-transform: uppercase;
  border-radius: 0.6rem;
}

.avatar-circle {
  border-radius: 50%;
}
.avatar-circle .avatar,
.avatar-circle .avatar-initials,
.avatar-circle .avatar-img {
  border-radius: 50%;
}

.avatar-centered {
  display: flex;
  margin-right: auto;
  margin-left: auto;
}

/*------------------------------------
  Avatar Group
------------------------------------*/
.avatar-group {
  display: flex;
}
.avatar-group .avatar:hover {
  z-index: 2;
}
.avatar-group .avatar-circle .avatar-initials {
  border-radius: 50%;
}
.avatar-group .avatar-xs .avatar-img,
.avatar-group .avatar-xs .avatar-initials,
.avatar-group .avatar-sm .avatar-img,
.avatar-group .avatar-sm .avatar-initials,
.avatar-group .avatar .avatar-img,
.avatar-group .avatar .avatar-initials {
  border: 2px solid white;
}
.avatar-group .avatar-lg .avatar-img,
.avatar-group .avatar-lg .avatar-initials {
  border: 5px solid white;
}
.avatar-group .avatar-xl .avatar-img,
.avatar-group .avatar-xl .avatar-initials {
  border: 7px solid white;
}
.avatar-group .avatar + .avatar {
  margin-left: -1rem;
}
.avatar-group .avatar-xs + .avatar-xs {
  margin-left: -0.6125rem;
}
.avatar-group .avatar-sm + .avatar-sm {
  margin-left: -0.875rem;
}
.avatar-group .avatar-lg + .avatar-lg {
  margin-left: -1.5rem;
}
.avatar-group .avatar-xl + .avatar-xl {
  margin-left: -2rem;
}

/*------------------------------------
  Avatar Group Sizes
------------------------------------*/
.avatar-group .avatar,
.avatar-group .avatar-initials {
  width: 2.875rem;
  height: 2.875rem;
}
.avatar-group .avatar-initials {
  font-size: 1rem;
}
.avatar-group .avatar + .avatar {
  margin-left: -1rem;
}

.avatar-group-xs .avatar,
.avatar-group-xs .avatar-initials {
  width: 1.75rem;
  height: 1.75rem;
}
.avatar-group-xs .avatar-initials {
  font-size: 0.75rem;
}
.avatar-group-xs .avatar + .avatar {
  margin-left: -0.6125rem;
}

.avatar-group-sm .avatar,
.avatar-group-sm .avatar-initials {
  width: 2.3125rem;
  height: 2.3125rem;
}
.avatar-group-sm .avatar-initials {
  font-size: 0.8125rem;
}
.avatar-group-sm .avatar + .avatar {
  margin-left: -0.875rem;
}

.avatar-group-lg .avatar,
.avatar-group-lg .avatar-initials {
  width: 4.25rem;
  height: 4.25rem;
}
.avatar-group-lg .avatar-initials {
  font-size: 1.125rem;
}
.avatar-group-lg .avatar + .avatar {
  margin-left: -1.5rem;
}

.avatar-group-xl .avatar,
.avatar-group-xl .avatar-initials {
  width: 5.625rem;
  height: 5.625rem;
}
.avatar-group-xl .avatar-initials {
  font-size: 2rem;
}
.avatar-group-xl .avatar + .avatar {
  margin-left: -1.5rem;
}

.avatar-group-xxl .avatar,
.avatar-group-xxl .avatar-initials {
  width: 7rem;
  height: 7rem;
}
.avatar-group-xxl .avatar-initials {
  font-size: 3rem;
}
.avatar-group-xxl .avatar + .avatar {
  margin-left: -2rem;
}

/*------------------------------------
  Avatar Sizes
------------------------------------*/
.avatar.avatar-circle .avatar-status {
  bottom: -0.21875rem;
  right: -0.21875rem;
}
.avatar.avatar-circle .avatar-sm-status {
  bottom: 0;
  right: 0;
}
.avatar.avatar-circle .avatar-lg-status {
  bottom: -0.325rem;
  right: -0.325rem;
}

.avatar-xss,
.avatar-xss .avatar-initials {
  width: 1rem;
  height: 1rem;
}
.avatar-xss .avatar-img {
  width: 1rem;
}
.avatar-xss .avatar-initials {
  font-size: 0.75rem;
}

.avatar-xs,
.avatar-xs .avatar-initials {
  width: 1.75rem;
  height: 1.75rem;
}
.avatar-xs .avatar-img {
  width: 1.75rem;
}
.avatar-xs .avatar-initials {
  font-size: 0.75rem;
}
.avatar-xs.avatar-circle .avatar-status {
  bottom: -0.21875rem;
  right: -0.21875rem;
}
.avatar-xs.avatar-circle .avatar-sm-status {
  bottom: -0.1171875rem;
  right: -0.1171875rem;
}
.avatar-xs.avatar-circle .avatar-lg-status {
  bottom: -0.325rem;
  right: -0.325rem;
}

.avatar-xs,
.avatar-xs .avatar-initials {
  width: 1.75rem;
  height: 1.75rem;
}
.avatar-xs .avatar-img {
  width: 1.75rem;
}
.avatar-xs .avatar-initials {
  font-size: 0.75rem;
}
.avatar-xs.avatar-circle .avatar-status {
  bottom: -0.21875rem;
  right: -0.21875rem;
}
.avatar-xs.avatar-circle .avatar-sm-status {
  bottom: -0.1171875rem;
  right: -0.1171875rem;
}
.avatar-xs.avatar-circle .avatar-lg-status {
  bottom: -0.325rem;
  right: -0.325rem;
}

.avatar-sm,
.avatar-sm .avatar-initials {
  width: 2.3125rem;
  height: 2.3125rem;
}
.avatar-sm .avatar-img {
  width: 2.3125rem;
}
.avatar-sm .avatar-initials {
  font-size: 0.8125rem;
}
.avatar-sm.avatar-circle .avatar-status {
  bottom: -0.21875rem;
  right: -0.21875rem;
}
.avatar-sm.avatar-circle .avatar-sm-status {
  bottom: -0.09375rem;
  right: -0.09375rem;
}
.avatar-sm.avatar-circle .avatar-lg-status {
  bottom: -0.40625rem;
  right: -0.40625rem;
}

.avatar-lg,
.avatar-lg .avatar-initials {
  width: 4.25rem;
  height: 4.25rem;
}
.avatar-lg .avatar-img {
  width: 4.25rem;
}
.avatar-lg .avatar-initials {
  font-size: 1.125rem;
}
.avatar-lg.avatar-circle .avatar-status {
  bottom: -0.13125rem;
  right: -0.13125rem;
}
.avatar-lg.avatar-circle .avatar-sm-status {
  bottom: 0.09375rem;
  right: 0.09375rem;
}
.avatar-lg.avatar-circle .avatar-lg-status {
  bottom: -0.203125rem;
  right: -0.203125rem;
}

.avatar-xl,
.avatar-xl .avatar-initials {
  width: 5.625rem;
  height: 5.625rem;
}
.avatar-xl .avatar-img {
  width: 5.625rem;
}
.avatar-xl .avatar-initials {
  font-size: 2rem;
}
.avatar-xl.avatar-circle .avatar-status {
  bottom: 0.1640625rem;
  right: 0.1640625rem;
}
.avatar-xl.avatar-circle .avatar-sm-status {
  bottom: 0.234375rem;
  right: 0.234375rem;
}
.avatar-xl.avatar-circle .avatar-lg-status {
  bottom: 0.1354166667rem;
  right: 0.1354166667rem;
}

.avatar-xxl,
.avatar-xxl .avatar-initials {
  width: 7rem;
  height: 7rem;
}
.avatar-xxl .avatar-img {
  width: 7rem;
}
.avatar-xxl .avatar-initials {
  font-size: 3rem;
}
.avatar-xxl.avatar-circle .avatar-status {
  bottom: 0.75rem;
  right: 0.75rem;
}
.avatar-xxl.avatar-circle .avatar-sm-status {
  bottom: 0.875rem;
  right: 0.875rem;
}
.avatar-xxl.avatar-circle .avatar-lg-status {
  bottom: 0.65rem;
  right: 0.65rem;
}

/*------------------------------------
  Avatar Status
------------------------------------*/
.avatar-status {
  position: absolute;
  bottom: -0.525rem;
  right: -0.525rem;
  display: inline-flex;
  flex-shrink: 0;
  justify-content: center;
  align-items: center;
  white-space: nowrap;
  text-align: center;
  vertical-align: baseline;
  border: 0.125rem solid white;
  width: 1.3125rem;
  height: 1.3125rem;
  line-height: 1;
  font-size: 0.625rem;
  border-radius: 50%;
}

.avatar-sm-status {
  bottom: -0.2625rem;
  right: -0.2625rem;
  width: 0.9375rem;
  height: 0.9375rem;
  font-size: 0.5rem;
}

.avatar-lg-status {
  width: 1.625rem;
  height: 1.625rem;
  font-size: 0.75rem;
}

/*------------------------------------
  Avatar Styles
------------------------------------*/
.avatar-primary .avatar-initials {
  color: white;
  background-color: #0abf53;
}

.avatar-status-primary {
  color: white;
  background-color: #0abf53;
}

.avatar-secondary .avatar-initials {
  color: white;
  background-color: #51596c;
}

.avatar-status-secondary {
  color: white;
  background-color: #51596c;
}

.avatar-success .avatar-initials {
  color: white;
  background-color: #077c76;
}

.avatar-status-success {
  color: white;
  background-color: #077c76;
}

.avatar-info .avatar-initials {
  color: white;
  background-color: #334ac0;
}

.avatar-status-info {
  color: white;
  background-color: #334ac0;
}

.avatar-warning .avatar-initials {
  color: #000;
  background-color: #f39568;
}

.avatar-status-warning {
  color: #000;
  background-color: #f39568;
}

.avatar-danger .avatar-initials {
  color: white;
  background-color: #692340;
}

.avatar-status-danger {
  color: white;
  background-color: #692340;
}

.avatar-light .avatar-initials {
  color: #000;
  background-color: #f8f9fa;
}

.avatar-status-light {
  color: #000;
  background-color: #f8f9fa;
}

.avatar-dark .avatar-initials {
  color: white;
  background-color: #2d374b;
}

.avatar-status-dark {
  color: white;
  background-color: #2d374b;
}

.avatar-soft-primary .avatar-initials {
  color: #0abf53;
  background-color: rgba(10, 191, 83, 0.1);
}

.avatar-status-soft-primary {
  color: #0abf53;
  background-color: rgba(10, 191, 83, 0.1);
}

.avatar-soft-secondary .avatar-initials {
  color: #51596c;
  background-color: rgba(81, 89, 108, 0.1);
}

.avatar-status-soft-secondary {
  color: #51596c;
  background-color: rgba(81, 89, 108, 0.1);
}

.avatar-soft-success .avatar-initials {
  color: #077c76;
  background-color: rgba(7, 124, 118, 0.1);
}

.avatar-status-soft-success {
  color: #077c76;
  background-color: rgba(7, 124, 118, 0.1);
}

.avatar-soft-info .avatar-initials {
  color: #334ac0;
  background-color: rgba(51, 74, 192, 0.1);
}

.avatar-status-soft-info {
  color: #334ac0;
  background-color: rgba(51, 74, 192, 0.1);
}

.avatar-soft-warning .avatar-initials {
  color: #f39568;
  background-color: rgba(243, 149, 104, 0.1);
}

.avatar-status-soft-warning {
  color: #f39568;
  background-color: rgba(243, 149, 104, 0.1);
}

.avatar-soft-danger .avatar-initials {
  color: #692340;
  background-color: rgba(105, 35, 64, 0.1);
}

.avatar-status-soft-danger {
  color: #692340;
  background-color: rgba(105, 35, 64, 0.1);
}

.avatar-soft-light .avatar-initials {
  color: #f8f9fa;
  background-color: rgba(248, 249, 250, 0.1);
}

.avatar-status-soft-light {
  color: #f8f9fa;
  background-color: rgba(248, 249, 250, 0.1);
}

.avatar-soft-dark .avatar-initials {
  color: #2d374b;
  background-color: rgba(45, 55, 75, 0.1);
}

.avatar-status-soft-dark {
  color: #2d374b;
  background-color: rgba(45, 55, 75, 0.1);
}

/*------------------------------------
  Avatar Ratio
------------------------------------*/
.avatar.avatar-4x3 {
  width: 3.8333333333rem;
  height: auto;
  border-radius: 0;
}
.avatar.avatar-4x3 .avatar-img {
  width: 3.8333333333rem;
  height: inherit;
}

.avatar-xss.avatar-4x3 {
  width: 1.3333333333rem;
  height: auto;
  border-radius: 0;
}
.avatar-xss.avatar-4x3 .avatar-img {
  width: 1.3333333333rem;
  height: inherit;
}

.avatar-xs.avatar-4x3 {
  width: 2.3333333333rem;
  height: auto;
  border-radius: 0;
}
.avatar-xs.avatar-4x3 .avatar-img {
  width: 2.3333333333rem;
  height: inherit;
}

.avatar-sm.avatar-4x3 {
  width: 3.0833333333rem;
  height: auto;
  border-radius: 0;
}
.avatar-sm.avatar-4x3 .avatar-img {
  width: 3.0833333333rem;
  height: inherit;
}

.avatar-lg.avatar-4x3 {
  width: 5.6666666667rem;
  height: auto;
  border-radius: 0;
}
.avatar-lg.avatar-4x3 .avatar-img {
  width: 5.6666666667rem;
  height: inherit;
}

.avatar-xl.avatar-4x3 {
  width: 7.5rem;
  height: auto;
  border-radius: 0;
}
.avatar-xl.avatar-4x3 .avatar-img {
  width: 7.5rem;
  height: inherit;
}

.avatar-xxl.avatar-4x3 {
  width: 9.3333333333rem;
  height: auto;
  border-radius: 0;
}
.avatar-xxl.avatar-4x3 .avatar-img {
  width: 9.3333333333rem;
  height: inherit;
}

/*------------------------------------
  Badge
------------------------------------*/
.badge {
  padding: 0.525em 0.975em;
  line-height: normal;
}

.badge-sm {
  padding: 0.35em 0.65em;
}

/*------------------------------------
  Blockquote
------------------------------------*/
.blockquote {
  position: relative;
  color: #2d374b;
}
.blockquote::before {
  position: absolute;
  top: -2rem;
  left: -1.5rem;
  width: 4rem;
  height: 4rem;
  background-image: url("data:image/svg+xml,%3csvg width='5' height='4' viewBox='0 0 5 4' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M2.244 2.84803C2.244 3.08003 2.168 3.26803 2.016 3.41203C1.864 3.54803 1.672 3.61603 1.44 3.61603C1.16 3.61603 0.927996 3.52403 0.743996 3.34003C0.567996 3.15603 0.479996 2.89203 0.479996 2.54803C0.479996 2.18003 0.583996 1.82003 0.791996 1.46803C1.008 1.10803 1.308 0.824028 1.692 0.616028L1.968 1.03603C1.76 1.18003 1.592 1.34003 1.464 1.51603C1.344 1.69203 1.264 1.89603 1.224 2.12803C1.296 2.09603 1.38 2.08003 1.476 2.08003C1.7 2.08003 1.884 2.15203 2.028 2.29603C2.172 2.44003 2.244 2.62403 2.244 2.84803ZM4.452 2.84803C4.452 3.08003 4.376 3.26803 4.224 3.41203C4.072 3.54803 3.88 3.61603 3.648 3.61603C3.368 3.61603 3.136 3.52403 2.952 3.34003C2.776 3.15603 2.688 2.89203 2.688 2.54803C2.688 2.18003 2.792 1.82003 3 1.46803C3.216 1.10803 3.516 0.824028 3.9 0.616028L4.176 1.03603C3.968 1.18003 3.8 1.34003 3.672 1.51603C3.552 1.69203 3.472 1.89603 3.432 2.12803C3.504 2.09603 3.588 2.08003 3.684 2.08003C3.908 2.08003 4.092 2.15203 4.236 2.29603C4.38 2.44003 4.452 2.62403 4.452 2.84803Z' fill='%232d374b' fill-opacity='.125'/%3e%3c/svg%3e");
  background-repeat: no-repeat;
  background-position: center center;
  background-size: contain;
  content: "";
}

.blockquote-footer {
  font-weight: 700;
  line-height: normal;
  margin-top: 1.5rem;
  margin-bottom: 0;
}
.blockquote-footer::before {
  content: "";
}

.blockquote-footer-source {
  display: block;
  color: #677788;
  font-size: 0.8125rem;
  font-weight: 400;
  margin-top: 0.25rem;
}

.blockquote-light blockquote,
.blockquote-light .blockquote {
  color: white;
}
.blockquote-light blockquote::before,
.blockquote-light .blockquote::before {
  background-image: url("data:image/svg+xml,%3csvg width='5' height='4' viewBox='0 0 5 4' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M2.244 2.84803C2.244 3.08003 2.168 3.26803 2.016 3.41203C1.864 3.54803 1.672 3.61603 1.44 3.61603C1.16 3.61603 0.927996 3.52403 0.743996 3.34003C0.567996 3.15603 0.479996 2.89203 0.479996 2.54803C0.479996 2.18003 0.583996 1.82003 0.791996 1.46803C1.008 1.10803 1.308 0.824028 1.692 0.616028L1.968 1.03603C1.76 1.18003 1.592 1.34003 1.464 1.51603C1.344 1.69203 1.264 1.89603 1.224 2.12803C1.296 2.09603 1.38 2.08003 1.476 2.08003C1.7 2.08003 1.884 2.15203 2.028 2.29603C2.172 2.44003 2.244 2.62403 2.244 2.84803ZM4.452 2.84803C4.452 3.08003 4.376 3.26803 4.224 3.41203C4.072 3.54803 3.88 3.61603 3.648 3.61603C3.368 3.61603 3.136 3.52403 2.952 3.34003C2.776 3.15603 2.688 2.89203 2.688 2.54803C2.688 2.18003 2.792 1.82003 3 1.46803C3.216 1.10803 3.516 0.824028 3.9 0.616028L4.176 1.03603C3.968 1.18003 3.8 1.34003 3.672 1.51603C3.552 1.69203 3.472 1.89603 3.432 2.12803C3.504 2.09603 3.588 2.08003 3.684 2.08003C3.908 2.08003 4.092 2.15203 4.236 2.29603C4.38 2.44003 4.452 2.62403 4.452 2.84803Z' fill='white' fill-opacity='.15'/%3e%3c/svg%3e");
}
.blockquote-light .blockquote-footer {
  color: white;
}
.blockquote-light .blockquote-footer-source {
  color: rgba(255, 255, 255, 0.7);
}

.blockquote-sm.blockquote,
.blockquote-sm .blockquote {
  font-size: 1rem;
}
.blockquote-sm.blockquote::before,
.blockquote-sm .blockquote::before {
  top: -1.125rem;
  left: -1rem;
  width: 2.5rem;
  height: 2.5rem;
}

.blockquote-lg.blockquote,
.blockquote-lg .blockquote {
  font-size: calc(1.30625rem + 0.675vw);
  font-weight: 500;
}
@media (min-width: 1200px) {
  .blockquote-lg.blockquote,
.blockquote-lg .blockquote {
    font-size: 1.8125rem;
  }
}
.blockquote-lg.blockquote::before,
.blockquote-lg .blockquote::before {
  top: -3rem;
  left: -2rem;
  width: 6rem;
  height: 6rem;
}

/*------------------------------------
  Breadcrumb
------------------------------------*/
.breadcrumb .breadcrumb-item {
  color: #2d374b;
}

/*------------------------------------
  Buttons
------------------------------------*/
.btn-link:focus {
  box-shadow: none;
}

.btn.dropdown-toggle {
  display: inline-flex;
  align-items: center;
}

/*------------------------------------
  Custom Buttons
------------------------------------*/
.btn-pointer {
  position: relative;
  font-weight: 500;
  padding-right: 1.25rem;
  padding-right: 2.5rem;
}
.btn-pointer::after {
  position: absolute;
  top: 50%;
  right: 0.75rem;
  width: 1.25rem;
  height: 1.25rem;
  background-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='currentColor' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/></svg>");
  background-repeat: no-repeat;
  background-position: right center;
  background-size: 1.25rem 1.25rem;
  content: "";
  transform: translateY(-50%);
  transition: 0.2s;
}
.btn-pointer:hover::after, [href]:hover .btn-pointer::after {
  right: 0.4375rem;
}

.btn-white {
  color: #2d374b;
  font-weight: 500;
  background-color: white;
  border-color: rgba(220, 224, 229, 0.6);
}
.btn-white.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%2351596c' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-white .btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%2351596c' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-white, .btn-white:hover, .btn-white:focus {
  color: #07853a;
  border-color: rgba(220, 224, 229, 0.6);
  box-shadow: 0px 3px 6px -2px rgba(140, 152, 164, 0.25);
}
.btn-check:focus + .btn-white.dropdown-toggle::after, .btn-white:hover.dropdown-toggle::after, .btn-white:focus.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%230abf53' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}
.btn-white.disabled, .btn-white:disabled {
  color: #BDC5D1;
  background-color: rgba(220, 224, 229, 0.5);
}

.btn-primary:hover.btn-pointer::after, .btn-check:focus + .btn-primary.btn-pointer::after, .btn-primary:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-primary.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-primary.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}

.btn-secondary:hover.btn-pointer::after, .btn-check:focus + .btn-secondary.btn-pointer::after, .btn-secondary:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-secondary.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-secondary.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}

.btn-success:hover.btn-pointer::after, .btn-check:focus + .btn-success.btn-pointer::after, .btn-success:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-success.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-success.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}

.btn-info:hover.btn-pointer::after, .btn-check:focus + .btn-info.btn-pointer::after, .btn-info:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-info.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-info.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}

.btn-warning:hover.btn-pointer::after, .btn-check:focus + .btn-warning.btn-pointer::after, .btn-warning:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23000' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-warning.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23000' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-warning.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23000' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}

.btn-danger:hover.btn-pointer::after, .btn-check:focus + .btn-danger.btn-pointer::after, .btn-danger:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-danger.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-danger.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}

.btn-light:hover.btn-pointer::after, .btn-check:focus + .btn-light.btn-pointer::after, .btn-light:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23000' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-light.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23000' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-light.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23000' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}

.btn-dark:hover.btn-pointer::after, .btn-check:focus + .btn-dark.btn-pointer::after, .btn-dark:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-dark.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-dark.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}

/*------------------------------------
  Ghost Buttons Styles
------------------------------------*/
.btn-ghost-primary {
  color: #0abf53;
  background-color: transparent;
}
.btn-ghost-primary:hover, .btn-check:focus + .btn-ghost-primary, .btn-ghost-primary:focus, .btn-check:checked + .btn-ghost-primary, .btn-check:active + .btn-ghost-primary, .btn-ghost-primary:active, .btn-ghost-primary.active, .show > .btn-ghost-primary.dropdown-toggle {
  color: #0abf53;
  border-color: transparent;
  background-color: rgba(10, 191, 83, 0.1);
}
.btn-ghost-primary.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%230abf53' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-ghost-primary.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%230abf53' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-ghost-primary.btn-no-focus, .btn-ghost-primary.btn-no-focus:hover, .btn-ghost-primary.btn-no-focus.focus, .btn-ghost-primary.btn-no-focus:focus {
  color: #0abf53;
  background-color: unset;
  box-shadow: none;
}
.btn-check:focus + .btn-ghost-primary.btn-no-focus:hover, .btn-ghost-primary.btn-no-focus:hover:hover, .btn-ghost-primary.btn-no-focus.focus:hover, .btn-ghost-primary.btn-no-focus:focus:hover {
  color: #0abf53;
  background-color: rgba(10, 191, 83, 0.1);
}

.btn-ghost-secondary {
  color: #51596c;
  background-color: transparent;
}
.btn-ghost-secondary:hover, .btn-check:focus + .btn-ghost-secondary, .btn-ghost-secondary:focus, .btn-check:checked + .btn-ghost-secondary, .btn-check:active + .btn-ghost-secondary, .btn-ghost-secondary:active, .btn-ghost-secondary.active, .show > .btn-ghost-secondary.dropdown-toggle {
  color: #51596c;
  border-color: transparent;
  background-color: rgba(10, 191, 83, 0.1);
}
.btn-ghost-secondary.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%2351596c' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-ghost-secondary.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%2351596c' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-ghost-secondary.btn-no-focus, .btn-ghost-secondary.btn-no-focus:hover, .btn-ghost-secondary.btn-no-focus.focus, .btn-ghost-secondary.btn-no-focus:focus {
  color: #51596c;
  background-color: unset;
  box-shadow: none;
}
.btn-check:focus + .btn-ghost-secondary.btn-no-focus:hover, .btn-ghost-secondary.btn-no-focus:hover:hover, .btn-ghost-secondary.btn-no-focus.focus:hover, .btn-ghost-secondary.btn-no-focus:focus:hover {
  color: #51596c;
  background-color: rgba(81, 89, 108, 0.1);
}

.btn-ghost-success {
  color: #077c76;
  background-color: transparent;
}
.btn-ghost-success:hover, .btn-check:focus + .btn-ghost-success, .btn-ghost-success:focus, .btn-check:checked + .btn-ghost-success, .btn-check:active + .btn-ghost-success, .btn-ghost-success:active, .btn-ghost-success.active, .show > .btn-ghost-success.dropdown-toggle {
  color: #077c76;
  border-color: transparent;
  background-color: rgba(7, 124, 118, 0.1);
}
.btn-ghost-success.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23077c76' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-ghost-success.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23077c76' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-ghost-success.btn-no-focus, .btn-ghost-success.btn-no-focus:hover, .btn-ghost-success.btn-no-focus.focus, .btn-ghost-success.btn-no-focus:focus {
  color: #077c76;
  background-color: unset;
  box-shadow: none;
}
.btn-check:focus + .btn-ghost-success.btn-no-focus:hover, .btn-ghost-success.btn-no-focus:hover:hover, .btn-ghost-success.btn-no-focus.focus:hover, .btn-ghost-success.btn-no-focus:focus:hover {
  color: #077c76;
  background-color: rgba(7, 124, 118, 0.1);
}

.btn-ghost-info {
  color: #334ac0;
  background-color: transparent;
}
.btn-ghost-info:hover, .btn-check:focus + .btn-ghost-info, .btn-ghost-info:focus, .btn-check:checked + .btn-ghost-info, .btn-check:active + .btn-ghost-info, .btn-ghost-info:active, .btn-ghost-info.active, .show > .btn-ghost-info.dropdown-toggle {
  color: #334ac0;
  border-color: transparent;
  background-color: rgba(51, 74, 192, 0.1);
}
.btn-ghost-info.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23334ac0' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-ghost-info.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23334ac0' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-ghost-info.btn-no-focus, .btn-ghost-info.btn-no-focus:hover, .btn-ghost-info.btn-no-focus.focus, .btn-ghost-info.btn-no-focus:focus {
  color: #334ac0;
  background-color: unset;
  box-shadow: none;
}
.btn-check:focus + .btn-ghost-info.btn-no-focus:hover, .btn-ghost-info.btn-no-focus:hover:hover, .btn-ghost-info.btn-no-focus.focus:hover, .btn-ghost-info.btn-no-focus:focus:hover {
  color: #334ac0;
  background-color: rgba(51, 74, 192, 0.1);
}

.btn-ghost-warning {
  color: #f39568;
  background-color: transparent;
}
.btn-ghost-warning:hover, .btn-check:focus + .btn-ghost-warning, .btn-ghost-warning:focus, .btn-check:checked + .btn-ghost-warning, .btn-check:active + .btn-ghost-warning, .btn-ghost-warning:active, .btn-ghost-warning.active, .show > .btn-ghost-warning.dropdown-toggle {
  color: #f39568;
  border-color: transparent;
  background-color: rgba(243, 149, 104, 0.1);
}
.btn-ghost-warning.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23f39568' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-ghost-warning.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23f39568' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-ghost-warning.btn-no-focus, .btn-ghost-warning.btn-no-focus:hover, .btn-ghost-warning.btn-no-focus.focus, .btn-ghost-warning.btn-no-focus:focus {
  color: #f39568;
  background-color: unset;
  box-shadow: none;
}
.btn-check:focus + .btn-ghost-warning.btn-no-focus:hover, .btn-ghost-warning.btn-no-focus:hover:hover, .btn-ghost-warning.btn-no-focus.focus:hover, .btn-ghost-warning.btn-no-focus:focus:hover {
  color: #f39568;
  background-color: rgba(243, 149, 104, 0.1);
}

.btn-ghost-danger {
  color: #692340;
  background-color: transparent;
}
.btn-ghost-danger:hover, .btn-check:focus + .btn-ghost-danger, .btn-ghost-danger:focus, .btn-check:checked + .btn-ghost-danger, .btn-check:active + .btn-ghost-danger, .btn-ghost-danger:active, .btn-ghost-danger.active, .show > .btn-ghost-danger.dropdown-toggle {
  color: #692340;
  border-color: transparent;
  background-color: rgba(105, 35, 64, 0.1);
}
.btn-ghost-danger.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23692340' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-ghost-danger.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23692340' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-ghost-danger.btn-no-focus, .btn-ghost-danger.btn-no-focus:hover, .btn-ghost-danger.btn-no-focus.focus, .btn-ghost-danger.btn-no-focus:focus {
  color: #692340;
  background-color: unset;
  box-shadow: none;
}
.btn-check:focus + .btn-ghost-danger.btn-no-focus:hover, .btn-ghost-danger.btn-no-focus:hover:hover, .btn-ghost-danger.btn-no-focus.focus:hover, .btn-ghost-danger.btn-no-focus:focus:hover {
  color: #692340;
  background-color: rgba(105, 35, 64, 0.1);
}

.btn-ghost-light {
  color: #f8f9fa;
  background-color: transparent;
}
.btn-ghost-light:hover, .btn-check:focus + .btn-ghost-light, .btn-ghost-light:focus, .btn-check:checked + .btn-ghost-light, .btn-check:active + .btn-ghost-light, .btn-ghost-light:active, .btn-ghost-light.active, .show > .btn-ghost-light.dropdown-toggle {
  color: #f8f9fa;
  border-color: transparent;
  background-color: rgba(248, 249, 250, 0.1);
}
.btn-ghost-light.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23f8f9fa' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-ghost-light.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23f8f9fa' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-ghost-light.btn-no-focus, .btn-ghost-light.btn-no-focus:hover, .btn-ghost-light.btn-no-focus.focus, .btn-ghost-light.btn-no-focus:focus {
  color: #f8f9fa;
  background-color: unset;
  box-shadow: none;
}
.btn-check:focus + .btn-ghost-light.btn-no-focus:hover, .btn-ghost-light.btn-no-focus:hover:hover, .btn-ghost-light.btn-no-focus.focus:hover, .btn-ghost-light.btn-no-focus:focus:hover {
  color: #f8f9fa;
  background-color: rgba(248, 249, 250, 0.1);
}

.btn-ghost-dark {
  color: #2d374b;
  background-color: transparent;
}
.btn-ghost-dark:hover, .btn-check:focus + .btn-ghost-dark, .btn-ghost-dark:focus, .btn-check:checked + .btn-ghost-dark, .btn-check:active + .btn-ghost-dark, .btn-ghost-dark:active, .btn-ghost-dark.active, .show > .btn-ghost-dark.dropdown-toggle {
  color: #2d374b;
  border-color: transparent;
  background-color: rgba(45, 55, 75, 0.1);
}
.btn-ghost-dark.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%232d374b' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-ghost-dark.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%232d374b' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-ghost-dark.btn-no-focus, .btn-ghost-dark.btn-no-focus:hover, .btn-ghost-dark.btn-no-focus.focus, .btn-ghost-dark.btn-no-focus:focus {
  color: #2d374b;
  background-color: unset;
  box-shadow: none;
}
.btn-check:focus + .btn-ghost-dark.btn-no-focus:hover, .btn-ghost-dark.btn-no-focus:hover:hover, .btn-ghost-dark.btn-no-focus.focus:hover, .btn-ghost-dark.btn-no-focus:focus:hover {
  color: #2d374b;
  background-color: rgba(45, 55, 75, 0.1);
}

.btn-check:focus + .btn-ghost-secondary, .btn-ghost-secondary:hover, .btn-ghost-secondary:focus {
  color: #0abf53;
}
.btn-check:focus + .btn-ghost-secondary.dropdown-toggle::after, .btn-ghost-secondary:hover.dropdown-toggle::after, .btn-ghost-secondary:focus.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%230abf53' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-ghost-secondary.btn-pointer::after, .btn-ghost-secondary:hover.btn-pointer::after, .btn-ghost-secondary:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%230abf53' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-ghost-secondary.btn-no-focus:hover, .btn-ghost-secondary.btn-no-focus:hover:hover, .btn-ghost-secondary.btn-no-focus.focus:hover, .btn-ghost-secondary.btn-no-focus:focus:hover {
  color: #0abf53;
  background-color: rgba(10, 191, 83, 0.1);
}

/*------------------------------------
  Button Soft
------------------------------------*/
.btn-soft-primary {
  color: #0abf53;
  background-color: rgba(10, 191, 83, 0.1);
  border-color: transparent;
}
.btn-soft-primary:hover, .btn-check:focus + .btn-soft-primary, .btn-soft-primary:focus {
  color: white;
  background-color: #0abf53;
}
.btn-check:checked + .btn-soft-primary, .btn-check:active + .btn-soft-primary, .btn-soft-primary:active, .btn-soft-primary.active, .show > .btn-soft-primary.dropdown-toggle {
  color: white;
  background-color: #0abf53;
  border-color: transparent;
}
.btn-soft-primary:disabled, .btn-soft-primary.disabled {
  color: #0abf53;
  background-color: #0abf53;
  border-color: transparent;
}

.btn-soft-secondary {
  color: #51596c;
  background-color: rgba(81, 89, 108, 0.1);
  border-color: transparent;
}
.btn-soft-secondary:hover, .btn-check:focus + .btn-soft-secondary, .btn-soft-secondary:focus {
  color: white;
  background-color: #51596c;
}
.btn-check:checked + .btn-soft-secondary, .btn-check:active + .btn-soft-secondary, .btn-soft-secondary:active, .btn-soft-secondary.active, .show > .btn-soft-secondary.dropdown-toggle {
  color: white;
  background-color: #51596c;
  border-color: transparent;
}
.btn-soft-secondary:disabled, .btn-soft-secondary.disabled {
  color: #51596c;
  background-color: #51596c;
  border-color: transparent;
}

.btn-soft-success {
  color: #077c76;
  background-color: rgba(7, 124, 118, 0.1);
  border-color: transparent;
}
.btn-soft-success:hover, .btn-check:focus + .btn-soft-success, .btn-soft-success:focus {
  color: white;
  background-color: #077c76;
}
.btn-check:checked + .btn-soft-success, .btn-check:active + .btn-soft-success, .btn-soft-success:active, .btn-soft-success.active, .show > .btn-soft-success.dropdown-toggle {
  color: white;
  background-color: #077c76;
  border-color: transparent;
}
.btn-soft-success:disabled, .btn-soft-success.disabled {
  color: #077c76;
  background-color: #077c76;
  border-color: transparent;
}

.btn-soft-info {
  color: #334ac0;
  background-color: rgba(51, 74, 192, 0.1);
  border-color: transparent;
}
.btn-soft-info:hover, .btn-check:focus + .btn-soft-info, .btn-soft-info:focus {
  color: white;
  background-color: #334ac0;
}
.btn-check:checked + .btn-soft-info, .btn-check:active + .btn-soft-info, .btn-soft-info:active, .btn-soft-info.active, .show > .btn-soft-info.dropdown-toggle {
  color: white;
  background-color: #334ac0;
  border-color: transparent;
}
.btn-soft-info:disabled, .btn-soft-info.disabled {
  color: #334ac0;
  background-color: #334ac0;
  border-color: transparent;
}

.btn-soft-warning {
  color: #f39568;
  background-color: rgba(243, 149, 104, 0.1);
  border-color: transparent;
}
.btn-soft-warning:hover, .btn-check:focus + .btn-soft-warning, .btn-soft-warning:focus {
  color: #000;
  background-color: #f39568;
}
.btn-check:checked + .btn-soft-warning, .btn-check:active + .btn-soft-warning, .btn-soft-warning:active, .btn-soft-warning.active, .show > .btn-soft-warning.dropdown-toggle {
  color: #000;
  background-color: #f39568;
  border-color: transparent;
}
.btn-soft-warning:disabled, .btn-soft-warning.disabled {
  color: #f39568;
  background-color: #f39568;
  border-color: transparent;
}

.btn-soft-danger {
  color: #692340;
  background-color: rgba(105, 35, 64, 0.1);
  border-color: transparent;
}
.btn-soft-danger:hover, .btn-check:focus + .btn-soft-danger, .btn-soft-danger:focus {
  color: white;
  background-color: #692340;
}
.btn-check:checked + .btn-soft-danger, .btn-check:active + .btn-soft-danger, .btn-soft-danger:active, .btn-soft-danger.active, .show > .btn-soft-danger.dropdown-toggle {
  color: white;
  background-color: #692340;
  border-color: transparent;
}
.btn-soft-danger:disabled, .btn-soft-danger.disabled {
  color: #692340;
  background-color: #692340;
  border-color: transparent;
}

.btn-soft-light {
  color: #f8f9fa;
  background-color: rgba(248, 249, 250, 0.1);
  border-color: transparent;
}
.btn-soft-light:hover, .btn-check:focus + .btn-soft-light, .btn-soft-light:focus {
  color: #000;
  background-color: #f8f9fa;
}
.btn-check:checked + .btn-soft-light, .btn-check:active + .btn-soft-light, .btn-soft-light:active, .btn-soft-light.active, .show > .btn-soft-light.dropdown-toggle {
  color: #000;
  background-color: #f8f9fa;
  border-color: transparent;
}
.btn-soft-light:disabled, .btn-soft-light.disabled {
  color: #f8f9fa;
  background-color: #f8f9fa;
  border-color: transparent;
}

.btn-soft-dark {
  color: #2d374b;
  background-color: rgba(45, 55, 75, 0.1);
  border-color: transparent;
}
.btn-soft-dark:hover, .btn-check:focus + .btn-soft-dark, .btn-soft-dark:focus {
  color: white;
  background-color: #2d374b;
}
.btn-check:checked + .btn-soft-dark, .btn-check:active + .btn-soft-dark, .btn-soft-dark:active, .btn-soft-dark.active, .show > .btn-soft-dark.dropdown-toggle {
  color: white;
  background-color: #2d374b;
  border-color: transparent;
}
.btn-soft-dark:disabled, .btn-soft-dark.disabled {
  color: #2d374b;
  background-color: #2d374b;
  border-color: transparent;
}

.btn-soft-primary.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%230abf53' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-soft-primary.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%230abf53' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-soft-primary.btn-pointer::after, .btn-soft-primary:hover.btn-pointer::after, .btn-soft-primary:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-soft-primary.dropdown-toggle::after, .btn-soft-primary:hover.dropdown-toggle::after, .btn-soft-primary:focus.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}

.btn-soft-secondary.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%2351596c' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-soft-secondary.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%2351596c' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-soft-secondary.btn-pointer::after, .btn-soft-secondary:hover.btn-pointer::after, .btn-soft-secondary:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-soft-secondary.dropdown-toggle::after, .btn-soft-secondary:hover.dropdown-toggle::after, .btn-soft-secondary:focus.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}

.btn-soft-success.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23077c76' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-soft-success.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23077c76' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-soft-success.btn-pointer::after, .btn-soft-success:hover.btn-pointer::after, .btn-soft-success:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-soft-success.dropdown-toggle::after, .btn-soft-success:hover.dropdown-toggle::after, .btn-soft-success:focus.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}

.btn-soft-info.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23334ac0' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-soft-info.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23334ac0' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-soft-info.btn-pointer::after, .btn-soft-info:hover.btn-pointer::after, .btn-soft-info:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-soft-info.dropdown-toggle::after, .btn-soft-info:hover.dropdown-toggle::after, .btn-soft-info:focus.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}

.btn-soft-warning.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23f39568' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-soft-warning.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23f39568' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-soft-warning.btn-pointer::after, .btn-soft-warning:hover.btn-pointer::after, .btn-soft-warning:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23000' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-soft-warning.dropdown-toggle::after, .btn-soft-warning:hover.dropdown-toggle::after, .btn-soft-warning:focus.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23000' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}

.btn-soft-danger.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23692340' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-soft-danger.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23692340' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-soft-danger.btn-pointer::after, .btn-soft-danger:hover.btn-pointer::after, .btn-soft-danger:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-soft-danger.dropdown-toggle::after, .btn-soft-danger:hover.dropdown-toggle::after, .btn-soft-danger:focus.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}

.btn-soft-light.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23f8f9fa' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-soft-light.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23f8f9fa' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-soft-light.btn-pointer::after, .btn-soft-light:hover.btn-pointer::after, .btn-soft-light:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23000' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-soft-light.dropdown-toggle::after, .btn-soft-light:hover.dropdown-toggle::after, .btn-soft-light:focus.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23000' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}

.btn-soft-dark.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%232d374b' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-soft-dark.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%232d374b' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-soft-dark.btn-pointer::after, .btn-soft-dark:hover.btn-pointer::after, .btn-soft-dark:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-soft-dark.dropdown-toggle::after, .btn-soft-dark:hover.dropdown-toggle::after, .btn-soft-dark:focus.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}

.btn-check:focus + .btn-soft-secondary, .btn-soft-secondary:hover, .btn-soft-secondary:focus {
  color: white;
}
.btn-check:focus + .btn-soft-secondary.dropdown-toggle::after, .btn-soft-secondary:hover.dropdown-toggle::after, .btn-soft-secondary:focus.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-soft-secondary.btn-pointer::after, .btn-soft-secondary:hover.btn-pointer::after, .btn-soft-secondary:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}

/*------------------------------------
  Button Icon
------------------------------------*/
.btn-icon {
  position: relative;
  display: inline-flex;
  flex-shrink: 0;
  justify-content: center;
  align-items: center;
  font-size: 1rem;
  font-weight: 500;
  width: 2.875rem;
  height: 2.875rem;
  padding: 0;
}
.btn-icon > svg {
  width: 1rem;
  height: auto;
}

/*------------------------------------
  Outline Button Styles
------------------------------------*/
.btn-outline-primary.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%230abf53' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-outline-primary:hover::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}
.btn-outline-primary.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%230abf53' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-outline-primary.btn-pointer::after, .btn-outline-primary:hover.btn-pointer::after, .btn-outline-primary:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:checked + .btn-outline-primary.dropdown-toggle::after, .btn-check:active + .btn-outline-primary.dropdown-toggle::after, .btn-outline-primary:active.dropdown-toggle::after, .btn-outline-primary.active.dropdown-toggle::after, .btn-outline-primary.dropdown-toggle.show.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}

.btn-outline-secondary.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%2351596c' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-outline-secondary:hover::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}
.btn-outline-secondary.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%2351596c' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-outline-secondary.btn-pointer::after, .btn-outline-secondary:hover.btn-pointer::after, .btn-outline-secondary:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:checked + .btn-outline-secondary.dropdown-toggle::after, .btn-check:active + .btn-outline-secondary.dropdown-toggle::after, .btn-outline-secondary:active.dropdown-toggle::after, .btn-outline-secondary.active.dropdown-toggle::after, .btn-outline-secondary.dropdown-toggle.show.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}

.btn-outline-success.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23077c76' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-outline-success:hover::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}
.btn-outline-success.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23077c76' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-outline-success.btn-pointer::after, .btn-outline-success:hover.btn-pointer::after, .btn-outline-success:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:checked + .btn-outline-success.dropdown-toggle::after, .btn-check:active + .btn-outline-success.dropdown-toggle::after, .btn-outline-success:active.dropdown-toggle::after, .btn-outline-success.active.dropdown-toggle::after, .btn-outline-success.dropdown-toggle.show.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}

.btn-outline-info.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23334ac0' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-outline-info:hover::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}
.btn-outline-info.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23334ac0' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-outline-info.btn-pointer::after, .btn-outline-info:hover.btn-pointer::after, .btn-outline-info:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:checked + .btn-outline-info.dropdown-toggle::after, .btn-check:active + .btn-outline-info.dropdown-toggle::after, .btn-outline-info:active.dropdown-toggle::after, .btn-outline-info.active.dropdown-toggle::after, .btn-outline-info.dropdown-toggle.show.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}

.btn-outline-warning.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23f39568' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-outline-warning:hover::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23000' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}
.btn-outline-warning.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23f39568' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-outline-warning.btn-pointer::after, .btn-outline-warning:hover.btn-pointer::after, .btn-outline-warning:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23000' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:checked + .btn-outline-warning.dropdown-toggle::after, .btn-check:active + .btn-outline-warning.dropdown-toggle::after, .btn-outline-warning:active.dropdown-toggle::after, .btn-outline-warning.active.dropdown-toggle::after, .btn-outline-warning.dropdown-toggle.show.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23000' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}

.btn-outline-danger.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23692340' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-outline-danger:hover::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}
.btn-outline-danger.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23692340' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-outline-danger.btn-pointer::after, .btn-outline-danger:hover.btn-pointer::after, .btn-outline-danger:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:checked + .btn-outline-danger.dropdown-toggle::after, .btn-check:active + .btn-outline-danger.dropdown-toggle::after, .btn-outline-danger:active.dropdown-toggle::after, .btn-outline-danger.active.dropdown-toggle::after, .btn-outline-danger.dropdown-toggle.show.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}

.btn-outline-light.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23f8f9fa' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-outline-light:hover::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23000' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}
.btn-outline-light.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23f8f9fa' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-outline-light.btn-pointer::after, .btn-outline-light:hover.btn-pointer::after, .btn-outline-light:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23000' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:checked + .btn-outline-light.dropdown-toggle::after, .btn-check:active + .btn-outline-light.dropdown-toggle::after, .btn-outline-light:active.dropdown-toggle::after, .btn-outline-light.active.dropdown-toggle::after, .btn-outline-light.dropdown-toggle.show.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23000' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}

.btn-outline-dark.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%232d374b' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  transition: all 0.2s ease-in-out;
}
.btn-outline-dark:hover::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}
.btn-outline-dark.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%232d374b' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:focus + .btn-outline-dark.btn-pointer::after, .btn-outline-dark:hover.btn-pointer::after, .btn-outline-dark:focus.btn-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.btn-check:checked + .btn-outline-dark.dropdown-toggle::after, .btn-check:active + .btn-outline-dark.dropdown-toggle::after, .btn-outline-dark:active.dropdown-toggle::after, .btn-outline-dark.active.dropdown-toggle::after, .btn-outline-dark.dropdown-toggle.show.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
}

.btn-outline-primary,
.btn-outline-secondary {
  border-color: rgba(220, 224, 229, 0.6);
}

/*------------------------------------
  Button Sizes
------------------------------------*/
.btn-icon.btn-sm, .btn-group-sm > .btn-icon.btn {
  font-size: 0.8125rem;
  width: 2.3125rem;
  height: 2.3125rem;
}
.btn-icon.btn-sm > svg, .btn-group-sm > .btn-icon.btn > svg {
  width: 0.8125rem;
  height: auto;
}

.btn-icon.btn-lg, .btn-group-lg > .btn-icon.btn {
  font-size: 1.125rem;
  width: 4.25rem;
  height: 4.25rem;
}
.btn-icon.btn-lg > svg, .btn-group-lg > .btn-icon.btn > svg {
  width: 1.125rem;
  height: auto;
}

/*------------------------------------
  Card
------------------------------------*/
.card[href] {
  transition: all 0.2s ease-in-out;
}
.card[href]:hover {
  box-shadow: 0rem 1rem 1.75rem 0rem rgba(45, 55, 75, 0.1);
}

.card-header,
.card-footer {
  border-width: 0;
}

.card-subtitle {
  display: block;
  font-size: 0.8125rem;
  text-transform: uppercase;
  margin-top: 0;
  margin-bottom: 0.5rem;
}

.card-title {
  margin-bottom: 0;
}
.card-title:not(:last-child) {
  margin-bottom: 0.5rem;
}

.card-header-title {
  margin-bottom: 0;
}
.card-header-title:not(:last-child) {
  margin-bottom: 0.25rem;
}

.card-link {
  position: relative;
  display: inline-block;
  font-size: 0.9375rem;
  font-weight: 500;
  padding-right: 2.5rem;
}
.card-link::after {
  position: absolute;
  top: 50%;
  right: 0.75rem;
  width: 1.25rem;
  height: 1.25rem;
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%230abf53' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
  background-repeat: no-repeat;
  background-position: right center;
  background-size: 1.25rem 1.25rem;
  content: "";
  transform: translateY(-50%);
  transition: 0.2s;
}
.card-link:hover::after, [href]:hover .card-link::after {
  right: 0.4375rem;
}

.card-link.link-primary::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%230abf53' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}

.card-link.link-secondary::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%2351596c' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}

.card-link.link-success::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23077c76' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}

.card-link.link-info::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23334ac0' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}

.card-link.link-warning::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23f39568' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}

.card-link.link-danger::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23692340' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}

.card-link.link-light::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23f8f9fa' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}

.card-link.link-dark::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%232d374b' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}

.card-borderless {
  border-width: 0;
}

.card-shadow {
  box-shadow: 0rem 1rem 1.75rem 0rem rgba(45, 55, 75, 0.1);
}

.card-ghost {
  background-color: transparent;
  border-width: 0;
}
.card-ghost[href]:hover {
  box-shadow: none;
}
.card-ghost .card-body {
  padding-left: 0;
  padding-right: 0;
}
.card-ghost .card-footer {
  padding: 0;
}

.card-transition {
  transition: all 0.2s ease-in-out;
}
.card-transition:hover, .card-transition:focus {
  transform: translateY(-0.1875rem) !important;
}

.card-transition-zoom {
  overflow: hidden;
}
.card-transition-zoom .card-transition-zoom-item {
  overflow: hidden;
  border-radius: 0.8rem;
  -webkit-backface-visibility: hidden;
  -moz-backface-visibility: hidden;
  -webkit-transform: translate3d(0, 0, 0);
  -moz-transform: translate3d(0, 0, 0);
}
.card-transition-zoom .card-img {
  transition: transform 0.4s;
}
.card-transition-zoom:hover .card-img {
  transform: scale(1.03);
}

.card-group .card {
  box-shadow: none;
}
.card-group .card + .card {
  border-left: var(--bs-border-width) solid rgba(220, 224, 229, 0.6);
}

.card-sm > .card-body,
.card-sm > .card-header,
.card-sm > .card-footer,
.card-sm > .card-img-overlay,
.card-sm > .collapse .card-body {
  padding: 0.8125rem 0.8125rem;
}
.card-sm .card-table > tbody > tr:first-child > td {
  padding-top: 0.8125rem;
}
.card-sm .card-table > tbody > tr:last-child > td {
  padding-bottom: 0.8125rem;
}
.card-sm .card-table > :not(caption) > * > * {
  padding-right: 0.8125rem;
  padding-left: 0.8125rem;
}

.card-lg > .card-body,
.card-lg > .card-header,
.card-lg > .card-footer,
.card-lg > .card-img-overlay,
.card-lg > .collapse .card-body {
  padding: 2.75rem 2.75rem;
}
@media (max-width: 767.98px) {
  .card-lg > .card-body,
.card-lg > .card-header,
.card-lg > .card-footer,
.card-lg > .card-img-overlay,
.card-lg > .collapse .card-body {
    padding: 1.8333333333rem 1.8333333333rem;
  }
}
.card-lg .card-table > tbody > tr:first-child > td {
  padding-top: 2.75rem;
}
@media (max-width: 767.98px) {
  .card-lg .card-table > tbody > tr:first-child > td {
    padding-top: 1.8333333333rem;
  }
}
.card-lg .card-table > tbody > tr:last-child > td {
  padding-bottom: 2.75rem;
}
@media (max-width: 767.98px) {
  .card-lg .card-table > tbody > tr:last-child > td {
    padding-bottom: 1.8333333333rem;
  }
}
.card-lg .card-table > :not(caption) > * > * {
  padding-right: 2.75rem;
  padding-left: 2.75rem;
}
@media (max-width: 767.98px) {
  .card-lg .card-table > :not(caption) > * > * {
    padding-right: 1.8333333333rem;
    padding-left: 1.8333333333rem;
  }
}

.card-pinned {
  position: relative;
  display: block;
}

.card-pinned-top-start {
  position: absolute;
  top: -0.0625rem;
  left: -0.0625rem;
}
.card-pinned-top-start.badge {
  border-radius: 0.8rem 0 0.8rem 0;
}

.card-pinned-top-end {
  position: absolute;
  top: -0.0625rem;
  right: -0.0625rem;
}
.card-pinned-top-end.badge {
  border-radius: 0 0.8rem 0 0.8rem;
}

.card-pinned-bottom-start {
  position: absolute;
  bottom: -0.0625rem;
  left: -0.0625rem;
}
.card-pinned-bottom-start.badge {
  border-radius: 0 0.8rem 0 0.8rem;
}

.card-pinned-bottom-end {
  position: absolute;
  bottom: -0.0625rem;
  right: -0.0625rem;
}
.card-pinned-bottom-end.badge {
  border-radius: 0.8rem 0 0.8rem 0;
}

.card-flush {
  box-shadow: none;
}
.card-flush .card-header,
.card-flush .card-footer,
.card-flush .card-body,
.card-flush .collapse .card-body {
  padding-right: 0;
  padding-left: 0;
}
.card-flush > .card-img-top {
  border-bottom-right-radius: 0.8rem;
  border-bottom-left-radius: 0.8rem;
}
.card-flush.card-stretched-vertical .card-body .card-footer {
  padding-bottom: 0;
}

.card-stretched-vertical .card-body {
  display: flex;
  flex-direction: column;
  height: 100%;
}
.card-stretched-vertical .card-body .card-footer {
  padding: 0;
  margin-top: auto;
}

.card .table {
  margin-bottom: 0;
}
.card table > tbody > tr:first-child > td {
  padding-top: 1.75rem;
}
.card table > tbody > tr:last-child > td {
  padding-bottom: 1.75rem;
}
.card table > :not(caption) > * > * {
  padding-right: 1.75rem;
  padding-left: 1.75rem;
}
.card .thead-light th:first-child {
  border-top-left-radius: 0.8rem;
}
.card .thead-light th:last-child {
  border-top-right-radius: 0.8rem;
}

.card-alert {
  border-radius: 0;
  margin-bottom: 0;
}

.card-login {
  flex-grow: 1;
  overflow: hidden;
}
.card-login .card-body {
  padding: 2.75rem 2.75rem;
}

/*------------------------------------
  Card Group Break
------------------------------------*/
@media (max-width: 575.98px) {
  .card-group-sm-break {
    display: block;
  }
  .card-group-sm-break > .card {
    margin-bottom: 0;
  }
  .card-group-sm-break > .card:not(:last-child) {
    border-bottom: var(--bs-border-width) solid rgba(220, 224, 229, 0.6);
  }
  .card-group-sm-break > .card + .card {
    border-left: none;
  }
  .card-group-sm-break > .card:not(:first-child):not(:last-child),
.card-group-sm-break > .card:not(:first-child):not(:last-child) .card-header,
.card-group-sm-break > .card:not(:first-child):not(:last-child) .card-img-top,
.card-group-sm-break > .card:not(:first-child):not(:last-child) .card-footer,
.card-group-sm-break > .card:not(:first-child):not(:last-child) .card-img-bottom {
    border-radius: 0;
  }
  .card-group-sm-break > .card:first-child {
    border-top-left-radius: 0.8rem;
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
  }
  .card-group-sm-break > .card:first-child .card-header,
.card-group-sm-break > .card:first-child .card-img-top {
    border-top-left-radius: 0.8rem;
    border-top-right-radius: 0.8rem;
  }
  .card-group-sm-break > .card:first-child .card-footer,
.card-group-sm-break > .card:first-child .card-img-bottom {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
  }
  .card-group-sm-break > .card:last-child {
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
    border-top-left-radius: 0;
    border-top-right-radius: 0;
  }
  .card-group-sm-break > .card:last-child .card-header,
.card-group-sm-break > .card:last-child .card-img-top {
    border-top-left-radius: 0;
    border-top-right-radius: 0;
  }
  .card-group-sm-break > .card:last-child .card-footer,
.card-group-sm-break > .card:last-child .card-img-bottom {
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
}
@media (max-width: 767.98px) {
  .card-group-md-break {
    display: block;
  }
  .card-group-md-break > .card {
    margin-bottom: 0;
  }
  .card-group-md-break > .card:not(:last-child) {
    border-bottom: var(--bs-border-width) solid rgba(220, 224, 229, 0.6);
  }
  .card-group-md-break > .card + .card {
    border-left: none;
  }
  .card-group-md-break > .card:not(:first-child):not(:last-child),
.card-group-md-break > .card:not(:first-child):not(:last-child) .card-header,
.card-group-md-break > .card:not(:first-child):not(:last-child) .card-img-top,
.card-group-md-break > .card:not(:first-child):not(:last-child) .card-footer,
.card-group-md-break > .card:not(:first-child):not(:last-child) .card-img-bottom {
    border-radius: 0;
  }
  .card-group-md-break > .card:first-child {
    border-top-left-radius: 0.8rem;
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
  }
  .card-group-md-break > .card:first-child .card-header,
.card-group-md-break > .card:first-child .card-img-top {
    border-top-left-radius: 0.8rem;
    border-top-right-radius: 0.8rem;
  }
  .card-group-md-break > .card:first-child .card-footer,
.card-group-md-break > .card:first-child .card-img-bottom {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
  }
  .card-group-md-break > .card:last-child {
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
    border-top-left-radius: 0;
    border-top-right-radius: 0;
  }
  .card-group-md-break > .card:last-child .card-header,
.card-group-md-break > .card:last-child .card-img-top {
    border-top-left-radius: 0;
    border-top-right-radius: 0;
  }
  .card-group-md-break > .card:last-child .card-footer,
.card-group-md-break > .card:last-child .card-img-bottom {
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
}
@media (max-width: 991.98px) {
  .card-group-lg-break {
    display: block;
  }
  .card-group-lg-break > .card {
    margin-bottom: 0;
  }
  .card-group-lg-break > .card:not(:last-child) {
    border-bottom: var(--bs-border-width) solid rgba(220, 224, 229, 0.6);
  }
  .card-group-lg-break > .card + .card {
    border-left: none;
  }
  .card-group-lg-break > .card:not(:first-child):not(:last-child),
.card-group-lg-break > .card:not(:first-child):not(:last-child) .card-header,
.card-group-lg-break > .card:not(:first-child):not(:last-child) .card-img-top,
.card-group-lg-break > .card:not(:first-child):not(:last-child) .card-footer,
.card-group-lg-break > .card:not(:first-child):not(:last-child) .card-img-bottom {
    border-radius: 0;
  }
  .card-group-lg-break > .card:first-child {
    border-top-left-radius: 0.8rem;
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
  }
  .card-group-lg-break > .card:first-child .card-header,
.card-group-lg-break > .card:first-child .card-img-top {
    border-top-left-radius: 0.8rem;
    border-top-right-radius: 0.8rem;
  }
  .card-group-lg-break > .card:first-child .card-footer,
.card-group-lg-break > .card:first-child .card-img-bottom {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
  }
  .card-group-lg-break > .card:last-child {
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
    border-top-left-radius: 0;
    border-top-right-radius: 0;
  }
  .card-group-lg-break > .card:last-child .card-header,
.card-group-lg-break > .card:last-child .card-img-top {
    border-top-left-radius: 0;
    border-top-right-radius: 0;
  }
  .card-group-lg-break > .card:last-child .card-footer,
.card-group-lg-break > .card:last-child .card-img-bottom {
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
}
/*------------------------------------
  Card Group Row
------------------------------------*/
@media (min-width: 576px) {
  .card-group-sm-row {
    box-shadow: 0rem 1rem 1.75rem 0rem rgba(45, 55, 75, 0.1);
    border-radius: 0.8rem;
    margin: 0;
  }
  .card-group-sm-row > * {
    padding: 0;
  }
  .card-group-sm-row > * > .card {
    height: 100%;
    box-shadow: none;
    border-radius: 0;
  }
  .card-group-sm-row > *:not(:first-child):not(:last-child),
.card-group-sm-row > *:not(:first-child):not(:last-child) .card-header,
.card-group-sm-row > *:not(:first-child):not(:last-child) .card-img-top,
.card-group-sm-row > *:not(:first-child):not(:last-child) .card-footer,
.card-group-sm-row > *:not(:first-child):not(:last-child) .card-img-bottom {
    border-radius: 0;
  }
  .card-group-sm-row > *:first-child > .card {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
  .card-group-sm-row > *:first-child > .card,
.card-group-sm-row > *:first-child > .card .card-header,
.card-group-sm-row > *:first-child > .card .card-img-top,
.card-group-sm-row > *:first-child > .card .card-footer,
.card-group-sm-row > *:first-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
  }
  .card-group-sm-row > *:last-child > .card {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0.8rem;
  }
  .card-group-sm-row > *:last-child > .card,
.card-group-sm-row > *:last-child > .card .card-header,
.card-group-sm-row > *:last-child > .card .card-img-top,
.card-group-sm-row > *:last-child > .card .card-footer,
.card-group-sm-row > *:last-child > .card .card-img-bottom {
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
  }
  .card-group-sm-row > * + * > .card {
    border-left: var(--bs-border-width) solid rgba(220, 224, 229, 0.6);
  }
  .card-group-sm-row .card-divider {
    border-left-width: 0;
    border-top: var(--bs-border-width) solid rgba(220, 224, 229, 0.6);
  }
  .card-group-sm-2 > *:first-child > .card,
.card-group-sm-2 > *:first-child > .card .card-header,
.card-group-sm-2 > *:first-child > .card .card-img-top,
.card-group-sm-2 > *:first-child > .card .card-footer,
.card-group-sm-2 > *:first-child > .card .card-img-bottom {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0;
  }
  .card-group-sm-2 > *:nth-child(2) > .card,
.card-group-sm-2 > *:nth-child(2) > .card .card-header,
.card-group-sm-2 > *:nth-child(2) > .card .card-img-top,
.card-group-sm-2 > *:nth-child(2) > .card .card-footer,
.card-group-sm-2 > *:nth-child(2) > .card .card-img-bottom {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0;
  }
  .card-group-sm-2 > *:last-child > .card,
.card-group-sm-2 > *:last-child > .card .card-header,
.card-group-sm-2 > *:last-child > .card .card-img-top,
.card-group-sm-2 > *:last-child > .card .card-footer,
.card-group-sm-2 > *:last-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
  .card-group-sm-3 > *:first-child > .card,
.card-group-sm-3 > *:first-child > .card .card-header,
.card-group-sm-3 > *:first-child > .card .card-img-top,
.card-group-sm-3 > *:first-child > .card .card-footer,
.card-group-sm-3 > *:first-child > .card .card-img-bottom {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0;
  }
  .card-group-sm-3 > *:nth-child(3) > .card,
.card-group-sm-3 > *:nth-child(3) > .card .card-header,
.card-group-sm-3 > *:nth-child(3) > .card .card-img-top,
.card-group-sm-3 > *:nth-child(3) > .card .card-footer,
.card-group-sm-3 > *:nth-child(3) > .card .card-img-bottom {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0;
  }
  .card-group-sm-3 > *:last-child > .card,
.card-group-sm-3 > *:last-child > .card .card-header,
.card-group-sm-3 > *:last-child > .card .card-img-top,
.card-group-sm-3 > *:last-child > .card .card-footer,
.card-group-sm-3 > *:last-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
  .card-group-sm-4 > *:first-child > .card,
.card-group-sm-4 > *:first-child > .card .card-header,
.card-group-sm-4 > *:first-child > .card .card-img-top,
.card-group-sm-4 > *:first-child > .card .card-footer,
.card-group-sm-4 > *:first-child > .card .card-img-bottom {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0;
  }
  .card-group-sm-4 > *:nth-child(4) > .card,
.card-group-sm-4 > *:nth-child(4) > .card .card-header,
.card-group-sm-4 > *:nth-child(4) > .card .card-img-top,
.card-group-sm-4 > *:nth-child(4) > .card .card-footer,
.card-group-sm-4 > *:nth-child(4) > .card .card-img-bottom {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0;
  }
  .card-group-sm-4 > *:last-child > .card,
.card-group-sm-4 > *:last-child > .card .card-header,
.card-group-sm-4 > *:last-child > .card .card-img-top,
.card-group-sm-4 > *:last-child > .card .card-footer,
.card-group-sm-4 > *:last-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
}
@media (min-width: 768px) {
  .card-group-md-row {
    box-shadow: 0rem 1rem 1.75rem 0rem rgba(45, 55, 75, 0.1);
    border-radius: 0.8rem;
    margin: 0;
  }
  .card-group-md-row > * {
    padding: 0;
  }
  .card-group-md-row > * > .card {
    height: 100%;
    box-shadow: none;
    border-radius: 0;
  }
  .card-group-md-row > *:not(:first-child):not(:last-child),
.card-group-md-row > *:not(:first-child):not(:last-child) .card-header,
.card-group-md-row > *:not(:first-child):not(:last-child) .card-img-top,
.card-group-md-row > *:not(:first-child):not(:last-child) .card-footer,
.card-group-md-row > *:not(:first-child):not(:last-child) .card-img-bottom {
    border-radius: 0;
  }
  .card-group-md-row > *:first-child > .card {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
  .card-group-md-row > *:first-child > .card,
.card-group-md-row > *:first-child > .card .card-header,
.card-group-md-row > *:first-child > .card .card-img-top,
.card-group-md-row > *:first-child > .card .card-footer,
.card-group-md-row > *:first-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
  }
  .card-group-md-row > *:last-child > .card {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0.8rem;
  }
  .card-group-md-row > *:last-child > .card,
.card-group-md-row > *:last-child > .card .card-header,
.card-group-md-row > *:last-child > .card .card-img-top,
.card-group-md-row > *:last-child > .card .card-footer,
.card-group-md-row > *:last-child > .card .card-img-bottom {
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
  }
  .card-group-md-row > * + * > .card {
    border-left: var(--bs-border-width) solid rgba(220, 224, 229, 0.6);
  }
  .card-group-md-row .card-divider {
    border-left-width: 0;
    border-top: var(--bs-border-width) solid rgba(220, 224, 229, 0.6);
  }
  .card-group-md-2 > *:first-child > .card,
.card-group-md-2 > *:first-child > .card .card-header,
.card-group-md-2 > *:first-child > .card .card-img-top,
.card-group-md-2 > *:first-child > .card .card-footer,
.card-group-md-2 > *:first-child > .card .card-img-bottom {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0;
  }
  .card-group-md-2 > *:nth-child(2) > .card,
.card-group-md-2 > *:nth-child(2) > .card .card-header,
.card-group-md-2 > *:nth-child(2) > .card .card-img-top,
.card-group-md-2 > *:nth-child(2) > .card .card-footer,
.card-group-md-2 > *:nth-child(2) > .card .card-img-bottom {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0;
  }
  .card-group-md-2 > *:last-child > .card,
.card-group-md-2 > *:last-child > .card .card-header,
.card-group-md-2 > *:last-child > .card .card-img-top,
.card-group-md-2 > *:last-child > .card .card-footer,
.card-group-md-2 > *:last-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
  .card-group-md-3 > *:first-child > .card,
.card-group-md-3 > *:first-child > .card .card-header,
.card-group-md-3 > *:first-child > .card .card-img-top,
.card-group-md-3 > *:first-child > .card .card-footer,
.card-group-md-3 > *:first-child > .card .card-img-bottom {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0;
  }
  .card-group-md-3 > *:nth-child(3) > .card,
.card-group-md-3 > *:nth-child(3) > .card .card-header,
.card-group-md-3 > *:nth-child(3) > .card .card-img-top,
.card-group-md-3 > *:nth-child(3) > .card .card-footer,
.card-group-md-3 > *:nth-child(3) > .card .card-img-bottom {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0;
  }
  .card-group-md-3 > *:last-child > .card,
.card-group-md-3 > *:last-child > .card .card-header,
.card-group-md-3 > *:last-child > .card .card-img-top,
.card-group-md-3 > *:last-child > .card .card-footer,
.card-group-md-3 > *:last-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
  .card-group-md-4 > *:first-child > .card,
.card-group-md-4 > *:first-child > .card .card-header,
.card-group-md-4 > *:first-child > .card .card-img-top,
.card-group-md-4 > *:first-child > .card .card-footer,
.card-group-md-4 > *:first-child > .card .card-img-bottom {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0;
  }
  .card-group-md-4 > *:nth-child(4) > .card,
.card-group-md-4 > *:nth-child(4) > .card .card-header,
.card-group-md-4 > *:nth-child(4) > .card .card-img-top,
.card-group-md-4 > *:nth-child(4) > .card .card-footer,
.card-group-md-4 > *:nth-child(4) > .card .card-img-bottom {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0;
  }
  .card-group-md-4 > *:last-child > .card,
.card-group-md-4 > *:last-child > .card .card-header,
.card-group-md-4 > *:last-child > .card .card-img-top,
.card-group-md-4 > *:last-child > .card .card-footer,
.card-group-md-4 > *:last-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
}
@media (min-width: 992px) {
  .card-group-lg-row {
    box-shadow: 0rem 1rem 1.75rem 0rem rgba(45, 55, 75, 0.1);
    border-radius: 0.8rem;
    margin: 0;
  }
  .card-group-lg-row > * {
    padding: 0;
  }
  .card-group-lg-row > * > .card {
    height: 100%;
    box-shadow: none;
    border-radius: 0;
  }
  .card-group-lg-row > *:not(:first-child):not(:last-child),
.card-group-lg-row > *:not(:first-child):not(:last-child) .card-header,
.card-group-lg-row > *:not(:first-child):not(:last-child) .card-img-top,
.card-group-lg-row > *:not(:first-child):not(:last-child) .card-footer,
.card-group-lg-row > *:not(:first-child):not(:last-child) .card-img-bottom {
    border-radius: 0;
  }
  .card-group-lg-row > *:first-child > .card {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
  .card-group-lg-row > *:first-child > .card,
.card-group-lg-row > *:first-child > .card .card-header,
.card-group-lg-row > *:first-child > .card .card-img-top,
.card-group-lg-row > *:first-child > .card .card-footer,
.card-group-lg-row > *:first-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
  }
  .card-group-lg-row > *:last-child > .card {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0.8rem;
  }
  .card-group-lg-row > *:last-child > .card,
.card-group-lg-row > *:last-child > .card .card-header,
.card-group-lg-row > *:last-child > .card .card-img-top,
.card-group-lg-row > *:last-child > .card .card-footer,
.card-group-lg-row > *:last-child > .card .card-img-bottom {
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
  }
  .card-group-lg-row > * + * > .card {
    border-left: var(--bs-border-width) solid rgba(220, 224, 229, 0.6);
  }
  .card-group-lg-row .card-divider {
    border-left-width: 0;
    border-top: var(--bs-border-width) solid rgba(220, 224, 229, 0.6);
  }
  .card-group-lg-2 > *:first-child > .card,
.card-group-lg-2 > *:first-child > .card .card-header,
.card-group-lg-2 > *:first-child > .card .card-img-top,
.card-group-lg-2 > *:first-child > .card .card-footer,
.card-group-lg-2 > *:first-child > .card .card-img-bottom {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0;
  }
  .card-group-lg-2 > *:nth-child(2) > .card,
.card-group-lg-2 > *:nth-child(2) > .card .card-header,
.card-group-lg-2 > *:nth-child(2) > .card .card-img-top,
.card-group-lg-2 > *:nth-child(2) > .card .card-footer,
.card-group-lg-2 > *:nth-child(2) > .card .card-img-bottom {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0;
  }
  .card-group-lg-2 > *:last-child > .card,
.card-group-lg-2 > *:last-child > .card .card-header,
.card-group-lg-2 > *:last-child > .card .card-img-top,
.card-group-lg-2 > *:last-child > .card .card-footer,
.card-group-lg-2 > *:last-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
  .card-group-lg-3 > *:first-child > .card,
.card-group-lg-3 > *:first-child > .card .card-header,
.card-group-lg-3 > *:first-child > .card .card-img-top,
.card-group-lg-3 > *:first-child > .card .card-footer,
.card-group-lg-3 > *:first-child > .card .card-img-bottom {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0;
  }
  .card-group-lg-3 > *:nth-child(3) > .card,
.card-group-lg-3 > *:nth-child(3) > .card .card-header,
.card-group-lg-3 > *:nth-child(3) > .card .card-img-top,
.card-group-lg-3 > *:nth-child(3) > .card .card-footer,
.card-group-lg-3 > *:nth-child(3) > .card .card-img-bottom {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0;
  }
  .card-group-lg-3 > *:last-child > .card,
.card-group-lg-3 > *:last-child > .card .card-header,
.card-group-lg-3 > *:last-child > .card .card-img-top,
.card-group-lg-3 > *:last-child > .card .card-footer,
.card-group-lg-3 > *:last-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
  .card-group-lg-4 > *:first-child > .card,
.card-group-lg-4 > *:first-child > .card .card-header,
.card-group-lg-4 > *:first-child > .card .card-img-top,
.card-group-lg-4 > *:first-child > .card .card-footer,
.card-group-lg-4 > *:first-child > .card .card-img-bottom {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0;
  }
  .card-group-lg-4 > *:nth-child(4) > .card,
.card-group-lg-4 > *:nth-child(4) > .card .card-header,
.card-group-lg-4 > *:nth-child(4) > .card .card-img-top,
.card-group-lg-4 > *:nth-child(4) > .card .card-footer,
.card-group-lg-4 > *:nth-child(4) > .card .card-img-bottom {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0;
  }
  .card-group-lg-4 > *:last-child > .card,
.card-group-lg-4 > *:last-child > .card .card-header,
.card-group-lg-4 > *:last-child > .card .card-img-top,
.card-group-lg-4 > *:last-child > .card .card-footer,
.card-group-lg-4 > *:last-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
}
@media (min-width: 1200px) {
  .card-group-xl-row {
    box-shadow: 0rem 1rem 1.75rem 0rem rgba(45, 55, 75, 0.1);
    border-radius: 0.8rem;
    margin: 0;
  }
  .card-group-xl-row > * {
    padding: 0;
  }
  .card-group-xl-row > * > .card {
    height: 100%;
    box-shadow: none;
    border-radius: 0;
  }
  .card-group-xl-row > *:not(:first-child):not(:last-child),
.card-group-xl-row > *:not(:first-child):not(:last-child) .card-header,
.card-group-xl-row > *:not(:first-child):not(:last-child) .card-img-top,
.card-group-xl-row > *:not(:first-child):not(:last-child) .card-footer,
.card-group-xl-row > *:not(:first-child):not(:last-child) .card-img-bottom {
    border-radius: 0;
  }
  .card-group-xl-row > *:first-child > .card {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
  .card-group-xl-row > *:first-child > .card,
.card-group-xl-row > *:first-child > .card .card-header,
.card-group-xl-row > *:first-child > .card .card-img-top,
.card-group-xl-row > *:first-child > .card .card-footer,
.card-group-xl-row > *:first-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
  }
  .card-group-xl-row > *:last-child > .card {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0.8rem;
  }
  .card-group-xl-row > *:last-child > .card,
.card-group-xl-row > *:last-child > .card .card-header,
.card-group-xl-row > *:last-child > .card .card-img-top,
.card-group-xl-row > *:last-child > .card .card-footer,
.card-group-xl-row > *:last-child > .card .card-img-bottom {
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
  }
  .card-group-xl-row > * + * > .card {
    border-left: var(--bs-border-width) solid rgba(220, 224, 229, 0.6);
  }
  .card-group-xl-row .card-divider {
    border-left-width: 0;
    border-top: var(--bs-border-width) solid rgba(220, 224, 229, 0.6);
  }
  .card-group-xl-2 > *:first-child > .card,
.card-group-xl-2 > *:first-child > .card .card-header,
.card-group-xl-2 > *:first-child > .card .card-img-top,
.card-group-xl-2 > *:first-child > .card .card-footer,
.card-group-xl-2 > *:first-child > .card .card-img-bottom {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0;
  }
  .card-group-xl-2 > *:nth-child(2) > .card,
.card-group-xl-2 > *:nth-child(2) > .card .card-header,
.card-group-xl-2 > *:nth-child(2) > .card .card-img-top,
.card-group-xl-2 > *:nth-child(2) > .card .card-footer,
.card-group-xl-2 > *:nth-child(2) > .card .card-img-bottom {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0;
  }
  .card-group-xl-2 > *:last-child > .card,
.card-group-xl-2 > *:last-child > .card .card-header,
.card-group-xl-2 > *:last-child > .card .card-img-top,
.card-group-xl-2 > *:last-child > .card .card-footer,
.card-group-xl-2 > *:last-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
  .card-group-xl-3 > *:first-child > .card,
.card-group-xl-3 > *:first-child > .card .card-header,
.card-group-xl-3 > *:first-child > .card .card-img-top,
.card-group-xl-3 > *:first-child > .card .card-footer,
.card-group-xl-3 > *:first-child > .card .card-img-bottom {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0;
  }
  .card-group-xl-3 > *:nth-child(3) > .card,
.card-group-xl-3 > *:nth-child(3) > .card .card-header,
.card-group-xl-3 > *:nth-child(3) > .card .card-img-top,
.card-group-xl-3 > *:nth-child(3) > .card .card-footer,
.card-group-xl-3 > *:nth-child(3) > .card .card-img-bottom {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0;
  }
  .card-group-xl-3 > *:last-child > .card,
.card-group-xl-3 > *:last-child > .card .card-header,
.card-group-xl-3 > *:last-child > .card .card-img-top,
.card-group-xl-3 > *:last-child > .card .card-footer,
.card-group-xl-3 > *:last-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
  .card-group-xl-4 > *:first-child > .card,
.card-group-xl-4 > *:first-child > .card .card-header,
.card-group-xl-4 > *:first-child > .card .card-img-top,
.card-group-xl-4 > *:first-child > .card .card-footer,
.card-group-xl-4 > *:first-child > .card .card-img-bottom {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0;
  }
  .card-group-xl-4 > *:nth-child(4) > .card,
.card-group-xl-4 > *:nth-child(4) > .card .card-header,
.card-group-xl-4 > *:nth-child(4) > .card .card-img-top,
.card-group-xl-4 > *:nth-child(4) > .card .card-footer,
.card-group-xl-4 > *:nth-child(4) > .card .card-img-bottom {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0;
  }
  .card-group-xl-4 > *:last-child > .card,
.card-group-xl-4 > *:last-child > .card .card-header,
.card-group-xl-4 > *:last-child > .card .card-img-top,
.card-group-xl-4 > *:last-child > .card .card-footer,
.card-group-xl-4 > *:last-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
}
@media (min-width: 1400px) {
  .card-group-xxl-row {
    box-shadow: 0rem 1rem 1.75rem 0rem rgba(45, 55, 75, 0.1);
    border-radius: 0.8rem;
    margin: 0;
  }
  .card-group-xxl-row > * {
    padding: 0;
  }
  .card-group-xxl-row > * > .card {
    height: 100%;
    box-shadow: none;
    border-radius: 0;
  }
  .card-group-xxl-row > *:not(:first-child):not(:last-child),
.card-group-xxl-row > *:not(:first-child):not(:last-child) .card-header,
.card-group-xxl-row > *:not(:first-child):not(:last-child) .card-img-top,
.card-group-xxl-row > *:not(:first-child):not(:last-child) .card-footer,
.card-group-xxl-row > *:not(:first-child):not(:last-child) .card-img-bottom {
    border-radius: 0;
  }
  .card-group-xxl-row > *:first-child > .card {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
  .card-group-xxl-row > *:first-child > .card,
.card-group-xxl-row > *:first-child > .card .card-header,
.card-group-xxl-row > *:first-child > .card .card-img-top,
.card-group-xxl-row > *:first-child > .card .card-footer,
.card-group-xxl-row > *:first-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
  }
  .card-group-xxl-row > *:last-child > .card {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0.8rem;
  }
  .card-group-xxl-row > *:last-child > .card,
.card-group-xxl-row > *:last-child > .card .card-header,
.card-group-xxl-row > *:last-child > .card .card-img-top,
.card-group-xxl-row > *:last-child > .card .card-footer,
.card-group-xxl-row > *:last-child > .card .card-img-bottom {
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
  }
  .card-group-xxl-row > * + * > .card {
    border-left: var(--bs-border-width) solid rgba(220, 224, 229, 0.6);
  }
  .card-group-xxl-row .card-divider {
    border-left-width: 0;
    border-top: var(--bs-border-width) solid rgba(220, 224, 229, 0.6);
  }
  .card-group-xxl-2 > *:first-child > .card,
.card-group-xxl-2 > *:first-child > .card .card-header,
.card-group-xxl-2 > *:first-child > .card .card-img-top,
.card-group-xxl-2 > *:first-child > .card .card-footer,
.card-group-xxl-2 > *:first-child > .card .card-img-bottom {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0;
  }
  .card-group-xxl-2 > *:nth-child(2) > .card,
.card-group-xxl-2 > *:nth-child(2) > .card .card-header,
.card-group-xxl-2 > *:nth-child(2) > .card .card-img-top,
.card-group-xxl-2 > *:nth-child(2) > .card .card-footer,
.card-group-xxl-2 > *:nth-child(2) > .card .card-img-bottom {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0;
  }
  .card-group-xxl-2 > *:last-child > .card,
.card-group-xxl-2 > *:last-child > .card .card-header,
.card-group-xxl-2 > *:last-child > .card .card-img-top,
.card-group-xxl-2 > *:last-child > .card .card-footer,
.card-group-xxl-2 > *:last-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
  .card-group-xxl-3 > *:first-child > .card,
.card-group-xxl-3 > *:first-child > .card .card-header,
.card-group-xxl-3 > *:first-child > .card .card-img-top,
.card-group-xxl-3 > *:first-child > .card .card-footer,
.card-group-xxl-3 > *:first-child > .card .card-img-bottom {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0;
  }
  .card-group-xxl-3 > *:nth-child(3) > .card,
.card-group-xxl-3 > *:nth-child(3) > .card .card-header,
.card-group-xxl-3 > *:nth-child(3) > .card .card-img-top,
.card-group-xxl-3 > *:nth-child(3) > .card .card-footer,
.card-group-xxl-3 > *:nth-child(3) > .card .card-img-bottom {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0;
  }
  .card-group-xxl-3 > *:last-child > .card,
.card-group-xxl-3 > *:last-child > .card .card-header,
.card-group-xxl-3 > *:last-child > .card .card-img-top,
.card-group-xxl-3 > *:last-child > .card .card-footer,
.card-group-xxl-3 > *:last-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
  .card-group-xxl-4 > *:first-child > .card,
.card-group-xxl-4 > *:first-child > .card .card-header,
.card-group-xxl-4 > *:first-child > .card .card-img-top,
.card-group-xxl-4 > *:first-child > .card .card-footer,
.card-group-xxl-4 > *:first-child > .card .card-img-bottom {
    border-top-left-radius: 0.8rem;
    border-bottom-left-radius: 0;
  }
  .card-group-xxl-4 > *:nth-child(4) > .card,
.card-group-xxl-4 > *:nth-child(4) > .card .card-header,
.card-group-xxl-4 > *:nth-child(4) > .card .card-img-top,
.card-group-xxl-4 > *:nth-child(4) > .card .card-footer,
.card-group-xxl-4 > *:nth-child(4) > .card .card-img-bottom {
    border-top-right-radius: 0.8rem;
    border-bottom-right-radius: 0;
  }
  .card-group-xxl-4 > *:last-child > .card,
.card-group-xxl-4 > *:last-child > .card .card-header,
.card-group-xxl-4 > *:last-child > .card .card-img-top,
.card-group-xxl-4 > *:last-child > .card .card-footer,
.card-group-xxl-4 > *:last-child > .card .card-img-bottom {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0.8rem;
    border-bottom-left-radius: 0.8rem;
  }
}
.card-group-row {
  box-shadow: 0rem 1rem 1.75rem 0rem rgba(45, 55, 75, 0.1);
  border-radius: 0.8rem;
  margin: 0;
}
.card-group-row > * {
  padding: 0;
}
.card-group-row > * > .card {
  height: 100%;
  box-shadow: none;
  border-radius: 0;
}
.card-group-row > *:not(:first-child):not(:last-child),
.card-group-row > *:not(:first-child):not(:last-child) .card-header,
.card-group-row > *:not(:first-child):not(:last-child) .card-img-top,
.card-group-row > *:not(:first-child):not(:last-child) .card-footer,
.card-group-row > *:not(:first-child):not(:last-child) .card-img-bottom {
  border-radius: 0;
}
.card-group-row > *:first-child > .card {
  border-top-left-radius: 0.8rem;
  border-bottom-left-radius: 0.8rem;
}
.card-group-row > *:first-child > .card,
.card-group-row > *:first-child > .card .card-header,
.card-group-row > *:first-child > .card .card-img-top,
.card-group-row > *:first-child > .card .card-footer,
.card-group-row > *:first-child > .card .card-img-bottom {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
.card-group-row > *:last-child > .card {
  border-top-right-radius: 0.8rem;
  border-bottom-right-radius: 0.8rem;
}
.card-group-row > *:last-child > .card,
.card-group-row > *:last-child > .card .card-header,
.card-group-row > *:last-child > .card .card-img-top,
.card-group-row > *:last-child > .card .card-footer,
.card-group-row > *:last-child > .card .card-img-bottom {
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}
.card-group-row > * + * > .card {
  border-left: var(--bs-border-width) solid rgba(220, 224, 229, 0.6);
}
.card-group-row .card-divider {
  border-left-width: 0;
  border-top: var(--bs-border-width) solid rgba(220, 224, 229, 0.6);
}

.card-group-2 > *:first-child > .card,
.card-group-2 > *:first-child > .card .card-header,
.card-group-2 > *:first-child > .card .card-img-top,
.card-group-2 > *:first-child > .card .card-footer,
.card-group-2 > *:first-child > .card .card-img-bottom {
  border-top-left-radius: 0.8rem;
  border-bottom-left-radius: 0;
}
.card-group-2 > *:nth-child(2) > .card,
.card-group-2 > *:nth-child(2) > .card .card-header,
.card-group-2 > *:nth-child(2) > .card .card-img-top,
.card-group-2 > *:nth-child(2) > .card .card-footer,
.card-group-2 > *:nth-child(2) > .card .card-img-bottom {
  border-top-right-radius: 0.8rem;
  border-bottom-right-radius: 0;
}
.card-group-2 > *:last-child > .card,
.card-group-2 > *:last-child > .card .card-header,
.card-group-2 > *:last-child > .card .card-img-top,
.card-group-2 > *:last-child > .card .card-footer,
.card-group-2 > *:last-child > .card .card-img-bottom {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0.8rem;
  border-bottom-left-radius: 0.8rem;
}

.card-group-3 > *:first-child > .card,
.card-group-3 > *:first-child > .card .card-header,
.card-group-3 > *:first-child > .card .card-img-top,
.card-group-3 > *:first-child > .card .card-footer,
.card-group-3 > *:first-child > .card .card-img-bottom {
  border-top-left-radius: 0.8rem;
  border-bottom-left-radius: 0;
}
.card-group-3 > *:nth-child(3) > .card,
.card-group-3 > *:nth-child(3) > .card .card-header,
.card-group-3 > *:nth-child(3) > .card .card-img-top,
.card-group-3 > *:nth-child(3) > .card .card-footer,
.card-group-3 > *:nth-child(3) > .card .card-img-bottom {
  border-top-right-radius: 0.8rem;
  border-bottom-right-radius: 0;
}
.card-group-3 > *:last-child > .card,
.card-group-3 > *:last-child > .card .card-header,
.card-group-3 > *:last-child > .card .card-img-top,
.card-group-3 > *:last-child > .card .card-footer,
.card-group-3 > *:last-child > .card .card-img-bottom {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0.8rem;
  border-bottom-left-radius: 0.8rem;
}

.card-group-4 > *:first-child > .card,
.card-group-4 > *:first-child > .card .card-header,
.card-group-4 > *:first-child > .card .card-img-top,
.card-group-4 > *:first-child > .card .card-footer,
.card-group-4 > *:first-child > .card .card-img-bottom {
  border-top-left-radius: 0.8rem;
  border-bottom-left-radius: 0;
}
.card-group-4 > *:nth-child(4) > .card,
.card-group-4 > *:nth-child(4) > .card .card-header,
.card-group-4 > *:nth-child(4) > .card .card-img-top,
.card-group-4 > *:nth-child(4) > .card .card-footer,
.card-group-4 > *:nth-child(4) > .card .card-img-bottom {
  border-top-right-radius: 0.8rem;
  border-bottom-right-radius: 0;
}
.card-group-4 > *:last-child > .card,
.card-group-4 > *:last-child > .card .card-header,
.card-group-4 > *:last-child > .card .card-img-top,
.card-group-4 > *:last-child > .card .card-footer,
.card-group-4 > *:last-child > .card .card-img-bottom {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0.8rem;
  border-bottom-left-radius: 0.8rem;
}

/*------------------------------------
  Close Button
------------------------------------*/
.btn-close:focus {
  box-shadow: none;
}

/*------------------------------------
  Col Divider
------------------------------------*/
@media (min-width: 576px) {
  .col-sm-divider > *:not(:first-child) {
    position: relative;
  }
  .col-sm-divider > *:not(:first-child)::before {
    position: absolute;
    top: 0;
    left: 0;
    width: 0.0625rem;
    height: 100%;
    background-color: rgba(220, 224, 229, 0.6);
    content: "";
  }
}

@media (min-width: 768px) {
  .col-md-divider > *:not(:first-child) {
    position: relative;
  }
  .col-md-divider > *:not(:first-child)::before {
    position: absolute;
    top: 0;
    left: 0;
    width: 0.0625rem;
    height: 100%;
    background-color: rgba(220, 224, 229, 0.6);
    content: "";
  }
}

@media (min-width: 992px) {
  .col-lg-divider > *:not(:first-child) {
    position: relative;
  }
  .col-lg-divider > *:not(:first-child)::before {
    position: absolute;
    top: 0;
    left: 0;
    width: 0.0625rem;
    height: 100%;
    background-color: rgba(220, 224, 229, 0.6);
    content: "";
  }
}

@media (min-width: 1200px) {
  .col-xl-divider > *:not(:first-child) {
    position: relative;
  }
  .col-xl-divider > *:not(:first-child)::before {
    position: absolute;
    top: 0;
    left: 0;
    width: 0.0625rem;
    height: 100%;
    background-color: rgba(220, 224, 229, 0.6);
    content: "";
  }
}

@media (min-width: 1400px) {
  .col-xxl-divider > *:not(:first-child) {
    position: relative;
  }
  .col-xxl-divider > *:not(:first-child)::before {
    position: absolute;
    top: 0;
    left: 0;
    width: 0.0625rem;
    height: 100%;
    background-color: rgba(220, 224, 229, 0.6);
    content: "";
  }
}

.col-divider > *:not(:first-child) {
  position: relative;
}
.col-divider > *:not(:first-child)::before {
  position: absolute;
  top: 0;
  left: 0;
  width: 0.0625rem;
  height: 100%;
  background-color: rgba(220, 224, 229, 0.6);
  content: "";
}

.col-divider > *:not(:first-child) {
  position: relative;
}
.col-divider > *:not(:first-child)::before {
  position: absolute;
  top: 0;
  left: 50%;
  width: calc(100% - 1.5rem);
  height: 0.0625rem;
  background-color: rgba(220, 224, 229, 0.6);
  content: "";
  transform: translateX(-50%);
}
.col-divider > * {
  padding-top: 1.5rem;
  padding-bottom: 1.5rem;
}
.col-divider > *:first-child {
  padding-top: 0;
}
.col-divider > *:last-child {
  padding-bottom: 0;
}

@media (max-width: 575.98px) {
  .col-sm-divider > *:not(:first-child) {
    position: relative;
  }
  .col-sm-divider > *:not(:first-child)::before {
    position: absolute;
    top: 0;
    left: 50%;
    width: calc(100% - 1.5rem);
    height: 0.0625rem;
    background-color: rgba(220, 224, 229, 0.6);
    content: "";
    transform: translateX(-50%);
  }
  .col-sm-divider > * {
    padding-top: 1.5rem;
    padding-bottom: 1.5rem;
  }
  .col-sm-divider > *:first-child {
    padding-top: 0;
  }
  .col-sm-divider > *:last-child {
    padding-bottom: 0;
  }
}

@media (max-width: 767.98px) {
  .col-md-divider > *:not(:first-child) {
    position: relative;
  }
  .col-md-divider > *:not(:first-child)::before {
    position: absolute;
    top: 0;
    left: 50%;
    width: calc(100% - 1.5rem);
    height: 0.0625rem;
    background-color: rgba(220, 224, 229, 0.6);
    content: "";
    transform: translateX(-50%);
  }
  .col-md-divider > * {
    padding-top: 1.5rem;
    padding-bottom: 1.5rem;
  }
  .col-md-divider > *:first-child {
    padding-top: 0;
  }
  .col-md-divider > *:last-child {
    padding-bottom: 0;
  }
}

@media (max-width: 991.98px) {
  .col-lg-divider > *:not(:first-child) {
    position: relative;
  }
  .col-lg-divider > *:not(:first-child)::before {
    position: absolute;
    top: 0;
    left: 50%;
    width: calc(100% - 1.5rem);
    height: 0.0625rem;
    background-color: rgba(220, 224, 229, 0.6);
    content: "";
    transform: translateX(-50%);
  }
  .col-lg-divider > * {
    padding-top: 1.5rem;
    padding-bottom: 1.5rem;
  }
  .col-lg-divider > *:first-child {
    padding-top: 0;
  }
  .col-lg-divider > *:last-child {
    padding-bottom: 0;
  }
}

@media (max-width: 1199.98px) {
  .col-xl-divider > *:not(:first-child) {
    position: relative;
  }
  .col-xl-divider > *:not(:first-child)::before {
    position: absolute;
    top: 0;
    left: 50%;
    width: calc(100% - 1.5rem);
    height: 0.0625rem;
    background-color: rgba(220, 224, 229, 0.6);
    content: "";
    transform: translateX(-50%);
  }
  .col-xl-divider > * {
    padding-top: 1.5rem;
    padding-bottom: 1.5rem;
  }
  .col-xl-divider > *:first-child {
    padding-top: 0;
  }
  .col-xl-divider > *:last-child {
    padding-bottom: 0;
  }
}

@media (max-width: 1399.98px) {
  .col-xxl-divider > *:not(:first-child) {
    position: relative;
  }
  .col-xxl-divider > *:not(:first-child)::before {
    position: absolute;
    top: 0;
    left: 50%;
    width: calc(100% - 1.5rem);
    height: 0.0625rem;
    background-color: rgba(220, 224, 229, 0.6);
    content: "";
    transform: translateX(-50%);
  }
  .col-xxl-divider > * {
    padding-top: 1.5rem;
    padding-bottom: 1.5rem;
  }
  .col-xxl-divider > *:first-child {
    padding-top: 0;
  }
  .col-xxl-divider > *:last-child {
    padding-bottom: 0;
  }
}

.col-divider-light > *:not(:first-child)::before {
  background-color: rgba(255, 255, 255, 0.1);
}

/*------------------------------------
  Devices
------------------------------------*/
.devices {
  max-width: 1140px;
  position: relative;
  padding: 1.75rem 0.75rem 7rem;
  margin-right: -0.75rem;
  margin-left: -0.75rem;
}
.devices .device-mobile {
  position: absolute;
  bottom: 0;
  left: 0;
  z-index: 2;
  margin-left: 5rem;
  margin-bottom: 5rem;
}
@media (max-width: 991.98px) {
  .devices .device-mobile {
    display: none;
  }
}
.devices .device-browser {
  margin-left: auto;
  margin-right: 5rem;
}
@media (max-width: 991.98px) {
  .devices .device-mobile {
    margin-right: 0.5rem;
  }
  .devices .device-browser {
    margin-right: auto;
  }
}

/*------------------------------------
  Mobile Device
------------------------------------*/
.device-mobile {
  position: relative;
  z-index: 1;
  max-width: 100%;
  width: 15rem;
  height: auto;
}

.device-mobile-frame {
  background: #2d374b;
  box-shadow: 0 2.75rem 5.5rem -3.5rem rgba(45, 55, 75, 0.2), 0 2rem 4rem -2rem rgba(45, 55, 75, 0.3), inset 0 -0.1875rem 0.3125rem 0 rgba(45, 55, 75, 0.2);
  border-radius: 2rem;
  padding: 0.3125rem;
}

.device-mobile-img {
  max-width: 100%;
  height: auto;
  border-radius: 1.6rem;
}

/*------------------------------------
  Browser Device
------------------------------------*/
.device-browser {
  position: relative;
  z-index: 1;
  max-width: 100%;
  width: 50rem;
  height: auto;
  box-shadow: 0 2.75rem 3.5rem -2rem rgba(45, 55, 75, 0.2), 0 0 5rem -2rem rgba(45, 55, 75, 0.15);
  border-bottom-right-radius: 0.5rem;
  border-bottom-left-radius: 0.5rem;
  margin-left: auto;
  margin-right: auto;
}

.device-browser-lg {
  width: 60rem;
}

.device-browser-frame {
  background: #2d374b;
  border-bottom-right-radius: 0.5rem;
  border-bottom-left-radius: 0.5rem;
}

.device-browser-img {
  max-width: 100%;
  height: auto;
  border-bottom-right-radius: 0.5rem;
  border-bottom-left-radius: 0.5rem;
}

.device-browser-header {
  position: relative;
  display: flex;
  max-width: 50rem;
  background: #2d374b;
  border-bottom: 0.0625rem solid #e5e8ec;
  border-top-left-radius: 0.5rem;
  border-top-right-radius: 0.5rem;
  padding: 0.5rem 6.5rem;
}

.device-browser-header-btn-list {
  display: flex;
  grid-gap: 0.25rem;
  position: absolute;
  top: calc(50% - 0.25rem);
  left: 1rem;
}

.device-browser-header-btn-list-btn {
  width: 0.5rem;
  height: 0.5rem;
  background-color: #404e6b;
  border-radius: 50%;
}

.device-browser-header-browser-bar {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  color: rgba(255, 255, 255, 0.7);
  background-color: #404e6b;
  font-size: 0.5rem;
  border-radius: 0.125rem;
}

.device-browser-lg {
  width: 60rem;
}
.device-browser-lg .device-browser-header {
  max-width: 60rem;
}

/*------------------------------------
  Dropdown
------------------------------------*/
.dropdown-menu {
  box-shadow: 0rem 0.1875rem 0.375rem rgba(140, 152, 164, 0.25);
  margin-top: 0.5rem;
}
.dropdown-menu .dropdown-item.dropdown-toggle::after {
  transform: rotate(-90deg);
}

.dropdown-item {
  position: relative;
  font-size: 0.875rem;
  border-radius: 0.6rem;
  padding-right: 2.5rem;
}
.dropdown-item:not(:last-child) {
  margin-bottom: 0.25rem;
}
.dropdown-item::after {
  position: absolute;
  top: 50%;
  right: 0.75rem;
  opacity: 0;
  width: 1.25rem;
  height: 1.25rem;
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%230abf53' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
  background-repeat: no-repeat;
  background-position: right center;
  background-size: 1.25rem 1.25rem;
  content: "";
  transform: translateY(-50%);
  transition: 0.2s;
}
.dropdown-item:hover::after {
  opacity: 1;
  right: 0.4375rem;
}
.dropdown-item:active {
  color: var(--bs-body-color);
  background-color: rgba(189, 197, 209, 0.2);
}
.dropdown-item.active:not(:focus):not(:active) {
  color: #2d374b;
  background-color: rgba(189, 197, 209, 0.2);
}
.dropdown-item[href]:hover.dropdown-toggle::after {
  background: url("data:image/svg+xml,<svg width='24' height='24' viewBox='0 0 24 24' fill='#0abf53' xmlns='http://www.w3.org/2000/svg'><path d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/></svg>");
}

.dropdown-header {
  font-size: 0.9375rem;
  font-weight: 700;
  padding: 0.5rem 1rem;
}

.dropdown-item-icon {
  display: inline-block;
  opacity: 0.7;
  font-size: 1.125rem;
  width: 1.5rem;
  color: #51596C;
}

.dropdown-toggle {
  position: relative;
  display: flex;
  align-items: center;
}
.dropdown-toggle::after {
  display: inline-block;
  width: 1rem;
  height: 1rem;
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%232d374b' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/%3e%3c/svg%3e");
  background-repeat: no-repeat;
  background-position: right center;
  background-size: 1rem 1rem;
  margin-left: auto;
  padding-left: 1.25rem;
  content: "";
}

.dropup .dropdown-toggle::after {
  transform: rotate(-180deg);
}

.dropright .dropdown-toggle::after {
  transform: rotate(-90deg);
  margin-top: 0.25rem;
}

.dropleft .dropdown-toggle::after {
  transform: rotate(90deg);
  margin-top: -0.25rem;
}

.dropdown-toggle-collapse::after {
  transition: 0.3s;
}
.dropdown-toggle-collapse[aria-expanded=true]::after {
  transform: rotate(-180deg);
}

/*------------------------------------
  Form Check
------------------------------------*/
.form-check-input,
.form-check-label {
  cursor: pointer;
}

.form-check-label {
  font-size: 0.875rem;
}

.was-validated .form-check-input:valid,
.form-check-input.is-valid {
  border: 1px solid #dce0e5;
}

.was-validated .form-check-input:valid ~ .form-check-label,
.form-check-input.is-valid ~ .form-check-label {
  color: #51596C;
}

.form-check-custom .form-check-input:checked[type=checkbox], .form-check-custom .form-check-input:checked[type=radio] {
  background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M13.3035 4.76425C13.5718 4.44865 14.0451 4.41027 14.3607 4.67853C14.6763 4.9468 14.7147 5.42012 14.4464 5.73572L8.07144 13.2357C7.79896 13.5563 7.31616 13.5901 7.00171 13.3105L3.62671 10.3105C3.31713 10.0354 3.28924 9.5613 3.56443 9.25172C3.83962 8.94213 4.31367 8.91424 4.62326 9.18943L7.42515 11.68L13.3035 4.76425Z' fill='white'/%3e%3c/svg%3e");
}

.form-check-reverse {
  padding-left: 0;
  padding-right: 1.5rem;
  text-align: left;
}
.form-check-reverse .form-check-input {
  float: right;
  margin-left: 0;
  margin-right: 0;
}

/*------------------------------------
  Form Check Select
------------------------------------*/
.form-check-select {
  position: relative;
  cursor: pointer;
  padding: 0.75rem 1rem 0.75rem 2.5rem;
}
.form-check-select.form-check-pinned-top-end, .form-check-select.form-check-reverse {
  padding: 0.75rem 1rem;
}
.form-check-select .form-check-input {
  position: relative;
  z-index: 2;
  width: 12px;
  height: 12px;
  background-color: #dce0e5;
  border-width: 0;
  margin-top: 0.4375rem;
  border-radius: 50%;
}
.form-check-select .form-check-input:checked[type=radio], .form-check-select .form-check-input:checked[type=checkbox] {
  background-image: none;
}
.form-check-select .form-check-input:checked[type=radio] ~ .form-check-stretched-bg::before, .form-check-select .form-check-input:checked[type=checkbox] ~ .form-check-stretched-bg::before {
  background-color: rgba(10, 191, 83, 0.1);
  border-color: rgba(10, 191, 83, 0.2);
}
.form-check-select .form-check-input:disabled[type=radio] ~ .form-check-label > *, .form-check-select .form-check-input:disabled[type=checkbox] ~ .form-check-label > * {
  opacity: 0.5;
}
.form-check-select .form-check-input:disabled[type=radio] ~ .form-check-stretched-bg::before, .form-check-select .form-check-input:disabled[type=checkbox] ~ .form-check-stretched-bg::before {
  background-color: transparent;
}
.form-check-select .form-check-stretched-bg::before {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  pointer-events: auto;
  content: "";
  z-index: 1;
  border: 0.0625rem solid transparent;
  background-color: rgba(0, 0, 0, 0);
  border-radius: 0.6rem;
}

/*------------------------------------
  Form Check Pinned Top End
------------------------------------*/
.form-check-pinned-top-end {
  position: relative;
}
.form-check-pinned-top-end .form-check-input {
  position: absolute;
  top: 0.75rem;
  right: 0.75rem;
  width: 1rem;
  height: 1rem;
  float: none;
  margin-left: 0;
  margin-top: 0;
}
.form-check-pinned-top-end .form-check-input:checked[type=checkbox], .form-check-pinned-top-end .form-check-input:checked[type=radio] {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M13.3035 4.76425C13.5718 4.44865 14.0451 4.41027 14.3607 4.67853C14.6763 4.9468 14.7147 5.42012 14.4464 5.73572L8.07144 13.2357C7.79896 13.5563 7.31616 13.5901 7.00171 13.3105L3.62671 10.3105C3.31713 10.0354 3.28924 9.5613 3.56443 9.25172C3.83962 8.94213 4.31367 8.91424 4.62326 9.18943L7.42515 11.68L13.3035 4.76425Z' fill='white'/%3e%3c/svg%3e");
}

/*------------------------------------
  Form Select
------------------------------------*/
.form-select {
  cursor: pointer;
}

/*------------------------------------
  Form Switch
------------------------------------*/
.form-switch {
  position: relative;
}
.form-switch .form-check-input {
  width: 3em;
  height: 2em;
  border-width: 0;
  background-color: #dce0e5;
  margin-top: -0.25rem;
  margin-right: 0.5rem;
}
.form-switch .form-check-input:active {
  filter: 100%;
}

.form-check-input:checked {
  background-color: #0abf53;
}

.form-switch-between {
  align-items: center;
  padding-left: 0;
}
.form-switch-between .form-check-input {
  float: none;
  align-items: center;
  margin-left: 0.5rem;
}
.form-switch-between .form-check-label {
  cursor: inherit;
}

/*------------------------------------
  Input Group Merge
------------------------------------*/
.input-group-merge {
  position: relative;
}
.input-group-merge .input-group-prepend,
.input-group-merge .input-group-append {
  position: absolute;
  top: 50%;
  z-index: 4;
  background-color: transparent;
  transform: translateY(-50%);
}
.input-group-merge .input-group-prepend.input-group-text,
.input-group-merge .input-group-append.input-group-text {
  border-width: 0;
  min-height: calc(1.5em + 1rem + calc(0.0625rem * 2));
}
.input-group-merge .input-group-prepend {
  left: 1px;
}
.input-group-merge .input-group-append {
  right: 1px;
}
.input-group-merge .form-select:not(:first-child),
.input-group-merge .form-control:not(:first-child) {
  padding-left: 3.53125rem;
  border-top-left-radius: 0.4rem;
  border-bottom-left-radius: 0.4rem;
}
.input-group-merge .form-select:not(:last-child),
.input-group-merge .form-control:not(:last-child) {
  padding-right: 3.53125rem;
  border-top-right-radius: 0.4rem;
  border-bottom-right-radius: 0.4rem;
}

.input-group-merge .form-select-sm:not(:first-child),
.input-group-merge .form-control-sm:not(:first-child) {
  padding-left: 3.0625rem;
}
.input-group-merge .form-select-sm:not(:last-child),
.input-group-merge .form-control-sm:not(:last-child) {
  padding-right: 3.0625rem;
}

/*------------------------------------
  Input Card
------------------------------------*/
.input-card {
  display: flex;
  background-color: white;
  padding: 0.75rem 0.75rem;
  border: 0.0625rem solid rgba(220, 224, 229, 0.6);
  box-shadow: 0rem 0.375rem 1.5rem 0rem rgba(140, 152, 164, 0.125);
  border-radius: 0.6rem;
}
.input-card .input-card-form {
  flex: 1 0 0%;
}
.input-card .btn {
  flex: 0 0 auto;
}
.input-card .form-control {
  border-width: 0;
}
.input-card .form-control:focus {
  box-shadow: none;
}
.input-card .input-group {
  border-width: 0;
}
.input-card .input-card-form {
  position: relative;
}
.input-card .input-card-form:not(:first-child) {
  padding-left: 1rem;
}
.input-card .input-card-form:not(:first-child)::before {
  position: absolute;
  top: 50%;
  left: 0;
  width: 0.0625rem;
  height: 2rem;
  background-color: rgba(220, 224, 229, 0.6);
  content: "";
  transform: translateY(-50%);
}
.input-card .input-card-form:not(:last-child) {
  padding-right: 1rem;
}

@media (max-width: 575.98px) {
  .input-card-sm {
    display: grid;
  }
  .input-card-sm .btn,
.input-card-sm .input-card-form {
    flex: 0 0 auto;
  }
  .input-card-sm .input-card-form {
    padding: 1rem 0 !important;
    border-bottom: 0.0625rem solid rgba(220, 224, 229, 0.6);
  }
  .input-card-sm .input-card-form:first-child {
    padding-top: 0 !important;
  }
  .input-card-sm .input-card-form:not(:first-child)::before {
    display: none;
  }
}
/*------------------------------------
  Labels
------------------------------------*/
.form-label-secondary {
  color: #8C98A4;
}

.form-label-link {
  font-weight: 500;
  font-size: 0.875rem;
  margin-bottom: 0.5rem;
}

/*------------------------------------
  Go To
------------------------------------*/
.go-to {
  display: inline-flex;
  flex-shrink: 0;
  justify-content: center;
  align-items: center;
  z-index: 9999;
  width: 2.875rem;
  height: 2.875rem;
  background-color: rgba(83, 102, 139, 0.1);
  color: #404e6b;
  font-size: 1rem;
  opacity: 0.5;
  border-radius: 0.6rem;
  transition: 0.3s ease-out;
}
.go-to:hover, .go-to:focus:hover {
  color: white;
  background-color: #404e6b;
  opacity: 1;
}

/*------------------------------------
  List Group
------------------------------------*/
.list-group-item:first-child {
  border-top-left-radius: var(--bs-border-radius);
  border-top-right-radius: var(--bs-border-radius);
}
.list-group-item:last-child {
  border-bottom-right-radius: var(--bs-border-radius);
  border-bottom-left-radius: var(--bs-border-radius);
}

.list-group-icon {
  width: 1.25rem;
  text-align: center;
  margin-right: 0.25rem;
}

.list-group-striped > li:nth-of-type(odd) {
  background-color: rgba(243, 149, 104, 0.1);
}

.list-group-sm .list-group-item {
  font-size: 0.8125rem;
  padding: 0.375rem 0.5rem;
}

.list-group-lg .list-group-item {
  padding: 1.5rem 1.5rem;
}
.list-group-lg .list-group-icon {
  font-size: 1.5rem;
  width: 2.3125rem;
  margin-right: 0.5rem;
}

.list-group-no-gutters .list-group-item {
  padding-right: 0;
  padding-left: 0;
}
.list-group-no-gutters .list-group-item:first-child {
  padding-top: 0;
}
.list-group-no-gutters .list-group-item:last-child {
  padding-bottom: 0;
}

/*------------------------------------
  List Checked
------------------------------------*/
.list-checked {
  padding-left: 0;
  list-style: none;
}

.list-checked-item,
.list-unchecked-item {
  position: relative;
  color: #51596C;
  padding-left: 2rem;
}
.list-checked-item:not(:last-child),
.list-unchecked-item:not(:last-child) {
  margin-bottom: 0.5rem;
}
.list-checked-item::before,
.list-unchecked-item::before {
  position: absolute;
  top: 0;
  left: 0;
  width: 1.25rem;
  height: 1.25rem;
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M13.3035 4.76425C13.5718 4.44865 14.0451 4.41027 14.3607 4.67853C14.6763 4.9468 14.7147 5.42012 14.4464 5.73572L8.07144 13.2357C7.79896 13.5563 7.31616 13.5901 7.00171 13.3105L3.62671 10.3105C3.31713 10.0354 3.28924 9.5613 3.56443 9.25172C3.83962 8.94213 4.31367 8.91424 4.62326 9.18943L7.42515 11.68L13.3035 4.76425Z' fill='%2351596C'/%3e%3c/svg%3e");
  background-repeat: no-repeat;
  background-position: right center;
  background-size: 1.25rem 1.25rem;
  content: "";
  margin-top: 0.125rem;
}
.list-checked-item[hover]:hover,
.list-unchecked-item[hover]:hover {
  color: #0abf53;
}

[class*=list-checked-bg-] .list-checked-item::before,
[class*=list-checked-bg-] .list-unchecked-item::before,
[class*=list-checked-soft-bg-] .list-checked-item::before,
[class*=list-checked-soft-bg-] .list-unchecked-item::before {
  margin-top: 0.125rem;
}

.list-checked-primary .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M13.3035 4.76425C13.5718 4.44865 14.0451 4.41027 14.3607 4.67853C14.6763 4.9468 14.7147 5.42012 14.4464 5.73572L8.07144 13.2357C7.79896 13.5563 7.31616 13.5901 7.00171 13.3105L3.62671 10.3105C3.31713 10.0354 3.28924 9.5613 3.56443 9.25172C3.83962 8.94213 4.31367 8.91424 4.62326 9.18943L7.42515 11.68L13.3035 4.76425Z' fill='%230abf53'/%3e%3c/svg%3e");
}
.list-checked-primary .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M4.20895 4.21806C4.34279 4.08416 4.52428 4.00893 4.71352 4.00893C4.90276 4.00893 5.08425 4.08416 5.21808 4.21806L8.99554 7.99878L12.773 4.21806C12.8388 4.14984 12.9176 4.09543 13.0046 4.05799C13.0917 4.02056 13.1854 4.00085 13.2801 4.00003C13.3749 3.9992 13.4689 4.01728 13.5566 4.05319C13.6443 4.08911 13.724 4.14214 13.791 4.20921C13.858 4.27628 13.911 4.35603 13.9469 4.44381C13.9827 4.53159 14.0008 4.62565 14 4.72049C13.9991 4.81533 13.9795 4.90906 13.9421 4.99621C13.9047 5.08335 13.8503 5.16217 13.7821 5.22806L10.0047 9.00878L13.7821 12.7895C13.9121 12.9242 13.9841 13.1046 13.9824 13.2919C13.9808 13.4792 13.9058 13.6584 13.7734 13.7908C13.6411 13.9232 13.4621 13.9983 13.275 14C13.0879 14.0016 12.9076 13.9296 12.773 13.7995L8.99554 10.0188L5.21808 13.7995C5.08348 13.9296 4.90321 14.0016 4.71609 14C4.52896 13.9983 4.34997 13.9232 4.21765 13.7908C4.08533 13.6584 4.01027 13.4792 4.00864 13.2919C4.00702 13.1046 4.07895 12.9242 4.20895 12.7895L7.98641 9.00878L4.20895 5.22806C4.07516 5.09411 4 4.91247 4 4.72306C4 4.53366 4.07516 4.35201 4.20895 4.21806V4.21806Z' fill='%238997a4'/%3e%3c/svg%3e");
}

.list-checked-bg-primary .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='18' height='18' rx='9' fill='%230abf53'/%3e%3cpath d='M12.0603 5.78792C12.2511 5.56349 12.5876 5.5362 12.8121 5.72697C13.0365 5.91774 13.0638 6.25432 12.873 6.47875L8.3397 11.8121C8.14594 12.04 7.80261 12.064 7.57901 11.8653L5.17901 9.73195C4.95886 9.53626 4.93903 9.19915 5.13472 8.979C5.33041 8.75885 5.66751 8.73902 5.88766 8.93471L7.88011 10.7058L12.0603 5.78792Z' fill='white'/%3e%3c/svg%3e");
}
.list-checked-bg-primary .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M18 9C18 4.02944 13.9706 0 9 0C4.02944 0 0 4.02944 0 9C0 13.9706 4.02944 18 9 18C13.9706 18 18 13.9706 18 9Z' fill='%238997a4'/%3E%3Cpath d='M5.64639 5.64654C5.74016 5.55281 5.86731 5.50015 5.99989 5.50015C6.13248 5.50015 6.25963 5.55281 6.35339 5.64654L8.99989 8.29304L11.6464 5.64654C11.6925 5.59879 11.7477 5.56069 11.8087 5.53449C11.8697 5.50829 11.9353 5.49449 12.0017 5.49392C12.0681 5.49334 12.1339 5.50599 12.1954 5.53113C12.2568 5.55627 12.3126 5.5934 12.3596 5.64034C12.4065 5.68729 12.4437 5.74312 12.4688 5.80456C12.4939 5.86601 12.5066 5.93185 12.506 5.99824C12.5054 6.06463 12.4916 6.13024 12.4654 6.19124C12.4392 6.25224 12.4011 6.30742 12.3534 6.35354L9.70689 9.00004L12.3534 11.6465C12.4445 11.7408 12.4949 11.8671 12.4937 11.9982C12.4926 12.1293 12.44 12.2547 12.3473 12.3474C12.2546 12.4402 12.1292 12.4927 11.9981 12.4939C11.867 12.495 11.7407 12.4446 11.6464 12.3535L8.99989 9.70704L6.35339 12.3535C6.25909 12.4446 6.13279 12.495 6.00169 12.4939C5.87059 12.4927 5.74519 12.4402 5.65248 12.3474C5.55978 12.2547 5.5072 12.1293 5.50606 11.9982C5.50492 11.8671 5.55531 11.7408 5.64639 11.6465L8.29289 9.00004L5.64639 6.35354C5.55266 6.25978 5.5 6.13262 5.5 6.00004C5.5 5.86746 5.55266 5.7403 5.64639 5.64654V5.64654Z' fill='white'/%3e%3c/svg%3e");
}

.list-checked-soft-bg-primary .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='18' height='18' rx='9' fill='%230abf53' fill-opacity='0.1'/%3e%3cpath d='M12.0603 5.78792C12.2511 5.56349 12.5876 5.5362 12.8121 5.72697C13.0365 5.91774 13.0638 6.25432 12.873 6.47875L8.3397 11.8121C8.14594 12.04 7.80261 12.064 7.57901 11.8653L5.17901 9.73195C4.95886 9.53626 4.93903 9.19915 5.13472 8.979C5.33041 8.75885 5.66751 8.73902 5.88766 8.93471L7.88011 10.7058L12.0603 5.78792Z' fill='%230abf53'/%3e%3c/svg%3e");
}
.list-checked-soft-bg-primary .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M18 9C18 4.02944 13.9706 0 9 0C4.02944 0 0 4.02944 0 9C0 13.9706 4.02944 18 9 18C13.9706 18 18 13.9706 18 9Z' fill='%238997a4' fill-opacity='0.1'/%3E%3Cpath d='M5.64639 5.64654C5.74016 5.55281 5.86731 5.50015 5.99989 5.50015C6.13248 5.50015 6.25963 5.55281 6.35339 5.64654L8.99989 8.29304L11.6464 5.64654C11.6925 5.59879 11.7477 5.56069 11.8087 5.53449C11.8697 5.50829 11.9353 5.49449 12.0017 5.49392C12.0681 5.49334 12.1339 5.50599 12.1954 5.53113C12.2568 5.55627 12.3126 5.5934 12.3596 5.64034C12.4065 5.68729 12.4437 5.74312 12.4688 5.80456C12.4939 5.86601 12.5066 5.93185 12.506 5.99824C12.5054 6.06463 12.4916 6.13024 12.4654 6.19124C12.4392 6.25224 12.4011 6.30742 12.3534 6.35354L9.70689 9.00004L12.3534 11.6465C12.4445 11.7408 12.4949 11.8671 12.4937 11.9982C12.4926 12.1293 12.44 12.2547 12.3473 12.3474C12.2546 12.4402 12.1292 12.4927 11.9981 12.4939C11.867 12.495 11.7407 12.4446 11.6464 12.3535L8.99989 9.70704L6.35339 12.3535C6.25909 12.4446 6.13279 12.495 6.00169 12.4939C5.87059 12.4927 5.74519 12.4402 5.65248 12.3474C5.55978 12.2547 5.5072 12.1293 5.50606 11.9982C5.50492 11.8671 5.55531 11.7408 5.64639 11.6465L8.29289 9.00004L5.64639 6.35354C5.55266 6.25978 5.5 6.13262 5.5 6.00004C5.5 5.86746 5.55266 5.7403 5.64639 5.64654V5.64654Z' fill='%238997a4'/%3e%3c/svg%3e");
}

.list-checked-secondary .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M13.3035 4.76425C13.5718 4.44865 14.0451 4.41027 14.3607 4.67853C14.6763 4.9468 14.7147 5.42012 14.4464 5.73572L8.07144 13.2357C7.79896 13.5563 7.31616 13.5901 7.00171 13.3105L3.62671 10.3105C3.31713 10.0354 3.28924 9.5613 3.56443 9.25172C3.83962 8.94213 4.31367 8.91424 4.62326 9.18943L7.42515 11.68L13.3035 4.76425Z' fill='%2351596c'/%3e%3c/svg%3e");
}
.list-checked-secondary .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M4.20895 4.21806C4.34279 4.08416 4.52428 4.00893 4.71352 4.00893C4.90276 4.00893 5.08425 4.08416 5.21808 4.21806L8.99554 7.99878L12.773 4.21806C12.8388 4.14984 12.9176 4.09543 13.0046 4.05799C13.0917 4.02056 13.1854 4.00085 13.2801 4.00003C13.3749 3.9992 13.4689 4.01728 13.5566 4.05319C13.6443 4.08911 13.724 4.14214 13.791 4.20921C13.858 4.27628 13.911 4.35603 13.9469 4.44381C13.9827 4.53159 14.0008 4.62565 14 4.72049C13.9991 4.81533 13.9795 4.90906 13.9421 4.99621C13.9047 5.08335 13.8503 5.16217 13.7821 5.22806L10.0047 9.00878L13.7821 12.7895C13.9121 12.9242 13.9841 13.1046 13.9824 13.2919C13.9808 13.4792 13.9058 13.6584 13.7734 13.7908C13.6411 13.9232 13.4621 13.9983 13.275 14C13.0879 14.0016 12.9076 13.9296 12.773 13.7995L8.99554 10.0188L5.21808 13.7995C5.08348 13.9296 4.90321 14.0016 4.71609 14C4.52896 13.9983 4.34997 13.9232 4.21765 13.7908C4.08533 13.6584 4.01027 13.4792 4.00864 13.2919C4.00702 13.1046 4.07895 12.9242 4.20895 12.7895L7.98641 9.00878L4.20895 5.22806C4.07516 5.09411 4 4.91247 4 4.72306C4 4.53366 4.07516 4.35201 4.20895 4.21806V4.21806Z' fill='%238997a4'/%3e%3c/svg%3e");
}

.list-checked-bg-secondary .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='18' height='18' rx='9' fill='%2351596c'/%3e%3cpath d='M12.0603 5.78792C12.2511 5.56349 12.5876 5.5362 12.8121 5.72697C13.0365 5.91774 13.0638 6.25432 12.873 6.47875L8.3397 11.8121C8.14594 12.04 7.80261 12.064 7.57901 11.8653L5.17901 9.73195C4.95886 9.53626 4.93903 9.19915 5.13472 8.979C5.33041 8.75885 5.66751 8.73902 5.88766 8.93471L7.88011 10.7058L12.0603 5.78792Z' fill='white'/%3e%3c/svg%3e");
}
.list-checked-bg-secondary .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M18 9C18 4.02944 13.9706 0 9 0C4.02944 0 0 4.02944 0 9C0 13.9706 4.02944 18 9 18C13.9706 18 18 13.9706 18 9Z' fill='%238997a4'/%3E%3Cpath d='M5.64639 5.64654C5.74016 5.55281 5.86731 5.50015 5.99989 5.50015C6.13248 5.50015 6.25963 5.55281 6.35339 5.64654L8.99989 8.29304L11.6464 5.64654C11.6925 5.59879 11.7477 5.56069 11.8087 5.53449C11.8697 5.50829 11.9353 5.49449 12.0017 5.49392C12.0681 5.49334 12.1339 5.50599 12.1954 5.53113C12.2568 5.55627 12.3126 5.5934 12.3596 5.64034C12.4065 5.68729 12.4437 5.74312 12.4688 5.80456C12.4939 5.86601 12.5066 5.93185 12.506 5.99824C12.5054 6.06463 12.4916 6.13024 12.4654 6.19124C12.4392 6.25224 12.4011 6.30742 12.3534 6.35354L9.70689 9.00004L12.3534 11.6465C12.4445 11.7408 12.4949 11.8671 12.4937 11.9982C12.4926 12.1293 12.44 12.2547 12.3473 12.3474C12.2546 12.4402 12.1292 12.4927 11.9981 12.4939C11.867 12.495 11.7407 12.4446 11.6464 12.3535L8.99989 9.70704L6.35339 12.3535C6.25909 12.4446 6.13279 12.495 6.00169 12.4939C5.87059 12.4927 5.74519 12.4402 5.65248 12.3474C5.55978 12.2547 5.5072 12.1293 5.50606 11.9982C5.50492 11.8671 5.55531 11.7408 5.64639 11.6465L8.29289 9.00004L5.64639 6.35354C5.55266 6.25978 5.5 6.13262 5.5 6.00004C5.5 5.86746 5.55266 5.7403 5.64639 5.64654V5.64654Z' fill='white'/%3e%3c/svg%3e");
}

.list-checked-soft-bg-secondary .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='18' height='18' rx='9' fill='%2351596c' fill-opacity='0.1'/%3e%3cpath d='M12.0603 5.78792C12.2511 5.56349 12.5876 5.5362 12.8121 5.72697C13.0365 5.91774 13.0638 6.25432 12.873 6.47875L8.3397 11.8121C8.14594 12.04 7.80261 12.064 7.57901 11.8653L5.17901 9.73195C4.95886 9.53626 4.93903 9.19915 5.13472 8.979C5.33041 8.75885 5.66751 8.73902 5.88766 8.93471L7.88011 10.7058L12.0603 5.78792Z' fill='%2351596c'/%3e%3c/svg%3e");
}
.list-checked-soft-bg-secondary .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M18 9C18 4.02944 13.9706 0 9 0C4.02944 0 0 4.02944 0 9C0 13.9706 4.02944 18 9 18C13.9706 18 18 13.9706 18 9Z' fill='%238997a4' fill-opacity='0.1'/%3E%3Cpath d='M5.64639 5.64654C5.74016 5.55281 5.86731 5.50015 5.99989 5.50015C6.13248 5.50015 6.25963 5.55281 6.35339 5.64654L8.99989 8.29304L11.6464 5.64654C11.6925 5.59879 11.7477 5.56069 11.8087 5.53449C11.8697 5.50829 11.9353 5.49449 12.0017 5.49392C12.0681 5.49334 12.1339 5.50599 12.1954 5.53113C12.2568 5.55627 12.3126 5.5934 12.3596 5.64034C12.4065 5.68729 12.4437 5.74312 12.4688 5.80456C12.4939 5.86601 12.5066 5.93185 12.506 5.99824C12.5054 6.06463 12.4916 6.13024 12.4654 6.19124C12.4392 6.25224 12.4011 6.30742 12.3534 6.35354L9.70689 9.00004L12.3534 11.6465C12.4445 11.7408 12.4949 11.8671 12.4937 11.9982C12.4926 12.1293 12.44 12.2547 12.3473 12.3474C12.2546 12.4402 12.1292 12.4927 11.9981 12.4939C11.867 12.495 11.7407 12.4446 11.6464 12.3535L8.99989 9.70704L6.35339 12.3535C6.25909 12.4446 6.13279 12.495 6.00169 12.4939C5.87059 12.4927 5.74519 12.4402 5.65248 12.3474C5.55978 12.2547 5.5072 12.1293 5.50606 11.9982C5.50492 11.8671 5.55531 11.7408 5.64639 11.6465L8.29289 9.00004L5.64639 6.35354C5.55266 6.25978 5.5 6.13262 5.5 6.00004C5.5 5.86746 5.55266 5.7403 5.64639 5.64654V5.64654Z' fill='%238997a4'/%3e%3c/svg%3e");
}

.list-checked-success .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M13.3035 4.76425C13.5718 4.44865 14.0451 4.41027 14.3607 4.67853C14.6763 4.9468 14.7147 5.42012 14.4464 5.73572L8.07144 13.2357C7.79896 13.5563 7.31616 13.5901 7.00171 13.3105L3.62671 10.3105C3.31713 10.0354 3.28924 9.5613 3.56443 9.25172C3.83962 8.94213 4.31367 8.91424 4.62326 9.18943L7.42515 11.68L13.3035 4.76425Z' fill='%23077c76'/%3e%3c/svg%3e");
}
.list-checked-success .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M4.20895 4.21806C4.34279 4.08416 4.52428 4.00893 4.71352 4.00893C4.90276 4.00893 5.08425 4.08416 5.21808 4.21806L8.99554 7.99878L12.773 4.21806C12.8388 4.14984 12.9176 4.09543 13.0046 4.05799C13.0917 4.02056 13.1854 4.00085 13.2801 4.00003C13.3749 3.9992 13.4689 4.01728 13.5566 4.05319C13.6443 4.08911 13.724 4.14214 13.791 4.20921C13.858 4.27628 13.911 4.35603 13.9469 4.44381C13.9827 4.53159 14.0008 4.62565 14 4.72049C13.9991 4.81533 13.9795 4.90906 13.9421 4.99621C13.9047 5.08335 13.8503 5.16217 13.7821 5.22806L10.0047 9.00878L13.7821 12.7895C13.9121 12.9242 13.9841 13.1046 13.9824 13.2919C13.9808 13.4792 13.9058 13.6584 13.7734 13.7908C13.6411 13.9232 13.4621 13.9983 13.275 14C13.0879 14.0016 12.9076 13.9296 12.773 13.7995L8.99554 10.0188L5.21808 13.7995C5.08348 13.9296 4.90321 14.0016 4.71609 14C4.52896 13.9983 4.34997 13.9232 4.21765 13.7908C4.08533 13.6584 4.01027 13.4792 4.00864 13.2919C4.00702 13.1046 4.07895 12.9242 4.20895 12.7895L7.98641 9.00878L4.20895 5.22806C4.07516 5.09411 4 4.91247 4 4.72306C4 4.53366 4.07516 4.35201 4.20895 4.21806V4.21806Z' fill='%238997a4'/%3e%3c/svg%3e");
}

.list-checked-bg-success .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='18' height='18' rx='9' fill='%23077c76'/%3e%3cpath d='M12.0603 5.78792C12.2511 5.56349 12.5876 5.5362 12.8121 5.72697C13.0365 5.91774 13.0638 6.25432 12.873 6.47875L8.3397 11.8121C8.14594 12.04 7.80261 12.064 7.57901 11.8653L5.17901 9.73195C4.95886 9.53626 4.93903 9.19915 5.13472 8.979C5.33041 8.75885 5.66751 8.73902 5.88766 8.93471L7.88011 10.7058L12.0603 5.78792Z' fill='white'/%3e%3c/svg%3e");
}
.list-checked-bg-success .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M18 9C18 4.02944 13.9706 0 9 0C4.02944 0 0 4.02944 0 9C0 13.9706 4.02944 18 9 18C13.9706 18 18 13.9706 18 9Z' fill='%238997a4'/%3E%3Cpath d='M5.64639 5.64654C5.74016 5.55281 5.86731 5.50015 5.99989 5.50015C6.13248 5.50015 6.25963 5.55281 6.35339 5.64654L8.99989 8.29304L11.6464 5.64654C11.6925 5.59879 11.7477 5.56069 11.8087 5.53449C11.8697 5.50829 11.9353 5.49449 12.0017 5.49392C12.0681 5.49334 12.1339 5.50599 12.1954 5.53113C12.2568 5.55627 12.3126 5.5934 12.3596 5.64034C12.4065 5.68729 12.4437 5.74312 12.4688 5.80456C12.4939 5.86601 12.5066 5.93185 12.506 5.99824C12.5054 6.06463 12.4916 6.13024 12.4654 6.19124C12.4392 6.25224 12.4011 6.30742 12.3534 6.35354L9.70689 9.00004L12.3534 11.6465C12.4445 11.7408 12.4949 11.8671 12.4937 11.9982C12.4926 12.1293 12.44 12.2547 12.3473 12.3474C12.2546 12.4402 12.1292 12.4927 11.9981 12.4939C11.867 12.495 11.7407 12.4446 11.6464 12.3535L8.99989 9.70704L6.35339 12.3535C6.25909 12.4446 6.13279 12.495 6.00169 12.4939C5.87059 12.4927 5.74519 12.4402 5.65248 12.3474C5.55978 12.2547 5.5072 12.1293 5.50606 11.9982C5.50492 11.8671 5.55531 11.7408 5.64639 11.6465L8.29289 9.00004L5.64639 6.35354C5.55266 6.25978 5.5 6.13262 5.5 6.00004C5.5 5.86746 5.55266 5.7403 5.64639 5.64654V5.64654Z' fill='white'/%3e%3c/svg%3e");
}

.list-checked-soft-bg-success .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='18' height='18' rx='9' fill='%23077c76' fill-opacity='0.1'/%3e%3cpath d='M12.0603 5.78792C12.2511 5.56349 12.5876 5.5362 12.8121 5.72697C13.0365 5.91774 13.0638 6.25432 12.873 6.47875L8.3397 11.8121C8.14594 12.04 7.80261 12.064 7.57901 11.8653L5.17901 9.73195C4.95886 9.53626 4.93903 9.19915 5.13472 8.979C5.33041 8.75885 5.66751 8.73902 5.88766 8.93471L7.88011 10.7058L12.0603 5.78792Z' fill='%23077c76'/%3e%3c/svg%3e");
}
.list-checked-soft-bg-success .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M18 9C18 4.02944 13.9706 0 9 0C4.02944 0 0 4.02944 0 9C0 13.9706 4.02944 18 9 18C13.9706 18 18 13.9706 18 9Z' fill='%238997a4' fill-opacity='0.1'/%3E%3Cpath d='M5.64639 5.64654C5.74016 5.55281 5.86731 5.50015 5.99989 5.50015C6.13248 5.50015 6.25963 5.55281 6.35339 5.64654L8.99989 8.29304L11.6464 5.64654C11.6925 5.59879 11.7477 5.56069 11.8087 5.53449C11.8697 5.50829 11.9353 5.49449 12.0017 5.49392C12.0681 5.49334 12.1339 5.50599 12.1954 5.53113C12.2568 5.55627 12.3126 5.5934 12.3596 5.64034C12.4065 5.68729 12.4437 5.74312 12.4688 5.80456C12.4939 5.86601 12.5066 5.93185 12.506 5.99824C12.5054 6.06463 12.4916 6.13024 12.4654 6.19124C12.4392 6.25224 12.4011 6.30742 12.3534 6.35354L9.70689 9.00004L12.3534 11.6465C12.4445 11.7408 12.4949 11.8671 12.4937 11.9982C12.4926 12.1293 12.44 12.2547 12.3473 12.3474C12.2546 12.4402 12.1292 12.4927 11.9981 12.4939C11.867 12.495 11.7407 12.4446 11.6464 12.3535L8.99989 9.70704L6.35339 12.3535C6.25909 12.4446 6.13279 12.495 6.00169 12.4939C5.87059 12.4927 5.74519 12.4402 5.65248 12.3474C5.55978 12.2547 5.5072 12.1293 5.50606 11.9982C5.50492 11.8671 5.55531 11.7408 5.64639 11.6465L8.29289 9.00004L5.64639 6.35354C5.55266 6.25978 5.5 6.13262 5.5 6.00004C5.5 5.86746 5.55266 5.7403 5.64639 5.64654V5.64654Z' fill='%238997a4'/%3e%3c/svg%3e");
}

.list-checked-info .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M13.3035 4.76425C13.5718 4.44865 14.0451 4.41027 14.3607 4.67853C14.6763 4.9468 14.7147 5.42012 14.4464 5.73572L8.07144 13.2357C7.79896 13.5563 7.31616 13.5901 7.00171 13.3105L3.62671 10.3105C3.31713 10.0354 3.28924 9.5613 3.56443 9.25172C3.83962 8.94213 4.31367 8.91424 4.62326 9.18943L7.42515 11.68L13.3035 4.76425Z' fill='%23334ac0'/%3e%3c/svg%3e");
}
.list-checked-info .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M4.20895 4.21806C4.34279 4.08416 4.52428 4.00893 4.71352 4.00893C4.90276 4.00893 5.08425 4.08416 5.21808 4.21806L8.99554 7.99878L12.773 4.21806C12.8388 4.14984 12.9176 4.09543 13.0046 4.05799C13.0917 4.02056 13.1854 4.00085 13.2801 4.00003C13.3749 3.9992 13.4689 4.01728 13.5566 4.05319C13.6443 4.08911 13.724 4.14214 13.791 4.20921C13.858 4.27628 13.911 4.35603 13.9469 4.44381C13.9827 4.53159 14.0008 4.62565 14 4.72049C13.9991 4.81533 13.9795 4.90906 13.9421 4.99621C13.9047 5.08335 13.8503 5.16217 13.7821 5.22806L10.0047 9.00878L13.7821 12.7895C13.9121 12.9242 13.9841 13.1046 13.9824 13.2919C13.9808 13.4792 13.9058 13.6584 13.7734 13.7908C13.6411 13.9232 13.4621 13.9983 13.275 14C13.0879 14.0016 12.9076 13.9296 12.773 13.7995L8.99554 10.0188L5.21808 13.7995C5.08348 13.9296 4.90321 14.0016 4.71609 14C4.52896 13.9983 4.34997 13.9232 4.21765 13.7908C4.08533 13.6584 4.01027 13.4792 4.00864 13.2919C4.00702 13.1046 4.07895 12.9242 4.20895 12.7895L7.98641 9.00878L4.20895 5.22806C4.07516 5.09411 4 4.91247 4 4.72306C4 4.53366 4.07516 4.35201 4.20895 4.21806V4.21806Z' fill='%238997a4'/%3e%3c/svg%3e");
}

.list-checked-bg-info .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='18' height='18' rx='9' fill='%23334ac0'/%3e%3cpath d='M12.0603 5.78792C12.2511 5.56349 12.5876 5.5362 12.8121 5.72697C13.0365 5.91774 13.0638 6.25432 12.873 6.47875L8.3397 11.8121C8.14594 12.04 7.80261 12.064 7.57901 11.8653L5.17901 9.73195C4.95886 9.53626 4.93903 9.19915 5.13472 8.979C5.33041 8.75885 5.66751 8.73902 5.88766 8.93471L7.88011 10.7058L12.0603 5.78792Z' fill='white'/%3e%3c/svg%3e");
}
.list-checked-bg-info .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M18 9C18 4.02944 13.9706 0 9 0C4.02944 0 0 4.02944 0 9C0 13.9706 4.02944 18 9 18C13.9706 18 18 13.9706 18 9Z' fill='%238997a4'/%3E%3Cpath d='M5.64639 5.64654C5.74016 5.55281 5.86731 5.50015 5.99989 5.50015C6.13248 5.50015 6.25963 5.55281 6.35339 5.64654L8.99989 8.29304L11.6464 5.64654C11.6925 5.59879 11.7477 5.56069 11.8087 5.53449C11.8697 5.50829 11.9353 5.49449 12.0017 5.49392C12.0681 5.49334 12.1339 5.50599 12.1954 5.53113C12.2568 5.55627 12.3126 5.5934 12.3596 5.64034C12.4065 5.68729 12.4437 5.74312 12.4688 5.80456C12.4939 5.86601 12.5066 5.93185 12.506 5.99824C12.5054 6.06463 12.4916 6.13024 12.4654 6.19124C12.4392 6.25224 12.4011 6.30742 12.3534 6.35354L9.70689 9.00004L12.3534 11.6465C12.4445 11.7408 12.4949 11.8671 12.4937 11.9982C12.4926 12.1293 12.44 12.2547 12.3473 12.3474C12.2546 12.4402 12.1292 12.4927 11.9981 12.4939C11.867 12.495 11.7407 12.4446 11.6464 12.3535L8.99989 9.70704L6.35339 12.3535C6.25909 12.4446 6.13279 12.495 6.00169 12.4939C5.87059 12.4927 5.74519 12.4402 5.65248 12.3474C5.55978 12.2547 5.5072 12.1293 5.50606 11.9982C5.50492 11.8671 5.55531 11.7408 5.64639 11.6465L8.29289 9.00004L5.64639 6.35354C5.55266 6.25978 5.5 6.13262 5.5 6.00004C5.5 5.86746 5.55266 5.7403 5.64639 5.64654V5.64654Z' fill='white'/%3e%3c/svg%3e");
}

.list-checked-soft-bg-info .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='18' height='18' rx='9' fill='%23334ac0' fill-opacity='0.1'/%3e%3cpath d='M12.0603 5.78792C12.2511 5.56349 12.5876 5.5362 12.8121 5.72697C13.0365 5.91774 13.0638 6.25432 12.873 6.47875L8.3397 11.8121C8.14594 12.04 7.80261 12.064 7.57901 11.8653L5.17901 9.73195C4.95886 9.53626 4.93903 9.19915 5.13472 8.979C5.33041 8.75885 5.66751 8.73902 5.88766 8.93471L7.88011 10.7058L12.0603 5.78792Z' fill='%23334ac0'/%3e%3c/svg%3e");
}
.list-checked-soft-bg-info .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M18 9C18 4.02944 13.9706 0 9 0C4.02944 0 0 4.02944 0 9C0 13.9706 4.02944 18 9 18C13.9706 18 18 13.9706 18 9Z' fill='%238997a4' fill-opacity='0.1'/%3E%3Cpath d='M5.64639 5.64654C5.74016 5.55281 5.86731 5.50015 5.99989 5.50015C6.13248 5.50015 6.25963 5.55281 6.35339 5.64654L8.99989 8.29304L11.6464 5.64654C11.6925 5.59879 11.7477 5.56069 11.8087 5.53449C11.8697 5.50829 11.9353 5.49449 12.0017 5.49392C12.0681 5.49334 12.1339 5.50599 12.1954 5.53113C12.2568 5.55627 12.3126 5.5934 12.3596 5.64034C12.4065 5.68729 12.4437 5.74312 12.4688 5.80456C12.4939 5.86601 12.5066 5.93185 12.506 5.99824C12.5054 6.06463 12.4916 6.13024 12.4654 6.19124C12.4392 6.25224 12.4011 6.30742 12.3534 6.35354L9.70689 9.00004L12.3534 11.6465C12.4445 11.7408 12.4949 11.8671 12.4937 11.9982C12.4926 12.1293 12.44 12.2547 12.3473 12.3474C12.2546 12.4402 12.1292 12.4927 11.9981 12.4939C11.867 12.495 11.7407 12.4446 11.6464 12.3535L8.99989 9.70704L6.35339 12.3535C6.25909 12.4446 6.13279 12.495 6.00169 12.4939C5.87059 12.4927 5.74519 12.4402 5.65248 12.3474C5.55978 12.2547 5.5072 12.1293 5.50606 11.9982C5.50492 11.8671 5.55531 11.7408 5.64639 11.6465L8.29289 9.00004L5.64639 6.35354C5.55266 6.25978 5.5 6.13262 5.5 6.00004C5.5 5.86746 5.55266 5.7403 5.64639 5.64654V5.64654Z' fill='%238997a4'/%3e%3c/svg%3e");
}

.list-checked-warning .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M13.3035 4.76425C13.5718 4.44865 14.0451 4.41027 14.3607 4.67853C14.6763 4.9468 14.7147 5.42012 14.4464 5.73572L8.07144 13.2357C7.79896 13.5563 7.31616 13.5901 7.00171 13.3105L3.62671 10.3105C3.31713 10.0354 3.28924 9.5613 3.56443 9.25172C3.83962 8.94213 4.31367 8.91424 4.62326 9.18943L7.42515 11.68L13.3035 4.76425Z' fill='%23f39568'/%3e%3c/svg%3e");
}
.list-checked-warning .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M4.20895 4.21806C4.34279 4.08416 4.52428 4.00893 4.71352 4.00893C4.90276 4.00893 5.08425 4.08416 5.21808 4.21806L8.99554 7.99878L12.773 4.21806C12.8388 4.14984 12.9176 4.09543 13.0046 4.05799C13.0917 4.02056 13.1854 4.00085 13.2801 4.00003C13.3749 3.9992 13.4689 4.01728 13.5566 4.05319C13.6443 4.08911 13.724 4.14214 13.791 4.20921C13.858 4.27628 13.911 4.35603 13.9469 4.44381C13.9827 4.53159 14.0008 4.62565 14 4.72049C13.9991 4.81533 13.9795 4.90906 13.9421 4.99621C13.9047 5.08335 13.8503 5.16217 13.7821 5.22806L10.0047 9.00878L13.7821 12.7895C13.9121 12.9242 13.9841 13.1046 13.9824 13.2919C13.9808 13.4792 13.9058 13.6584 13.7734 13.7908C13.6411 13.9232 13.4621 13.9983 13.275 14C13.0879 14.0016 12.9076 13.9296 12.773 13.7995L8.99554 10.0188L5.21808 13.7995C5.08348 13.9296 4.90321 14.0016 4.71609 14C4.52896 13.9983 4.34997 13.9232 4.21765 13.7908C4.08533 13.6584 4.01027 13.4792 4.00864 13.2919C4.00702 13.1046 4.07895 12.9242 4.20895 12.7895L7.98641 9.00878L4.20895 5.22806C4.07516 5.09411 4 4.91247 4 4.72306C4 4.53366 4.07516 4.35201 4.20895 4.21806V4.21806Z' fill='%238997a4'/%3e%3c/svg%3e");
}

.list-checked-bg-warning .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='18' height='18' rx='9' fill='%23f39568'/%3e%3cpath d='M12.0603 5.78792C12.2511 5.56349 12.5876 5.5362 12.8121 5.72697C13.0365 5.91774 13.0638 6.25432 12.873 6.47875L8.3397 11.8121C8.14594 12.04 7.80261 12.064 7.57901 11.8653L5.17901 9.73195C4.95886 9.53626 4.93903 9.19915 5.13472 8.979C5.33041 8.75885 5.66751 8.73902 5.88766 8.93471L7.88011 10.7058L12.0603 5.78792Z' fill='white'/%3e%3c/svg%3e");
}
.list-checked-bg-warning .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M18 9C18 4.02944 13.9706 0 9 0C4.02944 0 0 4.02944 0 9C0 13.9706 4.02944 18 9 18C13.9706 18 18 13.9706 18 9Z' fill='%238997a4'/%3E%3Cpath d='M5.64639 5.64654C5.74016 5.55281 5.86731 5.50015 5.99989 5.50015C6.13248 5.50015 6.25963 5.55281 6.35339 5.64654L8.99989 8.29304L11.6464 5.64654C11.6925 5.59879 11.7477 5.56069 11.8087 5.53449C11.8697 5.50829 11.9353 5.49449 12.0017 5.49392C12.0681 5.49334 12.1339 5.50599 12.1954 5.53113C12.2568 5.55627 12.3126 5.5934 12.3596 5.64034C12.4065 5.68729 12.4437 5.74312 12.4688 5.80456C12.4939 5.86601 12.5066 5.93185 12.506 5.99824C12.5054 6.06463 12.4916 6.13024 12.4654 6.19124C12.4392 6.25224 12.4011 6.30742 12.3534 6.35354L9.70689 9.00004L12.3534 11.6465C12.4445 11.7408 12.4949 11.8671 12.4937 11.9982C12.4926 12.1293 12.44 12.2547 12.3473 12.3474C12.2546 12.4402 12.1292 12.4927 11.9981 12.4939C11.867 12.495 11.7407 12.4446 11.6464 12.3535L8.99989 9.70704L6.35339 12.3535C6.25909 12.4446 6.13279 12.495 6.00169 12.4939C5.87059 12.4927 5.74519 12.4402 5.65248 12.3474C5.55978 12.2547 5.5072 12.1293 5.50606 11.9982C5.50492 11.8671 5.55531 11.7408 5.64639 11.6465L8.29289 9.00004L5.64639 6.35354C5.55266 6.25978 5.5 6.13262 5.5 6.00004C5.5 5.86746 5.55266 5.7403 5.64639 5.64654V5.64654Z' fill='white'/%3e%3c/svg%3e");
}

.list-checked-soft-bg-warning .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='18' height='18' rx='9' fill='%23f39568' fill-opacity='0.1'/%3e%3cpath d='M12.0603 5.78792C12.2511 5.56349 12.5876 5.5362 12.8121 5.72697C13.0365 5.91774 13.0638 6.25432 12.873 6.47875L8.3397 11.8121C8.14594 12.04 7.80261 12.064 7.57901 11.8653L5.17901 9.73195C4.95886 9.53626 4.93903 9.19915 5.13472 8.979C5.33041 8.75885 5.66751 8.73902 5.88766 8.93471L7.88011 10.7058L12.0603 5.78792Z' fill='%23f39568'/%3e%3c/svg%3e");
}
.list-checked-soft-bg-warning .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M18 9C18 4.02944 13.9706 0 9 0C4.02944 0 0 4.02944 0 9C0 13.9706 4.02944 18 9 18C13.9706 18 18 13.9706 18 9Z' fill='%238997a4' fill-opacity='0.1'/%3E%3Cpath d='M5.64639 5.64654C5.74016 5.55281 5.86731 5.50015 5.99989 5.50015C6.13248 5.50015 6.25963 5.55281 6.35339 5.64654L8.99989 8.29304L11.6464 5.64654C11.6925 5.59879 11.7477 5.56069 11.8087 5.53449C11.8697 5.50829 11.9353 5.49449 12.0017 5.49392C12.0681 5.49334 12.1339 5.50599 12.1954 5.53113C12.2568 5.55627 12.3126 5.5934 12.3596 5.64034C12.4065 5.68729 12.4437 5.74312 12.4688 5.80456C12.4939 5.86601 12.5066 5.93185 12.506 5.99824C12.5054 6.06463 12.4916 6.13024 12.4654 6.19124C12.4392 6.25224 12.4011 6.30742 12.3534 6.35354L9.70689 9.00004L12.3534 11.6465C12.4445 11.7408 12.4949 11.8671 12.4937 11.9982C12.4926 12.1293 12.44 12.2547 12.3473 12.3474C12.2546 12.4402 12.1292 12.4927 11.9981 12.4939C11.867 12.495 11.7407 12.4446 11.6464 12.3535L8.99989 9.70704L6.35339 12.3535C6.25909 12.4446 6.13279 12.495 6.00169 12.4939C5.87059 12.4927 5.74519 12.4402 5.65248 12.3474C5.55978 12.2547 5.5072 12.1293 5.50606 11.9982C5.50492 11.8671 5.55531 11.7408 5.64639 11.6465L8.29289 9.00004L5.64639 6.35354C5.55266 6.25978 5.5 6.13262 5.5 6.00004C5.5 5.86746 5.55266 5.7403 5.64639 5.64654V5.64654Z' fill='%238997a4'/%3e%3c/svg%3e");
}

.list-checked-danger .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M13.3035 4.76425C13.5718 4.44865 14.0451 4.41027 14.3607 4.67853C14.6763 4.9468 14.7147 5.42012 14.4464 5.73572L8.07144 13.2357C7.79896 13.5563 7.31616 13.5901 7.00171 13.3105L3.62671 10.3105C3.31713 10.0354 3.28924 9.5613 3.56443 9.25172C3.83962 8.94213 4.31367 8.91424 4.62326 9.18943L7.42515 11.68L13.3035 4.76425Z' fill='%23692340'/%3e%3c/svg%3e");
}
.list-checked-danger .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M4.20895 4.21806C4.34279 4.08416 4.52428 4.00893 4.71352 4.00893C4.90276 4.00893 5.08425 4.08416 5.21808 4.21806L8.99554 7.99878L12.773 4.21806C12.8388 4.14984 12.9176 4.09543 13.0046 4.05799C13.0917 4.02056 13.1854 4.00085 13.2801 4.00003C13.3749 3.9992 13.4689 4.01728 13.5566 4.05319C13.6443 4.08911 13.724 4.14214 13.791 4.20921C13.858 4.27628 13.911 4.35603 13.9469 4.44381C13.9827 4.53159 14.0008 4.62565 14 4.72049C13.9991 4.81533 13.9795 4.90906 13.9421 4.99621C13.9047 5.08335 13.8503 5.16217 13.7821 5.22806L10.0047 9.00878L13.7821 12.7895C13.9121 12.9242 13.9841 13.1046 13.9824 13.2919C13.9808 13.4792 13.9058 13.6584 13.7734 13.7908C13.6411 13.9232 13.4621 13.9983 13.275 14C13.0879 14.0016 12.9076 13.9296 12.773 13.7995L8.99554 10.0188L5.21808 13.7995C5.08348 13.9296 4.90321 14.0016 4.71609 14C4.52896 13.9983 4.34997 13.9232 4.21765 13.7908C4.08533 13.6584 4.01027 13.4792 4.00864 13.2919C4.00702 13.1046 4.07895 12.9242 4.20895 12.7895L7.98641 9.00878L4.20895 5.22806C4.07516 5.09411 4 4.91247 4 4.72306C4 4.53366 4.07516 4.35201 4.20895 4.21806V4.21806Z' fill='%238997a4'/%3e%3c/svg%3e");
}

.list-checked-bg-danger .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='18' height='18' rx='9' fill='%23692340'/%3e%3cpath d='M12.0603 5.78792C12.2511 5.56349 12.5876 5.5362 12.8121 5.72697C13.0365 5.91774 13.0638 6.25432 12.873 6.47875L8.3397 11.8121C8.14594 12.04 7.80261 12.064 7.57901 11.8653L5.17901 9.73195C4.95886 9.53626 4.93903 9.19915 5.13472 8.979C5.33041 8.75885 5.66751 8.73902 5.88766 8.93471L7.88011 10.7058L12.0603 5.78792Z' fill='white'/%3e%3c/svg%3e");
}
.list-checked-bg-danger .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M18 9C18 4.02944 13.9706 0 9 0C4.02944 0 0 4.02944 0 9C0 13.9706 4.02944 18 9 18C13.9706 18 18 13.9706 18 9Z' fill='%238997a4'/%3E%3Cpath d='M5.64639 5.64654C5.74016 5.55281 5.86731 5.50015 5.99989 5.50015C6.13248 5.50015 6.25963 5.55281 6.35339 5.64654L8.99989 8.29304L11.6464 5.64654C11.6925 5.59879 11.7477 5.56069 11.8087 5.53449C11.8697 5.50829 11.9353 5.49449 12.0017 5.49392C12.0681 5.49334 12.1339 5.50599 12.1954 5.53113C12.2568 5.55627 12.3126 5.5934 12.3596 5.64034C12.4065 5.68729 12.4437 5.74312 12.4688 5.80456C12.4939 5.86601 12.5066 5.93185 12.506 5.99824C12.5054 6.06463 12.4916 6.13024 12.4654 6.19124C12.4392 6.25224 12.4011 6.30742 12.3534 6.35354L9.70689 9.00004L12.3534 11.6465C12.4445 11.7408 12.4949 11.8671 12.4937 11.9982C12.4926 12.1293 12.44 12.2547 12.3473 12.3474C12.2546 12.4402 12.1292 12.4927 11.9981 12.4939C11.867 12.495 11.7407 12.4446 11.6464 12.3535L8.99989 9.70704L6.35339 12.3535C6.25909 12.4446 6.13279 12.495 6.00169 12.4939C5.87059 12.4927 5.74519 12.4402 5.65248 12.3474C5.55978 12.2547 5.5072 12.1293 5.50606 11.9982C5.50492 11.8671 5.55531 11.7408 5.64639 11.6465L8.29289 9.00004L5.64639 6.35354C5.55266 6.25978 5.5 6.13262 5.5 6.00004C5.5 5.86746 5.55266 5.7403 5.64639 5.64654V5.64654Z' fill='white'/%3e%3c/svg%3e");
}

.list-checked-soft-bg-danger .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='18' height='18' rx='9' fill='%23692340' fill-opacity='0.1'/%3e%3cpath d='M12.0603 5.78792C12.2511 5.56349 12.5876 5.5362 12.8121 5.72697C13.0365 5.91774 13.0638 6.25432 12.873 6.47875L8.3397 11.8121C8.14594 12.04 7.80261 12.064 7.57901 11.8653L5.17901 9.73195C4.95886 9.53626 4.93903 9.19915 5.13472 8.979C5.33041 8.75885 5.66751 8.73902 5.88766 8.93471L7.88011 10.7058L12.0603 5.78792Z' fill='%23692340'/%3e%3c/svg%3e");
}
.list-checked-soft-bg-danger .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M18 9C18 4.02944 13.9706 0 9 0C4.02944 0 0 4.02944 0 9C0 13.9706 4.02944 18 9 18C13.9706 18 18 13.9706 18 9Z' fill='%238997a4' fill-opacity='0.1'/%3E%3Cpath d='M5.64639 5.64654C5.74016 5.55281 5.86731 5.50015 5.99989 5.50015C6.13248 5.50015 6.25963 5.55281 6.35339 5.64654L8.99989 8.29304L11.6464 5.64654C11.6925 5.59879 11.7477 5.56069 11.8087 5.53449C11.8697 5.50829 11.9353 5.49449 12.0017 5.49392C12.0681 5.49334 12.1339 5.50599 12.1954 5.53113C12.2568 5.55627 12.3126 5.5934 12.3596 5.64034C12.4065 5.68729 12.4437 5.74312 12.4688 5.80456C12.4939 5.86601 12.5066 5.93185 12.506 5.99824C12.5054 6.06463 12.4916 6.13024 12.4654 6.19124C12.4392 6.25224 12.4011 6.30742 12.3534 6.35354L9.70689 9.00004L12.3534 11.6465C12.4445 11.7408 12.4949 11.8671 12.4937 11.9982C12.4926 12.1293 12.44 12.2547 12.3473 12.3474C12.2546 12.4402 12.1292 12.4927 11.9981 12.4939C11.867 12.495 11.7407 12.4446 11.6464 12.3535L8.99989 9.70704L6.35339 12.3535C6.25909 12.4446 6.13279 12.495 6.00169 12.4939C5.87059 12.4927 5.74519 12.4402 5.65248 12.3474C5.55978 12.2547 5.5072 12.1293 5.50606 11.9982C5.50492 11.8671 5.55531 11.7408 5.64639 11.6465L8.29289 9.00004L5.64639 6.35354C5.55266 6.25978 5.5 6.13262 5.5 6.00004C5.5 5.86746 5.55266 5.7403 5.64639 5.64654V5.64654Z' fill='%238997a4'/%3e%3c/svg%3e");
}

.list-checked-light .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M13.3035 4.76425C13.5718 4.44865 14.0451 4.41027 14.3607 4.67853C14.6763 4.9468 14.7147 5.42012 14.4464 5.73572L8.07144 13.2357C7.79896 13.5563 7.31616 13.5901 7.00171 13.3105L3.62671 10.3105C3.31713 10.0354 3.28924 9.5613 3.56443 9.25172C3.83962 8.94213 4.31367 8.91424 4.62326 9.18943L7.42515 11.68L13.3035 4.76425Z' fill='%23f8f9fa'/%3e%3c/svg%3e");
}
.list-checked-light .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M4.20895 4.21806C4.34279 4.08416 4.52428 4.00893 4.71352 4.00893C4.90276 4.00893 5.08425 4.08416 5.21808 4.21806L8.99554 7.99878L12.773 4.21806C12.8388 4.14984 12.9176 4.09543 13.0046 4.05799C13.0917 4.02056 13.1854 4.00085 13.2801 4.00003C13.3749 3.9992 13.4689 4.01728 13.5566 4.05319C13.6443 4.08911 13.724 4.14214 13.791 4.20921C13.858 4.27628 13.911 4.35603 13.9469 4.44381C13.9827 4.53159 14.0008 4.62565 14 4.72049C13.9991 4.81533 13.9795 4.90906 13.9421 4.99621C13.9047 5.08335 13.8503 5.16217 13.7821 5.22806L10.0047 9.00878L13.7821 12.7895C13.9121 12.9242 13.9841 13.1046 13.9824 13.2919C13.9808 13.4792 13.9058 13.6584 13.7734 13.7908C13.6411 13.9232 13.4621 13.9983 13.275 14C13.0879 14.0016 12.9076 13.9296 12.773 13.7995L8.99554 10.0188L5.21808 13.7995C5.08348 13.9296 4.90321 14.0016 4.71609 14C4.52896 13.9983 4.34997 13.9232 4.21765 13.7908C4.08533 13.6584 4.01027 13.4792 4.00864 13.2919C4.00702 13.1046 4.07895 12.9242 4.20895 12.7895L7.98641 9.00878L4.20895 5.22806C4.07516 5.09411 4 4.91247 4 4.72306C4 4.53366 4.07516 4.35201 4.20895 4.21806V4.21806Z' fill='%238997a4'/%3e%3c/svg%3e");
}

.list-checked-bg-light .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='18' height='18' rx='9' fill='%23f8f9fa'/%3e%3cpath d='M12.0603 5.78792C12.2511 5.56349 12.5876 5.5362 12.8121 5.72697C13.0365 5.91774 13.0638 6.25432 12.873 6.47875L8.3397 11.8121C8.14594 12.04 7.80261 12.064 7.57901 11.8653L5.17901 9.73195C4.95886 9.53626 4.93903 9.19915 5.13472 8.979C5.33041 8.75885 5.66751 8.73902 5.88766 8.93471L7.88011 10.7058L12.0603 5.78792Z' fill='white'/%3e%3c/svg%3e");
}
.list-checked-bg-light .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M18 9C18 4.02944 13.9706 0 9 0C4.02944 0 0 4.02944 0 9C0 13.9706 4.02944 18 9 18C13.9706 18 18 13.9706 18 9Z' fill='%238997a4'/%3E%3Cpath d='M5.64639 5.64654C5.74016 5.55281 5.86731 5.50015 5.99989 5.50015C6.13248 5.50015 6.25963 5.55281 6.35339 5.64654L8.99989 8.29304L11.6464 5.64654C11.6925 5.59879 11.7477 5.56069 11.8087 5.53449C11.8697 5.50829 11.9353 5.49449 12.0017 5.49392C12.0681 5.49334 12.1339 5.50599 12.1954 5.53113C12.2568 5.55627 12.3126 5.5934 12.3596 5.64034C12.4065 5.68729 12.4437 5.74312 12.4688 5.80456C12.4939 5.86601 12.5066 5.93185 12.506 5.99824C12.5054 6.06463 12.4916 6.13024 12.4654 6.19124C12.4392 6.25224 12.4011 6.30742 12.3534 6.35354L9.70689 9.00004L12.3534 11.6465C12.4445 11.7408 12.4949 11.8671 12.4937 11.9982C12.4926 12.1293 12.44 12.2547 12.3473 12.3474C12.2546 12.4402 12.1292 12.4927 11.9981 12.4939C11.867 12.495 11.7407 12.4446 11.6464 12.3535L8.99989 9.70704L6.35339 12.3535C6.25909 12.4446 6.13279 12.495 6.00169 12.4939C5.87059 12.4927 5.74519 12.4402 5.65248 12.3474C5.55978 12.2547 5.5072 12.1293 5.50606 11.9982C5.50492 11.8671 5.55531 11.7408 5.64639 11.6465L8.29289 9.00004L5.64639 6.35354C5.55266 6.25978 5.5 6.13262 5.5 6.00004C5.5 5.86746 5.55266 5.7403 5.64639 5.64654V5.64654Z' fill='white'/%3e%3c/svg%3e");
}

.list-checked-soft-bg-light .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='18' height='18' rx='9' fill='%23f8f9fa' fill-opacity='0.1'/%3e%3cpath d='M12.0603 5.78792C12.2511 5.56349 12.5876 5.5362 12.8121 5.72697C13.0365 5.91774 13.0638 6.25432 12.873 6.47875L8.3397 11.8121C8.14594 12.04 7.80261 12.064 7.57901 11.8653L5.17901 9.73195C4.95886 9.53626 4.93903 9.19915 5.13472 8.979C5.33041 8.75885 5.66751 8.73902 5.88766 8.93471L7.88011 10.7058L12.0603 5.78792Z' fill='%23f8f9fa'/%3e%3c/svg%3e");
}
.list-checked-soft-bg-light .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M18 9C18 4.02944 13.9706 0 9 0C4.02944 0 0 4.02944 0 9C0 13.9706 4.02944 18 9 18C13.9706 18 18 13.9706 18 9Z' fill='%238997a4' fill-opacity='0.1'/%3E%3Cpath d='M5.64639 5.64654C5.74016 5.55281 5.86731 5.50015 5.99989 5.50015C6.13248 5.50015 6.25963 5.55281 6.35339 5.64654L8.99989 8.29304L11.6464 5.64654C11.6925 5.59879 11.7477 5.56069 11.8087 5.53449C11.8697 5.50829 11.9353 5.49449 12.0017 5.49392C12.0681 5.49334 12.1339 5.50599 12.1954 5.53113C12.2568 5.55627 12.3126 5.5934 12.3596 5.64034C12.4065 5.68729 12.4437 5.74312 12.4688 5.80456C12.4939 5.86601 12.5066 5.93185 12.506 5.99824C12.5054 6.06463 12.4916 6.13024 12.4654 6.19124C12.4392 6.25224 12.4011 6.30742 12.3534 6.35354L9.70689 9.00004L12.3534 11.6465C12.4445 11.7408 12.4949 11.8671 12.4937 11.9982C12.4926 12.1293 12.44 12.2547 12.3473 12.3474C12.2546 12.4402 12.1292 12.4927 11.9981 12.4939C11.867 12.495 11.7407 12.4446 11.6464 12.3535L8.99989 9.70704L6.35339 12.3535C6.25909 12.4446 6.13279 12.495 6.00169 12.4939C5.87059 12.4927 5.74519 12.4402 5.65248 12.3474C5.55978 12.2547 5.5072 12.1293 5.50606 11.9982C5.50492 11.8671 5.55531 11.7408 5.64639 11.6465L8.29289 9.00004L5.64639 6.35354C5.55266 6.25978 5.5 6.13262 5.5 6.00004C5.5 5.86746 5.55266 5.7403 5.64639 5.64654V5.64654Z' fill='%238997a4'/%3e%3c/svg%3e");
}

.list-checked-dark .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M13.3035 4.76425C13.5718 4.44865 14.0451 4.41027 14.3607 4.67853C14.6763 4.9468 14.7147 5.42012 14.4464 5.73572L8.07144 13.2357C7.79896 13.5563 7.31616 13.5901 7.00171 13.3105L3.62671 10.3105C3.31713 10.0354 3.28924 9.5613 3.56443 9.25172C3.83962 8.94213 4.31367 8.91424 4.62326 9.18943L7.42515 11.68L13.3035 4.76425Z' fill='%232d374b'/%3e%3c/svg%3e");
}
.list-checked-dark .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M4.20895 4.21806C4.34279 4.08416 4.52428 4.00893 4.71352 4.00893C4.90276 4.00893 5.08425 4.08416 5.21808 4.21806L8.99554 7.99878L12.773 4.21806C12.8388 4.14984 12.9176 4.09543 13.0046 4.05799C13.0917 4.02056 13.1854 4.00085 13.2801 4.00003C13.3749 3.9992 13.4689 4.01728 13.5566 4.05319C13.6443 4.08911 13.724 4.14214 13.791 4.20921C13.858 4.27628 13.911 4.35603 13.9469 4.44381C13.9827 4.53159 14.0008 4.62565 14 4.72049C13.9991 4.81533 13.9795 4.90906 13.9421 4.99621C13.9047 5.08335 13.8503 5.16217 13.7821 5.22806L10.0047 9.00878L13.7821 12.7895C13.9121 12.9242 13.9841 13.1046 13.9824 13.2919C13.9808 13.4792 13.9058 13.6584 13.7734 13.7908C13.6411 13.9232 13.4621 13.9983 13.275 14C13.0879 14.0016 12.9076 13.9296 12.773 13.7995L8.99554 10.0188L5.21808 13.7995C5.08348 13.9296 4.90321 14.0016 4.71609 14C4.52896 13.9983 4.34997 13.9232 4.21765 13.7908C4.08533 13.6584 4.01027 13.4792 4.00864 13.2919C4.00702 13.1046 4.07895 12.9242 4.20895 12.7895L7.98641 9.00878L4.20895 5.22806C4.07516 5.09411 4 4.91247 4 4.72306C4 4.53366 4.07516 4.35201 4.20895 4.21806V4.21806Z' fill='%238997a4'/%3e%3c/svg%3e");
}

.list-checked-bg-dark .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='18' height='18' rx='9' fill='%232d374b'/%3e%3cpath d='M12.0603 5.78792C12.2511 5.56349 12.5876 5.5362 12.8121 5.72697C13.0365 5.91774 13.0638 6.25432 12.873 6.47875L8.3397 11.8121C8.14594 12.04 7.80261 12.064 7.57901 11.8653L5.17901 9.73195C4.95886 9.53626 4.93903 9.19915 5.13472 8.979C5.33041 8.75885 5.66751 8.73902 5.88766 8.93471L7.88011 10.7058L12.0603 5.78792Z' fill='white'/%3e%3c/svg%3e");
}
.list-checked-bg-dark .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M18 9C18 4.02944 13.9706 0 9 0C4.02944 0 0 4.02944 0 9C0 13.9706 4.02944 18 9 18C13.9706 18 18 13.9706 18 9Z' fill='%238997a4'/%3E%3Cpath d='M5.64639 5.64654C5.74016 5.55281 5.86731 5.50015 5.99989 5.50015C6.13248 5.50015 6.25963 5.55281 6.35339 5.64654L8.99989 8.29304L11.6464 5.64654C11.6925 5.59879 11.7477 5.56069 11.8087 5.53449C11.8697 5.50829 11.9353 5.49449 12.0017 5.49392C12.0681 5.49334 12.1339 5.50599 12.1954 5.53113C12.2568 5.55627 12.3126 5.5934 12.3596 5.64034C12.4065 5.68729 12.4437 5.74312 12.4688 5.80456C12.4939 5.86601 12.5066 5.93185 12.506 5.99824C12.5054 6.06463 12.4916 6.13024 12.4654 6.19124C12.4392 6.25224 12.4011 6.30742 12.3534 6.35354L9.70689 9.00004L12.3534 11.6465C12.4445 11.7408 12.4949 11.8671 12.4937 11.9982C12.4926 12.1293 12.44 12.2547 12.3473 12.3474C12.2546 12.4402 12.1292 12.4927 11.9981 12.4939C11.867 12.495 11.7407 12.4446 11.6464 12.3535L8.99989 9.70704L6.35339 12.3535C6.25909 12.4446 6.13279 12.495 6.00169 12.4939C5.87059 12.4927 5.74519 12.4402 5.65248 12.3474C5.55978 12.2547 5.5072 12.1293 5.50606 11.9982C5.50492 11.8671 5.55531 11.7408 5.64639 11.6465L8.29289 9.00004L5.64639 6.35354C5.55266 6.25978 5.5 6.13262 5.5 6.00004C5.5 5.86746 5.55266 5.7403 5.64639 5.64654V5.64654Z' fill='white'/%3e%3c/svg%3e");
}

.list-checked-soft-bg-dark .list-checked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='18' height='18' rx='9' fill='%232d374b' fill-opacity='0.1'/%3e%3cpath d='M12.0603 5.78792C12.2511 5.56349 12.5876 5.5362 12.8121 5.72697C13.0365 5.91774 13.0638 6.25432 12.873 6.47875L8.3397 11.8121C8.14594 12.04 7.80261 12.064 7.57901 11.8653L5.17901 9.73195C4.95886 9.53626 4.93903 9.19915 5.13472 8.979C5.33041 8.75885 5.66751 8.73902 5.88766 8.93471L7.88011 10.7058L12.0603 5.78792Z' fill='%232d374b'/%3e%3c/svg%3e");
}
.list-checked-soft-bg-dark .list-unchecked-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='18' height='18' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M18 9C18 4.02944 13.9706 0 9 0C4.02944 0 0 4.02944 0 9C0 13.9706 4.02944 18 9 18C13.9706 18 18 13.9706 18 9Z' fill='%238997a4' fill-opacity='0.1'/%3E%3Cpath d='M5.64639 5.64654C5.74016 5.55281 5.86731 5.50015 5.99989 5.50015C6.13248 5.50015 6.25963 5.55281 6.35339 5.64654L8.99989 8.29304L11.6464 5.64654C11.6925 5.59879 11.7477 5.56069 11.8087 5.53449C11.8697 5.50829 11.9353 5.49449 12.0017 5.49392C12.0681 5.49334 12.1339 5.50599 12.1954 5.53113C12.2568 5.55627 12.3126 5.5934 12.3596 5.64034C12.4065 5.68729 12.4437 5.74312 12.4688 5.80456C12.4939 5.86601 12.5066 5.93185 12.506 5.99824C12.5054 6.06463 12.4916 6.13024 12.4654 6.19124C12.4392 6.25224 12.4011 6.30742 12.3534 6.35354L9.70689 9.00004L12.3534 11.6465C12.4445 11.7408 12.4949 11.8671 12.4937 11.9982C12.4926 12.1293 12.44 12.2547 12.3473 12.3474C12.2546 12.4402 12.1292 12.4927 11.9981 12.4939C11.867 12.495 11.7407 12.4446 11.6464 12.3535L8.99989 9.70704L6.35339 12.3535C6.25909 12.4446 6.13279 12.495 6.00169 12.4939C5.87059 12.4927 5.74519 12.4402 5.65248 12.3474C5.55978 12.2547 5.5072 12.1293 5.50606 11.9982C5.50492 11.8671 5.55531 11.7408 5.64639 11.6465L8.29289 9.00004L5.64639 6.35354C5.55266 6.25978 5.5 6.13262 5.5 6.00004C5.5 5.86746 5.55266 5.7403 5.64639 5.64654V5.64654Z' fill='%238997a4'/%3e%3c/svg%3e");
}

.list-checked-sm .list-checked-item,
.list-checked-sm .list-unchecked-item {
  padding-left: 1.5rem;
}
.list-checked-sm .list-checked-item::before,
.list-checked-sm .list-unchecked-item::before {
  width: 1rem;
  height: 1rem;
  background-size: 1rem 1rem;
  margin-top: 0.3125rem;
}
.list-checked-sm[class*=list-checked-bg-] .list-checked-item::before,
.list-checked-sm[class*=list-checked-bg-] .list-unchecked-item::before, .list-checked-sm[class*=list-checked-soft-bg-] .list-checked-item::before,
.list-checked-sm[class*=list-checked-soft-bg-] .list-unchecked-item::before {
  margin-top: 0.25rem;
}

.list-checked-lg .list-checked-item,
.list-checked-lg .list-unchecked-item {
  padding-left: 2.5rem;
}
.list-checked-lg .list-checked-item:not(:last-child),
.list-checked-lg .list-unchecked-item:not(:last-child) {
  margin-bottom: 1.25rem;
}
.list-checked-lg .list-checked-item::before,
.list-checked-lg .list-unchecked-item::before {
  width: 1.5rem;
  height: 1.5rem;
  background-size: 1.5rem 1.5rem;
  margin-top: 0;
}
.list-checked-lg[class*=list-checked-bg-] .list-checked-item::before,
.list-checked-lg[class*=list-checked-bg-] .list-unchecked-item::before, .list-checked-lg[class*=list-checked-soft-bg-] .list-checked-item::before,
.list-checked-lg[class*=list-checked-soft-bg-] .list-unchecked-item::before {
  margin-top: -0.0625rem;
}

/*------------------------------------
  List Comment
------------------------------------*/
.list-comment {
  padding-left: 0;
  list-style: none;
  margin-bottom: 0;
}
.list-comment:first-child {
  margin-top: -2.5rem;
}

.list-comment-item {
  margin-top: 2.5rem;
}
.list-comment-item .list-comment .list-comment-item {
  padding-left: 1rem;
  border-left: 0.1875rem solid rgba(220, 224, 229, 0.6);
}

/*------------------------------------
  List Equal Height
------------------------------------*/
.list-equal-height {
  position: relative;
  display: grid;
  overflow: hidden;
  list-style: none;
  padding-left: 0;
  margin-bottom: 0;
}

.list-equal-height-2-cols {
  grid-template-columns: 50% 50%;
}

.list-equal-height-3-cols {
  grid-template-columns: 33% 33% 33%;
}

.list-equal-height-4-cols {
  grid-template-columns: 25% 25% 25% 25%;
}

.list-equal-height-item {
  position: relative;
  display: flex;
  flex-direction: column;
  padding: 2rem 2rem;
}

.list-equal-height-item::before,
.list-equal-height-item::after {
  position: absolute;
  left: 0;
  bottom: 0;
  border: 0 solid rgba(220, 224, 229, 0.6);
  content: "";
}

.list-equal-height-item::before {
  top: 0;
  border-right-width: 0.125rem;
  margin-left: -0.125rem;
}

.list-equal-height-item::after {
  right: 0;
  border-bottom-width: 0.125rem;
  margin-bottom: -0.125rem;
}

@media (max-width: 991.98px) {
  .list-equal-height-4-cols {
    grid-template-columns: 33% 33% 33%;
  }
}
@media (max-width: 767.98px) {
  .list-equal-height-3-cols,
.list-equal-height-4-cols {
    grid-template-columns: 50% 50%;
  }
}
@media (max-width: 575.98px) {
  .list-equal-height {
    grid-template-columns: 100%;
  }
  .list-equal-height-item {
    padding: 1rem 0;
    margin-bottom: 1rem;
  }
  .list-equal-height-item:last-child {
    padding-bottom: 0;
    margin-bottom: 0;
  }
  .list-equal-height-item:last-child::after {
    display: none;
  }
}
/*------------------------------------
  List Padding
------------------------------------*/
.list-py-1 > li:not(:first-child) {
  padding-top: 0.3125rem;
}
.list-py-1 > li:not(:last-child) {
  padding-bottom: 0.3125rem;
}

.list-py-2 > li:not(:first-child) {
  padding-top: 0.5rem;
}
.list-py-2 > li:not(:last-child) {
  padding-bottom: 0.5rem;
}

.list-py-3 > li:not(:first-child) {
  padding-top: 1rem;
}
.list-py-3 > li:not(:last-child) {
  padding-bottom: 1rem;
}

.list-px-1 > li:not(:first-child) {
  padding-left: 0.25rem;
}
.list-px-1 > li:not(:last-child) {
  padding-right: 0.25rem;
}

.list-px-2 > li:not(:first-child) {
  padding-left: 0.5rem;
}
.list-px-2 > li:not(:last-child) {
  padding-right: 0.5rem;
}

.list-px-3 > li:not(:first-child) {
  padding-left: 1rem;
}
.list-px-3 > li:not(:last-child) {
  padding-right: 1rem;
}

/*------------------------------------
  List Pointer
------------------------------------*/
.list-pointer {
  padding-left: 0;
  list-style: none;
}

.list-pointer-item {
  position: relative;
  color: #51596C;
  padding-left: 1.75rem;
}
.list-pointer-item:not(:last-child) {
  margin-bottom: 0.5rem;
}
.list-pointer-item::before {
  position: absolute;
  top: 0;
  left: 0;
  width: 1.25rem;
  height: 1.25rem;
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3e%3cpath fill='%2351596C' d='M15.78,11.28a.75.75,0,0,1,.22.53v.38a.77.77,0,0,1-.22.53l-5.14,5.13a.5.5,0,0,1-.71,0l-.71-.71a.49.49,0,0,1,0-.7L13.67,12,9.22,7.56a.5.5,0,0,1,0-.71l.71-.7a.5.5,0,0,1,.71,0Z'/%3e%3c/svg%3e");
  background-repeat: no-repeat;
  background-position: right center;
  background-size: 1.25rem 1.25rem;
  content: "";
  margin-top: 0.1875rem;
}
.list-pointer-item[hover]:hover {
  color: #0abf53;
}

[class*=list-pointer-bg-] .list-pointer-item::before,
[class*=list-pointer-soft-bg-] .list-pointer-item::before {
  margin-top: 0.25rem;
}

.list-pointer-primary .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3e%3cpath fill='%230abf53' d='M15.78,11.28a.75.75,0,0,1,.22.53v.38a.77.77,0,0,1-.22.53l-5.14,5.13a.5.5,0,0,1-.71,0l-.71-.71a.49.49,0,0,1,0-.7L13.67,12,9.22,7.56a.5.5,0,0,1,0-.71l.71-.7a.5.5,0,0,1,.71,0Z'/%3e%3c/svg%3e");
}

.list-pointer-bg-primary .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='24' height='24' rx='12' fill='%230abf53'/%3e%3cpath d='M15.78 11.28C15.9207 11.4205 15.9998 11.6112 16 11.81V12.19C15.9977 12.3884 15.9189 12.5783 15.78 12.72L10.64 17.85C10.5935 17.8969 10.5382 17.9341 10.4773 17.9595C10.4164 17.9848 10.351 17.9979 10.285 17.9979C10.219 17.9979 10.1536 17.9848 10.0927 17.9595C10.0318 17.9341 9.97648 17.8969 9.93 17.85L9.22 17.14C9.17344 17.0944 9.13644 17.0399 9.11119 16.9798C9.08594 16.9197 9.07293 16.8552 9.07293 16.79C9.07293 16.7248 9.08594 16.6603 9.11119 16.6002C9.13644 16.5401 9.17344 16.4856 9.22 16.44L13.67 12L9.22 7.56C9.17314 7.51352 9.13594 7.45822 9.11055 7.39729C9.08517 7.33636 9.0721 7.27101 9.0721 7.205C9.0721 7.139 9.08517 7.07365 9.11055 7.01272C9.13594 6.95179 9.17314 6.89649 9.22 6.85L9.93 6.15C9.97648 6.10314 10.0318 6.06594 10.0927 6.04056C10.1536 6.01517 10.219 6.00211 10.285 6.00211C10.351 6.00211 10.4164 6.01517 10.4773 6.04056C10.5382 6.06594 10.5935 6.10314 10.64 6.15L15.78 11.28Z' fill='white'/%3e%3c/svg%3e");
}

.list-pointer-soft-bg-primary .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%230abf53' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='24' height='24' rx='12' fill='%230abf53' fill-opacity='0.1'/%3e%3cpath d='M15.78 11.28C15.9207 11.4205 15.9998 11.6112 16 11.81V12.19C15.9977 12.3884 15.9189 12.5783 15.78 12.72L10.64 17.85C10.5935 17.8969 10.5382 17.9341 10.4773 17.9595C10.4164 17.9848 10.351 17.9979 10.285 17.9979C10.219 17.9979 10.1536 17.9848 10.0927 17.9595C10.0318 17.9341 9.97648 17.8969 9.93 17.85L9.22 17.14C9.17344 17.0944 9.13644 17.0399 9.11119 16.9798C9.08594 16.9197 9.07293 16.8552 9.07293 16.79C9.07293 16.7248 9.08594 16.6603 9.11119 16.6002C9.13644 16.5401 9.17344 16.4856 9.22 16.44L13.67 12L9.22 7.56C9.17314 7.51352 9.13594 7.45822 9.11055 7.39729C9.08517 7.33636 9.0721 7.27101 9.0721 7.205C9.0721 7.139 9.08517 7.07365 9.11055 7.01272C9.13594 6.95179 9.17314 6.89649 9.22 6.85L9.93 6.15C9.97648 6.10314 10.0318 6.06594 10.0927 6.04056C10.1536 6.01517 10.219 6.00211 10.285 6.00211C10.351 6.00211 10.4164 6.01517 10.4773 6.04056C10.5382 6.06594 10.5935 6.10314 10.64 6.15L15.78 11.28Z' fill='%230abf53'/%3e%3c/svg%3e");
}

.list-pointer-secondary .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3e%3cpath fill='%2351596c' d='M15.78,11.28a.75.75,0,0,1,.22.53v.38a.77.77,0,0,1-.22.53l-5.14,5.13a.5.5,0,0,1-.71,0l-.71-.71a.49.49,0,0,1,0-.7L13.67,12,9.22,7.56a.5.5,0,0,1,0-.71l.71-.7a.5.5,0,0,1,.71,0Z'/%3e%3c/svg%3e");
}

.list-pointer-bg-secondary .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='24' height='24' rx='12' fill='%2351596c'/%3e%3cpath d='M15.78 11.28C15.9207 11.4205 15.9998 11.6112 16 11.81V12.19C15.9977 12.3884 15.9189 12.5783 15.78 12.72L10.64 17.85C10.5935 17.8969 10.5382 17.9341 10.4773 17.9595C10.4164 17.9848 10.351 17.9979 10.285 17.9979C10.219 17.9979 10.1536 17.9848 10.0927 17.9595C10.0318 17.9341 9.97648 17.8969 9.93 17.85L9.22 17.14C9.17344 17.0944 9.13644 17.0399 9.11119 16.9798C9.08594 16.9197 9.07293 16.8552 9.07293 16.79C9.07293 16.7248 9.08594 16.6603 9.11119 16.6002C9.13644 16.5401 9.17344 16.4856 9.22 16.44L13.67 12L9.22 7.56C9.17314 7.51352 9.13594 7.45822 9.11055 7.39729C9.08517 7.33636 9.0721 7.27101 9.0721 7.205C9.0721 7.139 9.08517 7.07365 9.11055 7.01272C9.13594 6.95179 9.17314 6.89649 9.22 6.85L9.93 6.15C9.97648 6.10314 10.0318 6.06594 10.0927 6.04056C10.1536 6.01517 10.219 6.00211 10.285 6.00211C10.351 6.00211 10.4164 6.01517 10.4773 6.04056C10.5382 6.06594 10.5935 6.10314 10.64 6.15L15.78 11.28Z' fill='white'/%3e%3c/svg%3e");
}

.list-pointer-soft-bg-secondary .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%2351596c' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='24' height='24' rx='12' fill='%2351596c' fill-opacity='0.1'/%3e%3cpath d='M15.78 11.28C15.9207 11.4205 15.9998 11.6112 16 11.81V12.19C15.9977 12.3884 15.9189 12.5783 15.78 12.72L10.64 17.85C10.5935 17.8969 10.5382 17.9341 10.4773 17.9595C10.4164 17.9848 10.351 17.9979 10.285 17.9979C10.219 17.9979 10.1536 17.9848 10.0927 17.9595C10.0318 17.9341 9.97648 17.8969 9.93 17.85L9.22 17.14C9.17344 17.0944 9.13644 17.0399 9.11119 16.9798C9.08594 16.9197 9.07293 16.8552 9.07293 16.79C9.07293 16.7248 9.08594 16.6603 9.11119 16.6002C9.13644 16.5401 9.17344 16.4856 9.22 16.44L13.67 12L9.22 7.56C9.17314 7.51352 9.13594 7.45822 9.11055 7.39729C9.08517 7.33636 9.0721 7.27101 9.0721 7.205C9.0721 7.139 9.08517 7.07365 9.11055 7.01272C9.13594 6.95179 9.17314 6.89649 9.22 6.85L9.93 6.15C9.97648 6.10314 10.0318 6.06594 10.0927 6.04056C10.1536 6.01517 10.219 6.00211 10.285 6.00211C10.351 6.00211 10.4164 6.01517 10.4773 6.04056C10.5382 6.06594 10.5935 6.10314 10.64 6.15L15.78 11.28Z' fill='%2351596c'/%3e%3c/svg%3e");
}

.list-pointer-success .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3e%3cpath fill='%23077c76' d='M15.78,11.28a.75.75,0,0,1,.22.53v.38a.77.77,0,0,1-.22.53l-5.14,5.13a.5.5,0,0,1-.71,0l-.71-.71a.49.49,0,0,1,0-.7L13.67,12,9.22,7.56a.5.5,0,0,1,0-.71l.71-.7a.5.5,0,0,1,.71,0Z'/%3e%3c/svg%3e");
}

.list-pointer-bg-success .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='24' height='24' rx='12' fill='%23077c76'/%3e%3cpath d='M15.78 11.28C15.9207 11.4205 15.9998 11.6112 16 11.81V12.19C15.9977 12.3884 15.9189 12.5783 15.78 12.72L10.64 17.85C10.5935 17.8969 10.5382 17.9341 10.4773 17.9595C10.4164 17.9848 10.351 17.9979 10.285 17.9979C10.219 17.9979 10.1536 17.9848 10.0927 17.9595C10.0318 17.9341 9.97648 17.8969 9.93 17.85L9.22 17.14C9.17344 17.0944 9.13644 17.0399 9.11119 16.9798C9.08594 16.9197 9.07293 16.8552 9.07293 16.79C9.07293 16.7248 9.08594 16.6603 9.11119 16.6002C9.13644 16.5401 9.17344 16.4856 9.22 16.44L13.67 12L9.22 7.56C9.17314 7.51352 9.13594 7.45822 9.11055 7.39729C9.08517 7.33636 9.0721 7.27101 9.0721 7.205C9.0721 7.139 9.08517 7.07365 9.11055 7.01272C9.13594 6.95179 9.17314 6.89649 9.22 6.85L9.93 6.15C9.97648 6.10314 10.0318 6.06594 10.0927 6.04056C10.1536 6.01517 10.219 6.00211 10.285 6.00211C10.351 6.00211 10.4164 6.01517 10.4773 6.04056C10.5382 6.06594 10.5935 6.10314 10.64 6.15L15.78 11.28Z' fill='white'/%3e%3c/svg%3e");
}

.list-pointer-soft-bg-success .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23077c76' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='24' height='24' rx='12' fill='%23077c76' fill-opacity='0.1'/%3e%3cpath d='M15.78 11.28C15.9207 11.4205 15.9998 11.6112 16 11.81V12.19C15.9977 12.3884 15.9189 12.5783 15.78 12.72L10.64 17.85C10.5935 17.8969 10.5382 17.9341 10.4773 17.9595C10.4164 17.9848 10.351 17.9979 10.285 17.9979C10.219 17.9979 10.1536 17.9848 10.0927 17.9595C10.0318 17.9341 9.97648 17.8969 9.93 17.85L9.22 17.14C9.17344 17.0944 9.13644 17.0399 9.11119 16.9798C9.08594 16.9197 9.07293 16.8552 9.07293 16.79C9.07293 16.7248 9.08594 16.6603 9.11119 16.6002C9.13644 16.5401 9.17344 16.4856 9.22 16.44L13.67 12L9.22 7.56C9.17314 7.51352 9.13594 7.45822 9.11055 7.39729C9.08517 7.33636 9.0721 7.27101 9.0721 7.205C9.0721 7.139 9.08517 7.07365 9.11055 7.01272C9.13594 6.95179 9.17314 6.89649 9.22 6.85L9.93 6.15C9.97648 6.10314 10.0318 6.06594 10.0927 6.04056C10.1536 6.01517 10.219 6.00211 10.285 6.00211C10.351 6.00211 10.4164 6.01517 10.4773 6.04056C10.5382 6.06594 10.5935 6.10314 10.64 6.15L15.78 11.28Z' fill='%23077c76'/%3e%3c/svg%3e");
}

.list-pointer-info .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3e%3cpath fill='%23334ac0' d='M15.78,11.28a.75.75,0,0,1,.22.53v.38a.77.77,0,0,1-.22.53l-5.14,5.13a.5.5,0,0,1-.71,0l-.71-.71a.49.49,0,0,1,0-.7L13.67,12,9.22,7.56a.5.5,0,0,1,0-.71l.71-.7a.5.5,0,0,1,.71,0Z'/%3e%3c/svg%3e");
}

.list-pointer-bg-info .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='24' height='24' rx='12' fill='%23334ac0'/%3e%3cpath d='M15.78 11.28C15.9207 11.4205 15.9998 11.6112 16 11.81V12.19C15.9977 12.3884 15.9189 12.5783 15.78 12.72L10.64 17.85C10.5935 17.8969 10.5382 17.9341 10.4773 17.9595C10.4164 17.9848 10.351 17.9979 10.285 17.9979C10.219 17.9979 10.1536 17.9848 10.0927 17.9595C10.0318 17.9341 9.97648 17.8969 9.93 17.85L9.22 17.14C9.17344 17.0944 9.13644 17.0399 9.11119 16.9798C9.08594 16.9197 9.07293 16.8552 9.07293 16.79C9.07293 16.7248 9.08594 16.6603 9.11119 16.6002C9.13644 16.5401 9.17344 16.4856 9.22 16.44L13.67 12L9.22 7.56C9.17314 7.51352 9.13594 7.45822 9.11055 7.39729C9.08517 7.33636 9.0721 7.27101 9.0721 7.205C9.0721 7.139 9.08517 7.07365 9.11055 7.01272C9.13594 6.95179 9.17314 6.89649 9.22 6.85L9.93 6.15C9.97648 6.10314 10.0318 6.06594 10.0927 6.04056C10.1536 6.01517 10.219 6.00211 10.285 6.00211C10.351 6.00211 10.4164 6.01517 10.4773 6.04056C10.5382 6.06594 10.5935 6.10314 10.64 6.15L15.78 11.28Z' fill='white'/%3e%3c/svg%3e");
}

.list-pointer-soft-bg-info .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23334ac0' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='24' height='24' rx='12' fill='%23334ac0' fill-opacity='0.1'/%3e%3cpath d='M15.78 11.28C15.9207 11.4205 15.9998 11.6112 16 11.81V12.19C15.9977 12.3884 15.9189 12.5783 15.78 12.72L10.64 17.85C10.5935 17.8969 10.5382 17.9341 10.4773 17.9595C10.4164 17.9848 10.351 17.9979 10.285 17.9979C10.219 17.9979 10.1536 17.9848 10.0927 17.9595C10.0318 17.9341 9.97648 17.8969 9.93 17.85L9.22 17.14C9.17344 17.0944 9.13644 17.0399 9.11119 16.9798C9.08594 16.9197 9.07293 16.8552 9.07293 16.79C9.07293 16.7248 9.08594 16.6603 9.11119 16.6002C9.13644 16.5401 9.17344 16.4856 9.22 16.44L13.67 12L9.22 7.56C9.17314 7.51352 9.13594 7.45822 9.11055 7.39729C9.08517 7.33636 9.0721 7.27101 9.0721 7.205C9.0721 7.139 9.08517 7.07365 9.11055 7.01272C9.13594 6.95179 9.17314 6.89649 9.22 6.85L9.93 6.15C9.97648 6.10314 10.0318 6.06594 10.0927 6.04056C10.1536 6.01517 10.219 6.00211 10.285 6.00211C10.351 6.00211 10.4164 6.01517 10.4773 6.04056C10.5382 6.06594 10.5935 6.10314 10.64 6.15L15.78 11.28Z' fill='%23334ac0'/%3e%3c/svg%3e");
}

.list-pointer-warning .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3e%3cpath fill='%23f39568' d='M15.78,11.28a.75.75,0,0,1,.22.53v.38a.77.77,0,0,1-.22.53l-5.14,5.13a.5.5,0,0,1-.71,0l-.71-.71a.49.49,0,0,1,0-.7L13.67,12,9.22,7.56a.5.5,0,0,1,0-.71l.71-.7a.5.5,0,0,1,.71,0Z'/%3e%3c/svg%3e");
}

.list-pointer-bg-warning .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='24' height='24' rx='12' fill='%23f39568'/%3e%3cpath d='M15.78 11.28C15.9207 11.4205 15.9998 11.6112 16 11.81V12.19C15.9977 12.3884 15.9189 12.5783 15.78 12.72L10.64 17.85C10.5935 17.8969 10.5382 17.9341 10.4773 17.9595C10.4164 17.9848 10.351 17.9979 10.285 17.9979C10.219 17.9979 10.1536 17.9848 10.0927 17.9595C10.0318 17.9341 9.97648 17.8969 9.93 17.85L9.22 17.14C9.17344 17.0944 9.13644 17.0399 9.11119 16.9798C9.08594 16.9197 9.07293 16.8552 9.07293 16.79C9.07293 16.7248 9.08594 16.6603 9.11119 16.6002C9.13644 16.5401 9.17344 16.4856 9.22 16.44L13.67 12L9.22 7.56C9.17314 7.51352 9.13594 7.45822 9.11055 7.39729C9.08517 7.33636 9.0721 7.27101 9.0721 7.205C9.0721 7.139 9.08517 7.07365 9.11055 7.01272C9.13594 6.95179 9.17314 6.89649 9.22 6.85L9.93 6.15C9.97648 6.10314 10.0318 6.06594 10.0927 6.04056C10.1536 6.01517 10.219 6.00211 10.285 6.00211C10.351 6.00211 10.4164 6.01517 10.4773 6.04056C10.5382 6.06594 10.5935 6.10314 10.64 6.15L15.78 11.28Z' fill='%23000'/%3e%3c/svg%3e");
}

.list-pointer-soft-bg-warning .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23f39568' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='24' height='24' rx='12' fill='%23f39568' fill-opacity='0.1'/%3e%3cpath d='M15.78 11.28C15.9207 11.4205 15.9998 11.6112 16 11.81V12.19C15.9977 12.3884 15.9189 12.5783 15.78 12.72L10.64 17.85C10.5935 17.8969 10.5382 17.9341 10.4773 17.9595C10.4164 17.9848 10.351 17.9979 10.285 17.9979C10.219 17.9979 10.1536 17.9848 10.0927 17.9595C10.0318 17.9341 9.97648 17.8969 9.93 17.85L9.22 17.14C9.17344 17.0944 9.13644 17.0399 9.11119 16.9798C9.08594 16.9197 9.07293 16.8552 9.07293 16.79C9.07293 16.7248 9.08594 16.6603 9.11119 16.6002C9.13644 16.5401 9.17344 16.4856 9.22 16.44L13.67 12L9.22 7.56C9.17314 7.51352 9.13594 7.45822 9.11055 7.39729C9.08517 7.33636 9.0721 7.27101 9.0721 7.205C9.0721 7.139 9.08517 7.07365 9.11055 7.01272C9.13594 6.95179 9.17314 6.89649 9.22 6.85L9.93 6.15C9.97648 6.10314 10.0318 6.06594 10.0927 6.04056C10.1536 6.01517 10.219 6.00211 10.285 6.00211C10.351 6.00211 10.4164 6.01517 10.4773 6.04056C10.5382 6.06594 10.5935 6.10314 10.64 6.15L15.78 11.28Z' fill='%23f39568'/%3e%3c/svg%3e");
}

.list-pointer-danger .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3e%3cpath fill='%23692340' d='M15.78,11.28a.75.75,0,0,1,.22.53v.38a.77.77,0,0,1-.22.53l-5.14,5.13a.5.5,0,0,1-.71,0l-.71-.71a.49.49,0,0,1,0-.7L13.67,12,9.22,7.56a.5.5,0,0,1,0-.71l.71-.7a.5.5,0,0,1,.71,0Z'/%3e%3c/svg%3e");
}

.list-pointer-bg-danger .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='24' height='24' rx='12' fill='%23692340'/%3e%3cpath d='M15.78 11.28C15.9207 11.4205 15.9998 11.6112 16 11.81V12.19C15.9977 12.3884 15.9189 12.5783 15.78 12.72L10.64 17.85C10.5935 17.8969 10.5382 17.9341 10.4773 17.9595C10.4164 17.9848 10.351 17.9979 10.285 17.9979C10.219 17.9979 10.1536 17.9848 10.0927 17.9595C10.0318 17.9341 9.97648 17.8969 9.93 17.85L9.22 17.14C9.17344 17.0944 9.13644 17.0399 9.11119 16.9798C9.08594 16.9197 9.07293 16.8552 9.07293 16.79C9.07293 16.7248 9.08594 16.6603 9.11119 16.6002C9.13644 16.5401 9.17344 16.4856 9.22 16.44L13.67 12L9.22 7.56C9.17314 7.51352 9.13594 7.45822 9.11055 7.39729C9.08517 7.33636 9.0721 7.27101 9.0721 7.205C9.0721 7.139 9.08517 7.07365 9.11055 7.01272C9.13594 6.95179 9.17314 6.89649 9.22 6.85L9.93 6.15C9.97648 6.10314 10.0318 6.06594 10.0927 6.04056C10.1536 6.01517 10.219 6.00211 10.285 6.00211C10.351 6.00211 10.4164 6.01517 10.4773 6.04056C10.5382 6.06594 10.5935 6.10314 10.64 6.15L15.78 11.28Z' fill='white'/%3e%3c/svg%3e");
}

.list-pointer-soft-bg-danger .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23692340' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='24' height='24' rx='12' fill='%23692340' fill-opacity='0.1'/%3e%3cpath d='M15.78 11.28C15.9207 11.4205 15.9998 11.6112 16 11.81V12.19C15.9977 12.3884 15.9189 12.5783 15.78 12.72L10.64 17.85C10.5935 17.8969 10.5382 17.9341 10.4773 17.9595C10.4164 17.9848 10.351 17.9979 10.285 17.9979C10.219 17.9979 10.1536 17.9848 10.0927 17.9595C10.0318 17.9341 9.97648 17.8969 9.93 17.85L9.22 17.14C9.17344 17.0944 9.13644 17.0399 9.11119 16.9798C9.08594 16.9197 9.07293 16.8552 9.07293 16.79C9.07293 16.7248 9.08594 16.6603 9.11119 16.6002C9.13644 16.5401 9.17344 16.4856 9.22 16.44L13.67 12L9.22 7.56C9.17314 7.51352 9.13594 7.45822 9.11055 7.39729C9.08517 7.33636 9.0721 7.27101 9.0721 7.205C9.0721 7.139 9.08517 7.07365 9.11055 7.01272C9.13594 6.95179 9.17314 6.89649 9.22 6.85L9.93 6.15C9.97648 6.10314 10.0318 6.06594 10.0927 6.04056C10.1536 6.01517 10.219 6.00211 10.285 6.00211C10.351 6.00211 10.4164 6.01517 10.4773 6.04056C10.5382 6.06594 10.5935 6.10314 10.64 6.15L15.78 11.28Z' fill='%23692340'/%3e%3c/svg%3e");
}

.list-pointer-light .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3e%3cpath fill='%23f8f9fa' d='M15.78,11.28a.75.75,0,0,1,.22.53v.38a.77.77,0,0,1-.22.53l-5.14,5.13a.5.5,0,0,1-.71,0l-.71-.71a.49.49,0,0,1,0-.7L13.67,12,9.22,7.56a.5.5,0,0,1,0-.71l.71-.7a.5.5,0,0,1,.71,0Z'/%3e%3c/svg%3e");
}

.list-pointer-bg-light .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='24' height='24' rx='12' fill='%23f8f9fa'/%3e%3cpath d='M15.78 11.28C15.9207 11.4205 15.9998 11.6112 16 11.81V12.19C15.9977 12.3884 15.9189 12.5783 15.78 12.72L10.64 17.85C10.5935 17.8969 10.5382 17.9341 10.4773 17.9595C10.4164 17.9848 10.351 17.9979 10.285 17.9979C10.219 17.9979 10.1536 17.9848 10.0927 17.9595C10.0318 17.9341 9.97648 17.8969 9.93 17.85L9.22 17.14C9.17344 17.0944 9.13644 17.0399 9.11119 16.9798C9.08594 16.9197 9.07293 16.8552 9.07293 16.79C9.07293 16.7248 9.08594 16.6603 9.11119 16.6002C9.13644 16.5401 9.17344 16.4856 9.22 16.44L13.67 12L9.22 7.56C9.17314 7.51352 9.13594 7.45822 9.11055 7.39729C9.08517 7.33636 9.0721 7.27101 9.0721 7.205C9.0721 7.139 9.08517 7.07365 9.11055 7.01272C9.13594 6.95179 9.17314 6.89649 9.22 6.85L9.93 6.15C9.97648 6.10314 10.0318 6.06594 10.0927 6.04056C10.1536 6.01517 10.219 6.00211 10.285 6.00211C10.351 6.00211 10.4164 6.01517 10.4773 6.04056C10.5382 6.06594 10.5935 6.10314 10.64 6.15L15.78 11.28Z' fill='%23000'/%3e%3c/svg%3e");
}

.list-pointer-soft-bg-light .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%23f8f9fa' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='24' height='24' rx='12' fill='%23f8f9fa' fill-opacity='0.1'/%3e%3cpath d='M15.78 11.28C15.9207 11.4205 15.9998 11.6112 16 11.81V12.19C15.9977 12.3884 15.9189 12.5783 15.78 12.72L10.64 17.85C10.5935 17.8969 10.5382 17.9341 10.4773 17.9595C10.4164 17.9848 10.351 17.9979 10.285 17.9979C10.219 17.9979 10.1536 17.9848 10.0927 17.9595C10.0318 17.9341 9.97648 17.8969 9.93 17.85L9.22 17.14C9.17344 17.0944 9.13644 17.0399 9.11119 16.9798C9.08594 16.9197 9.07293 16.8552 9.07293 16.79C9.07293 16.7248 9.08594 16.6603 9.11119 16.6002C9.13644 16.5401 9.17344 16.4856 9.22 16.44L13.67 12L9.22 7.56C9.17314 7.51352 9.13594 7.45822 9.11055 7.39729C9.08517 7.33636 9.0721 7.27101 9.0721 7.205C9.0721 7.139 9.08517 7.07365 9.11055 7.01272C9.13594 6.95179 9.17314 6.89649 9.22 6.85L9.93 6.15C9.97648 6.10314 10.0318 6.06594 10.0927 6.04056C10.1536 6.01517 10.219 6.00211 10.285 6.00211C10.351 6.00211 10.4164 6.01517 10.4773 6.04056C10.5382 6.06594 10.5935 6.10314 10.64 6.15L15.78 11.28Z' fill='%23f8f9fa'/%3e%3c/svg%3e");
}

.list-pointer-dark .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3e%3cpath fill='%232d374b' d='M15.78,11.28a.75.75,0,0,1,.22.53v.38a.77.77,0,0,1-.22.53l-5.14,5.13a.5.5,0,0,1-.71,0l-.71-.71a.49.49,0,0,1,0-.7L13.67,12,9.22,7.56a.5.5,0,0,1,0-.71l.71-.7a.5.5,0,0,1,.71,0Z'/%3e%3c/svg%3e");
}

.list-pointer-bg-dark .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='24' height='24' rx='12' fill='%232d374b'/%3e%3cpath d='M15.78 11.28C15.9207 11.4205 15.9998 11.6112 16 11.81V12.19C15.9977 12.3884 15.9189 12.5783 15.78 12.72L10.64 17.85C10.5935 17.8969 10.5382 17.9341 10.4773 17.9595C10.4164 17.9848 10.351 17.9979 10.285 17.9979C10.219 17.9979 10.1536 17.9848 10.0927 17.9595C10.0318 17.9341 9.97648 17.8969 9.93 17.85L9.22 17.14C9.17344 17.0944 9.13644 17.0399 9.11119 16.9798C9.08594 16.9197 9.07293 16.8552 9.07293 16.79C9.07293 16.7248 9.08594 16.6603 9.11119 16.6002C9.13644 16.5401 9.17344 16.4856 9.22 16.44L13.67 12L9.22 7.56C9.17314 7.51352 9.13594 7.45822 9.11055 7.39729C9.08517 7.33636 9.0721 7.27101 9.0721 7.205C9.0721 7.139 9.08517 7.07365 9.11055 7.01272C9.13594 6.95179 9.17314 6.89649 9.22 6.85L9.93 6.15C9.97648 6.10314 10.0318 6.06594 10.0927 6.04056C10.1536 6.01517 10.219 6.00211 10.285 6.00211C10.351 6.00211 10.4164 6.01517 10.4773 6.04056C10.5382 6.06594 10.5935 6.10314 10.64 6.15L15.78 11.28Z' fill='white'/%3e%3c/svg%3e");
}

.list-pointer-soft-bg-dark .list-pointer-item::before {
  background-image: url("data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='%232d374b' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='24' height='24' rx='12' fill='%232d374b' fill-opacity='0.1'/%3e%3cpath d='M15.78 11.28C15.9207 11.4205 15.9998 11.6112 16 11.81V12.19C15.9977 12.3884 15.9189 12.5783 15.78 12.72L10.64 17.85C10.5935 17.8969 10.5382 17.9341 10.4773 17.9595C10.4164 17.9848 10.351 17.9979 10.285 17.9979C10.219 17.9979 10.1536 17.9848 10.0927 17.9595C10.0318 17.9341 9.97648 17.8969 9.93 17.85L9.22 17.14C9.17344 17.0944 9.13644 17.0399 9.11119 16.9798C9.08594 16.9197 9.07293 16.8552 9.07293 16.79C9.07293 16.7248 9.08594 16.6603 9.11119 16.6002C9.13644 16.5401 9.17344 16.4856 9.22 16.44L13.67 12L9.22 7.56C9.17314 7.51352 9.13594 7.45822 9.11055 7.39729C9.08517 7.33636 9.0721 7.27101 9.0721 7.205C9.0721 7.139 9.08517 7.07365 9.11055 7.01272C9.13594 6.95179 9.17314 6.89649 9.22 6.85L9.93 6.15C9.97648 6.10314 10.0318 6.06594 10.0927 6.04056C10.1536 6.01517 10.219 6.00211 10.285 6.00211C10.351 6.00211 10.4164 6.01517 10.4773 6.04056C10.5382 6.06594 10.5935 6.10314 10.64 6.15L15.78 11.28Z' fill='%232d374b'/%3e%3c/svg%3e");
}

.list-pointer-sm .list-pointer-item {
  padding-left: 1.5rem;
}
.list-pointer-sm .list-pointer-item::before {
  width: 1rem;
  height: 1rem;
  background-size: 1rem 1rem;
  margin-top: 0.3125rem;
}
.list-pointer-sm[class*=list-pointer-bg-] .list-pointer-item::before, .list-pointer-sm[class*=list-pointer-soft-bg-] .list-pointer-item::before {
  margin-top: 0.25rem;
}

.list-pointer-lg .list-pointer-item {
  padding-left: 2.75rem;
}
.list-pointer-lg .list-pointer-item:not(:last-child) {
  margin-bottom: 1.25rem;
}
.list-pointer-lg .list-pointer-item::before {
  width: 1.75rem;
  height: 1.75rem;
  background-size: 1.75rem 1.75rem;
  margin-top: 0;
}
.list-pointer-lg[class*=list-pointer-bg-] .list-pointer-item::before, .list-pointer-lg[class*=list-pointer-soft-bg-] .list-pointer-item::before {
  margin-top: -0.0625rem;
}

/*------------------------------------
  List Separator
------------------------------------*/
.list-separator {
  margin-bottom: 0;
}
.list-separator .list-inline-item {
  position: relative;
  margin-left: 0;
  margin-right: -0.25rem;
}
.list-separator .list-inline-item:not(:last-child) {
  padding-right: 2rem;
}
.list-separator .list-inline-item:not(:last-child)::after {
  position: absolute;
  top: 50%;
  right: 0.8rem;
  transform: translateY(-50%);
  content: "•";
  opacity: 0.5;
}
.list-separator .list-separator-link {
  color: #51596C;
}
.list-separator .list-separator-link:hover {
  color: #07853a;
}

/*------------------------------------
  List Step
------------------------------------*/
.list-step {
  position: relative;
}
.list-step .list-step-item {
  position: relative;
}
.list-step .list-step-item:not(:first-child)::before {
  position: absolute;
  top: -4.5rem;
  left: 50%;
  width: 3rem;
  height: 9rem;
  background-repeat: no-repeat;
  background-position: center center;
  background-size: 3rem 9rem;
  transform: translateX(-50%);
  content: "";
}
.list-step .list-step-item:nth-of-type(even)::before {
  background-image: url("data:image/svg+xml,%3Csvg width='187' height='674' viewBox='0 0 187 674' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M12.3307 1.3767C8.94892 -1.01509 4.26849 -0.212532 1.8767 3.16927C-0.515094 6.55108 0.287468 11.2315 3.66927 13.6233L12.3307 1.3767ZM0.5 666.5C0.5 670.642 3.85786 674 8 674H75.5C79.6421 674 83 670.642 83 666.5C83 662.358 79.6421 659 75.5 659H15.5V599C15.5 594.858 12.1421 591.5 8 591.5C3.85786 591.5 0.5 594.858 0.5 599V666.5ZM22.2839 27.7273C25.5051 30.3313 30.2274 29.8309 32.8314 26.6097C35.4354 23.3884 34.935 18.6661 31.7138 16.0621L22.2839 27.7273ZM67.7575 48.8281C64.8534 45.8746 60.1048 45.8347 57.1513 48.7388C54.1978 51.643 54.1578 56.3916 57.062 59.3451L67.7575 48.8281ZM88.196 94.6608C90.762 97.9124 95.4781 98.4682 98.7297 95.9022C101.981 93.3362 102.537 88.6201 99.9711 85.3685L88.196 94.6608ZM127.936 125.157C125.749 121.64 121.124 120.561 117.607 122.748C114.089 124.935 113.01 129.559 115.197 133.077L127.936 125.157ZM137.597 174.345C139.35 178.098 143.814 179.719 147.567 177.967C151.32 176.214 152.941 171.75 151.188 167.997L137.597 174.345ZM169.002 213.422C167.742 209.477 163.522 207.299 159.576 208.559C155.63 209.819 153.453 214.04 154.713 217.985L169.002 213.422ZM165.924 263.406C166.641 267.486 170.529 270.212 174.608 269.495C178.688 268.779 181.415 264.891 180.698 260.811L165.924 263.406ZM185.791 309.388C185.647 305.248 182.174 302.01 178.034 302.154C173.895 302.298 170.656 305.771 170.8 309.911L185.791 309.388ZM169.199 356.656C168.775 360.777 171.772 364.46 175.892 364.884C180.013 365.308 183.697 362.312 184.121 358.191L169.199 356.656ZM175.944 406.286C176.899 402.255 174.406 398.214 170.375 397.258C166.345 396.303 162.303 398.796 161.348 402.827L175.944 406.286ZM147.768 447.791C146.341 451.68 148.337 455.989 152.225 457.416C156.114 458.843 160.423 456.848 161.85 452.959L147.768 447.791ZM142.664 497.633C144.493 493.917 142.963 489.421 139.246 487.592C135.53 485.763 131.034 487.293 129.205 491.01L142.664 497.633ZM106.458 532.206C104.295 535.739 105.405 540.356 108.937 542.519C112.47 544.682 117.087 543.572 119.25 540.04L106.458 532.206ZM92.2476 580.332C94.6861 576.984 93.9487 572.292 90.6004 569.854C87.2521 567.415 82.561 568.153 80.1225 571.501L92.2476 580.332ZM50.9207 608.753C48.2569 611.925 48.6689 616.656 51.8409 619.32C55.0129 621.984 59.7437 621.572 62.4075 618.4L50.9207 608.753ZM30.3173 654.326C33.1655 651.318 33.0363 646.571 30.0288 643.723C27.0213 640.875 22.2743 641.004 19.4262 644.011L30.3173 654.326ZM3.66927 13.6233C9.76744 17.9363 15.9928 22.6418 22.2839 27.7273L31.7138 16.0621C25.1793 10.7798 18.6978 5.87987 12.3307 1.3767L3.66927 13.6233ZM57.062 59.3451C67.683 70.1464 78.1573 81.94 88.196 94.6608L99.9711 85.3685C89.5835 72.2056 78.7471 60.0043 67.7575 48.8281L57.062 59.3451ZM115.197 133.077C123.321 146.144 130.858 159.916 137.597 174.345L151.188 167.997C144.183 152.999 136.357 138.703 127.936 125.157L115.197 133.077ZM154.713 217.985C159.381 232.605 163.176 247.758 165.924 263.406L180.698 260.811C177.828 244.47 173.868 228.66 169.002 213.422L154.713 217.985ZM170.8 309.911C171.33 325.106 170.841 340.697 169.199 356.656L184.121 358.191C185.834 341.541 186.344 325.263 185.791 309.388L170.8 309.911ZM161.348 402.827C157.86 417.544 153.365 432.539 147.768 447.791L161.85 452.959C167.648 437.159 172.316 421.594 175.944 406.286L161.348 402.827ZM129.205 491.01C122.534 504.566 114.972 518.302 106.458 532.206L119.25 540.04C127.997 525.756 135.782 511.616 142.664 497.633L129.205 491.01ZM80.1225 571.501C71.1614 583.805 61.4411 596.226 50.9207 608.753L62.4075 618.4C73.1416 605.617 83.0757 592.925 92.2476 580.332L80.1225 571.501ZM19.4262 644.011C14.0197 649.72 8.44441 655.449 2.6967 661.197L13.3033 671.803C19.1454 665.961 24.8156 660.135 30.3173 654.326L19.4262 644.011Z' fill='%23BDC5D1'/%3e%3c/svg%3e");
}
.list-step .list-step-item:nth-of-type(odd)::before {
  background-image: url("data:image/svg+xml,%3csvg width='187' height='674' viewBox='0 0 187 674' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M174.174 1.3767C177.555 -1.01509 182.236 -0.212532 184.628 3.16927C187.019 6.55108 186.217 11.2315 182.835 13.6233L174.174 1.3767ZM186.004 666.5C186.004 670.642 182.647 674 178.504 674H111.004C106.862 674 103.504 670.642 103.504 666.5C103.504 662.358 106.862 659 111.004 659H171.004V599C171.004 594.858 174.362 591.5 178.504 591.5C182.647 591.5 186.004 594.858 186.004 599V666.5ZM164.221 27.7273C160.999 30.3313 156.277 29.8309 153.673 26.6097C151.069 23.3884 151.569 18.6661 154.791 16.0621L164.221 27.7273ZM118.747 48.8281C121.651 45.8746 126.4 45.8347 129.353 48.7388C132.307 51.643 132.347 56.3916 129.442 59.3451L118.747 48.8281ZM98.3084 94.6608C95.7424 97.9124 91.0263 98.4682 87.7747 95.9022C84.5231 93.3362 83.9673 88.6201 86.5333 85.3685L98.3084 94.6608ZM58.5685 125.157C60.7554 121.64 65.38 120.561 68.8977 122.748C72.4155 124.935 73.4943 129.559 71.3074 133.077L58.5685 125.157ZM48.9069 174.345C47.1541 178.098 42.6907 179.719 38.9377 177.967C35.1848 176.214 33.5634 171.75 35.3163 167.997L48.9069 174.345ZM17.5026 213.422C18.7626 209.477 22.9828 207.299 26.9287 208.559C30.8745 209.819 33.0518 214.04 31.7917 217.985L17.5026 213.422ZM20.5803 263.406C19.8637 267.486 15.9756 270.212 11.8959 269.495C7.81621 268.779 5.08987 264.891 5.80644 260.811L20.5803 263.406ZM0.713454 309.388C0.85777 305.248 4.33059 302.01 8.47021 302.154C12.6098 302.298 15.8487 305.771 15.7043 309.911L0.713454 309.388ZM17.305 356.656C17.729 360.777 14.7324 364.46 10.612 364.884C6.49165 365.308 2.80775 362.312 2.3838 358.191L17.305 356.656ZM10.5608 406.286C9.60551 402.255 12.0985 398.214 16.1289 397.258C20.1594 396.303 24.2012 398.796 25.1564 402.827L10.5608 406.286ZM38.7361 447.791C40.1632 451.68 38.1677 455.989 34.2791 457.416C30.3906 458.843 26.0814 456.848 24.6544 452.959L38.7361 447.791ZM43.8408 497.633C42.0117 493.917 43.5417 489.421 47.2581 487.592C50.9745 485.763 55.47 487.293 57.2991 491.01L43.8408 497.633ZM80.0465 532.206C82.2096 535.739 81.0995 540.356 77.5671 542.519C74.0346 544.682 69.4175 543.572 67.2543 540.04L80.0465 532.206ZM94.2568 580.332C91.8183 576.984 92.5557 572.292 95.904 569.854C99.2523 567.415 103.943 568.153 106.382 571.501L94.2568 580.332ZM135.584 608.753C138.248 611.925 137.836 616.656 134.664 619.32C131.492 621.984 126.761 621.572 124.097 618.4L135.584 608.753ZM156.187 654.326C153.339 651.318 153.468 646.571 156.476 643.723C159.483 640.875 164.23 641.004 167.078 644.011L156.187 654.326ZM182.835 13.6233C176.737 17.9363 170.512 22.6418 164.221 27.7273L154.791 16.0621C161.325 10.7798 167.807 5.87987 174.174 1.3767L182.835 13.6233ZM129.442 59.3451C118.821 70.1464 108.347 81.94 98.3084 94.6608L86.5333 85.3685C96.9209 72.2056 107.757 60.0043 118.747 48.8281L129.442 59.3451ZM71.3074 133.077C63.1839 146.144 55.6464 159.916 48.9069 174.345L35.3163 167.997C42.3214 152.999 50.147 138.703 58.5685 125.157L71.3074 133.077ZM31.7917 217.985C27.1232 232.605 23.3288 247.758 20.5803 263.406L5.80644 260.811C8.67665 244.47 12.6367 228.66 17.5026 213.422L31.7917 217.985ZM15.7043 309.911C15.1746 325.106 15.663 340.697 17.305 356.656L2.3838 358.191C0.670702 341.541 0.160023 325.263 0.713454 309.388L15.7043 309.911ZM25.1564 402.827C28.6447 417.544 33.1389 432.539 38.7361 447.791L24.6544 452.959C18.856 437.159 14.1889 421.594 10.5608 406.286L25.1564 402.827ZM57.2991 491.01C63.9708 504.566 71.5322 518.302 80.0465 532.206L67.2543 540.04C58.5077 525.756 50.7226 511.616 43.8408 497.633L57.2991 491.01ZM106.382 571.501C115.343 583.805 125.063 596.226 135.584 608.753L124.097 618.4C113.363 605.617 103.429 592.925 94.2568 580.332L106.382 571.501ZM167.078 644.011C172.485 649.72 178.06 655.449 183.808 661.197L173.201 671.803C167.359 665.961 161.689 660.135 156.187 654.326L167.078 644.011Z' fill='%23BDC5D1'/%3e%3c/svg%3e");
}

/*------------------------------------
  List Timeline
------------------------------------*/
.list-timeline {
  position: relative;
  padding-top: 1.5rem;
  padding-bottom: 1.5rem;
}
.list-timeline::before {
  position: absolute;
  top: 0;
  left: 50%;
  width: 100%;
  height: 100%;
  background-image: url("data:image/svg+xml,%3csvg width='309' height='968' viewBox='0 0 309 968' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M23 961C125.667 948.167 313.5 863 227.5 685C185.5 609 139 596.5 58 554C-43.8683 500.551 19 440 141.5 384.5C264 329 365.5 203 267.5 121C252.167 109.833 209 88.5 162.5 80.5C103.946 70.4263 65 63.5 23 18' stroke='%23F39568' stroke-width='3' stroke-dasharray='12 12'/%3E%3Ccircle cx='7.5' cy='960.5' r='7.5'  fill='%23f39568'/%3E%3Ccircle cx='14.5' cy='7.5' r='7.5'  fill='%23f39568'/%3e%3c/svg%3e");
  background-repeat: no-repeat;
  background-position: center center;
  background-size: 100% 100%;
  transform: translateX(-50%);
  content: "";
}

.list-timeline-item {
  max-width: 32rem;
}

/*------------------------------------
  Modal
------------------------------------*/
.modal-header {
  align-items: center;
  padding-bottom: 0;
}
.modal-header .close {
  padding: 0.25rem 0.25rem;
  margin: 0 0 0 auto;
}

.modal-footer > * {
  margin-top: 0;
  margin-bottom: 0;
}

.modal-footer-text:last-child {
  font-size: 0.8125rem;
  margin-bottom: 0;
}

.modal-close {
  position: absolute;
  top: 0.75rem;
  right: 0.75rem;
  z-index: 2;
}

/*------------------------------------
  Nav
------------------------------------*/
.nav-subtitle {
  display: block;
  color: #8997a4;
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.03125rem;
}

.nav-link.dropdown-toggle {
  display: flex;
  align-items: center;
}

.nav-link.active {
  color: #0abf53;
}

.nav-link.active .nav-link-svg path,
.nav-item.show .nav-link-svg path {
  fill: #0abf53;
}

.nav-title:last-child,
.nav-text:last-child {
  margin-bottom: 0;
}

.nav-icon {
  font-size: 1.125rem;
  opacity: 0.7;
  margin-right: 0.5rem;
}

.nav-divider {
  height: 2rem;
  border-left: 0.1rem solid rgba(220, 224, 229, 0.6);
  margin: 0 0.5rem;
}

.nav.nav-link-gray .nav-link {
  color: #BDC5D1;
}
.nav.nav-link-gray .nav-link.active, .nav.nav-link-gray .nav-link:hover {
  color: #2d374b;
}
.nav.nav-link-gray .nav-link.disabled {
  color: #BDC5D1;
}

.nav-tabs .nav-link {
  border-top-width: 0;
  border-left-width: 0;
  border-right-width: 0;
  border-bottom: 0.1875rem solid transparent;
}
.nav-tabs .nav-link.active,
.nav-tabs .nav-item.show .nav-link {
  font-weight: 500;
}
.nav-tabs:not(.nav-vertical) .nav-link {
  padding-top: 1.25rem;
  padding-bottom: 1.25rem;
}

.nav-vertical {
  flex-direction: column;
}
.nav-vertical.nav .nav-item:not(:last-child) {
  margin-right: 0;
}
.nav-vertical .nav-subtitle {
  padding-left: 1rem;
}
.nav-vertical.nav-lg.nav-link-gray .nav-link {
  padding: 0.25rem 0;
}
.nav-vertical.nav-tabs {
  border-bottom-width: 0;
}
.nav-vertical.nav-tabs .nav-link {
  border-top-width: 0;
  border-right-width: 0;
  border-bottom-width: 0;
  border-left: 0.1875rem solid rgba(220, 224, 229, 0.6);
  margin-bottom: 0;
}
.nav-vertical.nav-tabs .nav-subtitle {
  border-left: 0.1875rem solid rgba(220, 224, 229, 0.6);
}
.nav-vertical.nav-tabs .nav-link.active,
.nav-vertical.nav-tabs .nav-item.show .nav-link {
  border-color: #0abf53;
}
.nav-vertical.nav.nav-tabs .nav-collapse .nav-link {
  padding-left: 3rem;
}

.nav-collapse .nav-link {
  position: relative;
}
.nav-collapse .nav-link::before {
  position: absolute;
  top: 50%;
  left: 2rem;
  transform: translateY(-50%);
  content: "•";
}

.nav-pills .nav-item {
  margin: 0.25rem 0.25rem;
}
.nav-pills .nav-link {
  padding: 1rem 1rem;
}
.nav-pills .nav-link:hover {
  color: #2d374b;
}
.nav-pills .nav-link.active {
  box-shadow: 0rem 0.1875rem 0.375rem rgba(140, 152, 164, 0.25);
}
.nav-pills .nav-link.active:hover,
.nav-pills .show > .nav-link:hover {
  border-color: transparent;
}

.nav-segment {
  position: relative;
  background-color: #f3f6f9;
  padding: 0.25rem 0.25rem;
  border-radius: 0.6rem;
}
.nav-segment:not(.nav-fill) {
  display: inline-flex;
}
.nav-segment .nav-link {
  color: #51596C;
  font-size: 0.8125rem;
  padding: 0.5rem 0.875rem;
  border-radius: 0.6rem;
}
.nav-segment .nav-link:hover {
  color: #0abf53;
}
.nav-segment .nav-link.active {
  color: #2d374b;
  background-color: white;
  box-shadow: 0rem 0.1875rem 0.375rem 0rem rgba(140, 152, 164, 0.25);
}
.nav-segment.nav-pills {
  border-radius: 6.1875rem;
}
.nav-segment.nav-pills .nav-link {
  border-radius: 6.1875rem;
}

.nav-sm .nav-link {
  font-size: 0.875rem;
}

.nav-lg .nav-link {
  font-size: calc(1.35rem + 1.2vw);
  font-weight: 700;
}
@media (min-width: 1200px) {
  .nav-lg .nav-link {
    font-size: 2.25rem;
  }
}

/*------------------------------------
  Navbar
------------------------------------*/
.navbar {
  z-index: 99;
}

.navbar-collapse {
  align-items: flex-start;
}

.navbar-shadow {
  box-shadow: 0rem 0.375rem 1.5rem 0rem rgba(140, 152, 164, 0.125);
}

.navbar-height {
  height: 3.875rem;
}

.navbar.navbar-scrolled.navbar-light {
  background-color: white;
  box-shadow: 0rem 0.375rem 1.5rem 0rem rgba(140, 152, 164, 0.125);
}
.navbar.navbar-scrolled.navbar-dark {
  background-color: #2d374b;
}

.navbar-topbar {
  width: 100%;
  padding-bottom: 0.675rem;
  transition: all 0.2s ease-in-out;
}
.navbar-topbar .navbar-toggler {
  font-size: 0.75rem;
}
.navbar-topbar .navbar-toggler {
  display: flex;
  justify-content: flex-end;
  align-items: center;
}
.navbar-topbar .navbar-collapse {
  z-index: 11;
}
.navbar-topbar .navbar-topbar-collapse-toggler {
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 0.0625rem solid rgba(220, 224, 229, 0.6);
  padding: 1rem 1rem;
}
.navbar-topbar .navbar-topbar-toggler-text {
  font-size: 0.875rem;
}
.navbar-topbar .nav-link {
  font-size: 0.875rem;
}

@keyframes navbar-topbar-collapse-scale-up {
  0% {
    transform: scale(0.5);
    transform-origin: 100% 0%;
  }
  100% {
    transform: scale(1);
    transform-origin: 100% 0%;
  }
}
.navbar-brand {
  padding-top: 0;
  padding-bottom: 0;
}

.navbar-brand-logo {
  width: 100%;
  min-width: 6rem;
  max-width: 6rem;
}

.navbar-brand-collapsed,
.navbar-brand-on-scroll {
  display: none;
}

.navbar-scrolled .navbar-brand-default {
  display: none;
}
.navbar-scrolled .navbar-brand-on-scroll {
  display: inline-block;
}

.navbar-nav {
  width: 100%;
}

.navbar-nav-wrap {
  display: flex;
  flex-wrap: wrap;
  flex-basis: 100%;
  align-items: center;
}

.navbar-nav-wrap-secondary-content {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.navbar-toggler {
  padding: 0.5rem 0.5rem;
  margin-left: auto;
  z-index: 1;
}
.navbar-toggler:focus {
  box-shadow: none;
}
.navbar-toggler .navbar-toggler-default {
  display: flex;
}
.navbar-toggler .navbar-toggler-toggled {
  display: none;
}
.navbar-toggler[aria-expanded=true] .navbar-toggler-default {
  display: none;
}
.navbar-toggler[aria-expanded=true] .navbar-toggler-toggled {
  display: flex;
}

.navbar .nav-pills .nav-item {
  margin: 0;
}
.navbar .nav-pills .nav-link {
  padding: 0.75rem 0.75rem;
}
.navbar .nav-pills .nav-link.active, .navbar .nav-pills .nav-link:hover, .navbar .nav-pills .nav-link:focus {
  color: #07853a;
  background-color: rgba(189, 197, 209, 0.2);
}

.navbar .nav-pills .nav-item:hover > .nav-link {
  background-color: rgba(189, 197, 209, 0.2);
}

.navbar .dropdown-menu::before {
  position: absolute;
  top: -0.625rem;
  display: block;
  left: 0;
  width: 100%;
  height: 1.75rem;
  content: "";
}

.navbar .dropdown-item[href]:hover.dropdown-toggle::after {
  background: url("data:image/svg+xml,<svg width='24' height='24' viewBox='0 0 24 24' fill='#2d374b' xmlns='http://www.w3.org/2000/svg'><path d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/></svg>");
}

.navbar-dropdown-menu-inner {
  padding: 0.75rem 0.75rem;
}

.navbar-dropdown-menu-media-link {
  display: block;
  text-decoration: none;
  padding: 1rem 1rem;
  border-radius: 0.6rem;
}
.navbar-dropdown-menu-media-link:hover:not(.disabled):not(:disabled) {
  background-color: rgba(189, 197, 209, 0.2);
}
.navbar-dropdown-menu-media-link:hover:not(.disabled):not(:disabled) .navbar-dropdown-menu-media-title {
  color: #2d374b;
}
.navbar-dropdown-menu-media-link.disabled {
  pointer-events: none;
}
.navbar-dropdown-menu-media-link + .navbar-dropdown-menu-media-link {
  margin-top: 0.5rem;
}

.navbar-dropdown-menu-media-title {
  color: #2d374b;
  font-weight: 500;
}

.navbar-dropdown-menu-media-desc {
  color: #51596C;
  font-size: 0.875rem;
  margin-bottom: 0;
}

.navbar-dropdown-menu-promo:not(:first-child) .navbar-dropdown-menu-promo-item {
  position: relative;
}
.navbar-dropdown-menu-promo:not(:first-child) .navbar-dropdown-menu-promo-item::after {
  position: absolute;
  top: -0.75rem;
  right: 0;
  border-top: 0.0625rem solid rgba(220, 224, 229, 0.6);
  width: 100%;
  content: "";
}

.navbar-dropdown-menu-promo-item {
  display: flex;
  flex-direction: column;
  min-width: 0;
  word-wrap: break-word;
  background-clip: border-box;
  margin: 0.75rem 0.75rem;
}
.navbar-dropdown-menu-promo-item ~ .navbar-dropdown-menu-promo-item {
  border-top: 0.0625rem solid rgba(220, 224, 229, 0.6);
}

.navbar-dropdown-menu-promo .navbar-dropdown-menu-promo-item {
  border-top: none;
}

.navbar-dropdown-menu-promo-link {
  display: block;
  height: 100%;
  padding: 1rem 1rem;
  border-radius: 0.6rem;
}
.navbar-dropdown-menu-promo-link.active {
  background-color: rgba(189, 197, 209, 0.2);
}
.navbar-dropdown-menu-promo-link.active .navbar-dropdown-menu-media-title {
  color: #2d374b;
}
.navbar-dropdown-menu-promo-link.disabled {
  opacity: 0.7;
  pointer-events: none;
}
.navbar-dropdown-menu-promo-link:hover:not(.disabled):not(:disabled) {
  background-color: rgba(189, 197, 209, 0.2);
}
.navbar-dropdown-menu-promo-link:hover:not(.disabled):not(:disabled) .navbar-dropdown-menu-media-title {
  color: #2d374b;
}

.navbar.navbar-vertical .navbar-nav .nav-subtitle,
.navbar.navbar-vertical .navbar-nav .nav-link {
  padding: 0.3125rem 1.5rem;
}
.navbar.navbar-vertical .nav-tabs-borderless.nav-vertical {
  padding-right: 0;
  padding-left: 0;
}
.navbar.navbar-vertical .nav-tabs-borderless.nav-vertical .nav-link,
.navbar.navbar-vertical .nav-tabs-borderless.nav-vertical .nav-subtitle {
  border-left-color: transparent;
}
.navbar.navbar-vertical .nav-tabs-borderless.nav-vertical .nav-link.active,
.navbar.navbar-vertical .nav-tabs-borderless.nav-vertical .nav-item.show .nav-link {
  border-color: #0abf53;
}

.navbar-input-group {
  /* clears the 'X' from Internet Explorer */
  /* clears the 'X' from Chrome */
}
.navbar-input-group input[type=search]::-ms-clear {
  display: none;
  width: 0;
  height: 0;
}
.navbar-input-group input[type=search]::-ms-reveal {
  display: none;
  width: 0;
  height: 0;
}
.navbar-input-group input[type=search]::-webkit-search-decoration,
.navbar-input-group input[type=search]::-webkit-search-cancel-button,
.navbar-input-group input[type=search]::-webkit-search-results-button,
.navbar-input-group input[type=search]::-webkit-search-results-decoration {
  display: none;
}

/*------------------------------------
  Absolute Positions
------------------------------------*/
@media (min-width: 576px) {
  .navbar-absolute-sm-top {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
  }
}

@media (min-width: 768px) {
  .navbar-absolute-md-top {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
  }
}

@media (min-width: 992px) {
  .navbar-absolute-lg-top {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
  }
}

@media (min-width: 1200px) {
  .navbar-absolute-xl-top {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
  }
}

@media (min-width: 1400px) {
  .navbar-absolute-xxl-top {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
  }
}

.navbar-absolute-top {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
}

@media (max-width: 575.98px) {
  .navbar-absolute-md-top .navbar-absolute-top-scroller {
    max-height: 75vh;
    background-color: white;
    overflow: hidden;
    overflow-y: auto;
  }
  .navbar-absolute-md-top .navbar-absolute-top-scroller::-webkit-scrollbar {
    width: 0.6125rem;
  }
  .navbar-absolute-md-top .navbar-absolute-top-scroller::-webkit-scrollbar-thumb {
    background-color: rgba(189, 197, 209, 0.6);
    visibility: hidden;
  }
  .navbar-absolute-md-top .navbar-absolute-top-scroller:hover::-webkit-scrollbar-thumb {
    visibility: visible;
  }
}
@media (max-width: 767.98px) {
  .navbar-absolute-top .navbar-absolute-top-scroller,
.navbar-absolute-sm-top .navbar-absolute-top-scroller,
.navbar-absolute-lg-top .navbar-absolute-top-scroller {
    max-height: 75vh;
    background-color: white;
    overflow: hidden;
    overflow-y: auto;
  }
  .navbar-absolute-top .navbar-absolute-top-scroller::-webkit-scrollbar,
.navbar-absolute-sm-top .navbar-absolute-top-scroller::-webkit-scrollbar,
.navbar-absolute-lg-top .navbar-absolute-top-scroller::-webkit-scrollbar {
    width: 0.6125rem;
  }
  .navbar-absolute-top .navbar-absolute-top-scroller::-webkit-scrollbar-thumb,
.navbar-absolute-sm-top .navbar-absolute-top-scroller::-webkit-scrollbar-thumb,
.navbar-absolute-lg-top .navbar-absolute-top-scroller::-webkit-scrollbar-thumb {
    background-color: rgba(189, 197, 209, 0.6);
    visibility: hidden;
  }
  .navbar-absolute-top .navbar-absolute-top-scroller:hover::-webkit-scrollbar-thumb,
.navbar-absolute-sm-top .navbar-absolute-top-scroller:hover::-webkit-scrollbar-thumb,
.navbar-absolute-lg-top .navbar-absolute-top-scroller:hover::-webkit-scrollbar-thumb {
    visibility: visible;
  }
}
@media (max-width: 991.98px) {
  .navbar-absolute-xl-top .navbar-absolute-top-scroller {
    max-height: 75vh;
    background-color: white;
    overflow: hidden;
    overflow-y: auto;
  }
  .navbar-absolute-xl-top .navbar-absolute-top-scroller::-webkit-scrollbar {
    width: 0.6125rem;
  }
  .navbar-absolute-xl-top .navbar-absolute-top-scroller::-webkit-scrollbar-thumb {
    background-color: rgba(189, 197, 209, 0.6);
    visibility: hidden;
  }
  .navbar-absolute-xl-top .navbar-absolute-top-scroller:hover::-webkit-scrollbar-thumb {
    visibility: visible;
  }
}
/*------------------------------------
  Sticky Positions
------------------------------------*/
@media (min-width: 576px) {
  .navbar-sticky-sm-top {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
  }
  .navbar-sticky-sm-top.navbar-scrolled .navbar-topbar {
    margin-top: -42px;
  }
}

@media (min-width: 768px) {
  .navbar-sticky-md-top {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
  }
  .navbar-sticky-md-top.navbar-scrolled .navbar-topbar {
    margin-top: -42px;
  }
}

@media (min-width: 992px) {
  .navbar-sticky-lg-top {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
  }
  .navbar-sticky-lg-top.navbar-scrolled .navbar-topbar {
    margin-top: -42px;
  }
}

@media (min-width: 1200px) {
  .navbar-sticky-xl-top {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
  }
  .navbar-sticky-xl-top.navbar-scrolled .navbar-topbar {
    margin-top: -42px;
  }
}

@media (min-width: 1400px) {
  .navbar-sticky-xxl-top {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
  }
  .navbar-sticky-xxl-top.navbar-scrolled .navbar-topbar {
    margin-top: -42px;
  }
}

.navbar-sticky-top {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
}
.navbar-sticky-top.navbar-scrolled .navbar-topbar {
  margin-top: -42px;
}

@media (max-width: 575.98px) {
  .navbar-sticky-md-top .navbar-sticky-top-scroller {
    max-height: 75vh;
    overflow: hidden;
    overflow-y: auto;
  }
  .navbar-sticky-md-top .navbar-sticky-top-scroller::-webkit-scrollbar {
    width: 0.6125rem;
  }
  .navbar-sticky-md-top .navbar-sticky-top-scroller::-webkit-scrollbar-thumb {
    background-color: rgba(189, 197, 209, 0.6);
    visibility: hidden;
  }
  .navbar-sticky-md-top .navbar-sticky-top-scroller:hover::-webkit-scrollbar-thumb {
    visibility: visible;
  }
}
@media (max-width: 767.98px) {
  .navbar-sticky-top .navbar-sticky-top-scroller,
.navbar-sticky-sm-top .navbar-sticky-top-scroller,
.navbar-sticky-lg-top .navbar-sticky-top-scroller {
    max-height: 75vh;
    overflow: hidden;
    overflow-y: auto;
  }
  .navbar-sticky-top .navbar-sticky-top-scroller::-webkit-scrollbar,
.navbar-sticky-sm-top .navbar-sticky-top-scroller::-webkit-scrollbar,
.navbar-sticky-lg-top .navbar-sticky-top-scroller::-webkit-scrollbar {
    width: 0.6125rem;
  }
  .navbar-sticky-top .navbar-sticky-top-scroller::-webkit-scrollbar-thumb,
.navbar-sticky-sm-top .navbar-sticky-top-scroller::-webkit-scrollbar-thumb,
.navbar-sticky-lg-top .navbar-sticky-top-scroller::-webkit-scrollbar-thumb {
    background-color: rgba(189, 197, 209, 0.6);
    visibility: hidden;
  }
  .navbar-sticky-top .navbar-sticky-top-scroller:hover::-webkit-scrollbar-thumb,
.navbar-sticky-sm-top .navbar-sticky-top-scroller:hover::-webkit-scrollbar-thumb,
.navbar-sticky-lg-top .navbar-sticky-top-scroller:hover::-webkit-scrollbar-thumb {
    visibility: visible;
  }
}
@media (max-width: 991.98px) {
  .navbar-sticky-xl-top .navbar-sticky-top-scroller {
    max-height: 75vh;
    overflow: hidden;
    overflow-y: auto;
  }
  .navbar-sticky-xl-top .navbar-sticky-top-scroller::-webkit-scrollbar {
    width: 0.6125rem;
  }
  .navbar-sticky-xl-top .navbar-sticky-top-scroller::-webkit-scrollbar-thumb {
    background-color: rgba(189, 197, 209, 0.6);
    visibility: hidden;
  }
  .navbar-sticky-xl-top .navbar-sticky-top-scroller:hover::-webkit-scrollbar-thumb {
    visibility: visible;
  }
}
/*------------------------------------
  Navbar Expand
------------------------------------*/
@media (min-width: 576px) {
  .navbar-expand-sm .navbar-toggler {
    order: 1;
  }
  .navbar-expand-sm .navbar-collapse {
    width: auto;
    order: 2;
  }
  .navbar-expand-sm .navbar-nav-wrap-secondary-content {
    order: 3;
  }
  .navbar-expand-sm .navbar-nav {
    align-items: center;
  }
  .navbar-expand-sm .nav-item:not(:last-child) {
    margin-right: 0.5rem;
  }
  .navbar-expand-sm .nav-item .nav-item {
    margin-right: 0;
  }
  .navbar-expand-sm .navbar-topbar {
    padding-bottom: 0.25rem;
  }
  .navbar-expand-sm .navbar-topbar .navbar-toggler {
    display: none;
  }
  .navbar-expand-sm .navbar-topbar .navbar-topbar-collapse-toggler {
    display: none;
  }
  .navbar-expand-sm .navbar-topbar .nav-item:not(:last-child) {
    margin-right: 0;
  }
  .navbar-expand-sm .navbar-topbar .nav-item:last-child .nav-link {
    padding-right: 0;
  }
  .navbar-expand-sm .dropdown-menu[data-bs-popper] {
    margin-top: 0.5rem;
  }
  .navbar-expand-sm .dropdown-menu .hs-has-sub-menu .dropdown-menu {
    margin-top: -0.6875rem;
    margin-left: 0.5rem;
  }
  .navbar-expand-sm .dropdown-menu .hs-has-sub-menu .dropdown-menu[data-bs-popper] {
    left: 100%;
  }
  .navbar-expand-sm .dropdown-menu .hs-has-sub-menu .dropdown-menu::before {
    top: 0;
    left: -1rem;
    width: 1rem;
    height: 100%;
  }
  .navbar-expand-sm .navbar-sticky-top-scroller,
.navbar-expand-sm .navbar-absolute-top-scroller {
    width: 100%;
  }
  .navbar-expand-sm.navbar-end .navbar-nav {
    justify-content: flex-end;
    margin-left: auto;
  }
  .navbar-expand-sm.navbar-end .navbar-sticky-top-scroller, .navbar-expand-sm.navbar-end .navbar-absolute-top-scroller {
    margin-left: auto;
  }
  .navbar-expand-sm.navbar-vertical {
    flex-flow: column;
    overflow-y: scroll;
    height: 100%;
    max-height: 100vh;
  }
  .navbar-expand-sm.navbar-vertical::-webkit-scrollbar {
    width: 0.6125rem;
  }
  .navbar-expand-sm.navbar-vertical::-webkit-scrollbar-thumb {
    background-color: rgba(189, 197, 209, 0.6);
  }
  .navbar-expand-sm.navbar-vertical .navbar-collapse {
    width: 100%;
    display: block !important;
  }
  .navbar-expand-sm.navbar-vertical .navbar-nav {
    display: block;
    flex-direction: column;
    align-items: flex-start;
  }
  .navbar-expand-sm .hs-position-right-fix {
    right: 35%;
    left: auto;
  }
  .navbar-expand-sm .navbar-dropdown-menu-promo {
    display: flex;
    flex-flow: row wrap;
  }
  .navbar-expand-sm .navbar-dropdown-menu-promo-item {
    display: flex;
    flex: 1 0 0%;
    flex-direction: column;
  }
  .navbar-expand-sm .navbar-dropdown-menu-promo-item:not(:last-child) .navbar-dropdown-menu-promo-link {
    position: relative;
  }
  .navbar-expand-sm .navbar-dropdown-menu-promo-item:not(:last-child) .navbar-dropdown-menu-promo-link::after {
    position: absolute;
    top: 0;
    right: 0;
    margin-right: -0.75rem;
    border-right: 0.0625rem solid rgba(220, 224, 229, 0.6);
    height: 100%;
    content: "";
  }
}

@media (min-width: 768px) {
  .navbar-expand-md .navbar-toggler {
    order: 1;
  }
  .navbar-expand-md .navbar-collapse {
    width: auto;
    order: 2;
  }
  .navbar-expand-md .navbar-nav-wrap-secondary-content {
    order: 3;
  }
  .navbar-expand-md .navbar-nav {
    align-items: center;
  }
  .navbar-expand-md .nav-item:not(:last-child) {
    margin-right: 0.5rem;
  }
  .navbar-expand-md .nav-item .nav-item {
    margin-right: 0;
  }
  .navbar-expand-md .navbar-topbar {
    padding-bottom: 0.25rem;
  }
  .navbar-expand-md .navbar-topbar .navbar-toggler {
    display: none;
  }
  .navbar-expand-md .navbar-topbar .navbar-topbar-collapse-toggler {
    display: none;
  }
  .navbar-expand-md .navbar-topbar .nav-item:not(:last-child) {
    margin-right: 0;
  }
  .navbar-expand-md .navbar-topbar .nav-item:last-child .nav-link {
    padding-right: 0;
  }
  .navbar-expand-md .dropdown-menu[data-bs-popper] {
    margin-top: 0.5rem;
  }
  .navbar-expand-md .dropdown-menu .hs-has-sub-menu .dropdown-menu {
    margin-top: -0.6875rem;
    margin-left: 0.5rem;
  }
  .navbar-expand-md .dropdown-menu .hs-has-sub-menu .dropdown-menu[data-bs-popper] {
    left: 100%;
  }
  .navbar-expand-md .dropdown-menu .hs-has-sub-menu .dropdown-menu::before {
    top: 0;
    left: -1rem;
    width: 1rem;
    height: 100%;
  }
  .navbar-expand-md .navbar-sticky-top-scroller,
.navbar-expand-md .navbar-absolute-top-scroller {
    width: 100%;
  }
  .navbar-expand-md.navbar-end .navbar-nav {
    justify-content: flex-end;
    margin-left: auto;
  }
  .navbar-expand-md.navbar-end .navbar-sticky-top-scroller, .navbar-expand-md.navbar-end .navbar-absolute-top-scroller {
    margin-left: auto;
  }
  .navbar-expand-md.navbar-vertical {
    flex-flow: column;
    overflow-y: scroll;
    height: 100%;
    max-height: 100vh;
  }
  .navbar-expand-md.navbar-vertical::-webkit-scrollbar {
    width: 0.6125rem;
  }
  .navbar-expand-md.navbar-vertical::-webkit-scrollbar-thumb {
    background-color: rgba(189, 197, 209, 0.6);
  }
  .navbar-expand-md.navbar-vertical .navbar-collapse {
    width: 100%;
    display: block !important;
  }
  .navbar-expand-md.navbar-vertical .navbar-nav {
    display: block;
    flex-direction: column;
    align-items: flex-start;
  }
  .navbar-expand-md .hs-position-right-fix {
    right: 35%;
    left: auto;
  }
  .navbar-expand-md .navbar-dropdown-menu-promo {
    display: flex;
    flex-flow: row wrap;
  }
  .navbar-expand-md .navbar-dropdown-menu-promo-item {
    display: flex;
    flex: 1 0 0%;
    flex-direction: column;
  }
  .navbar-expand-md .navbar-dropdown-menu-promo-item:not(:last-child) .navbar-dropdown-menu-promo-link {
    position: relative;
  }
  .navbar-expand-md .navbar-dropdown-menu-promo-item:not(:last-child) .navbar-dropdown-menu-promo-link::after {
    position: absolute;
    top: 0;
    right: 0;
    margin-right: -0.75rem;
    border-right: 0.0625rem solid rgba(220, 224, 229, 0.6);
    height: 100%;
    content: "";
  }
}

@media (min-width: 992px) {
  .navbar-expand-lg .navbar-toggler {
    order: 1;
  }
  .navbar-expand-lg .navbar-collapse {
    width: auto;
    order: 2;
  }
  .navbar-expand-lg .navbar-nav-wrap-secondary-content {
    order: 3;
  }
  .navbar-expand-lg .navbar-nav {
    align-items: center;
  }
  .navbar-expand-lg .nav-item:not(:last-child) {
    margin-right: 0.5rem;
  }
  .navbar-expand-lg .nav-item .nav-item {
    margin-right: 0;
  }
  .navbar-expand-lg .navbar-topbar {
    padding-bottom: 0.25rem;
  }
  .navbar-expand-lg .navbar-topbar .navbar-toggler {
    display: none;
  }
  .navbar-expand-lg .navbar-topbar .navbar-topbar-collapse-toggler {
    display: none;
  }
  .navbar-expand-lg .navbar-topbar .nav-item:not(:last-child) {
    margin-right: 0;
  }
  .navbar-expand-lg .navbar-topbar .nav-item:last-child .nav-link {
    padding-right: 0;
  }
  .navbar-expand-lg .dropdown-menu[data-bs-popper] {
    margin-top: 0.5rem;
  }
  .navbar-expand-lg .dropdown-menu .hs-has-sub-menu .dropdown-menu {
    margin-top: -0.6875rem;
    margin-left: 0.5rem;
  }
  .navbar-expand-lg .dropdown-menu .hs-has-sub-menu .dropdown-menu[data-bs-popper] {
    left: 100%;
  }
  .navbar-expand-lg .dropdown-menu .hs-has-sub-menu .dropdown-menu::before {
    top: 0;
    left: -1rem;
    width: 1rem;
    height: 100%;
  }
  .navbar-expand-lg .navbar-sticky-top-scroller,
.navbar-expand-lg .navbar-absolute-top-scroller {
    width: 100%;
  }
  .navbar-expand-lg.navbar-end .navbar-nav {
    justify-content: flex-end;
    margin-left: auto;
  }
  .navbar-expand-lg.navbar-end .navbar-sticky-top-scroller, .navbar-expand-lg.navbar-end .navbar-absolute-top-scroller {
    margin-left: auto;
  }
  .navbar-expand-lg.navbar-vertical {
    flex-flow: column;
    overflow-y: scroll;
    height: 100%;
    max-height: 100vh;
  }
  .navbar-expand-lg.navbar-vertical::-webkit-scrollbar {
    width: 0.6125rem;
  }
  .navbar-expand-lg.navbar-vertical::-webkit-scrollbar-thumb {
    background-color: rgba(189, 197, 209, 0.6);
  }
  .navbar-expand-lg.navbar-vertical .navbar-collapse {
    width: 100%;
    display: block !important;
  }
  .navbar-expand-lg.navbar-vertical .navbar-nav {
    display: block;
    flex-direction: column;
    align-items: flex-start;
  }
  .navbar-expand-lg .hs-position-right-fix {
    right: 35%;
    left: auto;
  }
  .navbar-expand-lg .navbar-dropdown-menu-promo {
    display: flex;
    flex-flow: row wrap;
  }
  .navbar-expand-lg .navbar-dropdown-menu-promo-item {
    display: flex;
    flex: 1 0 0%;
    flex-direction: column;
  }
  .navbar-expand-lg .navbar-dropdown-menu-promo-item:not(:last-child) .navbar-dropdown-menu-promo-link {
    position: relative;
  }
  .navbar-expand-lg .navbar-dropdown-menu-promo-item:not(:last-child) .navbar-dropdown-menu-promo-link::after {
    position: absolute;
    top: 0;
    right: 0;
    margin-right: -0.75rem;
    border-right: 0.0625rem solid rgba(220, 224, 229, 0.6);
    height: 100%;
    content: "";
  }
}

@media (min-width: 1200px) {
  .navbar-expand-xl .navbar-toggler {
    order: 1;
  }
  .navbar-expand-xl .navbar-collapse {
    width: auto;
    order: 2;
  }
  .navbar-expand-xl .navbar-nav-wrap-secondary-content {
    order: 3;
  }
  .navbar-expand-xl .navbar-nav {
    align-items: center;
  }
  .navbar-expand-xl .nav-item:not(:last-child) {
    margin-right: 0.5rem;
  }
  .navbar-expand-xl .nav-item .nav-item {
    margin-right: 0;
  }
  .navbar-expand-xl .navbar-topbar {
    padding-bottom: 0.25rem;
  }
  .navbar-expand-xl .navbar-topbar .navbar-toggler {
    display: none;
  }
  .navbar-expand-xl .navbar-topbar .navbar-topbar-collapse-toggler {
    display: none;
  }
  .navbar-expand-xl .navbar-topbar .nav-item:not(:last-child) {
    margin-right: 0;
  }
  .navbar-expand-xl .navbar-topbar .nav-item:last-child .nav-link {
    padding-right: 0;
  }
  .navbar-expand-xl .dropdown-menu[data-bs-popper] {
    margin-top: 0.5rem;
  }
  .navbar-expand-xl .dropdown-menu .hs-has-sub-menu .dropdown-menu {
    margin-top: -0.6875rem;
    margin-left: 0.5rem;
  }
  .navbar-expand-xl .dropdown-menu .hs-has-sub-menu .dropdown-menu[data-bs-popper] {
    left: 100%;
  }
  .navbar-expand-xl .dropdown-menu .hs-has-sub-menu .dropdown-menu::before {
    top: 0;
    left: -1rem;
    width: 1rem;
    height: 100%;
  }
  .navbar-expand-xl .navbar-sticky-top-scroller,
.navbar-expand-xl .navbar-absolute-top-scroller {
    width: 100%;
  }
  .navbar-expand-xl.navbar-end .navbar-nav {
    justify-content: flex-end;
    margin-left: auto;
  }
  .navbar-expand-xl.navbar-end .navbar-sticky-top-scroller, .navbar-expand-xl.navbar-end .navbar-absolute-top-scroller {
    margin-left: auto;
  }
  .navbar-expand-xl.navbar-vertical {
    flex-flow: column;
    overflow-y: scroll;
    height: 100%;
    max-height: 100vh;
  }
  .navbar-expand-xl.navbar-vertical::-webkit-scrollbar {
    width: 0.6125rem;
  }
  .navbar-expand-xl.navbar-vertical::-webkit-scrollbar-thumb {
    background-color: rgba(189, 197, 209, 0.6);
  }
  .navbar-expand-xl.navbar-vertical .navbar-collapse {
    width: 100%;
    display: block !important;
  }
  .navbar-expand-xl.navbar-vertical .navbar-nav {
    display: block;
    flex-direction: column;
    align-items: flex-start;
  }
  .navbar-expand-xl .hs-position-right-fix {
    right: 35%;
    left: auto;
  }
  .navbar-expand-xl .navbar-dropdown-menu-promo {
    display: flex;
    flex-flow: row wrap;
  }
  .navbar-expand-xl .navbar-dropdown-menu-promo-item {
    display: flex;
    flex: 1 0 0%;
    flex-direction: column;
  }
  .navbar-expand-xl .navbar-dropdown-menu-promo-item:not(:last-child) .navbar-dropdown-menu-promo-link {
    position: relative;
  }
  .navbar-expand-xl .navbar-dropdown-menu-promo-item:not(:last-child) .navbar-dropdown-menu-promo-link::after {
    position: absolute;
    top: 0;
    right: 0;
    margin-right: -0.75rem;
    border-right: 0.0625rem solid rgba(220, 224, 229, 0.6);
    height: 100%;
    content: "";
  }
}

@media (min-width: 1400px) {
  .navbar-expand-xxl .navbar-toggler {
    order: 1;
  }
  .navbar-expand-xxl .navbar-collapse {
    width: auto;
    order: 2;
  }
  .navbar-expand-xxl .navbar-nav-wrap-secondary-content {
    order: 3;
  }
  .navbar-expand-xxl .navbar-nav {
    align-items: center;
  }
  .navbar-expand-xxl .nav-item:not(:last-child) {
    margin-right: 0.5rem;
  }
  .navbar-expand-xxl .nav-item .nav-item {
    margin-right: 0;
  }
  .navbar-expand-xxl .navbar-topbar {
    padding-bottom: 0.25rem;
  }
  .navbar-expand-xxl .navbar-topbar .navbar-toggler {
    display: none;
  }
  .navbar-expand-xxl .navbar-topbar .navbar-topbar-collapse-toggler {
    display: none;
  }
  .navbar-expand-xxl .navbar-topbar .nav-item:not(:last-child) {
    margin-right: 0;
  }
  .navbar-expand-xxl .navbar-topbar .nav-item:last-child .nav-link {
    padding-right: 0;
  }
  .navbar-expand-xxl .dropdown-menu[data-bs-popper] {
    margin-top: 0.5rem;
  }
  .navbar-expand-xxl .dropdown-menu .hs-has-sub-menu .dropdown-menu {
    margin-top: -0.6875rem;
    margin-left: 0.5rem;
  }
  .navbar-expand-xxl .dropdown-menu .hs-has-sub-menu .dropdown-menu[data-bs-popper] {
    left: 100%;
  }
  .navbar-expand-xxl .dropdown-menu .hs-has-sub-menu .dropdown-menu::before {
    top: 0;
    left: -1rem;
    width: 1rem;
    height: 100%;
  }
  .navbar-expand-xxl .navbar-sticky-top-scroller,
.navbar-expand-xxl .navbar-absolute-top-scroller {
    width: 100%;
  }
  .navbar-expand-xxl.navbar-end .navbar-nav {
    justify-content: flex-end;
    margin-left: auto;
  }
  .navbar-expand-xxl.navbar-end .navbar-sticky-top-scroller, .navbar-expand-xxl.navbar-end .navbar-absolute-top-scroller {
    margin-left: auto;
  }
  .navbar-expand-xxl.navbar-vertical {
    flex-flow: column;
    overflow-y: scroll;
    height: 100%;
    max-height: 100vh;
  }
  .navbar-expand-xxl.navbar-vertical::-webkit-scrollbar {
    width: 0.6125rem;
  }
  .navbar-expand-xxl.navbar-vertical::-webkit-scrollbar-thumb {
    background-color: rgba(189, 197, 209, 0.6);
  }
  .navbar-expand-xxl.navbar-vertical .navbar-collapse {
    width: 100%;
    display: block !important;
  }
  .navbar-expand-xxl.navbar-vertical .navbar-nav {
    display: block;
    flex-direction: column;
    align-items: flex-start;
  }
  .navbar-expand-xxl .hs-position-right-fix {
    right: 35%;
    left: auto;
  }
  .navbar-expand-xxl .navbar-dropdown-menu-promo {
    display: flex;
    flex-flow: row wrap;
  }
  .navbar-expand-xxl .navbar-dropdown-menu-promo-item {
    display: flex;
    flex: 1 0 0%;
    flex-direction: column;
  }
  .navbar-expand-xxl .navbar-dropdown-menu-promo-item:not(:last-child) .navbar-dropdown-menu-promo-link {
    position: relative;
  }
  .navbar-expand-xxl .navbar-dropdown-menu-promo-item:not(:last-child) .navbar-dropdown-menu-promo-link::after {
    position: absolute;
    top: 0;
    right: 0;
    margin-right: -0.75rem;
    border-right: 0.0625rem solid rgba(220, 224, 229, 0.6);
    height: 100%;
    content: "";
  }
}

.navbar-expand .navbar-toggler {
  order: 1;
}
.navbar-expand .navbar-collapse {
  width: auto;
  order: 2;
}
.navbar-expand .navbar-nav-wrap-secondary-content {
  order: 3;
}
.navbar-expand .navbar-nav {
  align-items: center;
}
.navbar-expand .nav-item:not(:last-child) {
  margin-right: 0.5rem;
}
.navbar-expand .nav-item .nav-item {
  margin-right: 0;
}
.navbar-expand .navbar-topbar {
  padding-bottom: 0.25rem;
}
.navbar-expand .navbar-topbar .navbar-toggler {
  display: none;
}
.navbar-expand .navbar-topbar .navbar-topbar-collapse-toggler {
  display: none;
}
.navbar-expand .navbar-topbar .nav-item:not(:last-child) {
  margin-right: 0;
}
.navbar-expand .navbar-topbar .nav-item:last-child .nav-link {
  padding-right: 0;
}
.navbar-expand .dropdown-menu[data-bs-popper] {
  margin-top: 0.5rem;
}
.navbar-expand .dropdown-menu .hs-has-sub-menu .dropdown-menu {
  margin-top: -0.6875rem;
  margin-left: 0.5rem;
}
.navbar-expand .dropdown-menu .hs-has-sub-menu .dropdown-menu[data-bs-popper] {
  left: 100%;
}
.navbar-expand .dropdown-menu .hs-has-sub-menu .dropdown-menu::before {
  top: 0;
  left: -1rem;
  width: 1rem;
  height: 100%;
}
.navbar-expand .navbar-sticky-top-scroller,
.navbar-expand .navbar-absolute-top-scroller {
  width: 100%;
}
.navbar-expand.navbar-end .navbar-nav {
  justify-content: flex-end;
  margin-left: auto;
}
.navbar-expand.navbar-end .navbar-sticky-top-scroller, .navbar-expand.navbar-end .navbar-absolute-top-scroller {
  margin-left: auto;
}
.navbar-expand.navbar-vertical {
  flex-flow: column;
  overflow-y: scroll;
  height: 100%;
  max-height: 100vh;
}
.navbar-expand.navbar-vertical::-webkit-scrollbar {
  width: 0.6125rem;
}
.navbar-expand.navbar-vertical::-webkit-scrollbar-thumb {
  background-color: rgba(189, 197, 209, 0.6);
}
.navbar-expand.navbar-vertical .navbar-collapse {
  width: 100%;
  display: block !important;
}
.navbar-expand.navbar-vertical .navbar-nav {
  display: block;
  flex-direction: column;
  align-items: flex-start;
}
.navbar-expand .hs-position-right-fix {
  right: 35%;
  left: auto;
}
.navbar-expand .navbar-dropdown-menu-promo {
  display: flex;
  flex-flow: row wrap;
}
.navbar-expand .navbar-dropdown-menu-promo-item {
  display: flex;
  flex: 1 0 0%;
  flex-direction: column;
}
.navbar-expand .navbar-dropdown-menu-promo-item:not(:last-child) .navbar-dropdown-menu-promo-link {
  position: relative;
}
.navbar-expand .navbar-dropdown-menu-promo-item:not(:last-child) .navbar-dropdown-menu-promo-link::after {
  position: absolute;
  top: 0;
  right: 0;
  margin-right: -0.75rem;
  border-right: 0.0625rem solid rgba(220, 224, 229, 0.6);
  height: 100%;
  content: "";
}

.navbar-expand .navbar-nav-wrap-secondary-content {
  margin-left: auto;
}
.navbar-expand .navbar-nav-wrap-secondary-content ~ .navbar-toggler {
  margin-left: 0.5rem;
}
.navbar-expand .navbar-collapse {
  background-color: white;
}
.navbar-expand .navbar-nav {
  padding: 1rem 0;
}
.navbar-expand .navbar-nav .nav-item {
  margin-bottom: 0.25rem;
}
.navbar-expand .nav-link.dropdown-toggle + .dropdown-menu {
  margin-top: 0.5rem;
}
.navbar-expand .nav-divider {
  width: 100%;
  height: 0.0625rem;
  border-left: none;
  border-top: 0.1rem solid rgba(220, 224, 229, 0.6);
  margin: 0.5rem 0;
}
.navbar-expand .hs-mega-menu {
  max-width: 100% !important;
  min-width: 100% !important;
}
.navbar-expand .navbar-nav .dropdown-menu {
  box-shadow: none;
  border: 0.0625rem solid rgba(220, 224, 229, 0.6);
  margin-top: 0;
}
.navbar-expand .navbar-topbar .navbar-collapse {
  position: fixed;
  top: 0.5rem;
  left: 0.5rem;
  width: calc(100% - 1rem);
  height: auto;
  max-height: calc(100% - 3rem);
  overflow-y: scroll;
  border-radius: 0.6rem;
  box-shadow: 0rem 1rem 1.75rem 0rem rgba(45, 55, 75, 0.1);
}
.navbar-expand .navbar-topbar .navbar-collapse.collapsing, .navbar-expand .navbar-topbar .navbar-collapse.show {
  animation: navbar-topbar-collapse-scale-up 0.3s cubic-bezier(0.39, 0.575, 0.565, 1) both;
}
.navbar-expand .navbar-topbar .navbar-nav {
  padding: 0.5rem 0 0 0;
}
.navbar-expand .navbar-topbar .nav-item {
  margin-bottom: 0;
}
.navbar-expand .navbar-topbar .nav-link {
  padding-left: 1rem;
}
.navbar-expand.navbar-dark .navbar-nav, .navbar-expand.navbar-dark .navbar-topbar-collapse-toggler {
  background-color: #2d374b;
}
.navbar-expand.navbar-vertical .navbar-nav {
  padding: 0;
}
.navbar-expand .navbar-dropdown-menu-promo:not(:first-child) .navbar-dropdown-menu-promo-item::after {
  top: -0.375rem;
}
.navbar-expand .navbar-dropdown-menu-promo:first-child .navbar-dropdown-menu-promo-item {
  position: relative;
}
.navbar-expand .navbar-dropdown-menu-promo:first-child .navbar-dropdown-menu-promo-item::after {
  position: absolute;
  bottom: -0.375rem;
  right: 0;
  border-bottom: 0.0625rem solid rgba(220, 224, 229, 0.6);
  width: 100%;
  content: "";
}
.navbar-expand .navbar-dropdown-menu-promo:not(:first-child) .navbar-dropdown-menu-promo-item:first-child::after {
  border-top-width: 0;
}
.navbar-expand .navbar-absolute-top-inner {
  background-color: white;
}

@media (max-width: 575.98px) {
  .navbar-expand-sm .navbar-nav-wrap-secondary-content {
    margin-left: auto;
  }
  .navbar-expand-sm .navbar-nav-wrap-secondary-content ~ .navbar-toggler {
    margin-left: 0.5rem;
  }
  .navbar-expand-sm .navbar-collapse {
    background-color: white;
  }
  .navbar-expand-sm .navbar-nav {
    padding: 1rem 0;
  }
  .navbar-expand-sm .navbar-nav .nav-item {
    margin-bottom: 0.25rem;
  }
  .navbar-expand-sm .nav-link.dropdown-toggle + .dropdown-menu {
    margin-top: 0.5rem;
  }
  .navbar-expand-sm .nav-divider {
    width: 100%;
    height: 0.0625rem;
    border-left: none;
    border-top: 0.1rem solid rgba(220, 224, 229, 0.6);
    margin: 0.5rem 0;
  }
  .navbar-expand-sm .hs-mega-menu {
    max-width: 100% !important;
    min-width: 100% !important;
  }
  .navbar-expand-sm .navbar-nav .dropdown-menu {
    box-shadow: none;
    border: 0.0625rem solid rgba(220, 224, 229, 0.6);
    margin-top: 0;
  }
  .navbar-expand-sm .navbar-topbar .navbar-collapse {
    position: fixed;
    top: 0.5rem;
    left: 0.5rem;
    width: calc(100% - 1rem);
    height: auto;
    max-height: calc(100% - 3rem);
    overflow-y: scroll;
    border-radius: 0.6rem;
    box-shadow: 0rem 1rem 1.75rem 0rem rgba(45, 55, 75, 0.1);
  }
  .navbar-expand-sm .navbar-topbar .navbar-collapse.collapsing, .navbar-expand-sm .navbar-topbar .navbar-collapse.show {
    animation: navbar-topbar-collapse-scale-up 0.3s cubic-bezier(0.39, 0.575, 0.565, 1) both;
  }
  .navbar-expand-sm .navbar-topbar .navbar-nav {
    padding: 0.5rem 0 0 0;
  }
  .navbar-expand-sm .navbar-topbar .nav-item {
    margin-bottom: 0;
  }
  .navbar-expand-sm .navbar-topbar .nav-link {
    padding-left: 1rem;
  }
  .navbar-expand-sm.navbar-dark .navbar-nav, .navbar-expand-sm.navbar-dark .navbar-topbar-collapse-toggler {
    background-color: #2d374b;
  }
  .navbar-expand-sm.navbar-vertical .navbar-nav {
    padding: 0;
  }
  .navbar-expand-sm .navbar-dropdown-menu-promo:not(:first-child) .navbar-dropdown-menu-promo-item::after {
    top: -0.375rem;
  }
  .navbar-expand-sm .navbar-dropdown-menu-promo:first-child .navbar-dropdown-menu-promo-item {
    position: relative;
  }
  .navbar-expand-sm .navbar-dropdown-menu-promo:first-child .navbar-dropdown-menu-promo-item::after {
    position: absolute;
    bottom: -0.375rem;
    right: 0;
    border-bottom: 0.0625rem solid rgba(220, 224, 229, 0.6);
    width: 100%;
    content: "";
  }
  .navbar-expand-sm .navbar-dropdown-menu-promo:not(:first-child) .navbar-dropdown-menu-promo-item:first-child::after {
    border-top-width: 0;
  }
  .navbar-expand-sm .navbar-absolute-top-inner {
    background-color: white;
  }
}

@media (max-width: 767.98px) {
  .navbar-expand-md .navbar-nav-wrap-secondary-content {
    margin-left: auto;
  }
  .navbar-expand-md .navbar-nav-wrap-secondary-content ~ .navbar-toggler {
    margin-left: 0.5rem;
  }
  .navbar-expand-md .navbar-collapse {
    background-color: white;
  }
  .navbar-expand-md .navbar-nav {
    padding: 1rem 0;
  }
  .navbar-expand-md .navbar-nav .nav-item {
    margin-bottom: 0.25rem;
  }
  .navbar-expand-md .nav-link.dropdown-toggle + .dropdown-menu {
    margin-top: 0.5rem;
  }
  .navbar-expand-md .nav-divider {
    width: 100%;
    height: 0.0625rem;
    border-left: none;
    border-top: 0.1rem solid rgba(220, 224, 229, 0.6);
    margin: 0.5rem 0;
  }
  .navbar-expand-md .hs-mega-menu {
    max-width: 100% !important;
    min-width: 100% !important;
  }
  .navbar-expand-md .navbar-nav .dropdown-menu {
    box-shadow: none;
    border: 0.0625rem solid rgba(220, 224, 229, 0.6);
    margin-top: 0;
  }
  .navbar-expand-md .navbar-topbar .navbar-collapse {
    position: fixed;
    top: 0.5rem;
    left: 0.5rem;
    width: calc(100% - 1rem);
    height: auto;
    max-height: calc(100% - 3rem);
    overflow-y: scroll;
    border-radius: 0.6rem;
    box-shadow: 0rem 1rem 1.75rem 0rem rgba(45, 55, 75, 0.1);
  }
  .navbar-expand-md .navbar-topbar .navbar-collapse.collapsing, .navbar-expand-md .navbar-topbar .navbar-collapse.show {
    animation: navbar-topbar-collapse-scale-up 0.3s cubic-bezier(0.39, 0.575, 0.565, 1) both;
  }
  .navbar-expand-md .navbar-topbar .navbar-nav {
    padding: 0.5rem 0 0 0;
  }
  .navbar-expand-md .navbar-topbar .nav-item {
    margin-bottom: 0;
  }
  .navbar-expand-md .navbar-topbar .nav-link {
    padding-left: 1rem;
  }
  .navbar-expand-md.navbar-dark .navbar-nav, .navbar-expand-md.navbar-dark .navbar-topbar-collapse-toggler {
    background-color: #2d374b;
  }
  .navbar-expand-md.navbar-vertical .navbar-nav {
    padding: 0;
  }
  .navbar-expand-md .navbar-dropdown-menu-promo:not(:first-child) .navbar-dropdown-menu-promo-item::after {
    top: -0.375rem;
  }
  .navbar-expand-md .navbar-dropdown-menu-promo:first-child .navbar-dropdown-menu-promo-item {
    position: relative;
  }
  .navbar-expand-md .navbar-dropdown-menu-promo:first-child .navbar-dropdown-menu-promo-item::after {
    position: absolute;
    bottom: -0.375rem;
    right: 0;
    border-bottom: 0.0625rem solid rgba(220, 224, 229, 0.6);
    width: 100%;
    content: "";
  }
  .navbar-expand-md .navbar-dropdown-menu-promo:not(:first-child) .navbar-dropdown-menu-promo-item:first-child::after {
    border-top-width: 0;
  }
  .navbar-expand-md .navbar-absolute-top-inner {
    background-color: white;
  }
}

@media (max-width: 991.98px) {
  .navbar-expand-lg .navbar-nav-wrap-secondary-content {
    margin-left: auto;
  }
  .navbar-expand-lg .navbar-nav-wrap-secondary-content ~ .navbar-toggler {
    margin-left: 0.5rem;
  }
  .navbar-expand-lg .navbar-collapse {
    background-color: white;
  }
  .navbar-expand-lg .navbar-nav {
    padding: 1rem 0;
  }
  .navbar-expand-lg .navbar-nav .nav-item {
    margin-bottom: 0.25rem;
  }
  .navbar-expand-lg .nav-link.dropdown-toggle + .dropdown-menu {
    margin-top: 0.5rem;
  }
  .navbar-expand-lg .nav-divider {
    width: 100%;
    height: 0.0625rem;
    border-left: none;
    border-top: 0.1rem solid rgba(220, 224, 229, 0.6);
    margin: 0.5rem 0;
  }
  .navbar-expand-lg .hs-mega-menu {
    max-width: 100% !important;
    min-width: 100% !important;
  }
  .navbar-expand-lg .navbar-nav .dropdown-menu {
    box-shadow: none;
    border: 0.0625rem solid rgba(220, 224, 229, 0.6);
    margin-top: 0;
  }
  .navbar-expand-lg .navbar-topbar .navbar-collapse {
    position: fixed;
    top: 0.5rem;
    left: 0.5rem;
    width: calc(100% - 1rem);
    height: auto;
    max-height: calc(100% - 3rem);
    overflow-y: scroll;
    border-radius: 0.6rem;
    box-shadow: 0rem 1rem 1.75rem 0rem rgba(45, 55, 75, 0.1);
  }
  .navbar-expand-lg .navbar-topbar .navbar-collapse.collapsing, .navbar-expand-lg .navbar-topbar .navbar-collapse.show {
    animation: navbar-topbar-collapse-scale-up 0.3s cubic-bezier(0.39, 0.575, 0.565, 1) both;
  }
  .navbar-expand-lg .navbar-topbar .navbar-nav {
    padding: 0.5rem 0 0 0;
  }
  .navbar-expand-lg .navbar-topbar .nav-item {
    margin-bottom: 0;
  }
  .navbar-expand-lg .navbar-topbar .nav-link {
    padding-left: 1rem;
  }
  .navbar-expand-lg.navbar-dark .navbar-nav, .navbar-expand-lg.navbar-dark .navbar-topbar-collapse-toggler {
    background-color: #2d374b;
  }
  .navbar-expand-lg.navbar-vertical .navbar-nav {
    padding: 0;
  }
  .navbar-expand-lg .navbar-dropdown-menu-promo:not(:first-child) .navbar-dropdown-menu-promo-item::after {
    top: -0.375rem;
  }
  .navbar-expand-lg .navbar-dropdown-menu-promo:first-child .navbar-dropdown-menu-promo-item {
    position: relative;
  }
  .navbar-expand-lg .navbar-dropdown-menu-promo:first-child .navbar-dropdown-menu-promo-item::after {
    position: absolute;
    bottom: -0.375rem;
    right: 0;
    border-bottom: 0.0625rem solid rgba(220, 224, 229, 0.6);
    width: 100%;
    content: "";
  }
  .navbar-expand-lg .navbar-dropdown-menu-promo:not(:first-child) .navbar-dropdown-menu-promo-item:first-child::after {
    border-top-width: 0;
  }
  .navbar-expand-lg .navbar-absolute-top-inner {
    background-color: white;
  }
}

@media (max-width: 1199.98px) {
  .navbar-expand-xl .navbar-nav-wrap-secondary-content {
    margin-left: auto;
  }
  .navbar-expand-xl .navbar-nav-wrap-secondary-content ~ .navbar-toggler {
    margin-left: 0.5rem;
  }
  .navbar-expand-xl .navbar-collapse {
    background-color: white;
  }
  .navbar-expand-xl .navbar-nav {
    padding: 1rem 0;
  }
  .navbar-expand-xl .navbar-nav .nav-item {
    margin-bottom: 0.25rem;
  }
  .navbar-expand-xl .nav-link.dropdown-toggle + .dropdown-menu {
    margin-top: 0.5rem;
  }
  .navbar-expand-xl .nav-divider {
    width: 100%;
    height: 0.0625rem;
    border-left: none;
    border-top: 0.1rem solid rgba(220, 224, 229, 0.6);
    margin: 0.5rem 0;
  }
  .navbar-expand-xl .hs-mega-menu {
    max-width: 100% !important;
    min-width: 100% !important;
  }
  .navbar-expand-xl .navbar-nav .dropdown-menu {
    box-shadow: none;
    border: 0.0625rem solid rgba(220, 224, 229, 0.6);
    margin-top: 0;
  }
  .navbar-expand-xl .navbar-topbar .navbar-collapse {
    position: fixed;
    top: 0.5rem;
    left: 0.5rem;
    width: calc(100% - 1rem);
    height: auto;
    max-height: calc(100% - 3rem);
    overflow-y: scroll;
    border-radius: 0.6rem;
    box-shadow: 0rem 1rem 1.75rem 0rem rgba(45, 55, 75, 0.1);
  }
  .navbar-expand-xl .navbar-topbar .navbar-collapse.collapsing, .navbar-expand-xl .navbar-topbar .navbar-collapse.show {
    animation: navbar-topbar-collapse-scale-up 0.3s cubic-bezier(0.39, 0.575, 0.565, 1) both;
  }
  .navbar-expand-xl .navbar-topbar .navbar-nav {
    padding: 0.5rem 0 0 0;
  }
  .navbar-expand-xl .navbar-topbar .nav-item {
    margin-bottom: 0;
  }
  .navbar-expand-xl .navbar-topbar .nav-link {
    padding-left: 1rem;
  }
  .navbar-expand-xl.navbar-dark .navbar-nav, .navbar-expand-xl.navbar-dark .navbar-topbar-collapse-toggler {
    background-color: #2d374b;
  }
  .navbar-expand-xl.navbar-vertical .navbar-nav {
    padding: 0;
  }
  .navbar-expand-xl .navbar-dropdown-menu-promo:not(:first-child) .navbar-dropdown-menu-promo-item::after {
    top: -0.375rem;
  }
  .navbar-expand-xl .navbar-dropdown-menu-promo:first-child .navbar-dropdown-menu-promo-item {
    position: relative;
  }
  .navbar-expand-xl .navbar-dropdown-menu-promo:first-child .navbar-dropdown-menu-promo-item::after {
    position: absolute;
    bottom: -0.375rem;
    right: 0;
    border-bottom: 0.0625rem solid rgba(220, 224, 229, 0.6);
    width: 100%;
    content: "";
  }
  .navbar-expand-xl .navbar-dropdown-menu-promo:not(:first-child) .navbar-dropdown-menu-promo-item:first-child::after {
    border-top-width: 0;
  }
  .navbar-expand-xl .navbar-absolute-top-inner {
    background-color: white;
  }
}

@media (max-width: 1399.98px) {
  .navbar-expand-xxl .navbar-nav-wrap-secondary-content {
    margin-left: auto;
  }
  .navbar-expand-xxl .navbar-nav-wrap-secondary-content ~ .navbar-toggler {
    margin-left: 0.5rem;
  }
  .navbar-expand-xxl .navbar-collapse {
    background-color: white;
  }
  .navbar-expand-xxl .navbar-nav {
    padding: 1rem 0;
  }
  .navbar-expand-xxl .navbar-nav .nav-item {
    margin-bottom: 0.25rem;
  }
  .navbar-expand-xxl .nav-link.dropdown-toggle + .dropdown-menu {
    margin-top: 0.5rem;
  }
  .navbar-expand-xxl .nav-divider {
    width: 100%;
    height: 0.0625rem;
    border-left: none;
    border-top: 0.1rem solid rgba(220, 224, 229, 0.6);
    margin: 0.5rem 0;
  }
  .navbar-expand-xxl .hs-mega-menu {
    max-width: 100% !important;
    min-width: 100% !important;
  }
  .navbar-expand-xxl .navbar-nav .dropdown-menu {
    box-shadow: none;
    border: 0.0625rem solid rgba(220, 224, 229, 0.6);
    margin-top: 0;
  }
  .navbar-expand-xxl .navbar-topbar .navbar-collapse {
    position: fixed;
    top: 0.5rem;
    left: 0.5rem;
    width: calc(100% - 1rem);
    height: auto;
    max-height: calc(100% - 3rem);
    overflow-y: scroll;
    border-radius: 0.6rem;
    box-shadow: 0rem 1rem 1.75rem 0rem rgba(45, 55, 75, 0.1);
  }
  .navbar-expand-xxl .navbar-topbar .navbar-collapse.collapsing, .navbar-expand-xxl .navbar-topbar .navbar-collapse.show {
    animation: navbar-topbar-collapse-scale-up 0.3s cubic-bezier(0.39, 0.575, 0.565, 1) both;
  }
  .navbar-expand-xxl .navbar-topbar .navbar-nav {
    padding: 0.5rem 0 0 0;
  }
  .navbar-expand-xxl .navbar-topbar .nav-item {
    margin-bottom: 0;
  }
  .navbar-expand-xxl .navbar-topbar .nav-link {
    padding-left: 1rem;
  }
  .navbar-expand-xxl.navbar-dark .navbar-nav, .navbar-expand-xxl.navbar-dark .navbar-topbar-collapse-toggler {
    background-color: #2d374b;
  }
  .navbar-expand-xxl.navbar-vertical .navbar-nav {
    padding: 0;
  }
  .navbar-expand-xxl .navbar-dropdown-menu-promo:not(:first-child) .navbar-dropdown-menu-promo-item::after {
    top: -0.375rem;
  }
  .navbar-expand-xxl .navbar-dropdown-menu-promo:first-child .navbar-dropdown-menu-promo-item {
    position: relative;
  }
  .navbar-expand-xxl .navbar-dropdown-menu-promo:first-child .navbar-dropdown-menu-promo-item::after {
    position: absolute;
    bottom: -0.375rem;
    right: 0;
    border-bottom: 0.0625rem solid rgba(220, 224, 229, 0.6);
    width: 100%;
    content: "";
  }
  .navbar-expand-xxl .navbar-dropdown-menu-promo:not(:first-child) .navbar-dropdown-menu-promo-item:first-child::after {
    border-top-width: 0;
  }
  .navbar-expand-xxl .navbar-absolute-top-inner {
    background-color: white;
  }
}

.navbar-expand .navbar-nav .nav-subtitle,
.navbar-expand .navbar-nav .nav-link {
  padding-right: 0.75rem;
  padding-left: 0.75rem;
}

/*------------------------------------
  Navbar Sidebar
------------------------------------*/
.navbar-sidebar-aside-content {
  padding-left: 0.75rem;
  padding-right: 0.75rem;
}

@media (min-width: 576px) {
  .navbar-sidebar-aside-sm .navbar-sidebar {
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    width: 17rem;
    padding: 0;
  }
  .navbar-sidebar-aside-sm .navbar-sidebar .navbar-collapse {
    width: 100%;
  }
  .navbar-sidebar-aside-sm .navbar-sidebar .navbar-brand-wrapper {
    position: fixed;
    top: 0;
    left: 0;
    width: 17rem;
    height: 5rem;
    background-color: white;
    z-index: 99;
    padding: 1.25rem 1.5rem;
    border-bottom: 0.0625rem solid rgba(220, 224, 229, 0.6);
  }
  .navbar-sidebar-aside-sm .navbar-sidebar .navbar-brand {
    display: flex;
    flex-shrink: 0;
    align-items: center;
    margin-right: 0;
  }
  .navbar-sidebar-aside-sm .navbar-sidebar .navbar-nav {
    padding-top: 1.25rem;
    padding-bottom: 1.25rem;
  }
  .navbar-sidebar-aside-sm .navbar-sidebar .navbar-sidebar-aside-body {
    padding-top: 6.25rem;
  }
  .navbar-sidebar-aside-sm .navbar-sidebar-aside-content {
    margin-left: 17rem;
  }
}
@media (min-width: 768px) {
  .navbar-sidebar-aside-md .navbar-sidebar {
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    width: 17rem;
    padding: 0;
  }
  .navbar-sidebar-aside-md .navbar-sidebar .navbar-collapse {
    width: 100%;
  }
  .navbar-sidebar-aside-md .navbar-sidebar .navbar-brand-wrapper {
    position: fixed;
    top: 0;
    left: 0;
    width: 17rem;
    height: 5rem;
    background-color: white;
    z-index: 99;
    padding: 1.25rem 1.5rem;
    border-bottom: 0.0625rem solid rgba(220, 224, 229, 0.6);
  }
  .navbar-sidebar-aside-md .navbar-sidebar .navbar-brand {
    display: flex;
    flex-shrink: 0;
    align-items: center;
    margin-right: 0;
  }
  .navbar-sidebar-aside-md .navbar-sidebar .navbar-nav {
    padding-top: 1.25rem;
    padding-bottom: 1.25rem;
  }
  .navbar-sidebar-aside-md .navbar-sidebar .navbar-sidebar-aside-body {
    padding-top: 6.25rem;
  }
  .navbar-sidebar-aside-md .navbar-sidebar-aside-content {
    margin-left: 17rem;
  }
}
@media (min-width: 992px) {
  .navbar-sidebar-aside-lg .navbar-sidebar {
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    width: 17rem;
    padding: 0;
  }
  .navbar-sidebar-aside-lg .navbar-sidebar .navbar-collapse {
    width: 100%;
  }
  .navbar-sidebar-aside-lg .navbar-sidebar .navbar-brand-wrapper {
    position: fixed;
    top: 0;
    left: 0;
    width: 17rem;
    height: 5rem;
    background-color: white;
    z-index: 99;
    padding: 1.25rem 1.5rem;
    border-bottom: 0.0625rem solid rgba(220, 224, 229, 0.6);
  }
  .navbar-sidebar-aside-lg .navbar-sidebar .navbar-brand {
    display: flex;
    flex-shrink: 0;
    align-items: center;
    margin-right: 0;
  }
  .navbar-sidebar-aside-lg .navbar-sidebar .navbar-nav {
    padding-top: 1.25rem;
    padding-bottom: 1.25rem;
  }
  .navbar-sidebar-aside-lg .navbar-sidebar .navbar-sidebar-aside-body {
    padding-top: 6.25rem;
  }
  .navbar-sidebar-aside-lg .navbar-sidebar-aside-content {
    margin-left: 17rem;
  }
}
@media (min-width: 1200px) {
  .navbar-sidebar-aside-xl .navbar-sidebar {
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    width: 17rem;
    padding: 0;
  }
  .navbar-sidebar-aside-xl .navbar-sidebar .navbar-collapse {
    width: 100%;
  }
  .navbar-sidebar-aside-xl .navbar-sidebar .navbar-brand-wrapper {
    position: fixed;
    top: 0;
    left: 0;
    width: 17rem;
    height: 5rem;
    background-color: white;
    z-index: 99;
    padding: 1.25rem 1.5rem;
    border-bottom: 0.0625rem solid rgba(220, 224, 229, 0.6);
  }
  .navbar-sidebar-aside-xl .navbar-sidebar .navbar-brand {
    display: flex;
    flex-shrink: 0;
    align-items: center;
    margin-right: 0;
  }
  .navbar-sidebar-aside-xl .navbar-sidebar .navbar-nav {
    padding-top: 1.25rem;
    padding-bottom: 1.25rem;
  }
  .navbar-sidebar-aside-xl .navbar-sidebar .navbar-sidebar-aside-body {
    padding-top: 6.25rem;
  }
  .navbar-sidebar-aside-xl .navbar-sidebar-aside-content {
    margin-left: 17rem;
  }
}
@media (min-width: 1400px) {
  .navbar-sidebar-aside-xxl .navbar-sidebar {
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    width: 17rem;
    padding: 0;
  }
  .navbar-sidebar-aside-xxl .navbar-sidebar .navbar-collapse {
    width: 100%;
  }
  .navbar-sidebar-aside-xxl .navbar-sidebar .navbar-brand-wrapper {
    position: fixed;
    top: 0;
    left: 0;
    width: 17rem;
    height: 5rem;
    background-color: white;
    z-index: 99;
    padding: 1.25rem 1.5rem;
    border-bottom: 0.0625rem solid rgba(220, 224, 229, 0.6);
  }
  .navbar-sidebar-aside-xxl .navbar-sidebar .navbar-brand {
    display: flex;
    flex-shrink: 0;
    align-items: center;
    margin-right: 0;
  }
  .navbar-sidebar-aside-xxl .navbar-sidebar .navbar-nav {
    padding-top: 1.25rem;
    padding-bottom: 1.25rem;
  }
  .navbar-sidebar-aside-xxl .navbar-sidebar .navbar-sidebar-aside-body {
    padding-top: 6.25rem;
  }
  .navbar-sidebar-aside-xxl .navbar-sidebar-aside-content {
    margin-left: 17rem;
  }
}
.navbar-sidebar-aside .navbar-sidebar {
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  width: 17rem;
  padding: 0;
}
.navbar-sidebar-aside .navbar-sidebar .navbar-collapse {
  width: 100%;
}
.navbar-sidebar-aside .navbar-sidebar .navbar-brand-wrapper {
  position: fixed;
  top: 0;
  left: 0;
  width: 17rem;
  height: 5rem;
  background-color: white;
  z-index: 99;
  padding: 1.25rem 1.5rem;
  border-bottom: 0.0625rem solid rgba(220, 224, 229, 0.6);
}
.navbar-sidebar-aside .navbar-sidebar .navbar-brand {
  display: flex;
  flex-shrink: 0;
  align-items: center;
  margin-right: 0;
}
.navbar-sidebar-aside .navbar-sidebar .navbar-nav {
  padding-top: 1.25rem;
  padding-bottom: 1.25rem;
}
.navbar-sidebar-aside .navbar-sidebar .navbar-sidebar-aside-body {
  padding-top: 6.25rem;
}
.navbar-sidebar-aside .navbar-sidebar-aside-content {
  margin-left: 17rem;
}

.navbar-sidebar-aside .navbar-sidebar .navbar-brand,
.navbar-sidebar-aside .navbar-sidebar .navbar-brand-badge {
  display: none;
}
.navbar-sidebar-aside .nav-segment {
  margin: 1.25rem 1.5rem;
}

@media (max-width: 575.98px) {
  .navbar-sidebar-aside-sm .navbar-sidebar .navbar-brand,
.navbar-sidebar-aside-sm .navbar-sidebar .navbar-brand-badge {
    display: none;
  }
  .navbar-sidebar-aside-sm .nav-segment {
    margin: 1.25rem 1.5rem;
  }
}
@media (max-width: 767.98px) {
  .navbar-sidebar-aside-md .navbar-sidebar .navbar-brand,
.navbar-sidebar-aside-md .navbar-sidebar .navbar-brand-badge {
    display: none;
  }
  .navbar-sidebar-aside-md .nav-segment {
    margin: 1.25rem 1.5rem;
  }
}
@media (max-width: 991.98px) {
  .navbar-sidebar-aside-lg .navbar-sidebar .navbar-brand,
.navbar-sidebar-aside-lg .navbar-sidebar .navbar-brand-badge {
    display: none;
  }
  .navbar-sidebar-aside-lg .nav-segment {
    margin: 1.25rem 1.5rem;
  }
}
@media (max-width: 1199.98px) {
  .navbar-sidebar-aside-xl .navbar-sidebar .navbar-brand,
.navbar-sidebar-aside-xl .navbar-sidebar .navbar-brand-badge {
    display: none;
  }
  .navbar-sidebar-aside-xl .nav-segment {
    margin: 1.25rem 1.5rem;
  }
}
@media (max-width: 1399.98px) {
  .navbar-sidebar-aside-xxl .navbar-sidebar .navbar-brand,
.navbar-sidebar-aside-xxl .navbar-sidebar .navbar-brand-badge {
    display: none;
  }
  .navbar-sidebar-aside-xxl .nav-segment {
    margin: 1.25rem 1.5rem;
  }
}
/*------------------------------------
  Navbar Skins
------------------------------------*/
.navbar-light .navbar-brand, .navbar-light .navbar-brand:hover, .navbar-light .navbar-brand:focus {
  color: #51596C;
}
.navbar-light .navbar-toggler {
  color: #51596C;
  border-color: rgba(220, 224, 229, 0.6);
}
.navbar-light .navbar-nav .nav-link {
  color: #2d374b;
}
.navbar-light .navbar-nav .nav-link.active, .navbar-light .navbar-nav .nav-link:hover, .navbar-light .navbar-nav .nav-link:focus {
  color: #2d374b;
}
.navbar-light .navbar-topbar .nav-link:hover {
  color: #0abf53;
}

.navbar-dark .navbar-nav .nav-item:hover .nav-link, .navbar-dark .navbar-nav .nav-item:hover .nav-link:hover, .navbar-dark .navbar-nav .nav-item:hover .nav-link:focus {
  color: white;
}
.navbar-dark .nav-link.dropdown-toggle::after {
  background-image: url("data:image/svg+xml,<svg width='24' height='24' viewBox='0 0 24 24' fill='rgba(255, 255, 255, 0.55)' xmlns='http://www.w3.org/2000/svg'><path d='M12.72,15.78a.75.75,0,0,1-.53.22h-.38a.77.77,0,0,1-.53-.22L6.15,10.64a.5.5,0,0,1,0-.71l.71-.71a.49.49,0,0,1,.7,0L12,13.67l4.44-4.45a.5.5,0,0,1,.71,0l.7.71a.5.5,0,0,1,0,.71Z'/></svg>");
}
.navbar-dark .nav-divider {
  border-color: rgba(255, 255, 255, 0.2);
}
.navbar-dark .navbar-topbar .navbar-topbar-toggler-text {
  color: white;
}
.navbar-dark .navbar-topbar .navbar-topbar-collapse-toggler {
  border-bottom-color: rgba(255, 255, 255, 0.2);
}

/*------------------------------------
  Navbar Helpers
------------------------------------*/
.navbar-invisible {
  display: none;
}

.navbar-moved-up {
  transform: translate3d(0, -100%, 0);
}

.navbar-faded {
  opacity: 0;
  visibility: hidden;
}

.navbar-section-hidden {
  position: relative;
}

.navbar[data-hs-header-options*=fixMoment] {
  transition: 0.3s ease;
}

.navbar.navbar-untransitioned {
  transition: none;
}

.navbar.navbar-scrolled {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: auto;
}

.navbar-fix-top {
  position: fixed;
}

.navbar.navbar-fix-top[data-hs-header-options*=effectCompensation] {
  transition: none;
}

/*------------------------------------
  Pagination
------------------------------------*/
.page-link {
  min-width: 2.25rem;
  font-weight: 500;
  text-align: center;
  margin-left: 0.25rem;
  margin-right: 0.25rem;
  border-radius: 50%;
}

/*------------------------------------
  Popover
------------------------------------*/
.popover {
  box-shadow: 0rem 1rem 1.75rem 0rem rgba(45, 55, 75, 0.1);
}

.popover-header {
  font-size: 1.125rem;
  font-weight: 500;
}

/*------------------------------------
  Vertical Progress Bar
------------------------------------*/
.progress-vertical {
  display: flex;
  flex-flow: column nowrap;
  justify-content: flex-end;
  background-color: #dce0e5;
  width: 0.5rem;
  height: 12.5rem;
}

/*------------------------------------
  Shapes
------------------------------------*/
.shape-container {
  position: relative;
}

.shape[class*=text-] > svg [fill]:not([fill=none]) {
  fill: currentColor !important;
}

.shape {
  position: absolute;
  z-index: -1;
}

.shape-top {
  top: 0;
  left: 0;
  right: 0;
}
.shape-top > svg {
  width: 100%;
  height: auto;
  margin-bottom: -1px;
  transform-origin: bottom center;
}

.shape-bottom {
  bottom: 0;
  left: 0;
  right: 0;
}
.shape-bottom > svg {
  width: 100%;
  height: auto;
  margin-bottom: -1px;
  transform-origin: top center;
}

/*------------------------------------
  Sliding Image
------------------------------------*/
.sliding-img {
  width: 100%;
  height: 281px;
  overflow: hidden;
}

.sliding-img-frame-to-start,
.sliding-img-frame-to-start-sm,
.sliding-img-frame-to-end {
  width: 2880px;
  height: 281px;
  background-size: 2880px 281px;
}

.sliding-img-frame-to-start {
  animation: sliding-img-frame-to-start 60s linear infinite;
}

.sliding-img-frame-to-start-sm {
  animation: sliding-img-frame-to-start-sm 90s linear infinite;
}

.sliding-img-frame-to-end {
  animation: sliding-img-frame-to-end 60s linear infinite;
}

@keyframes sliding-img-frame-to-start {
  from {
    background-position-x: 0;
  }
  to {
    background-position-x: -2880px;
  }
}
@keyframes sliding-img-frame-to-start-sm {
  from {
    background-position-x: 0;
  }
  to {
    background-position-x: -2880px;
  }
}
@keyframes sliding-img-frame-to-end {
  from {
    background-position-x: 0;
  }
  to {
    background-position-x: 2880px;
  }
}
/*------------------------------------
  Step
------------------------------------*/
.step {
  position: relative;
  list-style: none;
  display: flex;
  flex-wrap: wrap;
  padding-left: 0;
  margin-right: calc(1.5rem / -2);
  margin-left: calc(1.5rem / -2);
}

.step.step-dashed .step-icon::after {
  border-left-style: dashed;
}

.step-icon-border {
  border: 0.125rem solid rgba(220, 224, 229, 0.6);
}

.step-title {
  display: block;
  color: #2d374b;
  font-weight: 600;
}

.step-text:last-child {
  color: #51596C;
  margin-bottom: 0;
}

.step-border-last-0 .step-item:last-child .step-icon::after {
  display: none;
}

.step .step-item {
  display: flex;
  flex-direction: column;
  flex-basis: 0;
  flex: 0 0 100%;
  max-width: 100%;
  padding-right: 0.75rem;
  padding-left: 0.75rem;
  margin-bottom: 2.25rem;
}

.step-item-between .step-item:last-child {
  flex: 0 0 auto;
  width: auto;
}

.step .step-content-wrapper {
  position: relative;
  display: flex;
  width: 100%;
}

.step .step-content {
  flex: 1;
}

.step-item.collapse:not(.show) {
  display: none;
}

.step-item .step-title-description {
  display: none;
}

.step-item.focus .step-title-description {
  display: block;
}

/*------------------------------------
  Step Avatar
------------------------------------*/
.step .step-avatar {
  font-size: 1rem;
  font-weight: 600;
  width: 2.875rem;
  height: 2.875rem;
  border-radius: 50%;
  margin-right: 1rem;
}
.step .step-avatar-img {
  max-width: 100%;
  height: auto;
  border-radius: 50%;
}
.step .step-avatar::after {
  position: absolute;
  top: 3.625rem;
  left: 1.4375rem;
  height: calc(100% - 2.125rem);
  border-left: 0.125rem solid rgba(220, 224, 229, 0.6);
  content: "";
}

/*------------------------------------
  Step Avatar
------------------------------------*/
.step-avatar-xs .step-avatar, .step-avatar-xs.step-avatar {
  font-size: 0.75rem;
  width: 1.75rem;
  height: 1.75rem;
}
.step-avatar-xs .step-avatar::after, .step-avatar-xs.step-avatar::after {
  top: 2.5rem;
  left: 0.8125rem;
  width: 1.625rem;
  height: calc(100% - 1rem);
}
.step-avatar-xs .step-divider::after {
  left: 0.875rem;
}

.step-avatar-sm .step-avatar, .step-avatar-sm.step-avatar {
  font-size: 0.8125rem;
  width: 2.3125rem;
  height: 2.3125rem;
}
.step-avatar-sm .step-avatar::after, .step-avatar-sm.step-avatar::after {
  top: 3.0625rem;
  left: 1.09375rem;
  width: 1.625rem;
  height: calc(100% - 1.5625rem);
}
.step-avatar-sm .step-divider::after {
  left: 1.15625rem;
}

.step-avatar-lg .step-avatar, .step-avatar-lg.step-avatar {
  font-size: 1.125rem;
  width: 5.5rem;
  height: 5.5rem;
}
.step-avatar-lg .step-avatar::after, .step-avatar-lg.step-avatar::after {
  top: 6.25rem;
  left: 2.6875rem;
  width: 1.625rem;
  height: calc(100% - 4.75rem);
}
.step-avatar-lg .step-divider::after {
  left: 2.75rem;
}

/*------------------------------------
  Step Divider
------------------------------------*/
.step-divider {
  display: inline-flex;
  align-items: center;
  text-transform: uppercase;
  height: 1rem;
  font-size: 0.8125rem;
  font-weight: 600;
}
.step-divider::after {
  position: absolute;
  top: 1.75rem;
  left: 1.4375rem;
  height: calc(100% - 0.25rem);
  border-left: 0.125rem solid rgba(220, 224, 229, 0.6);
  content: "";
}

/*------------------------------------
  Step Icon
------------------------------------*/
.step .step-icon {
  display: inline-flex;
  flex-shrink: 0;
  justify-content: center;
  align-items: center;
  font-size: 1rem;
  font-weight: 600;
  width: 2.875rem;
  height: 2.875rem;
  border-radius: 50%;
  margin-right: 1rem;
}
.step .step-icon::after {
  position: absolute;
  top: 3.625rem;
  left: 1.4375rem;
  height: calc(100% - 2.125rem);
  border-left: 0.125rem solid rgba(220, 224, 229, 0.6);
  content: "";
}
.step .step-icon-pseudo::before {
  display: block;
  width: 0.25rem;
  height: 0.25rem;
  background-color: #97A4AF;
  border-radius: 50%;
  content: "";
}

/*------------------------------------
  Step Icon Sizes
------------------------------------*/
.step-icon-xs .step-icon, .step-icon-xs.step-icon {
  font-size: 0.75rem;
  width: 1.75rem;
  height: 1.75rem;
}
.step-icon-xs .step-icon::after, .step-icon-xs.step-icon::after {
  top: 2.5rem;
  left: 0.8125rem;
  width: 1.625rem;
  height: calc(100% - 1rem);
}
.step-icon-xs .step-divider::after {
  left: 0.875rem;
}

.step-icon-sm .step-icon, .step-icon-sm.step-icon {
  font-size: 0.8125rem;
  width: 2.3125rem;
  height: 2.3125rem;
}
.step-icon-sm .step-icon::after, .step-icon-sm.step-icon::after {
  top: 3.0625rem;
  left: 1.09375rem;
  width: 1.625rem;
  height: calc(100% - 1.5625rem);
}
.step-icon-sm .step-divider::after {
  left: 1.15625rem;
}

.step-icon-lg .step-icon, .step-icon-lg.step-icon {
  font-size: 1.125rem;
  width: 5.5rem;
  height: 5.5rem;
}
.step-icon-lg .step-icon::after, .step-icon-lg.step-icon::after {
  top: 6.25rem;
  left: 2.6875rem;
  width: 1.625rem;
  height: calc(100% - 4.75rem);
}
.step-icon-lg .step-divider::after {
  left: 2.75rem;
}

/*------------------------------------
  Step Breakpoints
------------------------------------*/
@media (min-width: 576px) {
  .step-sm.step-dashed .step-icon::after {
    border-left: none;
    border-top-style: dashed;
  }
  .step-sm .step-item {
    flex-grow: 1;
    flex: 1;
    margin-bottom: 0;
  }
  .step-sm:not(.step-inline) .step-content-wrapper {
    display: block;
  }
  .step-sm .step-icon {
    margin-bottom: 1rem;
  }
  .step-sm .step-icon::after {
    top: 1.4375rem;
    left: 4.375rem;
    width: calc(100% - 4.375rem);
    height: 1.625rem;
    border-top: 0.125rem solid rgba(220, 224, 229, 0.6);
    border-left: none;
  }
  .step-sm.step-icon-xs .step-icon::after,
.step-sm .step-icon.step-icon-xs::after {
    top: 0.875rem;
    left: 3.25rem;
    width: calc(100% - 3.25rem);
  }
  .step-sm.step-icon-sm .step-icon::after,
.step-sm .step-icon.step-icon-sm::after {
    top: 1.15625rem;
    left: 3.8125rem;
    width: calc(100% - 3.8125rem);
  }
  .step-sm.step-icon-lg .step-icon::after,
.step-sm .step-icon.step-icon-lg::after {
    top: 2.75rem;
    left: 7rem;
    width: calc(100% - 7rem);
  }
}
@media (min-width: 768px) {
  .step-md.step-dashed .step-icon::after {
    border-left: none;
    border-top-style: dashed;
  }
  .step-md .step-item {
    flex-grow: 1;
    flex: 1;
    margin-bottom: 0;
  }
  .step-md:not(.step-inline) .step-content-wrapper {
    display: block;
  }
  .step-md .step-icon {
    margin-bottom: 1rem;
  }
  .step-md .step-icon::after {
    top: 1.4375rem;
    left: 4.375rem;
    width: calc(100% - 4.375rem);
    height: 1.625rem;
    border-top: 0.125rem solid rgba(220, 224, 229, 0.6);
    border-left: none;
  }
  .step-md.step-icon-xs .step-icon::after,
.step-md .step-icon.step-icon-xs::after {
    top: 0.875rem;
    left: 3.25rem;
    width: calc(100% - 3.25rem);
  }
  .step-md.step-icon-sm .step-icon::after,
.step-md .step-icon.step-icon-sm::after {
    top: 1.15625rem;
    left: 3.8125rem;
    width: calc(100% - 3.8125rem);
  }
  .step-md.step-icon-lg .step-icon::after,
.step-md .step-icon.step-icon-lg::after {
    top: 2.75rem;
    left: 7rem;
    width: calc(100% - 7rem);
  }
}
@media (min-width: 992px) {
  .step-lg.step-dashed .step-icon::after {
    border-left: none;
    border-top-style: dashed;
  }
  .step-lg .step-item {
    flex-grow: 1;
    flex: 1;
    margin-bottom: 0;
  }
  .step-lg:not(.step-inline) .step-content-wrapper {
    display: block;
  }
  .step-lg .step-icon {
    margin-bottom: 1rem;
  }
  .step-lg .step-icon::after {
    top: 1.4375rem;
    left: 4.375rem;
    width: calc(100% - 4.375rem);
    height: 1.625rem;
    border-top: 0.125rem solid rgba(220, 224, 229, 0.6);
    border-left: none;
  }
  .step-lg.step-icon-xs .step-icon::after,
.step-lg .step-icon.step-icon-xs::after {
    top: 0.875rem;
    left: 3.25rem;
    width: calc(100% - 3.25rem);
  }
  .step-lg.step-icon-sm .step-icon::after,
.step-lg .step-icon.step-icon-sm::after {
    top: 1.15625rem;
    left: 3.8125rem;
    width: calc(100% - 3.8125rem);
  }
  .step-lg.step-icon-lg .step-icon::after,
.step-lg .step-icon.step-icon-lg::after {
    top: 2.75rem;
    left: 7rem;
    width: calc(100% - 7rem);
  }
}
@media (min-width: 1200px) {
  .step-xl.step-dashed .step-icon::after {
    border-left: none;
    border-top-style: dashed;
  }
  .step-xl .step-item {
    flex-grow: 1;
    flex: 1;
    margin-bottom: 0;
  }
  .step-xl:not(.step-inline) .step-content-wrapper {
    display: block;
  }
  .step-xl .step-icon {
    margin-bottom: 1rem;
  }
  .step-xl .step-icon::after {
    top: 1.4375rem;
    left: 4.375rem;
    width: calc(100% - 4.375rem);
    height: 1.625rem;
    border-top: 0.125rem solid rgba(220, 224, 229, 0.6);
    border-left: none;
  }
  .step-xl.step-icon-xs .step-icon::after,
.step-xl .step-icon.step-icon-xs::after {
    top: 0.875rem;
    left: 3.25rem;
    width: calc(100% - 3.25rem);
  }
  .step-xl.step-icon-sm .step-icon::after,
.step-xl .step-icon.step-icon-sm::after {
    top: 1.15625rem;
    left: 3.8125rem;
    width: calc(100% - 3.8125rem);
  }
  .step-xl.step-icon-lg .step-icon::after,
.step-xl .step-icon.step-icon-lg::after {
    top: 2.75rem;
    left: 7rem;
    width: calc(100% - 7rem);
  }
}
/*------------------------------------
  Step Centered
------------------------------------*/
@media (min-width: 576px) {
  .step-sm.step-centered {
    text-align: center;
  }
  .step-sm.step-centered .step-item:last-child .step-icon::after {
    display: none;
  }
  .step-sm.step-centered .step-icon {
    margin-left: auto;
    margin-right: auto;
  }
  .step-sm.step-centered .step-icon::after {
    width: calc(100% - 4.375rem);
    left: calc(50% + 2.9375rem);
  }
  .step-sm.step-centered.step-icon-xs .step-icon::after,
.step-sm.step-centered .step-icon.step-icon-xs::after {
    width: calc(100% - 3.25rem);
    left: calc(50% + 2.375rem);
  }
  .step-sm.step-centered.step-icon-sm .step-icon::after,
.step-sm.step-centered .step-icon.step-icon-sm::after {
    width: calc(100% - 3.8125rem);
    left: calc(50% + 2.65625rem);
  }
  .step-sm.step-centered.step-icon-lg .step-icon::after,
.step-sm.step-centered .step-icon.step-icon-lg::after {
    width: calc(100% - 7rem);
    left: calc(50% + 4.25rem);
  }
}
@media (min-width: 768px) {
  .step-md.step-centered {
    text-align: center;
  }
  .step-md.step-centered .step-item:last-child .step-icon::after {
    display: none;
  }
  .step-md.step-centered .step-icon {
    margin-left: auto;
    margin-right: auto;
  }
  .step-md.step-centered .step-icon::after {
    width: calc(100% - 4.375rem);
    left: calc(50% + 2.9375rem);
  }
  .step-md.step-centered.step-icon-xs .step-icon::after,
.step-md.step-centered .step-icon.step-icon-xs::after {
    width: calc(100% - 3.25rem);
    left: calc(50% + 2.375rem);
  }
  .step-md.step-centered.step-icon-sm .step-icon::after,
.step-md.step-centered .step-icon.step-icon-sm::after {
    width: calc(100% - 3.8125rem);
    left: calc(50% + 2.65625rem);
  }
  .step-md.step-centered.step-icon-lg .step-icon::after,
.step-md.step-centered .step-icon.step-icon-lg::after {
    width: calc(100% - 7rem);
    left: calc(50% + 4.25rem);
  }
}
@media (min-width: 992px) {
  .step-lg.step-centered {
    text-align: center;
  }
  .step-lg.step-centered .step-item:last-child .step-icon::after {
    display: none;
  }
  .step-lg.step-centered .step-icon {
    margin-left: auto;
    margin-right: auto;
  }
  .step-lg.step-centered .step-icon::after {
    width: calc(100% - 4.375rem);
    left: calc(50% + 2.9375rem);
  }
  .step-lg.step-centered.step-icon-xs .step-icon::after,
.step-lg.step-centered .step-icon.step-icon-xs::after {
    width: calc(100% - 3.25rem);
    left: calc(50% + 2.375rem);
  }
  .step-lg.step-centered.step-icon-sm .step-icon::after,
.step-lg.step-centered .step-icon.step-icon-sm::after {
    width: calc(100% - 3.8125rem);
    left: calc(50% + 2.65625rem);
  }
  .step-lg.step-centered.step-icon-lg .step-icon::after,
.step-lg.step-centered .step-icon.step-icon-lg::after {
    width: calc(100% - 7rem);
    left: calc(50% + 4.25rem);
  }
}
@media (min-width: 992px) {
  .step-lg.step-centered {
    text-align: center;
  }
  .step-lg.step-centered .step-item:last-child .step-icon::after {
    display: none;
  }
  .step-lg.step-centered .step-icon {
    margin-left: auto;
    margin-right: auto;
  }
  .step-lg.step-centered .step-icon::after {
    width: calc(100% - 4.375rem);
    left: calc(50% + 2.9375rem);
  }
  .step-lg.step-centered.step-icon-xs .step-icon::after,
.step-lg.step-centered .step-icon.step-icon-xs::after {
    width: calc(100% - 3.25rem);
    left: calc(50% + 2.375rem);
  }
  .step-lg.step-centered.step-icon-sm .step-icon::after,
.step-lg.step-centered .step-icon.step-icon-sm::after {
    width: calc(100% - 3.8125rem);
    left: calc(50% + 2.65625rem);
  }
  .step-lg.step-centered.step-icon-lg .step-icon::after,
.step-lg.step-centered .step-icon.step-icon-lg::after {
    width: calc(100% - 7rem);
    left: calc(50% + 4.25rem);
  }
}
/*------------------------------------
  Step States
------------------------------------*/
.step .step-is-valid-icon,
.step .step-is-invalid-icon {
  display: none;
}
.step .active .step-icon,
.step .active.is-valid .step-icon {
  color: white;
  background-color: #0abf53;
}
.step .active .step-title,
.step .active.is-valid .step-title {
  color: #0abf53;
}
.step .is-valid .step-icon {
  color: white;
  background-color: #0abf53;
}
.step .is-valid .step-title {
  color: #0abf53;
}
.step .is-valid .step-is-valid-icon {
  display: inline-flex;
}
.step .is-valid .step-is-default-icon,
.step .is-valid .step-is-invalid-icon {
  display: none;
}
.step .is-invalid .step-icon {
  color: white;
  background-color: #692340;
}
.step .is-invalid .step-title {
  color: #692340;
}
.step .is-invalid .step-is-invalid-icon {
  display: inline-flex;
}
.step .is-invalid .step-is-default-icon,
.step .is-invalid .step-is-valid-icon {
  display: none;
}

/*------------------------------------
  Step Colors
------------------------------------*/
.step-icon-primary {
  color: white;
  background-color: #0abf53;
}
.step-icon-primary.step-icon-pseudo::before {
  background-color: white;
}

.step-icon-secondary {
  color: white;
  background-color: #51596c;
}
.step-icon-secondary.step-icon-pseudo::before {
  background-color: white;
}

.step-icon-success {
  color: white;
  background-color: #077c76;
}
.step-icon-success.step-icon-pseudo::before {
  background-color: white;
}

.step-icon-info {
  color: white;
  background-color: #334ac0;
}
.step-icon-info.step-icon-pseudo::before {
  background-color: white;
}

.step-icon-warning {
  color: #000;
  background-color: #f39568;
}
.step-icon-warning.step-icon-pseudo::before {
  background-color: #000;
}

.step-icon-danger {
  color: white;
  background-color: #692340;
}
.step-icon-danger.step-icon-pseudo::before {
  background-color: white;
}

.step-icon-light {
  color: #000;
  background-color: #f8f9fa;
}
.step-icon-light.step-icon-pseudo::before {
  background-color: #000;
}

.step-icon-dark {
  color: white;
  background-color: #2d374b;
}
.step-icon-dark.step-icon-pseudo::before {
  background-color: white;
}

.step-icon-soft-primary {
  color: #0abf53;
  background-color: rgba(10, 191, 83, 0.1);
}
.step-icon-soft-primary.step-icon-pseudo::before {
  background-color: #0abf53;
}

.step-icon-soft-secondary {
  color: #51596c;
  background-color: rgba(81, 89, 108, 0.1);
}
.step-icon-soft-secondary.step-icon-pseudo::before {
  background-color: #51596c;
}

.step-icon-soft-success {
  color: #077c76;
  background-color: rgba(7, 124, 118, 0.1);
}
.step-icon-soft-success.step-icon-pseudo::before {
  background-color: #077c76;
}

.step-icon-soft-info {
  color: #334ac0;
  background-color: rgba(51, 74, 192, 0.1);
}
.step-icon-soft-info.step-icon-pseudo::before {
  background-color: #334ac0;
}

.step-icon-soft-warning {
  color: #f39568;
  background-color: rgba(243, 149, 104, 0.1);
}
.step-icon-soft-warning.step-icon-pseudo::before {
  background-color: #f39568;
}

.step-icon-soft-danger {
  color: #692340;
  background-color: rgba(105, 35, 64, 0.1);
}
.step-icon-soft-danger.step-icon-pseudo::before {
  background-color: #692340;
}

.step-icon-soft-light {
  color: #f8f9fa;
  background-color: rgba(248, 249, 250, 0.1);
}
.step-icon-soft-light.step-icon-pseudo::before {
  background-color: #f8f9fa;
}

.step-icon-soft-dark {
  color: #2d374b;
  background-color: rgba(45, 55, 75, 0.1);
}
.step-icon-soft-dark.step-icon-pseudo::before {
  background-color: #2d374b;
}

/*------------------------------------
  Step Inline
------------------------------------*/
.step-inline .step-content-wrapper {
  align-items: center;
}
.step-inline .step-item:last-child .step-title::after {
  display: none;
}
.step-inline .step-title {
  display: inline-block;
}

@media (min-width: 576px) {
  .step-sm.step-inline.step-dashed .step-title::after {
    border-top-style: dashed;
  }
  .step-sm.step-inline .step-item {
    overflow: hidden;
  }
  .step-sm.step-inline .step-icon {
    margin-bottom: 0;
  }
  .step-sm.step-inline .step-icon::after {
    display: none;
  }
  .step-sm.step-inline .step-title::after {
    position: absolute;
    top: 1.4375rem;
    width: 100%;
    height: 1.625rem;
    border-top: 0.125rem solid rgba(220, 224, 229, 0.6);
    margin-left: 1.5rem;
    content: "";
  }
  .step-sm.step-inline.step-icon-xs .step-content .step-title::after,
.step-sm.step-inline .step-icon-xs + .step-content .step-title::after {
    top: 0.875rem;
  }
  .step-sm.step-inline.step-icon-sm .step-content .step-title::after,
.step-sm.step-inline .step-icon-sm + .step-content .step-title::after {
    top: 1.15625rem;
  }
  .step-sm.step-inline.step-icon-lg .step-content .step-title::after,
.step-sm.step-inline .step-icon-lg + .step-content .step-title::after {
    top: 2.75rem;
  }
}
@media (min-width: 768px) {
  .step-md.step-inline.step-dashed .step-title::after {
    border-top-style: dashed;
  }
  .step-md.step-inline .step-item {
    overflow: hidden;
  }
  .step-md.step-inline .step-icon {
    margin-bottom: 0;
  }
  .step-md.step-inline .step-icon::after {
    display: none;
  }
  .step-md.step-inline .step-title::after {
    position: absolute;
    top: 1.4375rem;
    width: 100%;
    height: 1.625rem;
    border-top: 0.125rem solid rgba(220, 224, 229, 0.6);
    margin-left: 1.5rem;
    content: "";
  }
  .step-md.step-inline.step-icon-xs .step-content .step-title::after,
.step-md.step-inline .step-icon-xs + .step-content .step-title::after {
    top: 0.875rem;
  }
  .step-md.step-inline.step-icon-sm .step-content .step-title::after,
.step-md.step-inline .step-icon-sm + .step-content .step-title::after {
    top: 1.15625rem;
  }
  .step-md.step-inline.step-icon-lg .step-content .step-title::after,
.step-md.step-inline .step-icon-lg + .step-content .step-title::after {
    top: 2.75rem;
  }
}
@media (min-width: 992px) {
  .step-lg.step-inline.step-dashed .step-title::after {
    border-top-style: dashed;
  }
  .step-lg.step-inline .step-item {
    overflow: hidden;
  }
  .step-lg.step-inline .step-icon {
    margin-bottom: 0;
  }
  .step-lg.step-inline .step-icon::after {
    display: none;
  }
  .step-lg.step-inline .step-title::after {
    position: absolute;
    top: 1.4375rem;
    width: 100%;
    height: 1.625rem;
    border-top: 0.125rem solid rgba(220, 224, 229, 0.6);
    margin-left: 1.5rem;
    content: "";
  }
  .step-lg.step-inline.step-icon-xs .step-content .step-title::after,
.step-lg.step-inline .step-icon-xs + .step-content .step-title::after {
    top: 0.875rem;
  }
  .step-lg.step-inline.step-icon-sm .step-content .step-title::after,
.step-lg.step-inline .step-icon-sm + .step-content .step-title::after {
    top: 1.15625rem;
  }
  .step-lg.step-inline.step-icon-lg .step-content .step-title::after,
.step-lg.step-inline .step-icon-lg + .step-content .step-title::after {
    top: 2.75rem;
  }
}
@media (min-width: 1200px) {
  .step-xl.step-inline.step-dashed .step-title::after {
    border-top-style: dashed;
  }
  .step-xl.step-inline .step-item {
    overflow: hidden;
  }
  .step-xl.step-inline .step-icon {
    margin-bottom: 0;
  }
  .step-xl.step-inline .step-icon::after {
    display: none;
  }
  .step-xl.step-inline .step-title::after {
    position: absolute;
    top: 1.4375rem;
    width: 100%;
    height: 1.625rem;
    border-top: 0.125rem solid rgba(220, 224, 229, 0.6);
    margin-left: 1.5rem;
    content: "";
  }
  .step-xl.step-inline.step-icon-xs .step-content .step-title::after,
.step-xl.step-inline .step-icon-xs + .step-content .step-title::after {
    top: 0.875rem;
  }
  .step-xl.step-inline.step-icon-sm .step-content .step-title::after,
.step-xl.step-inline .step-icon-sm + .step-content .step-title::after {
    top: 1.15625rem;
  }
  .step-xl.step-inline.step-icon-lg .step-content .step-title::after,
.step-xl.step-inline .step-icon-lg + .step-content .step-title::after {
    top: 2.75rem;
  }
}
/*------------------------------------
  Step Timeline
------------------------------------*/
@media (min-width: 576px) {
  .step-timeline-sm {
    margin-left: 0;
    margin-right: 0;
  }
  .step-timeline-sm .step-item {
    flex: 0 0 50%;
    max-width: 50%;
    padding-left: 0;
    padding-right: 0;
    margin-left: 50%;
  }
  .step-timeline-sm .step-item:nth-child(even) {
    flex-direction: row-reverse;
    text-align: right;
    margin-left: auto;
    margin-right: 50%;
  }
  .step-timeline-sm .step-item:nth-child(even) .step-content-wrapper {
    flex-direction: row-reverse;
  }
  .step-timeline-sm .step-item:nth-child(even) .step-icon {
    margin-left: 0;
    margin-right: -1.4375rem;
  }
  .step-timeline-sm .step-item:nth-child(even) .step-icon-xs {
    margin-right: -0.875rem;
  }
  .step-timeline-sm .step-item:nth-child(even) .step-icon-sm {
    margin-right: -1.15625rem;
  }
  .step-timeline-sm .step-item:nth-child(even) .step-icon-lg {
    margin-right: -2.75rem;
  }
  .step-timeline-sm .step-item:nth-child(even) .step-content {
    margin-right: 1.5rem;
  }
  .step-timeline-sm .step-icon {
    margin-left: -1.4375rem;
  }
  .step-timeline-sm .step-icon::after {
    left: auto;
    width: auto;
  }
  .step-timeline-sm .step-icon-xs {
    margin-left: -0.875rem;
  }
  .step-timeline-sm .step-icon-sm {
    margin-left: -1.15625rem;
  }
  .step-timeline-sm .step-icon-lg {
    margin-left: -2.75rem;
  }
}
@media (min-width: 768px) {
  .step-timeline-md {
    margin-left: 0;
    margin-right: 0;
  }
  .step-timeline-md .step-item {
    flex: 0 0 50%;
    max-width: 50%;
    padding-left: 0;
    padding-right: 0;
    margin-left: 50%;
  }
  .step-timeline-md .step-item:nth-child(even) {
    flex-direction: row-reverse;
    text-align: right;
    margin-left: auto;
    margin-right: 50%;
  }
  .step-timeline-md .step-item:nth-child(even) .step-content-wrapper {
    flex-direction: row-reverse;
  }
  .step-timeline-md .step-item:nth-child(even) .step-icon {
    margin-left: 0;
    margin-right: -1.4375rem;
  }
  .step-timeline-md .step-item:nth-child(even) .step-icon-xs {
    margin-right: -0.875rem;
  }
  .step-timeline-md .step-item:nth-child(even) .step-icon-sm {
    margin-right: -1.15625rem;
  }
  .step-timeline-md .step-item:nth-child(even) .step-icon-lg {
    margin-right: -2.75rem;
  }
  .step-timeline-md .step-item:nth-child(even) .step-content {
    margin-right: 1.5rem;
  }
  .step-timeline-md .step-icon {
    margin-left: -1.4375rem;
  }
  .step-timeline-md .step-icon::after {
    left: auto;
    width: auto;
  }
  .step-timeline-md .step-icon-xs {
    margin-left: -0.875rem;
  }
  .step-timeline-md .step-icon-sm {
    margin-left: -1.15625rem;
  }
  .step-timeline-md .step-icon-lg {
    margin-left: -2.75rem;
  }
}
@media (min-width: 992px) {
  .step-timeline-lg {
    margin-left: 0;
    margin-right: 0;
  }
  .step-timeline-lg .step-item {
    flex: 0 0 50%;
    max-width: 50%;
    padding-left: 0;
    padding-right: 0;
    margin-left: 50%;
  }
  .step-timeline-lg .step-item:nth-child(even) {
    flex-direction: row-reverse;
    text-align: right;
    margin-left: auto;
    margin-right: 50%;
  }
  .step-timeline-lg .step-item:nth-child(even) .step-content-wrapper {
    flex-direction: row-reverse;
  }
  .step-timeline-lg .step-item:nth-child(even) .step-icon {
    margin-left: 0;
    margin-right: -1.4375rem;
  }
  .step-timeline-lg .step-item:nth-child(even) .step-icon-xs {
    margin-right: -0.875rem;
  }
  .step-timeline-lg .step-item:nth-child(even) .step-icon-sm {
    margin-right: -1.15625rem;
  }
  .step-timeline-lg .step-item:nth-child(even) .step-icon-lg {
    margin-right: -2.75rem;
  }
  .step-timeline-lg .step-item:nth-child(even) .step-content {
    margin-right: 1.5rem;
  }
  .step-timeline-lg .step-icon {
    margin-left: -1.4375rem;
  }
  .step-timeline-lg .step-icon::after {
    left: auto;
    width: auto;
  }
  .step-timeline-lg .step-icon-xs {
    margin-left: -0.875rem;
  }
  .step-timeline-lg .step-icon-sm {
    margin-left: -1.15625rem;
  }
  .step-timeline-lg .step-icon-lg {
    margin-left: -2.75rem;
  }
}
@media (min-width: 1200px) {
  .step-timeline-xl {
    margin-left: 0;
    margin-right: 0;
  }
  .step-timeline-xl .step-item {
    flex: 0 0 50%;
    max-width: 50%;
    padding-left: 0;
    padding-right: 0;
    margin-left: 50%;
  }
  .step-timeline-xl .step-item:nth-child(even) {
    flex-direction: row-reverse;
    text-align: right;
    margin-left: auto;
    margin-right: 50%;
  }
  .step-timeline-xl .step-item:nth-child(even) .step-content-wrapper {
    flex-direction: row-reverse;
  }
  .step-timeline-xl .step-item:nth-child(even) .step-icon {
    margin-left: 0;
    margin-right: -1.4375rem;
  }
  .step-timeline-xl .step-item:nth-child(even) .step-icon-xs {
    margin-right: -0.875rem;
  }
  .step-timeline-xl .step-item:nth-child(even) .step-icon-sm {
    margin-right: -1.15625rem;
  }
  .step-timeline-xl .step-item:nth-child(even) .step-icon-lg {
    margin-right: -2.75rem;
  }
  .step-timeline-xl .step-item:nth-child(even) .step-content {
    margin-right: 1.5rem;
  }
  .step-timeline-xl .step-icon {
    margin-left: -1.4375rem;
  }
  .step-timeline-xl .step-icon::after {
    left: auto;
    width: auto;
  }
  .step-timeline-xl .step-icon-xs {
    margin-left: -0.875rem;
  }
  .step-timeline-xl .step-icon-sm {
    margin-left: -1.15625rem;
  }
  .step-timeline-xl .step-icon-lg {
    margin-left: -2.75rem;
  }
}
/*------------------------------------
  Toasts
------------------------------------*/
.toast-header .btn-close {
  margin-right: 0;
}

/*------------------------------------
  Tables
------------------------------------*/
.table th {
  font-weight: 400;
}
.table tr {
  color: #2d374b;
}
.table thead th {
  color: #2d374b;
  font-weight: 500;
}
.table > :not(:last-child) > :last-child > * {
  border-bottom-color: rgba(220, 224, 229, 0.6);
}
.table > :not(caption) > *:last-child > * {
  border-bottom-width: 0;
}
.table .btn {
  white-space: nowrap;
}

.table-nowrap th, .table-nowrap td {
  white-space: nowrap;
}

.table-align-middle tbody tr, .table-align-middle th, .table-align-middle td {
  vertical-align: middle;
}

.table-text-center, .table-text-center th, .table-text-center td {
  text-align: center;
}

.table-text-end, .table-text-end th, .table-text-end td {
  text-align: right;
}

.thead-light th {
  background-color: #f3f6f9;
}

.table-lg > :not(caption) > * > * {
  padding: 1rem 1.5rem;
}

/*------------------------------------
  Video Bg
------------------------------------*/
.video-bg {
  position: relative;
  min-height: 75vh;
}

.video-bg-content {
  position: absolute !important;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
}

.video-bg-replacer-img {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  background-size: cover;
  background-repeat: no-repeat;
  background-position: top center;
}

@media (min-width: 768px) {
  .video-bg-replacer-img {
    display: none;
  }
}
@media (max-width: 767.98px) {
  .video-bg-content {
    display: none;
  }
}
.hs-video-bg-video iframe,
.hs-video-bg-video video {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border: 0;
}

/*------------------------------------
  Video Player
------------------------------------*/
.video-player {
  position: relative;
  display: inline-block;
}

.video-player-inline-btn {
  display: block;
  background-color: #000;
}

.video-player-preview {
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  z-index: 2;
  width: 100%;
  height: 100%;
  opacity: 1;
  object-fit: cover;
  transition: opacity 0.3s ease-in-out;
}

.video-player-played .video-player-preview {
  opacity: 0;
  pointer-events: none;
}

.video-player-btn {
  z-index: 3;
  color: #2d374b;
  transition: transform 0.3s ease-in-out;
}
.video-player-played .video-player-btn {
  animation: videoPlayerButton 0.3s ease-in-out forwards;
  pointer-events: none;
}
.video-player-btn:hover .video-player-icon {
  transform: scale(1.1);
}

.video-player-icon {
  position: relative;
  display: inline-flex;
  flex-shrink: 0;
  justify-content: center;
  align-items: center;
  vertical-align: middle;
  text-align: center;
  width: 5rem;
  height: 5rem;
  font-size: 2rem;
  border-radius: 50%;
  color: #0abf53;
  background-color: white;
  backface-visibility: hidden;
  transform: perspective(1px) translateZ(0);
  transition: 0.3s;
}

.video-player-centered {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

@keyframes videoPlayerButton {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    transform: translate(-50%, -50%) scale(1.3);
  }
}
/*------------------------------------
  Background Image Style
------------------------------------*/
.bg-img-start {
  background-size: cover;
  background-repeat: no-repeat;
  background-position: top center;
}

.bg-img-end {
  background-size: cover;
  background-repeat: no-repeat;
  background-position: bottom center;
}

.bg-img-center {
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center center;
}

/*------------------------------------
  Gradients
------------------------------------*/
.bg-soft-dark-to-start-75 {
  background-image: linear-gradient(to right, rgba(255, 255, 255, 0) 25%, rgba(45, 55, 75, 0.1) 0%);
}

.bg-gradient-to-bottom-sm-light {
  background-image: linear-gradient(to bottom, #F5F7FA, transparent);
}

/*------------------------------------
  Link
------------------------------------*/
.link {
  display: inline-block;
  font-size: 0.9375rem;
}

.link-pointer {
  position: relative;
  font-weight: 500;
  padding-right: 2.5rem;
}
.link-pointer::after {
  position: absolute;
  top: 50%;
  right: 0.75rem;
  width: 1.25rem;
  height: 1.25rem;
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%230abf53' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
  background-repeat: no-repeat;
  background-position: right center;
  background-size: 1.25rem 1.25rem;
  content: "";
  transform: translateY(-50%);
  transition: 0.2s;
}
.link-pointer:hover::after, [href]:hover .link-pointer::after {
  right: 0.4375rem;
}

.link-primary.link-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%230abf53' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.link-primary:hover, .link-primary:focus {
  opacity: 0.7;
}

.link-secondary.link-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%2351596c' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.link-secondary:hover, .link-secondary:focus {
  opacity: 0.7;
}

.link-success.link-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23077c76' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.link-success:hover, .link-success:focus {
  opacity: 0.7;
}

.link-info.link-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23334ac0' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.link-info:hover, .link-info:focus {
  opacity: 0.7;
}

.link-warning.link-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23f39568' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.link-warning:hover, .link-warning:focus {
  opacity: 0.7;
}

.link-danger.link-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23692340' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.link-danger:hover, .link-danger:focus {
  opacity: 0.7;
}

.link-light.link-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%23f8f9fa' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.link-light:hover, .link-light:focus {
  opacity: 0.7;
}

.link-dark.link-pointer::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='%232d374b' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z'/%3e%3c/svg%3e");
}
.link-dark:hover, .link-dark:focus {
  opacity: 0.7;
}

.link-light-75 {
  opacity: 0.75;
}
.link-light-75:hover, .link-light-75:focus {
  opacity: 1;
}

.link-bordered {
  border-bottom: 0.125rem solid #0abf53;
}
.link-bordered.link-primary {
  border-bottom-color: #0abf53;
}
.link-bordered.link-secondary {
  border-bottom-color: #51596c;
}
.link-bordered.link-success {
  border-bottom-color: #077c76;
}
.link-bordered.link-info {
  border-bottom-color: #334ac0;
}
.link-bordered.link-warning {
  border-bottom-color: #f39568;
}
.link-bordered.link-danger {
  border-bottom-color: #692340;
}
.link-bordered.link-light {
  border-bottom-color: #f8f9fa;
}
.link-bordered.link-dark {
  border-bottom-color: #2d374b;
}

/*------------------------------------
  Typography
------------------------------------*/
.text-cap {
  display: block;
  color: #2d374b;
  font-size: 0.75rem;
  font-weight: 700;
  letter-spacing: 0.03125rem;
  text-transform: uppercase;
  margin-bottom: 1rem;
}

/*------------------------------------
  Text Colors
------------------------------------*/
.text-dark {
  color: #2d374b !important;
}
.text-dark[href]:hover {
  color: #07853a !important;
}

.text-secondary[href]:hover {
  color: #07853a !important;
}

.text-muted[href]:hover,
.text-body[href]:hover {
  color: #07853a !important;
}

a:hover .text-inherit {
  color: #07853a !important;
}

.lead {
  color: #2d374b;
}

/*------------------------------------
  Divider
------------------------------------*/
.divider-start {
  display: flex;
  align-items: center;
  color: #8997a4;
}
.divider-start::after {
  flex: 1 1 0%;
  border-top: 0.0625rem solid rgba(220, 224, 229, 0.6);
  margin-top: 0.0625rem;
  content: "";
}
.divider-start::after {
  margin-left: 1.5rem;
}

.divider-end {
  display: flex;
  align-items: center;
  color: #8997a4;
}
.divider-end::before {
  flex: 1 1 0%;
  border-top: 0.0625rem solid rgba(220, 224, 229, 0.6);
  margin-top: 0.0625rem;
  content: "";
}
.divider-end::before {
  margin-right: 1.5rem;
}

.divider-center {
  display: flex;
  align-items: center;
  color: #8997a4;
}
.divider-center::before, .divider-center::after {
  flex: 1 1 0%;
  border-top: 0.0625rem solid rgba(220, 224, 229, 0.6);
  margin-top: 0.0625rem;
  content: "";
}
.divider-center::before {
  margin-right: 1.5rem;
}
.divider-center::after {
  margin-left: 1.5rem;
}

/*------------------------------------
  Nav Scroll Horizontal
------------------------------------*/
.hs-nav-scroller-horizontal {
  position: relative;
}
.hs-nav-scroller-horizontal .nav {
  overflow-x: auto;
  overflow-y: hidden;
  flex-wrap: nowrap;
  white-space: nowrap;
  scroll-behavior: smooth;
}
.hs-nav-scroller-horizontal .nav .nav-item {
  white-space: nowrap;
}
.hs-nav-scroller-horizontal .nav .nav-link {
  white-space: normal;
}
.hs-nav-scroller-horizontal .nav::-webkit-scrollbar {
  display: none;
}
.hs-nav-scroller-horizontal .nav-tabs {
  padding-bottom: 0.1875rem;
}
.hs-nav-scroller-horizontal .hs-nav-scroller-arrow-prev,
.hs-nav-scroller-horizontal .hs-nav-scroller-arrow-next {
  position: absolute;
  height: 100%;
  z-index: 1;
  font-size: 1.5rem;
  display: flex;
  align-items: center;
}
.hs-nav-scroller-horizontal .hs-nav-scroller-arrow-link {
  width: 2.875rem;
  color: #51596C;
}
.hs-nav-scroller-horizontal .hs-nav-scroller-arrow-link:hover {
  color: #07853a;
}
.hs-nav-scroller-horizontal .hs-nav-scroller-arrow-prev {
  left: 0;
  margin-left: -0.125rem;
  background-image: linear-gradient(to right, white 50%, rgba(255, 255, 255, 0) 100%);
}
.hs-nav-scroller-horizontal .hs-nav-scroller-arrow-prev .hs-nav-scroller-arrow-link {
  padding: 0.5rem 0;
}
.hs-nav-scroller-horizontal .hs-nav-scroller-arrow-next {
  right: 0;
  margin-right: -0.125rem;
  background-image: linear-gradient(to right, rgba(255, 255, 255, 0) 0%, white 50%);
}
.hs-nav-scroller-horizontal .hs-nav-scroller-arrow-next .hs-nav-scroller-arrow-link {
  padding: 0.5rem 0;
  text-align: right;
}
.hs-nav-scroller-horizontal .hs-nav-scroller-arrow-dark-prev .hs-nav-scroller-arrow-link,
.hs-nav-scroller-horizontal .hs-nav-scroller-arrow-dark-next .hs-nav-scroller-arrow-link {
  color: rgba(255, 255, 255, 0.7);
}
.hs-nav-scroller-horizontal .hs-nav-scroller-arrow-dark-prev .hs-nav-scroller-arrow-link:hover,
.hs-nav-scroller-horizontal .hs-nav-scroller-arrow-dark-next .hs-nav-scroller-arrow-link:hover {
  color: white;
}
.hs-nav-scroller-horizontal .hs-nav-scroller-arrow-dark-prev {
  background-image: linear-gradient(to right, #2d374b 50%, rgba(255, 255, 255, 0) 100%);
}
.hs-nav-scroller-horizontal .hs-nav-scroller-arrow-dark-next {
  background-image: linear-gradient(to right, rgba(255, 255, 255, 0) 0%, #2d374b 50%);
}

.hs-nav-scroller-vertical {
  height: 100%;
  overflow: hidden;
  overflow-y: auto;
}
.hs-nav-scroller-vertical::-webkit-scrollbar {
  width: 0.6125rem;
}
.hs-nav-scroller-vertical::-webkit-scrollbar-thumb {
  background-color: rgba(189, 197, 209, 0.6);
}

.hs-nav-scroller-unfold {
  position: static;
}

/*--------------------------------------------------
  Fancybox
----------------------------------------------------*/
.fancybox-custom .fancybox-slide.animated {
  display: block;
  opacity: 0;
  z-index: 0;
}

.fancybox-custom .fancybox-slide.animated.fancybox-slide--current {
  opacity: 1;
  z-index: 1;
}

.fancybox-custom .fancybox-content {
  background-color: transparent;
}

.fancybox-custom .fancybox-bg {
  background-color: #2d374b;
}

.fancybox-custom .fancybox-button svg {
  margin-bottom: 0;
}

.fancybox-custom .fancybox-progress {
  background-color: #0abf53;
}

.fancybox-blur header,
.fancybox-blur aside,
.fancybox-blur main,
.fancybox-blur footer {
  filter: blur(30px);
}

/*------------------------------------
  Leaflet
------------------------------------*/
.leaflet {
  min-height: 30rem;
  height: 100%;
  z-index: 0;
}

.leaflet-touch .leaflet-control-layers,
.leaflet-touch .leaflet-bar {
  border: none;
}

.leaflet-bar,
.leaflet-popup-content-wrapper,
.leaflet-popup-tip {
  box-shadow: 0rem 0.1875rem 0.375rem rgba(140, 152, 164, 0.25);
}

.leaflet-bar,
.leaflet-popup-content-wrapper {
  border-radius: 0.6rem;
}

.leaflet-popup {
  margin-bottom: 2.5rem;
}

/*------------------------------------
  Swiper
------------------------------------*/
.swiper {
  width: 100%;
  height: 100%;
}

.swiper-preloader {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: white;
  z-index: 1;
}

.swiper-button-next,
.swiper-button-prev {
  display: inline-flex;
  flex-shrink: 0;
  justify-content: center;
  align-items: center;
  color: #677788;
  width: 2.875rem;
  height: 2.875rem;
  background-color: white;
  border: 0.0625rem solid #dce0e5;
  border-radius: 50%;
  transition: all 0.2s ease-in-out;
}
.swiper-button-next:after,
.swiper-button-prev:after {
  width: 1rem;
  height: 1rem;
  font-family: inherit;
  background-repeat: no-repeat;
  background-position: 50%;
  background-size: 100% 100%;
  content: "";
}
.swiper-button-next:hover,
.swiper-button-prev:hover {
  box-shadow: 0rem 0.1875rem 0.3125rem 0rem rgba(140, 152, 164, 0.2);
}
.swiper-button-next.swiper-button-disabled,
.swiper-button-prev.swiper-button-disabled {
  opacity: 0.5;
  box-shadow: none;
}

.swiper-button-next:after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23677788'%3e%3cpath d='M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
}
.swiper-button-next:hover:after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%230abf53'%3e%3cpath d='M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
}

.swiper-button-prev:after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23677788'%3e%3cpath d='M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z'/%3e%3c/svg%3e");
}
.swiper-button-prev:hover:after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%230abf53'%3e%3cpath d='M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z'/%3e%3c/svg%3e");
}

.swiper-static-button-next,
.swiper-static-button-prev {
  position: static;
  left: 0;
  right: 0;
  margin-left: 0.25rem;
  margin-bottom: 0.5rem;
}

.swiper-static-button-prev {
  margin-right: 0.5rem;
}

.swiper-button-next-soft-white,
.swiper-button-prev-soft-white {
  color: white;
  background-color: rgba(255, 255, 255, 0.1);
}
.swiper-button-next-soft-white:hover,
.swiper-button-prev-soft-white:hover {
  background-color: #0abf53;
}

.swiper-button-next-soft-white:after, .swiper-button-next-soft-white:hover:after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='white'%3e%3cpath d='M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
}

.swiper-button-prev-soft-white:after, .swiper-button-prev-soft-white:hover:after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='white'%3e%3cpath d='M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z'/%3e%3c/svg%3e");
}

.swiper-pagination {
  position: static;
  width: 100% !important;
  display: flex;
  justify-content: center;
  margin-top: 2rem;
}

.swiper-pagination.swiper-horizontal > .swiper-pagination-bullets.swiper-pagination-bullets-dynamic,
.swiper-pagination.swiper-pagination-horizontal.swiper-pagination-bullets.swiper-pagination-bullets-dynamic {
  left: 0;
  transform: translateX(0%);
}

.swiper-horizontal > .swiper-pagination-bullets.swiper-pagination-bullets-dynamic {
  left: 0%;
  transform: translateX(0%);
}

.swiper-pagination-bullets.swiper-pagination-bullets-dynamic {
  transform: translateX(0%);
}
.swiper-pagination-bullets .swiper-pagination-bullet {
  margin: 0 0.25rem;
}

.swiper-pagination-bullet {
  position: relative;
  opacity: 1;
  width: 1.5rem;
  height: 1.5rem;
  border: 0.0625rem solid transparent;
  background-color: transparent;
  transition: 0.2s;
}
.swiper-pagination-bullet::before {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 0.25rem;
  height: 0.25rem;
  background-color: #BDC5D1;
  border-radius: 50%;
  transform: translate(-50%, -50%);
  transition: 0.2s;
  content: "";
}
.swiper-pagination-bullet:hover {
  border-color: rgba(10, 191, 83, 0.5);
}
.swiper-pagination-bullet:hover::before {
  background-color: rgba(10, 191, 83, 0.5);
}

.swiper-pagination-bullet-active, .swiper-pagination-bullet-active:hover {
  border-color: #0abf53;
}
.swiper-pagination-bullet-active::before, .swiper-pagination-bullet-active:hover::before {
  background-color: #0abf53;
}

.swiper-pagination-light .swiper-pagination-bullet::before {
  background-color: rgba(255, 255, 255, 0.5);
}
.swiper-pagination-light .swiper-pagination-bullet:hover {
  border-color: white;
}
.swiper-pagination-light .swiper-pagination-bullet:hover::before {
  background-color: rgba(255, 255, 255, 0.5);
}
.swiper-pagination-light .swiper-pagination-bullet-active, .swiper-pagination-light .swiper-pagination-bullet-active:hover {
  border-color: white;
}
.swiper-pagination-light .swiper-pagination-bullet-active::before, .swiper-pagination-light .swiper-pagination-bullet-active:hover::before {
  background-color: white;
}

.swiper-pagination-progress {
  cursor: pointer;
}

.swiper-pagination-progress-body {
  position: relative;
  display: block;
  width: 100%;
  height: 0.25rem;
  background-color: rgba(45, 55, 75, 0.1);
  border-radius: 6.1875rem;
}

.swiper-pagination-progress-body-helper {
  position: absolute;
  top: 0;
  left: 0;
  display: block;
  width: 0;
  height: 100%;
  background-color: #0abf53;
  border-radius: 6.1875rem;
  transition: none;
}

.swiper-slide-thumb-active .swiper-pagination-progress-body-helper {
  transition-property: width;
  transition-timing-function: linear;
  width: 100%;
}

.swiper-pagination-progress-light .swiper-pagination-progress-body {
  background-color: rgba(255, 255, 255, 0.5);
}
.swiper-pagination-progress-light .swiper-pagination-progress-body-helper {
  background-color: white;
}

.swiper-pagination-progressbar {
  background-color: rgba(45, 55, 75, 0.1);
}

.swiper-pagination-progressbar .swiper-pagination-progressbar-fill {
  background-color: #0abf53;
}

.swiper-step-pagination .swiper-wrapper {
  padding-top: 1rem;
}
.swiper-step-pagination .swiper-wrapper::before,
.swiper-step-pagination .swiper-slide::before {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 0.125rem;
  background-color: rgba(45, 55, 75, 0.1);
  content: "";
}
.swiper-step-pagination .swiper-slide {
  cursor: pointer;
}
.swiper-step-pagination .swiper-slide::before {
  top: -1rem;
  opacity: 0;
}
.swiper-step-pagination .swiper-slide.swiper-slide-thumb-active::before {
  background-color: #2d374b;
  opacity: 1;
}
.swiper-step-pagination .swiper-step-pagination-title {
  color: rgba(45, 55, 75, 0.7);
}
.swiper-step-pagination .swiper-slide-thumb-active .swiper-step-pagination-title {
  color: #2d374b;
}

.swiper-step-pagination-light .swiper-wrapper::before,
.swiper-step-pagination-light .swiper-slide::before {
  background-color: rgba(255, 255, 255, 0.2);
}
.swiper-step-pagination-light .swiper-slide.swiper-slide-thumb-active::before {
  background-color: white;
}
.swiper-step-pagination-light .swiper-step-pagination-title {
  color: rgba(255, 255, 255, 0.7);
}
.swiper-step-pagination-light .swiper-slide-thumb-active .swiper-step-pagination-title {
  color: white;
}

.swiper-pagination-fraction {
  display: block;
  letter-spacing: 0.125rem;
}
.swiper-pagination-fraction .swiper-pagination-current {
  font-size: 4rem;
  line-height: 4rem;
}

.swiper-thumbs {
  box-sizing: border-box;
}

.swiper-thumbs .swiper-slide {
  cursor: pointer;
  opacity: 0.4;
}

.swiper-thumbs .swiper-slide-thumb-active {
  opacity: 1;
}

.swiper-equal-height .swiper-wrapper {
  display: flex;
}
.swiper-equal-height .swiper-slide {
  display: flex;
  height: auto;
}

.swiper-pagination-vertical.swiper-pagination-bullets,
.swiper-vertical > .swiper-pagination-bullets {
  position: absolute;
  width: auto !important;
  flex-direction: column;
  justify-content: flex-end;
  margin: 0;
}
.swiper-pagination-vertical.swiper-pagination-bullets .swiper-pagination-bullet,
.swiper-vertical > .swiper-pagination-bullets .swiper-pagination-bullet {
  margin: 0.25rem 0;
}

.swiper-horizontal > .swiper-pagination-middle-y-end {
  position: absolute;
  top: 50%;
  left: auto;
  right: 0;
  bottom: auto;
  transform: translateY(-50%);
}

.swiper-center-mode-end {
  margin-right: calc(-1px - (100vw - 100%) / 2 + 15px) !important;
}

.swiper-step {
  padding-left: 0.3125rem;
}
.swiper-step .swiper-slide {
  cursor: grab;
}
.swiper-step .swiper-step-divider {
  position: relative;
  width: calc(100% + 2rem);
  height: 0.125rem;
  background-color: #0abf53;
  margin-top: 2rem;
  margin-bottom: 3rem;
}
.swiper-step .swiper-step-divider::before {
  position: absolute;
  top: 50%;
  left: 0;
  width: 1.5rem;
  height: 1.5rem;
  background-color: white;
  box-shadow: 0rem 0.1875rem 0.375rem rgba(140, 152, 164, 0.25);
  border-radius: 50%;
  transform: translateY(-50%);
  content: "";
}
.swiper-step .swiper-step-divider::after {
  position: absolute;
  top: 50%;
  left: 0.5rem;
  width: 0.5rem;
  height: 0.5rem;
  background-color: #0abf53;
  border-radius: 50%;
  transform: translateY(-50%);
  content: "";
}

.swiper-thumb-progress {
  width: 110%;
  height: 110%;
  position: absolute;
  top: 50%;
  left: 50%;
  -webkit-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}

.swiper-thumb-progress-avatar {
  position: relative;
  display: block;
  width: 2.875rem;
  height: 2.875rem;
  border: 0.0625rem solid rgba(220, 224, 229, 0.6);
  padding: 0.25rem;
  margin: 0.25rem;
  border-radius: 50%;
}

.swiper-thumb-progress-avatar-img {
  max-width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 50%;
}

.swiper-thumb-progress .swiper-thumb-progress-path {
  opacity: 0;
  fill: transparent;
  stroke: #0abf53;
  stroke-width: 8;
  stroke-dashoffset: 477;
  stroke-dashoffset: 0px;
}

.swiper-thumb-progress .swiper-thumb-progress-path {
  opacity: 0;
  fill: transparent;
  stroke: #0abf53;
  stroke-width: 8;
  stroke-dashoffset: 477;
  stroke-dashoffset: 0px;
}

@keyframes swiperThumbProgressDash {
  from {
    stroke-dasharray: 0 477;
  }
  to {
    stroke-dasharray: 477 477;
  }
}
/*------------------------------------
  File for your custom SCSS style
------------------------------------*/
body, html {
  min-height: 100vh;
}

.navbar, .card {
  box-shadow: 0 0.1875rem 0.5625rem rgba(0, 0, 0, 0);
}

.carousel-indicators > li[data-bs-target]::marker {
  font-size: 0;
}

.card.card-ghost {
  box-shadow: none;
}`),i="https://library.pinegrow.com/pinekit/",e.addResource("assets/vendor/bootstrap-icons/font/bootstrap-icons.css",i+"assets/vendor/bootstrap-icons/font/bootstrap-icons.css"),e.addResource("assets/vendor/bootstrap-icons/font/fonts/bootstrap-icons.woff",i+"assets/vendor/bootstrap-icons/font/fonts/bootstrap-icons.woff"),e.addResource("assets/vendor/bootstrap-icons/font/fonts/bootstrap-icons.woff2",i+"assets/vendor/bootstrap-icons/font/fonts/bootstrap-icons.woff2"),e.addResource("assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js",i+"assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"),(i=new pgParser).assignIds=!1,i.parse(a),n="https://library.pinegrow.com/pinekit/",i.rootNode.goThroughAllUrls(function(t,r,o){if(!crsaIsAbsoluteUrl(t)&&!e.hasFileOrResource(t))try{t=new URL(t,n).toString()}catch(t){}return t},!1,!0),a=i.rootNode.toStringOriginal(!0),e.addPage("index.html",a),e.addHiddenFile("_new.html",a),d.addLesson(e)})});